import sys
import pytest
from src.models.gpt import GPT
from src.train import train
from src.research.team import suite
from src.research import optimizer_study, attention_scale_study, worker

def forbidden(*a, **kw):
    raise AssertionError('Actual model/training/worker execution forbidden in metadata validation')
GPT.__init__ = forbidden
train.run_training = forbidden
suite._launch = forbidden
optimizer_study._launch = forbidden
attention_scale_study._launch = forbidden
worker.main = forbidden
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider',
 'tests/test_attention_scale_study.py','tests/test_attention_scale_predecessor.py','tests/test_attention_scale_report_audit.py']))
