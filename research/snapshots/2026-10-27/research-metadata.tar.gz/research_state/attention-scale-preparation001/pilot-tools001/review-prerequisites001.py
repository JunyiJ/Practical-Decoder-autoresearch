"""Audit saved attention-scale pilot evidence and forecast bounded resources; no training/scoring."""
import argparse,datetime,json,math,subprocess,re,sys,os
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--pilots',type=Path,required=True)
parser.add_argument('--cpu-review',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=Path(__file__).resolve().parent
prior=base/'research_runs/parallel-block-quality-001'
active=json.loads((base/'research_state/active-campaign.json').read_text())
if Path(active['campaign'])!=prior or active['status']!='completed_reviewed' or json.loads((prior/'state.json').read_text())['status']!='completed':
 raise ValueError('Completed reviewed parallel-block predecessor required before CPU checkpoint audit')
sys.path.insert(0,str(folder.parent/'cpu-tools001'))
from bounded_cpu import live_model_commands
live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
if live:raise ValueError('Competing model work: '+str(live))
if args.output.exists() or not args.output.resolve().is_relative_to(base/'research_state'):
 raise ValueError('New review output inside research_state required')
import torch
from omegaconf import OmegaConf
from src.research import attention_scale_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.models.output_bias import POLICY
from src.models.weight_tying import validate_weight_tying_model,POLICY as TYING_POLICY
from src.models.residual_topology import validate_residual_topology_model,POLICY as RESIDUAL_POLICY
from src.models.attention_scale import validate_attention_scale_model,POLICY as SCALE_POLICY
from src.utils.checkpoint import read_checkpoint,load_model_weights

p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
import importlib.util
prior_spec=importlib.util.spec_from_file_location('independent_output_prior',folder/'prior-audit.py')
prior_audit=importlib.util.module_from_spec(prior_spec);prior_spec.loader.exec_module(prior_audit)
prior_review=prior_audit.verify_prior(Path(p['config']['data']['path']).read_bytes(),p['output_bias_prior'])
assert prior_review['vocabulary_size']==65
assert study.BOOTSTRAP.startswith('from src.research.memory_guard import start_memory_guard\nstart_memory_guard()\n')
attention='mha';lr=.01;short_warmup=0;assert p['recipe']['warmup_steps']==0
cpu_path=args.cpu_review;cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
tests=cpu['full_tests'];assert cpu['status']=='cpu_verified' and tests['passed']==tests['collected']==3264 and tests['failed']==0
assert cpu['actual_attention_scale_training_tests_passed']==12 and cpu['actual_attention_scale_geometry_tests_passed']==12 and cpu['attention_scale_metadata_tests_passed']==210
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==6
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
intent=json.loads((args.pilots/'intent.json').read_text())
assert intent['source_commit']==p['git_commit'] and intent['source_sha256']==p['source_sha256']
subprocess.run(['git','merge-base','--is-ancestor',p['git_commit'],intent['published_tip']],cwd=source,check=True)
assert pilot['disk_mb']<1024
assert intent['cpu_review_sha256']==file_digest(cpu_path) and intent['pilot_driver_sha256']==file_digest(folder/'pilot-driver001.py')
assert intent['predecessor_review']==p['predecessor_review'] and intent['resolved_recipe']==p['recipe']
for path,digest in intent['helper_sha256'].items():assert file_digest(Path(path))==digest
assert intent['seed']==9423 and intent['holdout_consumed'] is False
assert intent['hard_limits']==dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024)
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
artifacts=[cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver001.py',folder/'resource-gate.py',folder/'preparation-review001.json',folder/'branch-capture.py',folder/'branch-math-audit.py',folder/'attention-capture.py',folder/'attention-math-audit.py',folder/'test_attention_math.py',folder.parent/'cpu-tools001/bounded_cpu.py',folder/'table-math-audit.py',source/'research/ATTENTION_SCALE_PROTOCOL.md',Path(p['predecessor_review']['path']),folder/'pilot-geometry.py',folder/'prior-audit.py',Path(__file__).resolve()]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
# Preserve earlier failed MPS agreement evidence; only unchanged general averaging
# arithmetic is inherited, not a claim about independent trajectory reproducibility.
for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 current=(source/rel).read_bytes()
 if rel=='src/train/train.py':
  guard=b'    from ..models.output_bias import validate_output_bias_training_data\n    validate_output_bias_training_data(cfg.model, loader, to_absolute_path(cfg.data.path))\n'
  assert current.count(guard)==2;current=current.replace(guard,b'')
 if rel=='src/utils/checkpoint.py':
  attention_guard=b'    from ..models.attention_scale import validate_attention_scale_load\n    validate_attention_scale_load(model, checkpoint)\n'
  assert current.count(attention_guard)==1;current=current.replace(attention_guard,b'',1)
  residual_guard=b'    from ..models.residual_topology import validate_residual_topology_load\n    validate_residual_topology_load(model, checkpoint)\n'
  assert current.count(residual_guard)==1;current=current.replace(residual_guard,b'',1)
  tying_guard=b'    from ..models.weight_tying import validate_weight_tying_load\n    validate_weight_tying_load(model, checkpoint)\n'
  assert current.count(tying_guard)==1;current=current.replace(tying_guard,b'',1)
  bias_guard=b'    from ..models.output_bias import validate_output_bias_load\n    validate_output_bias_load(model, checkpoint)\n'
  assert current.count(bias_guard)==1;current=current.replace(bias_guard,b'',1)
  guard=b'    from ..models.embedding_scale import validate_input_scale_load\n    validate_input_scale_load(model, checkpoint)\n'
  assert current.count(guard)==1
  current=current.replace(guard,b'',1)
  readout_guard=b'    from ..models.readout_norm import validate_readout_norm_load\n    validate_readout_norm_load(model, checkpoint)\n'
  assert current.count(readout_guard)==1
  current=current.replace(readout_guard,b'',1)
 assert current==subprocess.check_output(['git','show','280ea428792d4dd31780123d14846d5302d43227:'+rel],cwd=source)
for rel in ['averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-mps-coupled-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
artifacts.extend([source/'src/models/embedding_scale.py',source/'src/models/readout_norm.py',source/'src/models/output_bias.py',source/'src/models/weight_tying.py',source/'src/models/residual_topology.py',source/'src/models/attention_scale.py',source/'src/research/memory_guard.py'])
checks=[];checkpoint_paths=set();math_checks=[];branch_checks=[];attention_checks=[];torch.set_num_threads(1)
table_kind=p['recipe']['weight_tying_kind'];topology=p['recipe']['residual_topology_kind']
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];bias_kind=p['recipe']['output_bias_kind'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=40,20
 job=dict(family=f,lr=lr,width=w,n_heads=w//32,seed=9423,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,lr),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 if short_warmup:t['lr_schedule']['warmup_steps']=short_warmup
 assert row['attention_family']==attention and row['peak_learning_rate']==lr and row['warmup_steps']==t['lr_schedule'].get('warmup_steps',0)
 assert row['input_embedding_scale']==p['recipe']['input_embedding_scale'] and row['input_width_policy']=='mha4_input_scale'
 norm=p['recipe']['readout_norm_kind']
 assert row['output_bias_kind']==bias_kind and row['output_bias_width_policy']==POLICY and row['output_bias_prior_sha256']==p['output_bias_prior']['prior_sha256']
 assert row['readout_norm_kind']==norm and row['readout_norm_width_policy']=='mha4_readout_norm' and row['readout_norm_epsilon']==1e-5
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 assert raw['runtime']==dict(torch=p['runtime']['packages']['torch'],cpu_threads=req['cpu_threads'],requested_device='mps')
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total
 desired=json.loads(json.dumps(req['config']));desired['model']['vocab_size']=65;assert cp['cfg']==desired
 expected_contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
     optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=desired['model'],
     data_sha256=file_digest(Path(desired['data']['path'])),data_split=dict(train_fraction=.8,val_fraction=.1),
     eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
     training={key:t[key] for key in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==expected_contract
 avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True);names=dict(model.named_parameters())
 # Independently enumerate all named parameter shapes, without deriving them
 # from the model implementation. Strict load separately checks saved buffers.
 import importlib.util
 geometry_spec=importlib.util.spec_from_file_location('output_bias_independent_geometry',folder/'pilot-geometry.py')
 geometry=importlib.util.module_from_spec(geometry_spec);geometry_spec.loader.exec_module(geometry)
 shapes=geometry.parameter_shapes(w,attention,norm,bias_kind,table_kind)
 for i in range(4):
  pre=f'transformer.h.{i}.'
  assert cp['model_state'][pre+'freq_cos'].shape==(128,16)
  assert cp['model_state'][pre+'freq_sin'].shape==(128,16)
 assert cfg.model.input_embedding_scale==model.input_embedding_scale==p['recipe']['input_embedding_scale']
 assert cfg.model.input_width_policy=='mha4_input_scale'
 assert cfg.model.readout_norm_kind==norm and cfg.model.readout_norm_width_policy=='mha4_readout_norm' and cfg.model.readout_norm_epsilon==1e-5
 assert model.readout_norm_signature==(norm,1e-5) and model.transformer.ln_f.eps==1e-5
 assert isinstance(model.transformer.ln_f,torch.nn.RMSNorm if norm=='rms' else torch.nn.LayerNorm)
 cfg.model.readout_norm_kind='rms' if norm!='rms' else 'layer_no_bias'
 try: load_model_weights(model,cp)
 except ValueError: pass
 else: raise AssertionError('Wrong final normalization checkpoint accepted')
 cfg.model.readout_norm_kind=norm
 cfg.model.input_embedding_scale=.5 if p['recipe']['input_embedding_scale']==1. else 1.
 try: load_model_weights(model,cp)
 except ValueError: pass
 else: raise AssertionError('Wrong input-scale checkpoint accepted')
 cfg.model.input_embedding_scale=p['recipe']['input_embedding_scale']
 assert cfg.model.output_bias_kind==bias_kind and cfg.model.output_bias_width_policy==POLICY
 assert desired['model']['output_bias_prior']==p['output_bias_prior']
 assert model.output_bias_signature==(bias_kind,POLICY,p['output_bias_prior']['prior_sha256'])
 cfg.model.output_bias_kind='learned_zero' if bias_kind!='learned_zero' else 'learned_train_unigram'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed output-bias semantics accepted')
 cfg.model.output_bias_kind=bias_kind
 validate_weight_tying_model(model)
 assert model.weight_tying_signature==(table_kind,TYING_POLICY,64)
 assert cfg.model.weight_tying_kind==row['weight_tying_kind']==table_kind
 assert cfg.model.weight_tying_width_policy==row['weight_tying_width_policy']==TYING_POLICY
 assert ('lm_head.weight' in names)==(table_kind!='scaled_tied')
 assert len(list(model.named_parameters(remove_duplicate=False)))==len(names)
 cfg.model.weight_tying_kind='matched_untied' if table_kind!='matched_untied' else 'scaled_tied'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed table-sharing semantics accepted')
 cfg.model.weight_tying_kind=table_kind
 validate_residual_topology_model(model)
 assert model.residual_topology_signature==(topology,RESIDUAL_POLICY)
 assert row['residual_topology_kind']==topology and row['residual_topology_width_policy']==RESIDUAL_POLICY
 assert all(b.ln1 is not b.ln2 and b.residual_topology_kind==topology for b in model.transformer.h)
 cfg.model.residual_topology_kind='serial' if topology!='serial' else 'parallel_separate_norms'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped residual topology accepted')
 cfg.model.residual_topology_kind=topology
 validate_attention_scale_model(model)
 assert model.attention_scale_signature==(study.SCALES[f],SCALE_POLICY)
 assert row['attention_logit_scale']==study.SCALES[f] and row['attention_logit_scale_width_policy']==SCALE_POLICY
 assert all(b.attn.attention_logit_scale==study.SCALES[f] for b in model.transformer.h)
 cfg.model.attention_logit_scale=.5 if study.SCALES[f]!=.5 else 2.
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped attention scale accepted')
 cfg.model.attention_logit_scale=study.SCALES[f]
 assert set(shapes)==set(names)
 assert all(tuple(names[n].shape)==shape for n,shape in shapes.items())
 expected_count=sum(math.prod(shape) for shape in shapes.values())
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 assert model.position_encoding=='rope'
 assert cp['cfg']['model']['attn_type']==attention
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==p['recipe']['weight_decay']
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 for metric in raw['metrics']:
  step=metric['step'];warmup=row['warmup_steps']
  expected_ratio=(.1 if step==39 else .1+.9*step/(warmup-1) if warmup and step<warmup-1
                  else 1. if step<=20 else 1-.9*(step-20)/19)
  assert math.isclose(metric['lr_multiplier'],expected_ratio,rel_tol=0,abs_tol=1e-15)
  assert metric['base_learning_rate']==lr
  assert math.isclose(metric['scheduled_learning_rate'],lr*expected_ratio,rel_tol=0,abs_tol=1e-15)
 seen=set()
 assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   name,=g['parameter_names'];assert name not in seen;seen.add(name)
   matrix=name.startswith('transformer.h.') and names[name].ndim==2;scale=1/math.sqrt(w/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==lr*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'}
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==names[name].shape
 assert seen==set(names)
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved)
 for name,value in saved['model_state'].items():assert torch.equal(value,avg['averages']['200'][name] if name in names else cp['model_state'][name])
 gen=torch.Generator().manual_seed(9423);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
 valgen=torch.Generator().manual_seed(2026);val_length=int(.9*n)-int(.8*n)
 for _ in range(t['eval_iters']):torch.randint(val_length-128,(8,),generator=valgen)
 assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 cache_path=d/'cache-check.pt';assert file_digest(cache_path)==row['cached_evidence_sha256'];artifacts.append(cache_path)
 cache=torch.load(cache_path,map_location='cpu',weights_only=True);finite(cache)
 assert cache['derived_checkpoint_sha256']==item['checkpoint_sha256'] and cache['atol']==1e-4 and cache['rtol']==2e-5
 assert cache['full_logits'].shape==cache['cached_logits'].shape==(2,11,65)
 assert torch.equal(cache['tokens'],torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9423)))
 torch.testing.assert_close(cache['full_logits'],cache['cached_logits'],atol=1e-4,rtol=2e-5)
 assert math.isclose((cache['full_logits']-cache['cached_logits']).abs().max().item(),row['cached_full_max_abs_error'],abs_tol=0,rel_tol=0)
 math_path=d/'table-math-check.pt';assert file_digest(math_path)==row['table_math_sha256'];artifacts.append(math_path)
 evidence=torch.load(math_path,map_location='cpu',weights_only=True);finite(evidence)
 assert evidence['derived_checkpoint_sha256']==item['checkpoint_sha256'] and evidence['atol']==1e-4 and evidence['rtol']==2e-5
 assert evidence['tying_kind']==table_kind and evidence['width']==w
 assert torch.equal(evidence['tokens'],cache['tokens']) and torch.equal(evidence['targets'],(cache['tokens']+1)%65)
 # Exact binding prevents self-consistent algebra from validating unrelated tables.
 assert torch.equal(evidence['embedding'].double(),saved['model_state']['transformer.wte.weight'].double())
 expected_readout=saved['model_state']['transformer.wte.weight' if table_kind=='scaled_tied' else 'lm_head.weight'].double()
 assert torch.equal(evidence['readout'].double(),expected_readout)
 bias=torch.zeros(65,dtype=torch.float64) if bias_kind=='none' else saved['model_state']['output_bias'].double()
 assert torch.equal(evidence['bias'],bias) and (evidence['bias_gradient'] is None)==(bias_kind=='none')
 math_spec=importlib.util.spec_from_file_location('independent_table_math',folder/'table-math-audit.py')
 math_audit=importlib.util.module_from_spec(math_spec);math_spec.loader.exec_module(math_audit)
 arrays={k:v.numpy() if isinstance(v,torch.Tensor) else v for k,v in evidence.items()}
 math_checks.append(dict(width=w,family=f,**math_audit.verify(arrays)))
 branch_path=d/'branch-math-check.pt';assert file_digest(branch_path)==row['branch_math_sha256'];artifacts.append(branch_path)
 branch=torch.load(branch_path,map_location='cpu',weights_only=True);finite(branch)
 branch_spec=importlib.util.spec_from_file_location('independent_residual_branch_math',folder/'branch-math-audit.py')
 branch_audit=importlib.util.module_from_spec(branch_spec);branch_spec.loader.exec_module(branch_audit)
 def numpy_tree(value):
  if isinstance(value,torch.Tensor):return value.numpy()
  if isinstance(value,dict):return {k:numpy_tree(v) for k,v in value.items()}
  if isinstance(value,list):return [numpy_tree(v) for v in value]
  return value
 branch=numpy_tree(branch);state_arrays=numpy_tree(saved['model_state'])
 binding=branch_audit.bind_checkpoint(branch,state_arrays,item['checkpoint_sha256'],topology,w)
 branch_result=branch_audit.verify(branch);linkage=branch_audit.link_graph(branch,arrays,state_arrays,norm,p['recipe']['input_embedding_scale'])
 assert max(branch_result['errors'].values())==row['branch_math_max_error']
 branch_checks.append(dict(width=w,family=f,binding=binding,linkage=linkage,**branch_result))
 attention_path=d/'attention-math-check.pt';assert file_digest(attention_path)==row['attention_math_sha256'];artifacts.append(attention_path)
 attention_evidence=torch.load(attention_path,map_location='cpu',weights_only=True);finite(attention_evidence);attention_evidence=numpy_tree(attention_evidence)
 attn_spec=importlib.util.spec_from_file_location('independent_masked_attention',folder/'attention-math-audit.py')
 attn_audit=importlib.util.module_from_spec(attn_spec);attn_spec.loader.exec_module(attn_audit)
 attn_binding=attn_audit.bind_checkpoint(attention_evidence,state_arrays,item['checkpoint_sha256'],study.SCALES[f],w)
 attn_link=attn_audit.link_graph(attention_evidence,branch);attn_result=attn_audit.verify(attention_evidence)
 assert max(attn_result['errors'].values())==row['attention_math_max_error']
 attention_checks.append(dict(width=w,family=f,binding=attn_binding,linkage=attn_link,**attn_result))
 for checkpoint_path in (Path(checked['checkpoint']).resolve(),Path(item['checkpoint']).resolve()):
  assert checkpoint_path not in checkpoint_paths;checkpoint_paths.add(checkpoint_path)
 expected_cache_bytes=4*2*2*128*w*4
 assert row['actual_cache_bytes']==expected_cache_bytes and row['cache_batch_size']==2
 assert 0<row['training_seconds']<=row['wall_seconds']<240 and row['sampled_peak_rss_mb']<4096 and row['current_driver_mb']<6144
 assert row['driver_allocation_is_not_peak'] is True
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.extend([d/'review.json',Path(checked['checkpoint']),Path(item['checkpoint'])]);checks.append(row)
# Independently reconstruct the worst-case42-run bound, then compare the separately
# synthetic-tested resource function; never treat these forecasts as measurements.
seconds=0.;storage=0.;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=(12 if f=='baseline' else 9) if w==64 else (6 if f=='baseline' else 3)
 estimate=1.5*(row['training_seconds']*75+row['wall_seconds']-row['training_seconds'])
 size=(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)*1.5
 seconds+=count*estimate;storage+=count*size
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate,artifact_mb_per_trajectory_with_margin=size/1024**2,within_trial_limit=estimate<2400))
assert sum(x['trajectories'] for x in proxies)==42
import importlib.util
spec=importlib.util.spec_from_file_location('output_bias_resource_gate',folder/'resource-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
resource=gate.forecast(checks,p['recipe']['input_embedding_scale'])
assert resource['trial_proxies']==proxies and resource['hours']==seconds/3600 and resource['total_mb_with_margin']==storage/1024**2
if resource['status']!='feasible':
 rejection=args.output.with_name(args.output.stem+'-resource-infeasible.json');assert not rejection.exists()
 rejection.write_text(json.dumps(dict(status='infeasible_no_launch',source_commit=p['git_commit'],source_sha256=p['source_sha256'],resource_proxy=resource,pilot_path=str(pilot_path),pilot_sha256=file_digest(pilot_path),action='Preserve all pilots; no automatic retry or cap extension; review another algorithm or a distinct implementation change.'),indent=2)+'\n')
 raise ValueError('Attention-scale resource forecast exceeds frozen limits; no research launch')
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=sorted(set((base/'research_runs').glob('*/plan.json'))|set((base/'research_state').glob('*plan*.json')))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=resource,independent_training_prior=prior_review,independent_table_math=math_checks,independent_branch_math=branch_checks,independent_attention_math=attention_checks,
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Full3264 collected CPU suite,210 metadata cases,12 geometry and12 actual trainer/resume cases passed',
 'Six serial MPS baseline/half/double width64/25640-update jobs; twelve full validation panels, strict finite CPU loads and exact raw/H200 derivation',
 'Training-only prior counts/formula/hashes independently rebuilt; saved MPS lookup/readout gradient roles independently checked with NumPy and exact tables bound to derived checkpoints; every MHA/FFN/head/norm/bias parameter shape independently enumerated; all optimizer roles, states and width factors verified',
 'Every saved block weight bound to derived checkpoint; independent NumPy residual routing, RMS normalizer/SwiGLU forward and VJP; all four graph edges linked to table/readout evidence',
 'Sixteen attention weights and eight RoPE buffers bound to each derived checkpoint; independent NumPy post-RoPE QK/sqrt32 scaling, causal masking, exp/sum softmax and QKV/output input and parameter VJP, linked to all four captured residual blocks',
 'Saved cached/full logits and cache-byte algebra checked; no latency or peak-memory claim',
 'Exact private train and reset-validation RNG, untouched test RNG; warmup/cooldown and H200 counters; no historical training/evaluation rerun',
 'Final reviewed parallel-block decision resolves residual topology/table/bias/norm/input/LR and common schedule; upper-grid LR .01 pilots and prospective36/42-trajectory protocol, fresh seeds and exact prospective reference aliases'],
 limitations=['Short real-training-corpus correctness pilots excluded from quality findings','Resource forecasts are estimates; watchdog and hard caps stillapply','Current driver allocation is not peak memory','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness relies on separately tested frozen implementation','No optimalLR/muP transfer, seed-population inference or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=args.output;assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
