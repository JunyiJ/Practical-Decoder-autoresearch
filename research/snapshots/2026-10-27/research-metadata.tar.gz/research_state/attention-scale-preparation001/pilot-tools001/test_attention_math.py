import unittest,importlib.util,copy
from pathlib import Path
import numpy as np
spec=importlib.util.spec_from_file_location('math_audit',Path(__file__).with_name('attention-math-audit.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Checks(unittest.TestCase):
 def fixture(self,d,c):
  rng=np.random.default_rng(9423);x=rng.normal(size=(1,4,d))*.2;wq=rng.normal(size=(3*d,d))*.03;bq=rng.normal(size=3*d)*.02;wo=rng.normal(size=(d,d))*.03;bo=rng.normal(size=d)*.02;angles=np.arange(4)[:,None]*10000.**(-np.arange(0,32,2)/32.);co=np.cos(angles);si=np.sin(angles);g=rng.normal(size=x.shape)*.1
  return [x,wq,bq,wo,bo,co,si,c,g]
 def test_directional_gradients_and_causality(self):
  rng=np.random.default_rng(9477)
  for d in (64,256):
   for c in (1.,.5,2.):
    a=self.fixture(d,c);r=m.forward_vjp(*a)
    for j,key in enumerate(['input_gradient','qkv_weight_gradient','qkv_bias_gradient','out_weight_gradient','out_bias_gradient']):
     v=rng.normal(size=a[j].shape);v/=np.linalg.norm(v);eps=1e-5;plus=list(a);minus=list(a);plus[j]=a[j]+eps*v;minus[j]=a[j]-eps*v
     actual=np.sum((m.forward_vjp(*plus)['output']-m.forward_vjp(*minus)['output'])*a[-1])/(2*eps);expected=np.sum(r[key]*v)
     np.testing.assert_allclose(actual,expected,atol=2e-9,rtol=2e-6)
    changed=list(a);changed[0]=a[0].copy();changed[0][:,1:]+=4
    np.testing.assert_array_equal(m.forward_vjp(*changed)['output'][:,0],r['output'][:,0])
 def test_checkpoint_graph_binding_and_corruption(self):
  for d in (64,256):
   for c in (1.,.5,2.):
    a=self.fixture(d,c);r=m.forward_vjp(*a);rows=[];state={};branch=[]
    for i in range(4):
     row=dict(index=i,input=a[0].copy(),qkv_weight=a[1].copy(),qkv_bias=a[2].copy(),out_weight=a[3].copy(),out_bias=a[4].copy(),cos=a[5].copy(),sin=a[6].copy(),output_gradient=a[8].copy(),**{k:v.copy() for k,v in r.items()});rows.append(row)
     for k,n in [('qkv_weight','attn.qkv.weight'),('qkv_bias','attn.qkv.bias'),('out_weight','attn.out.weight'),('out_bias','attn.out.bias'),('cos','freq_cos'),('sin','freq_sin')]:state[f'transformer.h.{i}.{n}']=row[k].copy()
     branch.append(dict(index=i,ln1_output=row['input'].copy(),ln1_gradient=row['input_gradient'].copy(),attention=row['output'].copy(),attention_gradient=row['output_gradient'].copy()))
    p=dict(atol=1e-4,rtol=2e-5,width=d,scale=c,derived_checkpoint_sha256='a'*64,blocks=rows);bp=dict(width=d,derived_checkpoint_sha256='a'*64,blocks=branch)
    m.verify(p);m.bind_checkpoint(p,state,'a'*64,c,d);m.link_graph(p,bp)
    for key in ['qkv_weight','qkv_bias','out_weight','out_bias','cos','sin']:
     q=copy.deepcopy(p);q['blocks'][0][key].flat[0]+=.01
     with self.assertRaises(AssertionError):m.bind_checkpoint(q,state,'a'*64,c,d)
    for key in ['input','input_gradient','output','output_gradient']:
     q=copy.deepcopy(p);q['blocks'][0][key].flat[0]+=.1
     with self.assertRaises(AssertionError):m.link_graph(q,bp)
    for key in r:
     q=copy.deepcopy(p);q['blocks'][0][key].flat[0]+=.1
     with self.assertRaises(AssertionError):m.verify(q)
    q=copy.deepcopy(p);q['scale']=.5 if c!=.5 else 2.
    with self.assertRaises(AssertionError):m.bind_checkpoint(q,state,'a'*64,c,d)
if __name__=='__main__':unittest.main(verbosity=2)
