"""Independent NumPy masked MHA forward/VJP for a saved realized graph.

No model imports, tensors, training or corpus scoring. The caller must bind
weights and RoPE buffers to the derived checkpoint and link this graph to the
captured block graph. Pilot evidence is correctness evidence, never quality.
"""
import numpy as np

def rotate(x,cos,sin,inverse=False):
    cos=cos[None,None,:,:];sin=sin[None,None,:,:]*(-1 if inverse else 1)
    a=x[...,0::2];b=x[...,1::2]
    y=np.empty_like(x);y[...,0::2]=a*cos-b*sin;y[...,1::2]=a*sin+b*cos
    return y

def forward_vjp(x,wq,bq,wo,bo,cos,sin,scale,g):
    b,t,d=x.shape;h=d//32
    assert d in (64,256) and scale in (1.,.5,2.) and t>0
    assert wq.shape==(3*d,d) and bq.shape==(3*d,) and wo.shape==(d,d) and bo.shape==(d,)
    assert cos.shape==sin.shape==(t,16) and g.shape==x.shape
    qkv=x@wq.T+bq
    q,k,v=[z.reshape(b,t,h,32).transpose(0,2,1,3) for z in np.split(qkv,3,axis=-1)]
    qr=rotate(q,cos,sin);kr=rotate(k,cos,sin)
    logits=(qr@kr.swapaxes(-1,-2))/np.sqrt(32)*scale
    mask=np.arange(t)[None,:]<=np.arange(t)[:,None]
    logits=np.where(mask,logits,-np.inf)
    exp=np.exp(logits-np.max(logits,axis=-1,keepdims=True));p=exp/exp.sum(axis=-1,keepdims=True)
    heads=p@v;y=heads.transpose(0,2,1,3).reshape(b,t,d)
    out=y@wo.T+bo
    dy=(g@wo).reshape(b,t,h,32).transpose(0,2,1,3)
    dp=dy@v.swapaxes(-1,-2);dv=p.swapaxes(-1,-2)@dy
    dl=p*(dp-(dp*p).sum(axis=-1,keepdims=True));dl=np.where(mask,dl,0.)
    dq=rotate((dl@kr)*(scale/np.sqrt(32)),cos,sin,True)
    dk=rotate((dl.swapaxes(-1,-2)@qr)*(scale/np.sqrt(32)),cos,sin,True)
    dqkv=np.concatenate([z.transpose(0,2,1,3).reshape(b,t,d) for z in (dq,dk,dv)],axis=-1)
    return dict(output=out,input_gradient=dqkv@wq,
        qkv_weight_gradient=np.einsum('bti,btj->ij',dqkv,x),qkv_bias_gradient=dqkv.sum((0,1)),
        out_weight_gradient=np.einsum('bti,btj->ij',g,y),out_bias_gradient=g.sum((0,1)))

def verify(p):
    assert p['atol']==1e-4 and p['rtol']==2e-5
    assert p['width'] in (64,256) and p['scale'] in (1.,.5,2.) and len(p['blocks'])==4
    errors={}
    for i,row in enumerate(p['blocks']):
        assert row['index']==i
        def arr(k):
            a=np.asarray(row[k],dtype=np.float64);assert np.isfinite(a).all(),k;return a
        x=arr('input');g=arr('output_gradient');assert x.shape[-1]==p['width']
        expected=forward_vjp(x,arr('qkv_weight'),arr('qkv_bias'),arr('out_weight'),arr('out_bias'),arr('cos'),arr('sin'),p['scale'],g)
        for key,value in expected.items():
            actual=arr(key);assert actual.shape==value.shape
            np.testing.assert_allclose(actual,value,atol=1e-4,rtol=2e-5,err_msg=f'{i}:{key}')
            errors[f'{i}:{key}']=float(np.max(np.abs(actual-value)))
        t=x.shape[1];angles=np.arange(t)[:,None]*10000.**(-np.arange(0,32,2)/32.)
        np.testing.assert_allclose(arr('cos'),np.cos(angles),atol=1e-6,rtol=1e-6)
        np.testing.assert_allclose(arr('sin'),np.sin(angles),atol=1e-6,rtol=1e-6)
    return dict(status='verified',errors=errors,scope='Checkpoint-bound post-RoPE fixed-scale causal exp/sum attention and complete QKV/output input/parameter VJP; one saved realized graph, not trajectory reconstruction')

def bind_checkpoint(p,state,expected_sha,scale,width):
    assert p['derived_checkpoint_sha256']==expected_sha and p['scale']==scale and p['width']==width
    assert len(p['blocks'])==4
    for i,row in enumerate(p['blocks']):
        assert row['index']==i
        for key,name in [('qkv_weight','attn.qkv.weight'),('qkv_bias','attn.qkv.bias'),('out_weight','attn.out.weight'),('out_bias','attn.out.bias')]:
            assert np.array_equal(np.asarray(row[key]),np.asarray(state[f'transformer.h.{i}.{name}'])),(i,key)
        t=np.asarray(row['input']).shape[1]
        for key,name in [('cos','freq_cos'),('sin','freq_sin')]:
            assert np.array_equal(np.asarray(row[key]),np.asarray(state[f'transformer.h.{i}.{name}'])[:t]),(i,key)
    return dict(status='bound',weights=16,rope_buffers=8)

def link_graph(p,branch):
    assert p['derived_checkpoint_sha256']==branch['derived_checkpoint_sha256'] and p['width']==branch['width']
    assert len(p['blocks'])==len(branch['blocks'])==4
    for i,(a,b) in enumerate(zip(p['blocks'],branch['blocks'])):
        assert a['index']==b['index']==i
        for lhs,rhs in [('input','ln1_output'),('input_gradient','ln1_gradient'),('output','attention'),('output_gradient','attention_gradient')]:
            x=np.asarray(a[lhs]);y=np.asarray(b[rhs]);assert x.shape==y.shape
            np.testing.assert_allclose(x,y,atol=1e-4,rtol=2e-5,err_msg=f'block{i}:{lhs}')
    return dict(status='linked',edges=16)
