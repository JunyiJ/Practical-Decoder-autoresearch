"""Six serial attention-scale MPS pilots; final parallel-block review and full CPU suite required."""
import argparse,json,math,os,re,subprocess,time,threading,sys,importlib.util,shutil
from pathlib import Path


def post_worker_watchdog(output, jobdir, remaining, completed_jobs):
    """Bound native MPS checks after the separately bounded worker has exited."""
    if not math.isfinite(remaining) or remaining<=0:
        raise TimeoutError('Pilot budget exhausted before post-worker correctness checks')
    def expired():
        from src.research.runner import atomic_json
        try:
            atomic_json(Path(output)/'failure.json',dict(error='Post-worker correctness wall-time limit reached',
                phase='post_worker_correctness',job=str(jobdir),completed_jobs=completed_jobs,no_automatic_retry=True))
        finally:
            os._exit(88)
    timer=threading.Timer(remaining,expired);timer.daemon=True;timer.start()
    return timer


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-pilots',action='store_true');parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-review',type=Path,required=True);args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):raise ValueError('Unset fallback')
    base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();prior=base/'research_runs/parallel-block-quality-001'
    active=json.loads((base/'research_state/active-campaign.json').read_text())
    if Path(active['campaign'])!=prior or active['status']!='completed_reviewed':raise ValueError('Completed reviewed parallel-block predecessor required')
    if json.loads((prior/'state.json').read_text())['status']!='completed':raise ValueError('Predecessor still active')
    sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'cpu-tools001'))
    from bounded_cpu import live_model_commands
    live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
    if live:raise ValueError('Competing model work: '+str(live))
    if shutil.disk_usage(base).free<10*1024**3:raise ValueError('At least10GiB free disk required')
    import torch
    from omegaconf import OmegaConf
    from src.models.gpt import GPT
    from src.attention.cache import KVCache
    from src.utils.checkpoint import read_checkpoint,load_model_weights
    from src.train.lr_schedule import multiplier
    from src.research import attention_scale_study as study
    from src.models.residual_topology import validate_residual_topology_model, POLICY as RESIDUAL_POLICY
    from src.models.attention_scale import validate_attention_scale_model, POLICY as SCALE_POLICY
    from src.models.embedding_scale import input_scale_contract
    from src.models.readout_norm import readout_norm_contract
    from src.models.weight_tying import validate_weight_tying_model, POLICY as TYING_POLICY
    from src.models.output_bias import output_bias_contract,build_training_prior,POLICY
    from src.research.averaging_eval import validate_derivation
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest,_request,_launch
    from src.research.runner import atomic_json,session_lock,validate_result,disk_mb
    torch.set_num_threads(1)
    sha=source_digest(source);driver_sha=file_digest(Path(__file__).resolve());cpu=json.loads(args.cpu_review.read_text());tests=cpu['full_tests']
    if (cpu['status']!='cpu_verified' or cpu['source_sha256']!=sha or tests['passed']!=tests['collected']
            or tests['collected']!=3264 or tests['failed']!=0 or cpu['actual_attention_scale_training_tests_passed']!=12
            or cpu['actual_attention_scale_geometry_tests_passed']!=12 or cpu['attention_scale_metadata_tests_passed']!=210):
        raise ValueError('Complete matching full CPU suite, twenty-four actual attention-scale geometry/trainer/resume cases and210 metadata tests required')
    for a in cpu['artifacts']:
        if file_digest(Path(a['path']))!=a['sha256']:raise ValueError('CPU evidence changed')
    if subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise ValueError('Dirty source')
    p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
    published_tip=subprocess.check_output(['git','rev-parse','origin/main'],cwd=source,text=True).strip()
    subprocess.run(['git','merge-base','--is-ancestor',p['git_commit'],published_tip],cwd=source,check=True)
    assert study.BOOTSTRAP.startswith('from src.research.memory_guard import start_memory_guard\nstart_memory_guard()\n')
    inherited_bias=p['recipe']['output_bias_kind'];table_kind=p['recipe']['weight_tying_kind'];topology=p['recipe']['residual_topology_kind']
    def load_helper(name):
        path=Path(__file__).with_name(name+'.py');spec=importlib.util.spec_from_file_location(name.replace('-','_'),path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
    branch_capture=load_helper('branch-capture');branch_audit=load_helper('branch-math-audit')
    attn_capture=load_helper('attention-capture');attn_audit=load_helper('attention-math-audit')
    attention='mha';lr=.01;short_warmup=0;assert p['recipe']['warmup_steps']==0
    helper_paths=[Path(__file__).with_name(n) for n in ('branch-capture.py','branch-math-audit.py','table-math-audit.py','resource-gate.py','attention-capture.py','attention-math-audit.py')]
    helper_paths.append(Path(__file__).resolve().parent.parent/'cpu-tools001/bounded_cpu.py')
    helper_hashes={str(path.resolve()):file_digest(path) for path in helper_paths}
    out=args.output.resolve();assert out.is_relative_to(base/'research_state');out.mkdir(exist_ok=False)
    atomic_json(out/'intent.json',dict(source_commit=p['git_commit'],source_sha256=sha,cpu_review_sha256=file_digest(args.cpu_review),pilot_driver_sha256=driver_sha,
        predecessor_review=p['predecessor_review'],resolved_recipe=p['recipe'],seed=9423,helper_sha256=helper_hashes,published_tip=published_tip,
        purpose='Shortened attention-scale upper-grid-LR train/reload/raw+H200 coverage, optimizer state and cached/full checks; excluded from research',
        hard_limits=dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024),holdout_consumed=False))
    began=time.monotonic();rows=[]
    def finite(x):
        if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
        elif isinstance(x,dict):
            for v in x.values():finite(v)
        elif isinstance(x,(list,tuple)):
            for v in x:finite(v)
        elif isinstance(x,float):assert math.isfinite(x)
    post_timer=None
    with session_lock(out) as fd:
        try:
            for w in (64,256):
                for f in study.FAMILIES:
                    assert source_digest(source)==sha and file_digest(Path(__file__).resolve())==driver_sha
                    assert all(file_digest(Path(path))==digest for path,digest in helper_hashes.items())
                    d=out/f'w{w}_{f}';d.mkdir();job=dict(family=f,lr=lr,width=w,n_heads=w//32,seed=9423,stage='local',arm='candidate',trial_id=d.name)
                    req=_request(study.suite_spec(p,f,lr),job,d);t=req['config']['training']
                    total,start=40,20
                    t.update(max_iters=total,eval_every=10,eval_iters=2)
                    t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
                    if short_warmup:t['lr_schedule']['warmup_steps']=short_warmup
                    atomic_json(d/'request.json',req);started=time.monotonic()
                    allowance=min(240,1800-(started-began));assert allowance>0
                    status,error=_launch(d/'request.json',out,allowance,1024,fd,root=source,bootstrap=study.BOOTSTRAP)
                    if status!='completed':raise RuntimeError((status,error))
                    post_timer=post_worker_watchdog(out,d,min(240-(time.monotonic()-started),1800-(time.monotonic()-began)),len(rows))
                    raw=json.loads((d/'result.json').read_text());checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
                    extra=study.adapter(p,raw,checked,req,d);cp=read_checkpoint(checked['checkpoint']);finite(cp)
                    assert cp['step']==total and raw['completed_steps']==total
                    wanted=json.loads(json.dumps(req['config']));wanted['model']['vocab_size']=65;assert cp['cfg']==wanted
                    cfg=OmegaConf.create(cp['cfg'])
                    with torch.random.fork_rng(devices=[]):
                        model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
                    names=dict(model.named_parameters());state=cp['model_state']
                    assert cp['cfg']['model']['attn_type']==attention and len(model.transformer.h)==4
                    expected_norm=p['recipe']['readout_norm_kind']
                    expected_count=132*w+4*(4*w*w+6*w+3*w*(21*w//8))-(0 if expected_norm=='layer_affine' else w)+(0 if inherited_bias=='none' else 65)-(65*w if table_kind=='scaled_tied' else 0)
                    assert model.position_encoding=='rope'
                    assert input_scale_contract(cfg.model)==dict(input_width_policy='mha4_input_scale',input_embedding_scale=p['recipe']['input_embedding_scale'])
                    assert model.input_embedding_scale==p['recipe']['input_embedding_scale']
                    assert readout_norm_contract(cfg.model)==dict(readout_norm_kind=expected_norm,readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5)
                    assert model.readout_norm_signature==(expected_norm,1e-5)
                    assert ('transformer.ln_f.bias' in names)==(expected_norm=='layer_affine')
                    assert ('output_bias' in names)==(inherited_bias!='none')
                    validate_weight_tying_model(model)
                    assert model.weight_tying_signature==(table_kind,TYING_POLICY,64)
                    assert ('lm_head.weight' in names)==(table_kind!='scaled_tied')
                    bound=output_bias_contract(cfg.model)
                    assert bound==dict(output_bias_kind=inherited_bias,output_bias_width_policy=POLICY,output_bias_prior=p['output_bias_prior'])
                    assert build_training_prior(Path(req['config']['data']['path']).read_bytes(),.8,.1)==p['output_bias_prior']
                    original_kind=cfg.model.output_bias_kind
                    cfg.model.output_bias_kind='learned_zero' if inherited_bias!='learned_zero' else 'learned_train_unigram'
                    try: load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong output-bias semantic checkpoint accepted')
                    cfg.model.output_bias_kind=original_kind
                    original_tying=cfg.model.weight_tying_kind
                    cfg.model.weight_tying_kind='matched_untied' if table_kind!='matched_untied' else 'scaled_tied'
                    try: load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong sharing checkpoint accepted')
                    cfg.model.weight_tying_kind=original_tying
                    validate_residual_topology_model(model)
                    assert model.residual_topology_signature==(topology,RESIDUAL_POLICY)
                    assert all(block.ln1 is not block.ln2 for block in model.transformer.h)
                    cfg.model.residual_topology_kind='serial' if topology!='serial' else 'parallel_separate_norms'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped residual topology accepted')
                    cfg.model.residual_topology_kind=topology
                    validate_attention_scale_model(model)
                    assert model.attention_scale_signature==(study.SCALES[f],SCALE_POLICY)
                    cfg.model.attention_logit_scale=.5 if study.SCALES[f]!=.5 else 2.
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped attention scale accepted')
                    cfg.model.attention_logit_scale=study.SCALES[f]
                    original_scale=cfg.model.input_embedding_scale
                    cfg.model.input_embedding_scale=.5 if original_scale==1. else 1.
                    try:
                        load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong input-scale checkpoint accepted')
                    cfg.model.input_embedding_scale=original_scale
                    assert sum(v.numel() for v in model.parameters())==expected_count
                    assert not any('.mlp.hidden_norm.' in n for n in names)
                    avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
                    gen=torch.Generator().manual_seed(9423);text=Path(req['config']['data']['path']).read_text()
                    for _ in range(total):torch.randint(int(.8*len(text))-512,(2,),generator=gen)
                    assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
                    assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
                    valgen=torch.Generator().manual_seed(2026);val_length=int(.9*len(text))-int(.8*len(text))
                    for _ in range(t['eval_iters']):torch.randint(val_length-128,(8,),generator=valgen)
                    assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
                    assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
                    for m in raw['metrics']:assert m['lr_multiplier']==multiplier(t['lr_schedule'],m['step'])
                    assert raw['metrics'][-1]['tokens_processed']==1024*total and abs(raw['metrics'][-1]['lr_multiplier']-.1)<1e-12
                    assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']==t['weight_decay']
                    seen=set()
                    for opt in cp['optimizer_state']['optimizers']:
                        for g in opt['param_groups']:
                            assert g['weight_decay']==0.
                            name,=g['parameter_names'];assert name not in seen;seen.add(name);slot=opt['state'][g['params'][0]]
                            matrix=name.startswith('transformer.h.') and names[name].ndim==2
                            assert g['width_lr_scale']==(1/math.sqrt(w/64) if matrix else 1.)
                            assert g['lr']==lr*g['width_lr_scale']*.1
                            if matrix:
                                assert set(slot)=={'momentum_buffer'} and torch.count_nonzero(slot['momentum_buffer'])>0
                            else:
                                assert slot['step'].item()==total and set(slot)=={'step','exp_avg','exp_avg_sq'}
                                assert torch.count_nonzero(slot['exp_avg_sq'])>0
                            for key,value in slot.items():
                                assert torch.isfinite(value).all()
                                if key!='step':assert value.shape==names[name].shape
                    assert seen==set(names)
                    item=extra['averaged_outputs']['200'];derived=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
                    assert 'optimizer_state' not in derived and 'training_state' not in derived
                    load_model_weights(model,derived);finite(derived)
                    assert extra['coverage']['128']['target_count']==item['coverage']['evaluations']['128']['target_count']==111538
                    # Serial saved-weight inference only, after the training worker exited.
                    model=model.to('mps').eval();idx=torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9423)).to('mps')
                    with torch.no_grad():
                        full=model(idx)[0]
                        caches=[KVCache(cfg,'mps',batch_size=2) for _ in range(4)]
                        parts=[];position=0
                        for count in (5,3,3):
                            parts.append(model(idx[:,position:position+count],cache=caches,start_pos=position)[0]);position+=count
                        cached=torch.cat(parts,1);error=(full-cached).abs().max().item()
                        cache_bytes=sum(v.numel()*v.element_size() for c in caches for v in c.buffers())
                        expected_cache_bytes=4*2*2*128*w*4
                        assert cache_bytes==expected_cache_bytes
                        torch.testing.assert_close(full,cached,atol=1e-4,rtol=2e-5)
                        cache_evidence=dict(tokens=idx.cpu(),full_logits=full.cpu(),cached_logits=cached.cpu(),
                            derived_checkpoint_sha256=item['checkpoint_sha256'],atol=1e-4,rtol=2e-5)
                        torch.save(cache_evidence,d/'cache-check.pt')
                    # Save independent lookup/readout gradient roles from one realized MPS graph.
                    hidden=[];lookup=[]
                    def capture_hidden(module, inputs, output):
                        output.retain_grad();hidden.append(output)
                    def capture_lookup(module, inputs, output):
                        output.retain_grad();lookup.append(output)
                    hooks=[model.transformer.ln_f.register_forward_hook(capture_hidden),model.transformer.wte.register_forward_hook(capture_lookup)]
                    branch_tensors,branch_hooks=branch_capture.install(model)
                    attn_tensors,attn_hooks=attn_capture.install(model)
                    target=(idx+1)%65;model.zero_grad(set_to_none=True)
                    logits,loss=model(idx,target);loss.backward()
                    for hook in hooks+branch_hooks+attn_hooks:hook.remove()
                    branch_evidence=branch_capture.export(model,branch_tensors,item['checkpoint_sha256'])
                    branch_review=branch_audit.verify(branch_evidence)
                    torch.save(branch_evidence,d/'branch-math-check.pt')
                    attn_evidence=attn_capture.export(model,attn_tensors,item['checkpoint_sha256'])
                    attn_audit.bind_checkpoint(attn_evidence,derived['model_state'],item['checkpoint_sha256'],study.SCALES[f],w)
                    attn_audit.link_graph(attn_evidence,branch_evidence)
                    attn_review=attn_audit.verify(attn_evidence)
                    torch.save(attn_evidence,d/'attention-math-check.pt')
                    coefficient=(1. if table_kind=='legacy_untied' else 1/math.sqrt(192))/(w/64)
                    table=model.transformer.wte.weight
                    readout=table if table_kind=='scaled_tied' else model.lm_head.weight
                    h=hidden[0].detach().cpu().double();q=readout.detach().cpu().double()
                    bias=torch.zeros(65,dtype=torch.float64) if inherited_bias=='none' else model.output_bias.detach().cpu().double()
                    expected_logits=torch.einsum('btd,vd->btv',h,q)*coefficient+bias
                    torch.testing.assert_close(logits.detach().cpu().double(),expected_logits,atol=1e-4,rtol=2e-5)
                    ce_gradient=(torch.softmax(logits.detach().cpu().double(),-1)-torch.nn.functional.one_hot(target.cpu(),65))/target.numel()
                    expected_hidden=torch.einsum('btv,vd->btd',ce_gradient,q)*coefficient
                    projection_gradient=torch.einsum('btv,btd->vd',ce_gradient,h)*coefficient
                    lookup_gradient=torch.zeros_like(q);lookup_gradient.index_add_(0,idx.cpu().reshape(-1),lookup[0].grad.detach().cpu().double().reshape(-1,w))
                    expected_table=lookup_gradient+projection_gradient if table_kind=='scaled_tied' else lookup_gradient
                    torch.testing.assert_close(hidden[0].grad.detach().cpu().double(),expected_hidden,atol=1e-4,rtol=2e-5)
                    torch.testing.assert_close(table.grad.detach().cpu().double(),expected_table,atol=1e-4,rtol=2e-5)
                    if table_kind!='scaled_tied':torch.testing.assert_close(readout.grad.detach().cpu().double(),projection_gradient,atol=1e-4,rtol=2e-5)
                    if inherited_bias!='none':torch.testing.assert_close(model.output_bias.grad.detach().cpu().double(),ce_gradient.sum((0,1)),atol=1e-4,rtol=2e-5)
                    torch.save(dict(tokens=idx.cpu(),targets=target.cpu(),logits=logits.detach().cpu(),hidden=hidden[0].detach().cpu(),hidden_gradient=hidden[0].grad.detach().cpu(),lookup_output_gradient=lookup[0].grad.detach().cpu(),readout=q,embedding=table.detach().cpu(),table_gradient=table.grad.detach().cpu(),readout_gradient=None if table_kind=='scaled_tied' else readout.grad.detach().cpu(),bias=bias,bias_gradient=None if inherited_bias=='none' else model.output_bias.grad.detach().cpu(),coefficient=coefficient,tying_kind=table_kind,width=w,derived_checkpoint_sha256=item['checkpoint_sha256'],atol=1e-4,rtol=2e-5),d/'table-math-check.pt')
                    branch_error=max(branch_review['errors'].values());attention_error=max(attn_review['errors'].values())
                    del logits,loss,target,hidden,lookup,h,q,bias,expected_logits,ce_gradient,expected_hidden,projection_gradient,lookup_gradient,expected_table,table,readout,hooks,branch_tensors,branch_hooks,branch_evidence,branch_review,attn_tensors,attn_hooks,attn_evidence,attn_review
                    driver_mb=torch.mps.driver_allocated_memory()/1024**2;assert driver_mb<6144
                    del full,cached,caches,parts,idx,model,names;torch.mps.synchronize();torch.mps.empty_cache()
                    rss=max(x['rss_mb'] for x in raw['metrics']);assert rss<4096
                    row=dict(width=w,family=f,output_bias_kind=inherited_bias,output_bias_width_policy=POLICY,output_bias_prior_sha256=p['output_bias_prior']['prior_sha256'],weight_tying_kind=table_kind,weight_tying_width_policy=TYING_POLICY,residual_topology_kind=topology,residual_topology_width_policy=RESIDUAL_POLICY,attention_logit_scale=study.SCALES[f],attention_logit_scale_width_policy=SCALE_POLICY,attention_math_sha256=file_digest(d/'attention-math-check.pt'),attention_math_max_error=attention_error,branch_math_sha256=file_digest(d/'branch-math-check.pt'),branch_math_max_error=branch_error,table_math_sha256=file_digest(d/'table-math-check.pt'),readout_norm_kind=expected_norm,readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,input_embedding_scale=p['recipe']['input_embedding_scale'],input_width_policy='mha4_input_scale',attention_family=attention,peak_learning_rate=lr,warmup_steps=t['lr_schedule'].get('warmup_steps',0),steps=total,cooldown_start=start,snapshots=avg['snapshots'],status='verified',
                        training_seconds=raw['training_time_sec'],wall_seconds=time.monotonic()-started,sampled_peak_rss_mb=rss,
                        cached_full_max_abs_error=error,current_driver_mb=driver_mb,driver_allocation_is_not_peak=True,
                        cached_evidence_sha256=file_digest(d/'cache-check.pt'),actual_cache_bytes=cache_bytes,cache_batch_size=2,
                        parameter_count=expected_count,raw_checkpoint_bytes=Path(checked['checkpoint']).stat().st_size,
                        derived_checkpoint_bytes=Path(item['checkpoint']).stat().st_size,checkpoint_sha256=checked['checkpoint_sha256'],
                        derived_checkpoint_sha256=item['checkpoint_sha256'],request_sha256=file_digest(d/'request.json'),result_sha256=file_digest(d/'result.json'))
                    assert row['wall_seconds']<240 and time.monotonic()-began<1800 and disk_mb(out)<1024
                    atomic_json(d/'review.json',row);rows.append(row);post_timer.cancel();post_timer=None;print(row,flush=True)
        except Exception as e:
            if post_timer is not None:post_timer.cancel()
            atomic_json(out/'failure.json',dict(error=repr(e),completed_jobs=len(rows),no_automatic_retry=True));raise
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,rows=rows,excluded_from_research=True,
        holdout_consumed=False,disk_mb=disk_mb(out)))

if __name__=='__main__':main()
