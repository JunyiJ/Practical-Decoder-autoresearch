"""Independent named parameter geometry for the prospective table-sharing pilot audit."""


def parameter_shapes(width, attention, norm_kind, bias_kind, tying_kind):
    if type(width) is not int or width not in (64,256) or attention != 'mha' or norm_kind not in ('layer_affine','layer_no_bias','rms'):
        raise ValueError('Only the frozen width64/256 MHA pilot geometry is supported')
    if bias_kind not in ('none','learned_zero','learned_train_unigram'):
        raise ValueError('Unknown output bias')
    if tying_kind not in ('legacy_untied','matched_untied','scaled_tied'):
        raise ValueError('Unknown table sharing')
    w=width
    shapes={'transformer.wte.weight':(65,w),'lm_head.weight':(65,w),
            'transformer.ln_f.weight':(w,),'transformer.ln_f.bias':(w,)}
    if norm_kind!='layer_affine':del shapes['transformer.ln_f.bias']
    for i in range(4):
        pre=f'transformer.h.{i}.'
        local={'ln1.weight':(w,),'ln2.weight':(w,),
            'mlp.linear_gate.weight':(21*w//8,w),'mlp.linear_up.weight':(21*w//8,w),
            'mlp.linear_down.weight':(w,21*w//8)}
        local.update({'attn.qkv.weight':(3*w,w),'attn.qkv.bias':(3*w,),
                      'attn.out.weight':(w,w),'attn.out.bias':(w,)})
        shapes.update({pre+key:value for key,value in local.items()})
    if bias_kind!='none':shapes['output_bias']=(65,)
    if tying_kind=='scaled_tied':del shapes['lm_head.weight']
    return shapes
