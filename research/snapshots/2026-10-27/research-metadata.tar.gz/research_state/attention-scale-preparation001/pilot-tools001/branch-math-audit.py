"""NumPy formulas for saved realized block forward/VJP; never imports model code.

Attention is treated as a realized branch, with its gradient entering ln1.
This verifies residual routing, both RMS normalizers and complete SwiGLU VJP;
attention internals are separately covered by CPU/cache/checkpoint checks.
The prerequisite auditor must bind every supplied weight to the derived CP.
"""
import numpy as np

def verify(p):
    assert p['kind'] in ('serial','parallel_separate_norms')
    assert p['atol']==1e-4 and p['rtol']==2e-5
    assert p['width'] in (64,256) and len(p['blocks'])==4
    errors={}
    for i,b in enumerate(p['blocks']):
        assert b['index']==i
        def arr(k):
            a=np.asarray(b[k],dtype=np.float64);assert np.isfinite(a).all(),k;return a
        def close(k,a,e):
            assert a.shape==e.shape,k
            np.testing.assert_allclose(a,e,atol=1e-4,rtol=2e-5,err_msg=f'block{i}:{k}')
            errors[f'{i}:{k}']=float(np.max(np.abs(a-e)))
        x=arr('input');a=arr('attention');y=arr('output');g=arr('output_gradient')
        assert x.shape==a.shape==y.shape==g.shape and x.ndim==3 and x.shape[-1]==p['width']
        d=x.shape[-1];h=21*d//8
        wgate=arr('gate_weight');wup=arr('up_weight');wdown=arr('down_weight')
        assert wgate.shape==wup.shape==(h,d) and wdown.shape==(d,h)
        gamma1=arr('ln1_weight');gamma2=arr('ln2_weight');assert gamma1.shape==gamma2.shape==(d,)
        for eps in ('ln1_eps','ln2_eps'):assert b[eps]==float(np.finfo(np.float32).eps)
        def norm(z,gamma,eps):return z/np.sqrt(np.mean(z*z,axis=-1,keepdims=True)+eps)*gamma
        def vjp(z,gamma,eps,upstream):
            inv=1/np.sqrt(np.mean(z*z,axis=-1,keepdims=True)+eps)
            q=upstream*gamma
            return inv*q-z*inv**3*np.mean(q*z,axis=-1,keepdims=True)
        z=x if p['kind']=='parallel_separate_norms' else x+a
        close('ln2_input',arr('ln2_input'),z)
        n1=norm(x,gamma1,b['ln1_eps']);n2=norm(z,gamma2,b['ln2_eps'])
        close('ln1_output',arr('ln1_output'),n1);close('ln2_output',arr('ln2_output'),n2)
        gate=n2@wgate.T;up=n2@wup.T
        sig=1/(1+np.exp(-gate));silu=gate*sig;product=silu*up;ffn=product@wdown.T
        close('ffn_output',arr('ffn_output'),ffn);close('output',y,(x+a)+ffn)
        close('ffn_gradient',arr('ffn_gradient'),g)
        gp=g@wdown;gg=gp*up*sig*(1+gate*(1-sig));gu=gp*silu
        gn2=gg@wgate+gu@wup;gz=vjp(z,gamma2,b['ln2_eps'],gn2)
        close('ln2_gradient',arr('ln2_gradient'),gn2)
        close('gate_weight_gradient',arr('gate_weight_gradient'),np.einsum('bth,btd->hd',gg,n2))
        close('up_weight_gradient',arr('up_weight_gradient'),np.einsum('bth,btd->hd',gu,n2))
        close('down_weight_gradient',arr('down_weight_gradient'),np.einsum('btd,bth->dh',g,product))
        close('ln2_weight_gradient',arr('ln2_weight_gradient'),np.sum(gn2*z/np.sqrt(np.mean(z*z,axis=-1,keepdims=True)+b['ln2_eps']),axis=(0,1)))
        gn1=arr('ln1_gradient');assert gn1.shape==x.shape
        close('ln1_weight_gradient',arr('ln1_weight_gradient'),np.sum(gn1*x/np.sqrt(np.mean(x*x,axis=-1,keepdims=True)+b['ln1_eps']),axis=(0,1)))
        expected_a=g+(gz if p['kind']=='serial' else 0)
        close('attention_gradient',arr('attention_gradient'),expected_a)
        close('input_gradient',arr('input_gradient'),g+gz+vjp(x,gamma1,b['ln1_eps'],gn1))
    return dict(status='verified',errors=errors,scope='Saved realized residual routing, RMS normalizers and SwiGLU forward/VJP; not attention-internal or full trajectory reconstruction')

def bind_checkpoint(p, state, expected_sha, expected_kind, expected_width):
    assert p['derived_checkpoint_sha256']==expected_sha
    assert p['kind']==expected_kind and p['width']==expected_width
    assert len(p['blocks'])==4
    mapping={'ln1_weight':'ln1.weight','ln2_weight':'ln2.weight','gate_weight':'mlp.linear_gate.weight','up_weight':'mlp.linear_up.weight','down_weight':'mlp.linear_down.weight'}
    for i,b in enumerate(p['blocks']):
        assert b['index']==i
        for key,name in mapping.items():
            supplied=np.asarray(b[key]);actual=np.asarray(state[f'transformer.h.{i}.{name}'])
            assert np.array_equal(supplied,actual),(i,key)
    return dict(status='bound',weights=20)

def link_graph(p, table, state, norm_kind, input_scale):
    """Bind the four captured blocks to one common table/readout forward/backward."""
    assert norm_kind in ('layer_affine','layer_no_bias','rms') and input_scale in (1.,.5,.25)
    blocks=p['blocks'];idx=np.asarray(table['tokens']);embedding=np.asarray(table['embedding'],dtype=np.float64)
    errors={}
    def close(k,a,b):
        a=np.asarray(a,dtype=np.float64);b=np.asarray(b,dtype=np.float64)
        assert a.shape==b.shape,k;np.testing.assert_allclose(a,b,atol=1e-4,rtol=2e-5,err_msg=k);errors[k]=float(np.max(np.abs(a-b)))
    close('embedding_input',blocks[0]['input'],embedding[idx]*input_scale)
    close('embedding_gradient',table['lookup_output_gradient'],np.asarray(blocks[0]['input_gradient'])*input_scale)
    for i in range(3):
        close(f'block{i}_forward_edge',blocks[i]['output'],blocks[i+1]['input'])
        close(f'block{i}_backward_edge',blocks[i]['output_gradient'],blocks[i+1]['input_gradient'])
    z=np.asarray(blocks[-1]['output'],dtype=np.float64);gamma=np.asarray(state['transformer.ln_f.weight'],dtype=np.float64)
    gn=np.asarray(table['hidden_gradient'],dtype=np.float64);q=gn*gamma
    centered=z if norm_kind=='rms' else z-z.mean(axis=-1,keepdims=True)
    inv=1/np.sqrt(np.mean(centered*centered,axis=-1,keepdims=True)+1e-5)
    bias=np.asarray(state['transformer.ln_f.bias'],dtype=np.float64) if norm_kind=='layer_affine' else 0.
    close('final_norm_hidden',table['hidden'],centered*inv*gamma+bias)
    grad=inv*(q-(q.mean(axis=-1,keepdims=True) if norm_kind!='rms' else 0))-centered*inv**3*np.mean(q*centered,axis=-1,keepdims=True)
    close('final_norm_gradient',blocks[-1]['output_gradient'],grad)
    return dict(status='linked',errors=errors)
