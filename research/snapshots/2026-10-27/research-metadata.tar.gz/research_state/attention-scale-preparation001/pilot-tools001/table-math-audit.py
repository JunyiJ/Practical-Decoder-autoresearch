"""Independent NumPy oracle for saved realized MPS table gradient roles.

A full prerequisite auditor must additionally bind every saved table to the
reviewed derived checkpoint and verify optimizer/H200/coverage contracts.
"""
import math
import numpy as np

def verify(p):
 kind=p['tying_kind'];w=p['width'];assert kind in ('legacy_untied','matched_untied','scaled_tied') and w in (64,256)
 assert p['atol']==1e-4 and p['rtol']==2e-5
 coeff=(1 if kind=='legacy_untied' else 1/math.sqrt(192))/(w/64)
 assert p['coefficient']==coeff
 def array(k):
  a=np.asarray(p[k],dtype=np.float64);assert np.isfinite(a).all(),k;return a
 h=array('hidden');q=array('readout');e=array('embedding');bias=array('bias');logits=array('logits')
 idx=np.asarray(p['tokens']);target=np.asarray(p['targets']);assert idx.shape==target.shape==h.shape[:2]
 assert h.shape[2]==w and q.shape==e.shape==(65,w) and bias.shape==(65,) and logits.shape==(*idx.shape,65)
 assert np.issubdtype(idx.dtype,np.integer) and np.issubdtype(target.dtype,np.integer)
 assert idx.min()>=0 and idx.max()<65 and target.min()>=0 and target.max()<65
 errors={}
 def close(name,a,b):
  assert a.shape==b.shape,name;np.testing.assert_allclose(a,b,atol=1e-4,rtol=2e-5,err_msg=name);errors[name]=float(np.max(np.abs(a-b)))
 close('logits',logits,np.einsum('btd,vd->btv',h,q)*coeff+bias)
 ex=np.exp(logits-logits.max(axis=-1,keepdims=True));g=ex/ex.sum(axis=-1,keepdims=True)
 flat=g.reshape(-1,65);flat[np.arange(target.size),target.reshape(-1)]-=1;g/=target.size
 projection=np.einsum('btv,btd->vd',g,h)*coeff
 lookup=np.zeros_like(e);lg=array('lookup_output_gradient');assert lg.shape==h.shape
 np.add.at(lookup,idx.reshape(-1),lg.reshape(-1,w))
 close('hidden_gradient',array('hidden_gradient'),np.einsum('btv,vd->btd',g,q)*coeff)
 close('table_gradient',array('table_gradient'),lookup+projection if kind=='scaled_tied' else lookup)
 if kind=='scaled_tied':
  assert np.array_equal(e,q) and p['readout_gradient'] is None
 else:close('readout_gradient',array('readout_gradient'),projection)
 if p['bias_gradient'] is not None:close('bias_gradient',array('bias_gradient'),g.sum(axis=(0,1)))
 return dict(status='verified',errors=errors,scope='Realized saved forward/gradient algebra only; checkpoint binding, initialization, optimizer and trajectory checks are separate')
