"""Independent standard-library audit of corpus-bound training-prefix bias metadata.
Does not import production prior code, torch, or sample heldout tokens.
"""
import hashlib,json,math


def sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',', ':'),ensure_ascii=True,allow_nan=False).encode()).hexdigest()


def verify_prior(raw, prior, train_fraction=.8, val_fraction=.1):
    expected_keys={'version','corpus_sha256','tokenizer','alphabet','token_count','train_fraction','val_fraction','train_end','val_end','counts','counts_sha256','pseudocount','initial_values','initial_values_sha256','prior_sha256'}
    if type(raw) is not bytes or type(prior) is not dict or set(prior)!=expected_keys:
        raise ValueError('Incomplete independent prior inputs')
    text=raw.decode('utf-8').replace('\r\n','\n').replace('\r','\n')
    alphabet=sorted(set(text));cut=int(len(text)*train_fraction)
    val_end=len(text) if math.isclose(train_fraction+val_fraction,1.,rel_tol=0,abs_tol=1e-12) else int(len(text)*(train_fraction+val_fraction))
    if not alphabet or cut<1:raise ValueError('Empty training prior')
    indices={character:i for i,character in enumerate(alphabet)}
    counts=[0]*len(alphabet)
    for character in text[:cut]:counts[indices[character]]+=1
    expected={'version':1,'corpus_sha256':hashlib.sha256(raw).hexdigest(),'tokenizer':'TinyDataLoader.sorted_global_characters.universal_newlines.v1','alphabet':alphabet,'token_count':len(text),'train_fraction':float(train_fraction),'val_fraction':float(val_fraction),'train_end':cut,'val_end':val_end,'counts':counts,'counts_sha256':sha(counts),'pseudocount':1}
    if any(prior[k]!=v or type(prior[k])!=type(v) for k,v in expected.items()):
        raise ValueError('Corpus, alphabet ordering, split, training-only counts or smoothing differ')
    if any(type(n) is not int for n in prior['counts']):raise ValueError('Noninteger counts')
    # Centering cancels the common log(total+V) term; use this algebraically
    # independent form rather than the production probability formula.
    log_counts=[math.log1p(n) for n in counts];center=math.fsum(log_counts)/len(counts)
    wanted=[x-center for x in log_counts];values=prior['initial_values']
    if len(values)!=len(wanted) or any(type(a) is not float or not math.isfinite(a) or not math.isclose(a,b,rel_tol=0,abs_tol=1e-14) for a,b in zip(values,wanted)):
        raise ValueError('Incorrect centered log-Laplace initialization')
    if prior['initial_values_sha256']!=sha(values) or prior['prior_sha256']!=sha({k:v for k,v in prior.items() if k!='prior_sha256'}):
        raise ValueError('Prior digest differs')
    return {'prior_sha256':prior['prior_sha256'],'corpus_sha256':prior['corpus_sha256'],'training_prefix_tokens_counted':cut,'vocabulary_size':len(alphabet),'heldout_frequencies_used':False,'global_alphabet_uses_full_corpus':True,'max_initialization_formula_error':max(abs(a-b) for a,b in zip(values,wanted))}
