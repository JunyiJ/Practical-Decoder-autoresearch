"""Capture actual attention forward/backward for post-worker pilot validation only."""
def install(model):
    rows=[{} for _ in model.transformer.h];hooks=[]
    for i,b in enumerate(model.transformer.h):
        assert b.attn.q_norm is None and b.attn.k_norm is None and b.attn.output_gate is None
        assert b.attn.causal and b.attn.head_dim==32 and b.attn.attn_dropout.p==b.attn.out_dropout.p==0
        def capture(module,inputs,output,i=i):
            inputs[0].retain_grad();output[0].retain_grad();rows[i].update(input=inputs[0],output=output[0])
        hooks.append(b.attn.register_forward_hook(capture))
    return rows,hooks

def export(model,rows,derived_sha):
    result=[]
    for i,(b,t) in enumerate(zip(model.transformer.h,rows)):
        r=dict(index=i)
        for k,v in t.items():
            assert v.grad is not None;r[k]=v.detach().cpu();r[k+'_gradient']=v.grad.detach().cpu()
        for k,v in [('qkv_weight',b.attn.qkv.weight),('qkv_bias',b.attn.qkv.bias),('out_weight',b.attn.out.weight),('out_bias',b.attn.out.bias)]:
            assert v.grad is not None;r[k]=v.detach().cpu();r[k+'_gradient']=v.grad.detach().cpu()
        tlen=t['input'].shape[1];r['cos']=b.freq_cos[:tlen].detach().cpu();r['sin']=b.freq_sin[:tlen].detach().cpu();result.append(r)
    scales={b.attn.attention_logit_scale for b in model.transformer.h};assert len(scales)==1
    return dict(scale=scales.pop(),width=model.cfg.dim,derived_checkpoint_sha256=derived_sha,atol=1e-4,rtol=2e-5,blocks=result)
