"""Register exactly one new attention-scale round after actual source/test/pilot gates."""
import argparse,datetime,json,os,re,subprocess
from pathlib import Path

parser=argparse.ArgumentParser();parser.add_argument('--register',action='store_true');args=parser.parse_args()
if not args.register:parser.error('Explicit --register required')

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
run=base/'research_runs/attention-scale-quality-001';folder=Path(__file__).resolve().parent;prep=folder.parent;prior=base/'research_runs/parallel-block-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text())
if active['campaign']!=str(prior) or active['status']!='completed_reviewed' or active.get('human_stopped'):
 raise ValueError('Final reviewed parallel-block completion required before attention-scale registration')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
import sys,shutil
sys.path.insert(0,str(prep/'cpu-tools001'))
from bounded_cpu import live_model_commands
if live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()}):
 raise ValueError('Competing model work; registration deferred')
assert shutil.disk_usage(base).free>=10*1024**3
from src.research import attention_scale_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
manual_path=prep/'manual-source-review001.json';manual=json.loads(manual_path.read_text())
assert manual['status']=='complete_source_scaling_review_before_actual_validation'
integration=json.loads((prep/'integration-review.json').read_text())
assert integration['source_sha256']==p['source_sha256']
for name,expected in manual['files'].items():
 if name.endswith('.py'):assert file_digest(source/name)==expected
remote_main = subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]
# A later human merge must not silently enter an already tested study.
subprocess.check_call(['git','merge-base','--is-ancestor',p['git_commit'],remote_main])
p['publication_lineage'] = dict(tested_commit=p['git_commit'], observed_remote_main=remote_main,
    tested_commit_is_remote_ancestor=True, later_remote_changes_excluded=True)
review=prep/'review.json';v=json.loads(review.read_text());tests=v['tests']['full_tests']
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit']
assert v['independent_training_prior']['prior_sha256']==p['output_bias_prior']['prior_sha256'] and v['independent_training_prior']['heldout_frequencies_used'] is False
assert v['recipe']==p['recipe'] and v['returned_half_life']==200 and v['predecessor_review']==p['predecessor_review']
assert tests['passed']==tests['collected']==3264 and tests['failed']==0 and v['tests']['actual_attention_scale_training_tests_passed']==12 and v['tests']['actual_attention_scale_geometry_tests_passed']==12 and v['tests']['attention_scale_metadata_tests_passed']==210
assert len(v['pilot_audit'])==6 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['status']=='feasible' and v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in sorted(set((base/'research_runs').glob('*/plan.json'))|set((base/'research_state').glob('*plan*.json'))):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/ATTENTION_SCALE_PROTOCOL.md';con=json.loads((base/'research_state/parallel-block-quality-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
incumbent_path=base/'research_state/attention-scale-quality-incumbent.json';assert not incumbent_path.exists()
snapshot=base/'research_state/attention-scale-quality-knowledge-snapshot.md'
assert not snapshot.exists() and not (base/'research_state/attention-scale-quality-plan.json').exists()
artifacts=[incumbent_path,protocol,review,manual_path,prep/'integration-review.json',prep/'cpu-review.json',prep/'cpu-publication-review.json',
 folder/'freeze-attention-scale-quality001.py',folder/'launch-attention-scale-quality001.py',folder/'review.json',
 prep/'screening-tools001/audit.py',prep/'screening-tools001/review.json',
 prep/'completion-audit-tools001/completion-audit001.py',prep/'completion-audit-tools001/review.json',
 prep/'completion-tools001/record-completion.py',prep/'completion-tools001/review.json',
 prep/'completion-tools001/plot-completion001.py',prep/'completion-tools001/render-completed-guide001.mjs',prep/'completion-tools001/rendering-preparation-review001.json',
 base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/parallel-block-quality-conclusion.json',base/'research_state/parallel-block-quality-completed-knowledge-snapshot.md']
artifacts += [prep/'pilot-tools001'/n for n in ('pilot-driver001.py','review-prerequisites001.py','prior-audit.py','pilot-geometry.py','table-math-audit.py','branch-capture.py','branch-math-audit.py','attention-capture.py','attention-math-audit.py','resource-gate.py','preparation-review001.json')]
artifacts += [prior/f for f in ('plan.json','report.json','review.json','selection.json')]
assert len(v['independent_branch_math'])==6
assert {(x['width'],x['family']) for x in v['independent_branch_math']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for x in v['independent_branch_math']:
 assert x['status']=='verified' and x['binding']['status']=='bound' and x['binding']['weights']==20 and x['linkage']['status']=='linked'
assert len(v['independent_table_math'])==6 and all(x['status']=='verified' for x in v['independent_table_math'])
assert {(x['width'],x['family']) for x in v['independent_table_math']}=={(w,f) for w in (64,256) for f in study.FAMILIES}


assert len(v['independent_attention_math'])==6
assert {(x['width'],x['family']) for x in v['independent_attention_math']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for x in v['independent_attention_math']:
 assert x['status']=='verified' and x['binding']==dict(status='bound',weights=16,rope_buffers=8) and x['linkage']==dict(status='linked',edges=16)

# Verify every required artifact before creating an incumbent snapshot or bank entry.
for artifact in artifacts:
 if artifact!=incumbent_path:assert artifact.is_file(),str(artifact)
prior_review=json.loads((prior/'review.json').read_text())
assert con['quality_decision']==prior_review['quality_decision']
current_best=json.loads((base/'research_state/best-observed-config.json').read_text())
if con['quality_decision']['qualifies_for_incumbent_replacement']:
 assert current_best['result_id']==con['result_id']
else:
 prior_plan=json.loads((prior/'plan.json').read_text());frozen_prior=prior_plan['incumbent_snapshot']
 assert file_digest(Path(frozen_prior['path']))==frozen_prior['sha256']
 frozen_best=json.loads(Path(frozen_prior['path']).read_text())
 assert current_best['result_id']==frozen_best['result_id']==frozen_prior['result_id']
 for key in ('baseline_commit','baseline_config','config_overrides','returned_weights','selection'):
  assert current_best.get(key)==frozen_best.get(key),'Concurrent incumbent change: '+key
assert json.loads((base/'research_state/active-campaign.json').read_text())==active

incumbent_path.write_bytes((base/'research_state/best-observed-config.json').read_bytes());incumbent_path.chmod(0o444)
incumbent=json.loads(incumbent_path.read_text());p['incumbent_snapshot']=dict(path=str(incumbent_path),sha256=file_digest(incumbent_path),result_id=incumbent['result_id'])
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',
 title='Fixed attention-logit scaling passed CPU and serial MPS prerequisites',
 summary=f"All {tests['passed']} source-matched CPU tests, including24 actual geometry/trainer cases, and six serial MPS40-update pilots passed. Independent checkpoint-bound masked attention/RoPE/QKV/output and residual/RMS/SwiGLU forward and VJP, full graph linkage, canonical optimizer/H200, prior/RNG/coverage/cache and worst42 resource forecast verified. Correctness pilots excluded from quality evidence.",
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,
 artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id']]))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',
 title='Preregistered attention-scale quality001: fixed attention-logit multipliers1/.5/2',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='Fixed post-RoPE attention-logit scaling may improve quality. No numerical gain, entropy-collapse diagnosis, isolated mechanism, inference-speed benefit or optimal muP transfer is assumed.',
 selection='Eighteen width64 screens2401/2402 choose one LR per scale, ties lowerLR; bestfamily ties baseline/half/double. BaselineLR-only candidate requires>.005mean/everyseed gain versusfixedincumbent; changedscale also versus tunedbaseline. Failedbest retains incumbent, nofallback. Freeze before18selected fresh2411/2412/2413 at64/256 plus0/6 exactfixedreferences. Onlyeligiblefrozenwinner adopts after>.005mean/everyseed/allthreeconditionaltextuppernegative bothwidths against requiredrefs.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='All residual topology/table/bias/prior/norm/input/LR/decay/warmup inherit FINAL reviewed parallel-block decision. MHA4Swi21/8,3000updates3072000targets,cooldown2000/H200101snapshots. Fixed1/.5/2 multiplier once on post-RoPE QK/sqrt32 before causal masking/softmax; KVcache unscaled. Parameter layout/construction RNG unchanged, gradients and optimization paths differ. EqualLRgrid.0025/.005/.01;36/42physical72/84correlated. Noextension/reselection/rerun; allolderstudiesclosed/006permanentstop/primaryuntouched.',
 output_bias_prior=p['output_bias_prior']),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in (protocol,review,prior/'review.json')],related_ids=[implementation,con['result_id']]))
assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)

p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary human checkout untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in (run/'plan.json',base/'research_state/attention-scale-quality-plan.json'):path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],recipe=p['recipe'],maximum_physical_trajectories=42,maximum_correlated_model_outputs=84,returned_half_life=200,completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
