"""Launch only a newly frozen attention-scale round after all predecessor/source gates."""
import argparse,datetime,json,os,re,subprocess,sys
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--launch',action='store_true');args=parser.parse_args()
if not args.launch:parser.error('Explicit --launch required')
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();run=root/'research_runs/attention-scale-quality-001';prior=root/'research_runs/parallel-block-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
fp=root/'research_state/active-campaign.json';active=json.loads(fp.read_text())
if active['status']!='completed_reviewed' or active['campaign']!=str(prior) or active.get('human_stopped'):
 raise ValueError('Final reviewed parallel-block completion required before attention-scale launch')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'cpu-tools001'))
from bounded_cpu import live_model_commands
if live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()}):
 raise ValueError('Competing model work; launch deferred')
from src.research import attention_scale_study as study
p=json.loads((run/'plan.json').read_text());assert not (run/'state.json').exists() and not (run/'controller.log').exists();study.verify_lineage(p)
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
now=datetime.datetime.now(datetime.timezone.utc).isoformat();env=os.environ.copy();env.pop('PYTORCH_ENABLE_MPS_FALLBACK',None)
assert json.loads(fp.read_text())==active,'Active campaign changed during launch preparation'
history=active.setdefault('completed_algorithm_studies',[])
assert isinstance(history,list),'Completed study history must be a list'
def names_prior(x):
 return ((isinstance(x,str) and x==str(prior)) or
         (isinstance(x,dict) and (x.get('campaign')==str(prior) or
          (x.get('study')==prior.name and x.get('review')==str(prior/'review.json')))))
if not any(names_prior(x) for x in history):
 completion=active.get('parallel_block_quality_completion',{})
 assert isinstance(completion,dict) and completion.get('status')=='completed_reviewed'
 assert completion.get('review')==str(prior/'review.json') and completion.get('source_commit')==active['source_commit']
 assert isinstance(completion.get('result_id'),str) and completion['result_id'].startswith('kb_')
 history.append(dict(completion,campaign=str(prior)))
json.dumps(active,allow_nan=False)
# Validate all existing bookkeeping before any controller is created.
monitor_path=root/'research_state/research-monitor.json'
progress_path=root/'research_state/quality-evolution-progress.json'
m=json.loads(monitor_path.read_text());d=json.loads(progress_path.read_text())
assert isinstance(m,dict) and isinstance(d,dict),'Monitor and progress must be mappings'
json.dumps(m,allow_nan=False);json.dumps(d,allow_nan=False)
with (run/'controller.log').open('x') as log:
 proc=subprocess.Popen([sys.executable,'-m','src.research.attention_scale_study','--plan',str(run/'plan.json'),'--output',str(run),'--allow-training'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
def write(path,data):
 tmp=path.with_name(path.name+'.launch-tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
active.update(updated_at=now,campaign=str(run),kind='attention_scale_quality',stage='attention_scale_quality',status='running',pid=proc.pid,controller_exited=False,last_checked_at=now,launched_at=now,source_commit=p['git_commit'],source_root=str(source),plan=str(run/'plan.json'),state_file=str(run/'state.json'),predecessor=str(prior),scope='Fixed attention-logit scaling1/.5/2, equal finite LR tuning, final-reviewed topology/table/bias/prior/norm/inputscale/MHA4/cooldown/H200;36/42fresh trajectories72/84correlated outputs, exact aliases, holdout closed.',next_action='Verify and monitor one frozen worker; audit all physical raw/derived checkpoints, aliases, choices and independently reconstructed report at completion, then continue quality evolution until human interruption.')
for key in ['review','result_id','documentation_commit','completed_reviewed_at','completed_at','clarification_id','completed_knowledge_snapshot','conclusion']:active.pop(key,None)
write(fp,active)
fp=monitor_path;m.update(updated_at=now,source_commit=p['git_commit'],campaign=str(run),active_stage='attention_scale_quality',active_study=str(run),status='running',last_checked_at=now,last_live_controller_pid=proc.pid,attention_scale_quality_launch_notified=False,attention_scale_quality_record_count=0,next_action=active['next_action']);
if isinstance(m.get('attention_scale_preparation'),dict):m['attention_scale_preparation'].update(status='registered_launched',source_commit=p['git_commit'],source_sha256=p['source_sha256'],registered_run=str(run),research_launched=True)
write(fp,m)
fp=progress_path;d.update(updated_at=now,campaign=str(run),active_stage='attention_scale_quality',status='running',active_study=str(run),protocol=str(source/'research/ATTENTION_SCALE_PROTOCOL.md'),source_commit=p['git_commit'],preregistration_id=p['preregistration_id'],implementation_id=p['implementation_id'],next_action=active['next_action'],last_checked_at=now,resolved_model_recipe=p['recipe'],returned_half_life=200,attention_scale_quality_record_count=0,completion_audit=str(Path(__file__).resolve().parent.parent/'completion-audit-tools001/completion-audit001.py'));
if isinstance(d.get('attention_scale_preparation'),dict):d['attention_scale_preparation'].update(status='registered_launched',source_commit=p['git_commit'],source_sha256=p['source_sha256'],registered_run=str(run),research_launched=True)
write(fp,d)
print(json.dumps(dict(pid=proc.pid,source_commit=p['git_commit'],recipe=p['recipe'],run=str(run))))
