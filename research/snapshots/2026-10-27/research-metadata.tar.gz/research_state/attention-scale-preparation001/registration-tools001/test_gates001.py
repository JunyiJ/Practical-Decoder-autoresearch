"""Execute actual prerequisite assertions against metadata fixtures, no model imports."""
import ast,copy,json,types,unittest
from pathlib import Path
folder=Path(__file__).resolve().parent
s=(folder/'freeze-attention-scale-quality001.py').read_text()
a=s.index("assert v['status']");b=s.index('new=set(',a)
c=s.index("assert len(v['independent_branch_math'])");d=s.index('# Verify every required artifact',c)
code=compile(s[a:b]+s[c:d],'<actual-registration-prerequisite-assertions>','exec')
def fixture():
 families=['baseline','half','double'];cells=[dict(width=w,family=f) for w in (64,256) for f in families]
 p=dict(source_sha256='s',git_commit='c',output_bias_prior=dict(prior_sha256='p'),recipe=dict(learning_rate=.005),predecessor_review=dict(sha256='r'))
 v=dict(status='verified',source_sha256='s',source_commit='c',recipe=p['recipe'],predecessor_review=p['predecessor_review'],returned_half_life=200,
 independent_training_prior=dict(prior_sha256='p',heldout_frequencies_used=False),tests=dict(full_tests=dict(passed=3264,collected=3264,failed=0),actual_attention_scale_training_tests_passed=12,actual_attention_scale_geometry_tests_passed=12,attention_scale_metadata_tests_passed=210),pilot_audit=cells,artifacts=[dict(path='fixture',sha256='h')],resource_proxy=dict(status='feasible',hours=2.,total_mb_with_margin=1800.,trial_proxies=[dict(seconds_per_trajectory_with_margin=120.)]*6),independent_table_math=[dict(**x,status='verified') for x in cells],independent_branch_math=[dict(**x,status='verified',binding=dict(status='bound',weights=20),linkage=dict(status='linked')) for x in cells])
 v['independent_attention_math']=[dict(**x,status='verified',binding=dict(status='bound',weights=16,rope_buffers=8),linkage=dict(status='linked',edges=16)) for x in cells]
 return p,v

def verify(p,v):
 exec(code,dict(v=v,p=p,tests=v['tests']['full_tests'],study=types.SimpleNamespace(FAMILIES=['baseline','half','double']),Path=Path,file_digest=lambda p:'h'))
class Tests(unittest.TestCase):
 def test_actual_assertions_accept_complete_metadata(self):verify(*fixture())
 def test_actual_assertions_reject_incomplete_or_corrupt_gates(self):
  mutations=[lambda v:v.update(status='pending'),lambda v:v.update(source_sha256='bad'),lambda v:v.update(source_commit='bad'),lambda v:v.update(recipe={}),lambda v:v.update(predecessor_review={}),lambda v:v.update(returned_half_life=50),lambda v:v['independent_training_prior'].update(prior_sha256='bad'),lambda v:v['independent_training_prior'].update(heldout_frequencies_used=True),lambda v:v['tests']['full_tests'].update(passed=3263),lambda v:v['tests']['full_tests'].update(collected=3265),lambda v:v['tests']['full_tests'].update(failed=1),lambda v:v['tests'].update(actual_attention_scale_training_tests_passed=11),lambda v:v['tests'].update(actual_attention_scale_geometry_tests_passed=11),lambda v:v['tests'].update(attention_scale_metadata_tests_passed=209),lambda v:v['pilot_audit'].pop(),lambda v:v['artifacts'][0].update(sha256='bad'),lambda v:v['resource_proxy'].update(status='infeasible'),lambda v:v['resource_proxy'].update(hours=6),lambda v:v['resource_proxy'].update(total_mb_with_margin=4096),lambda v:v['resource_proxy']['trial_proxies'][0].update(seconds_per_trajectory_with_margin=2400),lambda v:v['independent_branch_math'].pop(),lambda v:v['independent_branch_math'][0].update(family='wrong'),lambda v:v['independent_branch_math'][0]['binding'].update(weights=19),lambda v:v['independent_branch_math'][0]['binding'].update(status='wrong'),lambda v:v['independent_branch_math'][0]['linkage'].update(status='wrong'),lambda v:v['independent_branch_math'][0].update(status='wrong'),lambda v:v['independent_table_math'].pop(),lambda v:v['independent_table_math'][0].update(status='wrong'),lambda v:v['independent_attention_math'].pop(),lambda v:v['independent_attention_math'][0].update(family='wrong'),lambda v:v['independent_attention_math'][0].update(status='wrong'),lambda v:v['independent_attention_math'][0]['binding'].update(weights=15),lambda v:v['independent_attention_math'][0]['binding'].update(rope_buffers=7),lambda v:v['independent_attention_math'][0]['binding'].update(status='wrong'),lambda v:v['independent_attention_math'][0]['linkage'].update(edges=15),lambda v:v['independent_attention_math'][0]['linkage'].update(status='wrong')]
  for i,mutate in enumerate(mutations):
   with self.subTest(i=i):
    p,v=fixture();mutate(v)
    with self.assertRaises(AssertionError):verify(p,v)
class LaunchHistory(unittest.TestCase):
 def test_mixed_history_preflight_before_spawn(self):
  text=(folder/'launch-attention-scale-quality001.py').read_text()
  start=text.index('history=active.setdefault');end=text.index('json.dumps(active',start)
  chunk=compile(text[start:end],'<actual-launch-history>','exec')
  self.assertLess(start,text.index('subprocess.Popen'))
  for history in ([],['old-study'],[dict(campaign='/prior')],['/prior'],['old-study',dict(campaign='/other')]):
   active=dict(completed_algorithm_studies=copy.deepcopy(history),source_commit='s',review='r',result_id='id')
   exec(chunk,dict(active=active,prior=Path('/prior')))
   found=[x for x in active['completed_algorithm_studies'] if (isinstance(x,dict) and x.get('campaign')=='/prior') or x=='/prior']
   self.assertEqual(len(found),1)
if __name__=='__main__':unittest.main()
