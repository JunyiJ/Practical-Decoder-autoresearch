"""Pure plot metadata guards; no matplotlib, model or actual evidence output."""
import ast,copy,unittest
from pathlib import Path
F=Path(__file__).resolve().parent
ns={};tree=ast.parse((F/'plot-completion001.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='validate'],type_ignores=[]),'plot-guard','exec'),ns)
validate=ns['validate'];families=('baseline','half','double')
def fixture(count,winner):
 decision=dict(frozen_screen_winner=winner,qualifies_for_incumbent_replacement=winner!='incumbent_unchanged')
 v=dict(status='verified',distinct_trajectories=count,distinct_checkpoints=2*count,quality_decision=decision)
 c=dict(quality_decision=decision,selection=dict(winner=winner,choices={f:dict(lr=lr) for f,lr in zip(families,(.005,.0025,.01))},confirmation=dict(reference_aliases={'incumbent_reference':'baseline'} if count==36 else {})),comparisons=[dict(width=w,sensitivity=[dict(text_block_tokens=t,paired_seed_deltas={str(s):-.01 for s in (2411,2412,2413)}) for t in (2048,4096,8192)]) for w in (64,256) for _ in range(6)])
 return c,v
class Tests(unittest.TestCase):
 def test_eight_alias_and_frozen_winner_routes(self):
  for count in (36,42):
   for winner in families+('incumbent_unchanged',):
    c,v=fixture(count,winner);self.assertEqual(validate(c,v),v['quality_decision'])
 def test_corrupt_completion_alias_seed_and_lr_rejected(self):
  for change in ('count','aliases','seed','lr','decision','winner'):
   c,v=fixture(36,'double');c=copy.deepcopy(c);v=copy.deepcopy(v)
   if change=='count':v['distinct_checkpoints']=36
   if change=='aliases':c['selection']['confirmation']['reference_aliases']={}
   if change=='seed':c['comparisons'][0]['sensitivity'][0]['paired_seed_deltas']={'2351':-.01}
   if change=='lr':c['selection']['choices']['double']['lr']=.02
   if change=='decision':v['quality_decision']['qualifies_for_incumbent_replacement']=False
   if change=='winner':c['selection']['winner']='half'
   with self.assertRaises(AssertionError,msg=change):validate(c,v)
if __name__=='__main__':unittest.main(verbosity=2)
