"""Preview, or explicitly record, a completely reviewed attention-scale quality result."""
import argparse,copy,datetime,json,statistics
from pathlib import Path
BASE=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
FAMILIES=('baseline','half','double');REFERENCE='incumbent_reference';SEEDS=(2411,2412,2413)


def verified_decision(plan, report):
    incumbent_lr=plan['recipe']['learning_rate'];assert incumbent_lr in (.0025,.005,.01)
    selection=report['selection'];choices=selection['choices']
    assert set(choices)==set(FAMILIES)
    best=min(FAMILIES,key=lambda f:(choices[f]['mean_ce'],FAMILIES.index(f)))
    assert best==selection['best_selected_arm']
    for choice in choices.values():
        assert [v['lr'] for v in choice['grid']]==[.0025,.005,.01]
        selected=min(choice['grid'],key=lambda v:(v['mean_ce'],v['lr']))
        assert selected=={k:choice[k] for k in ('lr','mean_ce')}
    expected_refs=[REFERENCE]+([] if best=='baseline' else ['baseline'])
    assert [c['reference'] for c in selection['local_contrasts']]==expected_refs
    for c in selection['local_contrasts']:
        ds=c['paired_seed_deltas'];assert set(ds)=={'2401','2402'}
        assert abs(statistics.mean(ds.values())-c['mean_delta'])<1e-12
        lr=incumbent_lr if c['reference']==REFERENCE else choices['baseline']['lr']
        refmean=next(v['mean_ce'] for v in choices['baseline']['grid'] if v['lr']==lr)
        assert c['reference_lr']==lr and abs(choices[best]['mean_ce']-refmean-c['mean_delta'])<1e-12
        assert c['supported']==(c['mean_delta']<-.005 and max(ds.values())<0)
    eligible=all(c['supported'] for c in selection['local_contrasts'])
    assert selection['candidate_eligible']==eligible
    winner=best if eligible else 'incumbent_unchanged'
    assert selection['winner']==winner
    adopt=eligible
    if eligible:
        for width in (64,256):
            for reference in expected_refs:
                found=[x for x in report['comparisons'] if (x['candidate'],x['reference'],x['width'])==(winner,reference,width)]
                assert len(found)==1
                c=found[0];values=c['sensitivity'];assert [v['text_block_tokens'] for v in values]==[2048,4096,8192]
                first=values[0];assert set(first['paired_seed_deltas'])==set(map(str,SEEDS))
                for v in values:
                    assert v['paired_seed_deltas']==first['paired_seed_deltas']
                    assert abs(v['mean_delta']-statistics.mean(first['paired_seed_deltas'].values()))<1e-12
                supported=first['mean_delta']<-.005 and max(first['paired_seed_deltas'].values())<0 and all(v['conditional_text_bootstrap_95pct'][1]<0 for v in values)
                assert c['quality_improvement']==supported
                adopt=adopt and supported
    assert report['quality_decision']==dict(frozen_screen_winner=winner,qualifies_for_incumbent_replacement=adopt)
    return winner,adopt


def verify_selected_model(plan,winner,cfg):
    assert winner in FAMILIES
    m,t=cfg['model'],cfg['training'];r=plan['recipe']
    expected=dict(attention_logit_scale={'baseline':1.,'half':.5,'double':2.}[winner],attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',
        residual_topology_kind=r['residual_topology_kind'],residual_topology_width_policy='mha4_separate_norm_residual_topology',
        weight_tying_kind=r['weight_tying_kind'],weight_tying_width_policy='mha4_scaled_table_sharing',
        output_bias_kind=r['output_bias_kind'],output_bias_width_policy='mha4_train_bound_output_bias',output_bias_prior=plan['output_bias_prior'],
        readout_norm_kind=r['readout_norm_kind'],readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,
        input_embedding_scale=r['input_embedding_scale'],input_width_policy='mha4_input_scale',vocab_size=len(plan['output_bias_prior']['alphabet']))
    assert all(m.get(k)==v for k,v in expected.items())
    assert t['lr_schedule'].get('warmup_steps',0)==r['warmup_steps'] and t['weight_averaging']['half_lives']==[200]
    return expected


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--record',action='store_true');args=parser.parse_args()
    run=BASE/'research_runs/attention-scale-quality-001'
    active=json.loads((BASE/'research_state/active-campaign.json').read_text())
    if active.get('campaign')!=str(run) or not (run/'review.json').is_file():
        raise ValueError('Terminal attention-scale run and full independent review required before recording')
    if json.loads((run/'state.json').read_text())['status']!='completed':
        raise ValueError('Completed attention-scale run required')
    import subprocess,re
    processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
    if any(re.search(r'src\.research\.(?:worker|attention_scale_study)|src\.train\.train|pytest|run-cpu-validation|pilot-driver',line) for line in processes):
        raise ValueError('Competing model work; defer completion recording')
    from src.research import attention_scale_study as study
    from src.research.attention_scale_audit import audit
    from src.research.protocol import digest,file_digest
    from src.research.team.knowledge import KnowledgeBank
    run=BASE/'research_runs/attention-scale-quality-001';folder=Path(__file__).resolve().parent
    p,s,r,v=[json.loads((run/n).read_text()) for n in ('plan.json','state.json','report.json','review.json')]
    assert s['status']=='completed' and v['status']=='verified'
    assert len(s['records'])==r['physical_training_trajectories']==v['distinct_trajectories'] in (36,42)
    assert v['distinct_checkpoints']==r['model_evaluations']==2*len(s['records'])
    assert digest(p)==r['plan_sha256']==v['plan_sha256']
    assert v['source_commit']==p['git_commit'] and v['source_sha256']==p['source_sha256']
    assert v['report_sha256']==file_digest(run/'report.json') and v['selection_sha256']==file_digest(run/'selection.json')
    study.verify_lineage(p);assert study.summarize(p,s)==r and r['quality_decision']==v['quality_decision']
    assert audit(p,s,r)==v['independent_report_review']
    assert v['independent_training_prior']['prior_sha256']==p['output_bias_prior']['prior_sha256'] and v['independent_training_prior']['heldout_frequencies_used'] is False
    winner,adopt=verified_decision(p,r)
    rows=[x for x in r['records'] if x['stage']=='confirmation']
    for alias,target in r['reference_aliases'].items():rows += [{**x,'family':alias,'alias_of':x['trial_id']} for x in list(rows) if x['family']==target]
    families=FAMILIES+(REFERENCE,)
    means={};cost={}
    for family in families:
        means[family]={};cost[family]={}
        for width in (64,256):
            panel=[x for x in rows if x['family']==family and x['width']==width]
            assert sorted(x['seed'] for x in panel)==list(SEEDS)
            means[family][str(width)]={key:statistics.mean(study.endpoint(p,x,raw)['mean_ce'] for x in panel) for key,raw in [('H200',False),('raw',True)]}
            cost[family][str(width)]=dict(mean_training_seconds=statistics.mean(x['training_time_sec'] for x in panel),mean_trajectory_wall_seconds=statistics.mean(x['duration_seconds'] for x in panel),mean_sampled_rss_mb=statistics.mean(x['rss_mb'] for x in panel))
    for family in families:
        for width in ('64','256'):cost[family][width]['training_time_ratio_vs_baseline']=cost[family][width]['mean_training_seconds']/cost['baseline'][width]['mean_training_seconds']
    def delta(f):return '/'.join(f"{next(c for c in r['comparisons'] if (c['candidate'],c['reference'],c['width'])==(f,'baseline',w))['sensitivity'][0]['mean_delta']:+.6f}" for w in (64,256))
    summary=(f"Fixed attention-logit scaling comparison completed {len(s['records'])} physical trajectories and {r['model_evaluations']} correlated raw/H200 outputs, independently reviewed. Common warmup {p['recipe']['warmup_steps']} updates. Frozen eligible winner: {winner}. Fresh H200 width64/256 deltas versus tuned baseline: half-scale {delta('half')}; double-scale {delta('double')}. "+(f'Adopt the frozen {winner} recipe after both-width support.' if adopt else 'Retain the prior incumbent under the complete frozen rule.'))
    limitations=[
        'Adaptive development on reused validation; conditional text intervals are not seed-population uncertainty, independent holdout or adjusted significance.',
        f"{len(s['records'])} physical trajectories yield {r['model_evaluations']} correlated raw/H200 endpoints. Reference aliases {r['reference_aliases']} were declared prospectively and are not independent repeated controls; no historical pooling.",
        'Only the frozen eligible width64 winner can be adopted; no alternate fallback, larger-width reselection, grid extension or completed-trial rerun.',
        'Equal finite LR tuning; selected-recipe contrasts include LR choice. A tuned baseline-only gain is attributed to LR selection, not attention scaling. Fixed-LR screens are separate.',
        'Equal 3000 updates and 3072000 targets, common final-reviewed residual topology/table/bias/prior/norm/input, warmup/cooldown/H200 and independent decay. Fixed1/.5/2 multiplier is applied once to post-RoPE QK/sqrt32 before causal masking and softmax. Unit path preserves historical arithmetic; cached K/V stay unscaled. Parameter layout and construction RNG are unchanged, but gradients, clipping and optimization paths can differ. Q/K weights can adapt. No diagnosed entropy collapse, isolated mechanism, paper replication or optimal muP transfer is claimed. Double-minus-half is reported separately.',
        'Measured training time is separate from quality; no equal-compute, serving-speed or peak-accelerator-memory claim.',
        'Final H200 tensors equal saved raw-parent shadows; endpoint evidence cannot reconstruct every historical snapshot. Earlier MPS reproducibility failures remain preserved without an identified cause.',
        'H200 checkpoints are inference-only; resume optimizer training only from their raw parent.']
    conclusion=dict(summary=summary,means=means,cost=cost,selection=r['selection'],comparisons=r['comparisons'],fixed_lr_screen=r['fixed_lr_screen'],quality_decision=v['quality_decision'],recipe=p['recipe'],output_bias_prior=p['output_bias_prior'],limitations=limitations,review=str(run/'review.json'),historical_incumbent_unchanged=not adopt)
    if not args.record:print(json.dumps(conclusion,indent=2));return
    conpath=BASE/'research_state/attention-scale-quality-conclusion.json';snapshot=BASE/'research_state/attention-scale-quality-completed-knowledge-snapshot.md';archive=BASE/'research_state/best-observed-before-attention-scale-quality001.json';bestpath=BASE/'research_state/best-observed-config.json'
    old=json.loads(bestpath.read_text());frozen=p['incumbent_snapshot'];assert file_digest(Path(frozen['path']))==frozen['sha256'];prior=json.loads(Path(frozen['path']).read_text())
    assert old['result_id']==prior['result_id']==frozen['result_id']
    for key in ('baseline_commit','baseline_config','config_overrides','returned_weights','selection'):assert old.get(key)==prior.get(key),'Concurrent incumbent change: '+key
    assert not conpath.exists() and not snapshot.exists()
    entry=dict(campaign=str(run),review=str(run/'review.json'),summary=summary,means=means,quality_decision=v['quality_decision'])
    if adopt:
        assert not archive.exists();lr=r['selection']['choices'][winner]['lr'];cfg=copy.deepcopy(study.suite_spec(p,winner,lr)['candidate']['config'])
        cfg['model']['vocab_size']=len(p['output_bias_prior']['alphabet'])
        verify_selected_model(p,winner,cfg)
        selected=[c for c in r['comparisons'] if c['candidate']==winner and c['reference']==REFERENCE];assert sorted(c['width'] for c in selected)==[64,256]
        updated=dict(label=f"Most promising observed recipe: four-layer MHA/SwiGLU, {winner}, H200",baseline_commit=p['git_commit'],baseline_config=cfg,config_overrides=[],reference_overrides={},source_campaign=str(run),source_iteration=None,evidence_path=str(run/'report.json'),source_contract=dict(source_sha256=p['source_sha256'],data_sha256=p['data_sha256']),previous_best=dict(path=str(archive),sha256=file_digest(bestpath),result_id=old['result_id']),returned_weights=dict(kind='spaced_tail_ema',half_life=200,purpose='inference_only_not_optimizer_resume',raw_training_parent_required=True,observed_training_config_has_three_shadows=False),selection=dict(path=str(run/'selection.json'),family=winner,attention_family='mha',input_embedding_scale=p['recipe']['input_embedding_scale'],attention_logit_scale={'baseline':1.,'half':.5,'double':2.}[winner],attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',residual_topology_kind=p['recipe']['residual_topology_kind'],residual_topology_width_policy='mha4_separate_norm_residual_topology',weight_tying_kind=p['recipe']['weight_tying_kind'],weight_tying_width_policy='mha4_scaled_table_sharing',output_bias_kind=p['recipe']['output_bias_kind'],output_bias_width_policy='mha4_train_bound_output_bias',output_bias_prior_sha256=p['output_bias_prior']['prior_sha256'],readout_norm_kind=p['recipe']['readout_norm_kind'],readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,warmup_steps=p['recipe']['warmup_steps'],learning_rate=lr,independent_decay=p['recipe']['weight_decay'],rule='Only frozen eligible recipe; mean gain>.005, every seed negative and all text upper bounds<0 versus fixed incumbent and tuned baseline for changed attention scale at both widths'),quality_decision=v['quality_decision'],local_outcome='supported',transfer_outcome='supported_at_tested_widths',metrics=[dict(target=f"width-{c['width']}",metric='full_validation_context128_ce_delta',candidate_mean=means[winner][str(c['width'])]['H200'],baseline_mean=means[REFERENCE][str(c['width'])]['H200'],**c['sensitivity'][0]) for c in selected],comparators=means,training_cost=cost,training_steps=3000,widths=[64,256],seeds=list(SEEDS),holdout_consumed=False,stage1_control_retained_as_reference=True,ranking_scope=limitations[0],limitations=limitations,learning_ids=[],subsequent_algorithm_studies=[])
        for key in ('constant_reference','raw_cooldown_reference'):
            if key in old:updated[key]=copy.deepcopy(old[key])
    else:updated=copy.deepcopy(old)
    artifacts=[run/n for n in ('plan.json','selection.json','report.json','review.json')]+[folder.parent/'completion-audit-tools001/completion-audit001.py',folder/'record-completion.py']
    bank=KnowledgeBank(BASE/'research_state/knowledge')
    kid=bank.add(dict(kind='result',outcome='supported' if adopt else 'mixed',created_by='continuing-quality-research',title='Fixed attention-logit scaling with equal LR tuning on the final reviewed backbone',summary=summary,scope=dict(source_commit=p['git_commit'],screen_seeds=[2401,2402],confirmation_seeds=list(SEEDS),widths=[64,256],physical_trajectories=len(s['records']),correlated_outputs=r['model_evaluations'],validation_targets=111538,holdout_consumed=False),details={**conclusion,'active_seconds':v['active_seconds'],'disk_mb':v['disk_mb']},artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in artifacts],related_ids=[p['preregistration_id'],p['implementation_id'],old['result_id']]))
    conclusion['result_id']=entry['result_id']=kid
    if adopt:archive.write_bytes(bestpath.read_bytes());archive.chmod(0o444);updated['result_id']=kid
    else:updated.setdefault('subsequent_algorithm_studies',[]).append(entry)
    updated['last_reviewed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    conpath.write_text(json.dumps(conclusion,indent=2)+'\n');bestpath.write_text(json.dumps(updated,indent=2)+'\n');snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
    lines=['# Fixed attention-logit scaling quality results','',summary,'',f"Historical source `{p['git_commit']}`. Result `{kid}`. All{v['distinct_checkpoints']} checkpoint hashes/payloads, requests/results, full coverage, optimizer/RNG/schedule/H200 contracts, frozen selection and complete report/bootstrap were independently reviewed. No training/evaluation rerun or holdout access.",'',f"Controller active time {v['active_seconds']:.2f}seconds; output before review {v['disk_mb']:.2f}MiB. [Frozen protocol](ATTENTION_SCALE_PROTOCOL.md).",'','## Fresh confirmation means','','Seeds2411/2412/2413;111,538 validation targets once each. H200 primary; raw correlated diagnostic.','','| Family | Selected peak LR | H200 CE64 | H200 CE256 | Raw CE64 | Raw CE256 |','|---|---:|---:|---:|---:|---:|']
    for family in families:lines.append(f"| {family} | {(p['recipe']['learning_rate'] if family==REFERENCE else r['selection']['choices'][family]['lr']):g} | {means[family]['64']['H200']:.6f} | {means[family]['256']['H200']:.6f} | {means[family]['64']['raw']:.6f} | {means[family]['256']['raw']:.6f} |")
    lines+=['','## Paired contrasts','','Positive is worse. Intervals use4096-token blocks; all three block sizes were audited.','','| Endpoint | Width | Contrast | Mean delta | Seed deltas | Conditional95% text interval | Primary support |','|---|---:|---|---:|---|---|---|']
    for c in r['comparisons']:
        for key,label in [('sensitivity','H200'),('raw_sensitivity','Raw')]:
            z=c[key][1];lo,hi=z['conditional_text_bootstrap_95pct'];ds=' / '.join(f"{z['paired_seed_deltas'][str(seed)]:+.6f}" for seed in SEEDS)
            support=str(c['quality_improvement']) if label=='H200' else 'Diagnostic'
            lines.append(f"| {label} | {c['width']} | {c['candidate']} minus {c['reference']} | {z['mean_delta']:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] | {support} |")
    lines+=['','## Fixed-LR screens','','| Contrast | H200 mean delta | Two seed deltas | Raw mean delta |','|---|---:|---|---:|']
    for x in r['fixed_lr_screen']:
        ds=' / '.join(f"{x['primary']['paired_seed_deltas'][str(seed)]:+.6f}" for seed in (2401,2402))
        lines.append(f"| LR{x['lr']:g}: {x['candidate']} minus {x['reference']} | {x['primary']['mean_delta']:+.6f} | {ds} | {x['raw']['mean_delta']:+.6f} |")
    lines+=['','## Measured training costs','','| Family | Width | Training seconds | Wall seconds | Ratio versus tuned baseline | Sampled RSS MiB |','|---|---:|---:|---:|---:|---:|']
    for family in families:
        for width,x in cost[family].items():lines.append(f"| {family} | {width} | {x['mean_training_seconds']:.2f} | {x['mean_trajectory_wall_seconds']:.2f} | {x['training_time_ratio_vs_baseline']:.3f} | {x['mean_sampled_rss_mb']:.2f} |")
    lines+=['','## Limits','']+['- '+x for x in limitations]
    Path('/private/tmp/ATTENTION_SCALE_RESULTS.md').write_text('\n'.join(lines)+'\n')
    Path('/private/tmp/attention-scale-quality-completed-guide-addition.md').write_text('## Completed fixed attention-logit scaling round\n\n'+summary+'\n\n[Full paired results and costs](ATTENTION_SCALE_RESULTS.md). Adaptive validation; no holdout.\n')
    print(kid);print(summary)


if __name__=='__main__':main()
