import unittest,tempfile
from pathlib import Path
from bounded_cpu import *

class Gates(unittest.TestCase):
 def test_collect_and_statuses(self):
  ids=['tests/a.py::test_x[failed]','tests/a.py::test_y'];text='\n'.join(ids)+'\n2 tests collected in 0.01s'
  self.assertEqual(collected_ids(text),ids)
  good='\n'.join(n+' PASSED [100%]' for n in ids)+'\n2 passed in 0.01s'
  self.assertEqual(passed_ids(good,0,ids)['ids'],ids)
  for bad in [good.replace('PASSED','SKIPPED',1),good.replace(ids[1],ids[0]),good.replace('2 passed','1 passed'),good.replace(ids[1],'tests/b.py::test_z')]:
   with self.assertRaises(ValueError):passed_ids(bad,0,ids)
  with self.assertRaises(ValueError):passed_ids(good,1,ids)
  with self.assertRaises(ValueError):collected_ids(text.replace('2 tests','3 tests'))
 def test_success_cleanup_keeps_receipt_and_log(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td).resolve()/'scratch';root.mkdir();batch=root/'batch-0000';batch.mkdir();(batch/'small.pt').write_bytes(b'synthetic checkpoint placeholder')
   (batch/'current').symlink_to('small.pt');log=root.parent/'passed.log';log.write_text('tests/a.py::ok PASSED [100%]\n1 passed in 0.01s')
   receipt=root.parent/'receipt.json';d=cleanup_passed_batch(root,batch,log,0,['tests/a.py::ok'],receipt)
   self.assertFalse(batch.exists());self.assertTrue(log.exists());self.assertTrue(receipt.exists());self.assertEqual(d['status'],'passed_scratch_removed');self.assertEqual(len(d['inventory']),2)
 def test_failure_and_external_link_preserved(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td).resolve()/'scratch';root.mkdir();batch=root/'batch-0000';batch.mkdir();p=batch/'failed.pt';p.write_bytes(b'failed evidence')
   log=root.parent/'failed.log';log.write_text('tests/a.py::ok FAILED [100%]\n1 failed in 0.01s');receipt=root.parent/'receipt.json'
   with self.assertRaises(ValueError):cleanup_passed_batch(root,batch,log,1,['tests/a.py::ok'],receipt)
   self.assertEqual(p.read_bytes(),b'failed evidence');self.assertFalse(receipt.exists())
   log.write_text('tests/a.py::ok PASSED [100%]\n1 passed in 0.01s');(batch/'external').symlink_to(log)
   with self.assertRaises(ValueError):cleanup_passed_batch(root,batch,log,0,['tests/a.py::ok'],receipt)
   self.assertTrue(p.exists());self.assertFalse(receipt.exists())
 def test_unsafe_paths_refused(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td).resolve()/'scratch';root.mkdir();batch=root/'arbitrary';batch.mkdir();log=root.parent/'passed.log';log.write_text('tests/a.py::ok PASSED\n1 passed in 0.01s')
   with self.assertRaises(ValueError):cleanup_passed_batch(root,batch,log,0,['tests/a.py::ok'],root.parent/'receipt')
   batch.rename(root/'batch-0000');batch=root/'batch-0000'
   with self.assertRaises(ValueError):cleanup_passed_batch(root,batch,log,0,['tests/a.py::ok'],batch/'receipt')
   link=root.parent/'link';link.symlink_to(root,target_is_directory=True)
   with self.assertRaises(ValueError):cleanup_passed_batch(link,link/'batch-0000',log,0,['tests/a.py::ok'],root.parent/'receipt')
   self.assertTrue(batch.exists())
 def test_process_routes(self):
  text='PID PPID COMMAND\n1 2 python -m src.research.weight_tying_study\n3 4 python -m pytest tests\n5 6 python -c pytest.main()\n7 8 python pilot-driver001.py\n9 10 python run-cpu-validation001.py\n11 12 python unrelated.py'
  self.assertEqual([x[0] for x in live_model_commands(text,{9})],[1,3,5,7])

if __name__=='__main__':unittest.main(verbosity=2)
