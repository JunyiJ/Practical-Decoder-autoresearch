"""Deferred serial per-file validation; only verified passed scratch may be removed."""
from pathlib import Path
import json,os,sys,subprocess,time,signal,datetime,shutil
from bounded_cpu import atomic_json,sha,collected_ids,passed_ids,live_model_commands,scratch_bytes,cleanup_passed_batch
BASE=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');ROOT=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');FOLDER=BASE/'research_state/attention-scale-preparation001'
SCRATCH=Path('/private/tmp/rsi-attention-scale-cpu001')
if Path.cwd()!=ROOT or 'PYTORCH_ENABLE_MPS_FALLBACK' in os.environ:raise ValueError('Use isolated cwd and unset MPS fallback')
active=json.loads((BASE/'research_state/active-campaign.json').read_text())
if active['kind']!='parallel_block_quality' or active['status']!='completed_reviewed':raise ValueError('Final reviewed parallel-block completion required before model imports')
run=Path(active['campaign']);review=json.loads((run/'review.json').read_text())
if review['status']!='verified' or json.loads((run/'state.json').read_text())['status']!='completed':raise ValueError('Complete predecessor evidence required')
live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
if live:raise ValueError('Competing model work: '+str(live))
if SCRATCH.exists() or (FOLDER/'cpu-execution-manifest.json').exists():raise ValueError('Preserve previous validation; no automatic retry')
if shutil.disk_usage('/private/tmp').free<10*2**30:raise ValueError('At least10GiB scratch headroom required')
from src.research.team.suite import source_digest
integration=json.loads((FOLDER/'integration-review.json').read_text());source=source_digest(ROOT)
if source!=integration['source_sha256']:raise ValueError('Integrated source digest mismatch')
test_hashes={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'tests').rglob('*.py'))}
def verify():
    if source_digest(ROOT)!=source:raise ValueError('Source changed during validation')
    for item in integration['files']:
        if sha(ROOT/item['path'])!=item['sha256']:raise ValueError('Integrated file changed')
    if {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'tests').rglob('*.py'))}!=test_hashes:raise ValueError('Test source changed')
verify();SCRATCH.mkdir();manifest=FOLDER/'cpu-execution-manifest.json';record=dict(status='running',pid=os.getpid(),active_pid=None,source_sha256=source,test_hashes=test_hashes,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),batches=[],scratch_root=str(SCRATCH),scratch_limit_gib=8,disk_free_min_gib=10)
def save():atomic_json(manifest,record)
save();env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.')
wrapper='import torch;torch.set_num_threads(1);import pytest,sys;sys.exit(pytest.main(sys.argv[1:]))'
def execute(args,log,seconds,scratch):
    if log.exists():raise ValueError('Preserve existing log')
    started=time.monotonic();code=None
    with log.open('x') as out:
        child=subprocess.Popen([sys.executable,'-u','-c',wrapper,*args],cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        record['active_pid']=child.pid;save()
        while child.poll() is None:
            if time.monotonic()-started>seconds:code=124
            elif scratch_bytes(scratch)>8*2**30 or shutil.disk_usage('/private/tmp').free<2*2**30:code=125
            if code is not None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                break
            time.sleep(.5)
        if code is None:code=child.returncode
    record['active_pid']=None;save();return code,time.monotonic()-started
try:
    log=FOLDER/'full-collection.log';code,seconds=execute(['tests','--collect-only','-q','--color=no','-p','no:cacheprovider'],log,120,SCRATCH)
    if code:raise ValueError('Collection failed')
    ids=collected_ids(log.read_text());actual=['tests/test_attention_scale_geometry.py','tests/test_attention_scale_training.py']
    if len(ids)!=3264 or [sum(n.startswith(f+'::') for n in ids) for f in actual]!=[12,12]:raise ValueError('Reviewed3264 collection and24actual cases required')
    record['collection']=dict(log=str(log),exit_code=code,seconds=seconds,ids=ids);save()
    files=actual+sorted({n.split('::')[0] for n in ids}-set(actual));budgets={'actual':900.,'remaining':3600.}
    for i,f in enumerate(files):
        verify();label='actual' if f in actual else 'remaining'
        if shutil.disk_usage('/private/tmp').free<10*2**30:raise ValueError('Insufficient headroom for next batch; preserve evidence')
        if budgets[label]<=0:raise ValueError('CPU partition wall budget exhausted')
        scratch=SCRATCH/f'batch-{i:04d}';scratch.mkdir();log=FOLDER/f'cpu-batch-{i:04d}.log';expected=[n for n in ids if n.startswith(f+'::')]
        code,seconds=execute([f,'-vv','-x','--color=no','-p','no:cacheprovider','--basetemp',str(scratch)],log,budgets[label],scratch);budgets[label]-=seconds
        item=dict(file=f,partition=label,log=str(log),log_sha256=sha(log),exit_code=code,seconds=seconds,expected_ids=expected,scratch=str(scratch));record['batches'].append(item);save()
        passed_ids(log.read_text(),code,expected);verify()
        receipt=FOLDER/f'cpu-batch-{i:04d}-cleanup.json';cleanup_passed_batch(SCRATCH,scratch,log,code,expected,receipt);item['cleanup']=str(receipt);save()
    verify();record.update(status='completed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print('CPU batches completed; independent exact-ID review remains required',flush=True)
except BaseException as exc:
    record.update(status='failed',error=repr(exc),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
