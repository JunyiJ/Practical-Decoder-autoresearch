import copy,importlib.util,unittest
from pathlib import Path
p=Path(__file__).with_name('record-cpu-review001.py');s=importlib.util.spec_from_file_location('recorder',p);r=importlib.util.module_from_spec(s);s.loader.exec_module(r)

def fixture():
 counts={**r.EXPECTED,'tests/test_historical.py':3030};names=[f+'::test_'+str(i) for f,n in counts.items() for i in range(n)];collection='\n'.join(names)+'\n3264 tests collected in 0.01s'
 files=list(r.EXPECTED)[:2]+sorted(set(counts)-set(list(r.EXPECTED)[:2]));m=dict(status='completed',active_pid=None,collection=dict(ids=names,exit_code=0),scratch_root='/private/tmp/synthetic-only-cpu',batches=[]);logs={};receipts={}
 for i,f in enumerate(files):
  ids=[n for n in names if n.startswith(f+'::')];logs[i]='\n'.join(n+' PASSED [100%]' for n in ids)+f'\n{len(ids)} passed in 0.01s';part='actual' if f in list(r.EXPECTED)[:2] else 'remaining'
  item=dict(file=f,expected_ids=ids,partition=part,exit_code=0,scratch=m['scratch_root']+f'/batch-{i:04d}',log=f'/synthetic/log{i}',log_sha256='a'*64);m['batches'].append(item)
  receipts[i]=dict(status='passed_scratch_removed',batch=item['scratch'],log=item['log'],log_sha256=item['log_sha256'],exit_code=0,verified=dict(ids=ids,seconds=.01,warnings=0),bytes=0,inventory=[])
 return m,collection,logs,receipts

class Recorder(unittest.TestCase):
 def test_exact_partition(self):
  out=r.verify_records(*fixture());self.assertEqual(out['passed'],3264);self.assertEqual(out['actual_tests'],24);self.assertEqual(out['metadata_tests'],210)
 def test_corruptions(self):
  for damage in ['status','pid','collection','batch_exit','missing','repeat','partition','id','receipt_status','receipt_log','receipt_hash','receipt_bytes','scratch','skip','duplicates','ordering']:
   with self.subTest(damage=damage):
    m,c,l,rs=fixture()
    if damage=='status':m['status']='running'
    elif damage=='pid':m['active_pid']=123
    elif damage=='collection':c=c.replace('3264 tests','3029 tests')
    elif damage=='batch_exit':m['batches'][0]['exit_code']=1
    elif damage=='missing':m['batches'].pop()
    elif damage=='repeat':m['batches'].append(m['batches'][0])
    elif damage=='partition':m['batches'][0]['partition']='remaining'
    elif damage=='id':m['batches'][0]['expected_ids'].pop()
    elif damage=='receipt_status':rs[0]['status']='passed_scratch_inventoried'
    elif damage=='receipt_log':rs[0]['log']='elsewhere'
    elif damage=='receipt_hash':rs[0]['log_sha256']='b'*64
    elif damage=='receipt_bytes':rs[0]['bytes']=1
    elif damage=='scratch':m['batches'][0]['scratch']='/private/tmp/unrelated'
    elif damage=='skip':l[0]=l[0].replace('PASSED','SKIPPED',1)
    elif damage=='duplicates':l[0]+=l[0]
    else:m['batches'].reverse()
    with self.assertRaises((ValueError,KeyError,IndexError)):r.verify_records(m,c,l,rs)
if __name__=='__main__':unittest.main(verbosity=2)
