"""Independently verify complete CPU coverage and every bounded-scratch receipt."""
import json,datetime,argparse
from pathlib import Path
from bounded_cpu import collected_ids,passed_ids,sha
EXPECTED={'tests/test_attention_scale_geometry.py':12,'tests/test_attention_scale_training.py':12,'tests/test_attention_scale_contract.py':48,'tests/test_attention_scale_study.py':103,'tests/test_attention_scale_predecessor.py':23,'tests/test_attention_scale_report_audit.py':36}


def verify_records(manifest,collection,logs,receipts):
    if manifest['status']!='completed' or manifest.get('active_pid') is not None:raise ValueError('CPU execution must be terminal successful')
    names=collected_ids(collection)
    if len(names)!=3264 or manifest['collection']['ids']!=names or manifest['collection']['exit_code']!=0:raise ValueError('Full3264-case collection required')
    if {f:sum(n.startswith(f+'::') for n in names) for f in EXPECTED}!=EXPECTED:raise ValueError('New actual and metadata partitions differ')
    executed=[];actual=0;seconds=0;warnings=0;files=[];actual_files=list(EXPECTED)[:2]
    expected_files=actual_files+sorted({n.split('::')[0] for n in names}-set(actual_files))
    for i,item in enumerate(manifest['batches']):
        f=item['file'];files.append(f);selected=[n for n in names if n.startswith(f+'::')]
        partition='actual' if f in actual_files else 'remaining'
        if item['expected_ids']!=selected or item['partition']!=partition:raise ValueError('Batch partition or identifiers changed')
        result=passed_ids(logs[i],item['exit_code'],selected);executed+=result['ids'];seconds+=result['seconds'];warnings+=result['warnings']
        if partition=='actual':actual+=len(result['ids'])
        receipt=receipts[i]
        if (receipt['status']!='passed_scratch_removed' or receipt['batch']!=item['scratch']
            or receipt['log']!=item['log'] or receipt['log_sha256']!=item['log_sha256']
            or receipt['exit_code']!=0 or receipt['verified']!=result
            or receipt['bytes']!=sum(x['bytes'] for x in receipt['inventory'] if x['kind']=='file')):raise ValueError('Successful scratch cleanup receipt changed')
        if Path(item['scratch'])!=Path(manifest['scratch_root'])/f'batch-{i:04d}':raise ValueError('Scratch batch outside expected namespace')
    if files!=expected_files or len(executed)!=len(set(executed)) or set(executed)!=set(names) or actual!=24:raise ValueError('Missing/repeated CPU cases or incorrect actual-first ordering')
    if len(logs)!=len(files) or len(receipts)!=len(files):raise ValueError('Extra or missing evidence')
    return dict(collected=3264,passed=3264,actual_tests=24,remaining_tests=3240,metadata_tests=210,warnings=warnings,total_test_seconds=seconds,batches=len(files),failed=0)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--folder',type=Path,required=True);args=ap.parse_args();folder=args.folder.resolve();root=Path.cwd()
    from src.research.team.suite import source_digest
    manifest_path=folder/'cpu-execution-manifest.json';m=json.loads(manifest_path.read_text());integration_path=folder/'integration-review.json';integration=json.loads(integration_path.read_text())
    if source_digest(root)!=m['source_sha256'] or integration['source_sha256']!=m['source_sha256']:raise ValueError('CPU source changed')
    if {str(p.relative_to(root)):sha(p) for p in sorted((root/'tests').rglob('*.py'))}!=m['test_hashes']:raise ValueError('Test source changed')
    artifacts=[manifest_path,integration_path,folder/'full-collection.log',Path(__file__),Path(__file__).with_name('bounded_cpu.py')]
    for x in integration['files']:
        f=root/x['path']
        if sha(f)!=x['sha256']:raise ValueError('Integrated file mismatch')
        artifacts.append(f)
    logs={};receipts={}
    for i,item in enumerate(m['batches']):
        log=Path(item['log']);receipt=Path(item['cleanup'])
        if sha(log)!=item['log_sha256'] or Path(item['scratch']).exists():raise ValueError('Changed log or claimed cleanup incomplete')
        logs[i]=log.read_text();receipts[i]=json.loads(receipt.read_text());artifacts.extend([log,receipt])
    result=verify_records(m,(folder/'full-collection.log').read_text(),logs,receipts)
    review=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=m['source_sha256'],full_tests=result,actual_attention_scale_geometry_tests_passed=12,actual_attention_scale_training_tests_passed=12,attention_scale_metadata_tests_passed=210,checks=['Exact3264 unique cases, actual24 first, all remaining3240, no skipped/repeated cases','All source/test hashes frozen throughout batch validation','Each passed batch exactIDs/log verified before durable scratch inventory and cleanup; failed batch retains scratch'],limitations=['CPU correctness is not model quality or MPS evidence','Successful temporary test checkpoints removed only after assertions passed; logs and full path/size/hash inventory remain','Six serial actual MPS pilots and independent math/checkpoint/resource audit still required'],artifacts=[dict(path=str(p.resolve()),sha256=sha(p)) for p in dict.fromkeys(artifacts)])
    out=folder/'cpu-review.json'
    if out.exists():raise ValueError('Preserve earlier review')
    out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
