"""Audit saved FFN hidden-norm pilot evidence and forecast bounded resources; no training/scoring."""
import argparse,datetime,json,math,subprocess
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.research import ffn_hidden_norm_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint,load_model_weights
from src.train.lr_schedule import multiplier

parser=argparse.ArgumentParser();parser.add_argument('--pilots',type=Path,required=True);args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=base/'research_state/ffn-hidden-norm-validation'
p=study.make_plan(source,base/'research_runs/output-gate-quality-001/review.json');assert p['returned_half_life']==200
cpu_path=folder/'cpu-review.json';cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
tests=cpu['full_tests'];assert cpu['status']=='cpu_verified' and tests['passed']==tests['collected']>=1485 and tests['failed']==0
assert cpu['actual_ffn_hidden_norm_training_tests_passed']==14
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==6
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
intent=json.loads((args.pilots/'intent.json').read_text())
assert intent['source_commit']==p['git_commit'] and intent['source_sha256']==p['source_sha256']
assert intent['cpu_review_sha256']==file_digest(cpu_path) and intent['pilot_driver_sha256']==file_digest(folder/'pilot-driver.py')
assert intent['predecessor_review']==p['predecessor_review'] and intent['resolved_recipe']==p['recipe']
assert intent['seed']==9341 and intent['holdout_consumed'] is False
assert intent['hard_limits']==dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024)
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
artifacts=[cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver.py',folder/'completion-audit.py',source/'research/FFN_HIDDEN_NORM_PROTOCOL.md',Path(p['predecessor_review']['path'])]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
# Preserve earlier failed MPS agreement evidence; only unchanged general averaging
# arithmetic is inherited, not a claim about independent trajectory reproducibility.
for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 assert (source/rel).read_bytes()==subprocess.check_output(['git','show','280ea428792d4dd31780123d14846d5302d43227:'+rel],cwd=source)
for rel in ['averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-mps-coupled-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
checks=[];torch.set_num_threads(1)
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=30,20
 job=dict(family=f,lr=.005,width=w,n_heads=w//32,seed=9341,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,.005),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total
 desired=json.loads(json.dumps(req['config']));desired['model']['vocab_size']=65;assert cp['cfg']==desired
 avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True);names=dict(model.named_parameters())
 expected_count=132*w+4*(4*w*w+6*w+3*w*(21*w//8))+(4*w*(w//32) if p['recipe']['attention_output_gate']=='sigmoid_headwise_zero' else 0)+(4*(21*w//8)*(2 if f=='layer' else 1) if f!='none' else 0)
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 for i in range(4):
  weights=cp['model_state'];prefix=f'transformer.h.{i}.'
  assert weights[prefix+'attn.qkv.weight'].shape==(3*w,w) and weights[prefix+'attn.out.weight'].shape==(w,w)
  assert weights[prefix+'mlp.linear_gate.weight'].shape==(21*w//8,w)
  assert weights[prefix+'mlp.linear_up.weight'].shape==(21*w//8,w)
  assert weights[prefix+'mlp.linear_down.weight'].shape==(w,21*w//8)
  for kind in ('q','k'):
   name=prefix+'attn.'+kind+'_norm.weight'
   assert name not in weights
  gate_name=prefix+'attn.output_gate.weight'
  if p['recipe']['attention_output_gate']=='sigmoid_headwise_zero':
   assert weights[gate_name].shape==(w//32,w) and torch.count_nonzero(weights[gate_name])>0
  else:assert gate_name not in weights
  norm_prefix=prefix+'mlp.hidden_norm.'
  norm=model.transformer.h[i].mlp.hidden_norm
  if f=='none':
   assert norm is None and not any(n.startswith(norm_prefix) for n in weights)
  else:
   assert norm.eps==1e-5 and weights[norm_prefix+'weight'].shape==(21*w//8,)
   if f=='layer':assert weights[norm_prefix+'bias'].shape==(21*w//8,)
   else:assert norm_prefix+'bias' not in weights
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==.00006
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 for metric in raw['metrics']:assert metric['lr_multiplier']==multiplier(t['lr_schedule'],metric['step'])
 seen=set()
 assert cp['optimizer_state']['independent_decay']==.00006
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   name,=g['parameter_names'];assert name not in seen;seen.add(name)
   matrix=name.startswith('transformer.h.') and names[name].ndim==2;scale=1/math.sqrt(w/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==.005*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'}
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==names[name].shape
 assert seen==set(names)
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved)
 for name,value in saved['model_state'].items():assert torch.equal(value,avg['averages']['200'][name] if name in names else cp['model_state'][name])
 gen=torch.Generator().manual_seed(9341);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 cache_path=d/'cache-check.pt';assert file_digest(cache_path)==row['cached_evidence_sha256'];artifacts.append(cache_path)
 cache=torch.load(cache_path,map_location='cpu',weights_only=True);finite(cache)
 assert cache['derived_checkpoint_sha256']==item['checkpoint_sha256'] and cache['atol']==1e-4 and cache['rtol']==2e-5
 assert cache['full_logits'].shape==cache['cached_logits'].shape==(2,11,65)
 assert torch.equal(cache['tokens'],torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9341)))
 torch.testing.assert_close(cache['full_logits'],cache['cached_logits'],atol=1e-4,rtol=2e-5)
 assert math.isclose((cache['full_logits']-cache['cached_logits']).abs().max().item(),row['cached_full_max_abs_error'],abs_tol=0,rel_tol=0)
 assert len(row['norm_math'])==(0 if f=='none' else 1)
 for check in row['norm_math']:
  assert check['kind']==f;path=d/'norm-math.pt';assert file_digest(path)==check['sha256'];artifacts.append(path)
  v=torch.load(path,map_location='cpu',weights_only=True);finite(v)
  assert v['derived_checkpoint_sha256']==item['checkpoint_sha256'] and v['atol']==1e-4 and v['rtol']==2e-5 and v['eps']==1e-5
  assert v['x'].shape==(2,7,21*w//8)
  assert torch.equal(v['x'],torch.randn(2,7,21*w//8,generator=torch.Generator().manual_seed(9342)))
  assert torch.equal(v['coefficient'],torch.linspace(-.1,.1,v['x'].numel()).reshape(v['x'].shape))
  x=v['x'].double().requires_grad_();weight=v['weight'].double().requires_grad_()
  assert torch.equal(weight,saved['model_state']['transformer.h.0.mlp.hidden_norm.weight'].double())
  if f=='layer':
   bias=v['bias'].double().requires_grad_()
   assert torch.equal(bias,saved['model_state']['transformer.h.0.mlp.hidden_norm.bias'].double())
  else:
   assert v['bias'] is None
   bias=None
  center=x-x.mean(-1,keepdim=True) if f=='layer' else x
  expected=center/(center.square().mean(-1,keepdim=True)+1e-5).sqrt()*weight
  if f=='layer':expected=expected+bias
  grads=torch.autograd.grad((expected*v['coefficient'].double()).sum(),(x,weight,bias) if f=='layer' else (x,weight))
  assert len(v['gradients'])==len(grads)
  errors=[]
  for actual,reference in zip([v['output']]+v['gradients'],[expected]+list(grads)):
   torch.testing.assert_close(actual.double(),reference,atol=1e-4,rtol=2e-5)
   errors.append((actual.double()-reference).abs().max().item())
  assert len(check['max_abs_errors'])==len(errors) and all(math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-12) for a,b in zip(errors,check['max_abs_errors']))
 assert 0<row['training_seconds']<=row['wall_seconds']<240 and row['sampled_peak_rss_mb']<4096 and row['current_driver_mb']<6144
 assert row['driver_allocation_is_not_peak'] is True
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.append(d/'review.json');checks.append(row)
# Worst-case42jobs: each family6screens plus3small/3large selected confirmations,
# and six separate standard fixed-reference runs. Exact aliases may reduce this.
seconds=0;storage=0;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=(12 if f=='none' else 9) if w==64 else (6 if f=='none' else 3)
 estimate=1.5*(row['training_seconds']*3000/row['steps']+row['wall_seconds']-row['training_seconds'])
 assert estimate<2400;seconds+=count*estimate
 size=row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2;storage+=count*size*1.5
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate))
assert sum(x['trajectories'] for x in proxies)==42 and seconds<21600 and storage/1024**2<4096
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=list((base/'research_runs').glob('*/plan.json'))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=dict(hours=seconds/3600,trial_proxies=proxies,total_mb_with_margin=storage/1024**2,
 method='Worst-case42trajectories; scale each measured30-update pilot training by100, retain measured two-output plus cache-check overhead, add50%margin. Raw+derived bytes plus25MiBmetadata per trajectory and50%margin. Forecast, not measured production cost.'),
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Full collected CPU suite passed, including14actual training/resume/norm-optimizer/averaging cases',
 'Six actual serial MPS shortened3family/2width jobs;12full validation panels, finite strict CPU raw/derived loads, exact H200 derivation',
 'Saved full/cached logits independently checked; saved MPS normalization outputs/input/gain/bias gradients checked against independent CPUfloat64 formula',
 'Default/common initialization and private data RNG preserved; explicit FFN hidden-norm resume contract; heldout RNG untouched',
 'Newnormgain/biasvectors useAdamW/baseLR/independentdecay; adds672/2688RMSor1344/5376LNparams64/256; finalreviewedattentiongate unchanged',
 'Final adopted output-gate resolved only from completedreview; finite36or42physicaltrajectories72or84correlatedoutputs, exactaliases, freshfrozenwinner beforeconfirmation'],
 limitations=['Short synthetic pilots excluded from quality findings','Resource forecasts are estimates; watchdog and hard caps stillapply','Current driver allocation is not peak memory','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness relies on separately tested frozen implementation','No optimalLR/muP transfer, seed-population inference or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=folder/'review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
