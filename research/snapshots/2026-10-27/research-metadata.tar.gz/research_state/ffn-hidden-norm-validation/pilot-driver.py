"""Six serial ffn-hidden-norm MPS pilots; require final output-gate review and full CPU tests."""
import argparse,json,math,os,re,subprocess,time,threading
from pathlib import Path


def post_worker_watchdog(output, jobdir, remaining, completed_jobs):
    """Bound native MPS checks after the separately bounded worker has exited."""
    if not math.isfinite(remaining) or remaining<=0:
        raise TimeoutError('Pilot budget exhausted before post-worker correctness checks')
    def expired():
        from src.research.runner import atomic_json
        try:
            atomic_json(Path(output)/'failure.json',dict(error='Post-worker correctness wall-time limit reached',
                phase='post_worker_correctness',job=str(jobdir),completed_jobs=completed_jobs,no_automatic_retry=True))
        finally:
            os._exit(88)
    timer=threading.Timer(remaining,expired);timer.daemon=True;timer.start()
    return timer


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-pilots',action='store_true');parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-review',type=Path,required=True);args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):raise ValueError('Unset fallback')
    base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();prior=base/'research_runs/output-gate-quality-001'
    active=json.loads((base/'research_state/active-campaign.json').read_text())
    if Path(active['campaign'])!=prior or active['status']!='completed_reviewed':raise ValueError('Completed reviewed output-gate predecessor required')
    if json.loads((prior/'state.json').read_text())['status']!='completed':raise ValueError('Predecessor still active')
    processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
    live=[x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
    if live:raise ValueError('Competing model work: '+str(live))
    import torch
    from omegaconf import OmegaConf
    from src.models.gpt import GPT
    from src.attention.cache import KVCache
    from src.utils.checkpoint import read_checkpoint,load_model_weights
    from src.train.lr_schedule import multiplier
    from src.research import ffn_hidden_norm_study as study
    from src.research.averaging_eval import validate_derivation
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest,_request,_launch
    from src.research.runner import atomic_json,session_lock,validate_result,disk_mb
    torch.set_num_threads(1)
    sha=source_digest(source);driver_sha=file_digest(Path(__file__).resolve());cpu=json.loads(args.cpu_review.read_text());tests=cpu['full_tests']
    if (cpu['status']!='cpu_verified' or cpu['source_sha256']!=sha or tests['passed']!=tests['collected']
            or tests['collected']<1485 or tests['failed']!=0 or cpu['actual_ffn_hidden_norm_training_tests_passed']!=14):
        raise ValueError('Complete matching full CPU suite and fourteen actual ffn-hidden-norm training gates required')
    for a in cpu['artifacts']:
        if file_digest(Path(a['path']))!=a['sha256']:raise ValueError('CPU evidence changed')
    if subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise ValueError('Dirty source')
    p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
    out=args.output.resolve();assert out.is_relative_to(base/'research_state');out.mkdir(exist_ok=False)
    atomic_json(out/'intent.json',dict(source_commit=p['git_commit'],source_sha256=sha,cpu_review_sha256=file_digest(args.cpu_review),pilot_driver_sha256=driver_sha,
        predecessor_review=p['predecessor_review'],resolved_recipe=p['recipe'],seed=9341,
        purpose='Shortened ffn-hidden-norm train/reload/raw+H200 coverage and cached/full/independent hidden-norm gradients; excluded from research',
        hard_limits=dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024),holdout_consumed=False))
    began=time.monotonic();rows=[]
    def finite(x):
        if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
        elif isinstance(x,dict):
            for v in x.values():finite(v)
        elif isinstance(x,(list,tuple)):
            for v in x:finite(v)
        elif isinstance(x,float):assert math.isfinite(x)
    post_timer=None
    with session_lock(out) as fd:
        try:
            for w in (64,256):
                for f in study.FAMILIES:
                    assert source_digest(source)==sha and file_digest(Path(__file__).resolve())==driver_sha
                    d=out/f'w{w}_{f}';d.mkdir();job=dict(family=f,lr=.005,width=w,n_heads=w//32,seed=9341,stage='local',arm='candidate',trial_id=d.name)
                    req=_request(study.suite_spec(p,f,.005),job,d);t=req['config']['training']
                    total,start=30,20
                    t.update(max_iters=total,eval_every=10,eval_iters=2)
                    t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
                    atomic_json(d/'request.json',req);started=time.monotonic()
                    allowance=min(240,1800-(started-began));assert allowance>0
                    status,error=_launch(d/'request.json',out,allowance,1024,fd,root=source,bootstrap=study.BOOTSTRAP)
                    if status!='completed':raise RuntimeError((status,error))
                    post_timer=post_worker_watchdog(out,d,min(240-(time.monotonic()-started),1800-(time.monotonic()-began)),len(rows))
                    raw=json.loads((d/'result.json').read_text());checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
                    extra=study.adapter(p,raw,checked,req,d);cp=read_checkpoint(checked['checkpoint']);finite(cp)
                    assert cp['step']==total and raw['completed_steps']==total
                    wanted=json.loads(json.dumps(req['config']));wanted['model']['vocab_size']=65;assert cp['cfg']==wanted
                    cfg=OmegaConf.create(cp['cfg'])
                    with torch.random.fork_rng(devices=[]):
                        model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
                    names=dict(model.named_parameters());state=cp['model_state']
                    gains={n for n in names if n.endswith(('.q_norm.weight','.k_norm.weight'))}
                    assert not gains
                    expected_count=132*w+4*(4*w*w+6*w+3*w*(21*w//8))+(4*w*(w//32) if p['recipe']['attention_output_gate']=='sigmoid_headwise_zero' else 0)+(4*(21*w//8)*(2 if f=='layer' else 1) if f!='none' else 0)
                    assert sum(v.numel() for v in model.parameters())==expected_count
                    assert all(state[n].shape==(32,) for n in gains)
                    gates={n for n in names if n.endswith('output_gate.weight')}
                    assert len(gates)==(4 if p['recipe']['attention_output_gate']=='sigmoid_headwise_zero' else 0)
                    norms={n for n in names if '.mlp.hidden_norm.' in n}
                    assert len(norms)==(0 if f=='none' else 8 if f=='layer' else 4)
                    assert all(state[n].shape==(21*w//8,) for n in norms)
                    assert all(state[n].shape==(w//32,w) and torch.count_nonzero(state[n])>0 for n in gates)
                    avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
                    gen=torch.Generator().manual_seed(9341);text=Path(req['config']['data']['path']).read_text()
                    for _ in range(total):torch.randint(int(.8*len(text))-512,(2,),generator=gen)
                    assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
                    assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
                    for m in raw['metrics']:assert m['lr_multiplier']==multiplier(t['lr_schedule'],m['step'])
                    assert raw['metrics'][-1]['tokens_processed']==1024*total and abs(raw['metrics'][-1]['lr_multiplier']-.1)<1e-12
                    seen=set()
                    for opt in cp['optimizer_state']['optimizers']:
                        for g in opt['param_groups']:
                            name,=g['parameter_names'];seen.add(name);slot=opt['state'][g['params'][0]]
                            matrix=name.startswith('transformer.h.') and names[name].ndim==2
                            assert g['width_lr_scale']==(1/math.sqrt(w/64) if matrix else 1.)
                            if name in norms:
                                assert slot['step'].item()==total and set(slot)=={'step','exp_avg','exp_avg_sq'}
                                assert torch.count_nonzero(slot['exp_avg_sq'])>0
                                assert g['width_lr_scale']==1.
                            if name in gates:assert set(slot)=={'momentum_buffer'} and torch.count_nonzero(slot['momentum_buffer'])>0
                    assert seen==set(names)
                    item=extra['averaged_outputs']['200'];derived=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
                    assert 'optimizer_state' not in derived and 'training_state' not in derived
                    load_model_weights(model,derived);finite(derived)
                    assert extra['coverage']['128']['target_count']==item['coverage']['evaluations']['128']['target_count']==111538
                    # Serial saved-weight inference only, after the training worker exited.
                    model=model.to('mps').eval();idx=torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9341)).to('mps')
                    with torch.no_grad():
                        full=model(idx)[0]
                        caches=[KVCache(cfg,'mps',batch_size=2) for _ in range(4)]
                        parts=[];position=0
                        for count in (5,3,3):
                            parts.append(model(idx[:,position:position+count],cache=caches,start_pos=position)[0]);position+=count
                        cached=torch.cat(parts,1);error=(full-cached).abs().max().item()
                        torch.testing.assert_close(full,cached,atol=1e-4,rtol=2e-5)
                        cache_evidence=dict(tokens=idx.cpu(),full_logits=full.cpu(),cached_logits=cached.cpu(),
                            derived_checkpoint_sha256=item['checkpoint_sha256'],atol=1e-4,rtol=2e-5)
                        torch.save(cache_evidence,d/'cache-check.pt')
                    math_checks=[]
                    if f!='none':
                        norm=model.transformer.h[0].mlp.hidden_norm
                        xc=torch.randn(2,7,21*w//8,generator=torch.Generator().manual_seed(9342))
                        cc=torch.linspace(-.1,.1,xc.numel()).reshape(xc.shape)
                        x=xc.to('mps').requires_grad_()
                        inputs=(x,norm.weight,norm.bias) if f=='layer' else (x,norm.weight)
                        actual=norm(x);grads=torch.autograd.grad((actual*cc.to('mps')).sum(),inputs)
                        xr=xc.double().requires_grad_();wr=norm.weight.detach().cpu().double().requires_grad_()
                        br=norm.bias.detach().cpu().double().requires_grad_() if f=='layer' else None
                        center=xr-xr.mean(-1,keepdim=True) if f=='layer' else xr
                        expected=center/(center.square().mean(-1,keepdim=True)+1e-5).sqrt()*wr
                        if f=='layer':expected=expected+br
                        refs=torch.autograd.grad((expected*cc.double()).sum(),(xr,wr,br) if f=='layer' else (xr,wr))
                        evidence=dict(kind=f,x=xc,coefficient=cc,weight=wr.detach(),bias=br.detach() if br is not None else None,
                            output=actual.detach().cpu(),gradients=[v.detach().cpu() for v in grads],
                            derived_checkpoint_sha256=item['checkpoint_sha256'],atol=1e-4,rtol=2e-5,eps=1e-5)
                        errors=[]
                        for observed,reference in zip([evidence['output']]+evidence['gradients'],[expected]+list(refs)):
                            torch.testing.assert_close(observed.double(),reference,atol=1e-4,rtol=2e-5)
                            errors.append((observed.double()-reference).abs().max().item())
                        torch.save(evidence,d/'norm-math.pt')
                        math_checks.append(dict(kind=f,max_abs_errors=errors,sha256=file_digest(d/'norm-math.pt')))
                        del norm,x,actual,grads,xr,wr,br,center,expected,refs,inputs
                    driver_mb=torch.mps.driver_allocated_memory()/1024**2;assert driver_mb<6144
                    del full,cached,caches,parts,idx,model,names;torch.mps.synchronize();torch.mps.empty_cache()
                    rss=max(x['rss_mb'] for x in raw['metrics']);assert rss<4096
                    row=dict(width=w,family=f,steps=total,cooldown_start=start,snapshots=avg['snapshots'],status='verified',
                        training_seconds=raw['training_time_sec'],wall_seconds=time.monotonic()-started,sampled_peak_rss_mb=rss,
                        cached_full_max_abs_error=error,current_driver_mb=driver_mb,driver_allocation_is_not_peak=True,
                        cached_evidence_sha256=file_digest(d/'cache-check.pt'),norm_math=math_checks,
                        parameter_count=expected_count,raw_checkpoint_bytes=Path(checked['checkpoint']).stat().st_size,
                        derived_checkpoint_bytes=Path(item['checkpoint']).stat().st_size,checkpoint_sha256=checked['checkpoint_sha256'],
                        derived_checkpoint_sha256=item['checkpoint_sha256'],request_sha256=file_digest(d/'request.json'),result_sha256=file_digest(d/'result.json'))
                    assert row['wall_seconds']<240 and time.monotonic()-began<1800
                    atomic_json(d/'review.json',row);rows.append(row);post_timer.cancel();post_timer=None;print(row,flush=True)
        except Exception as e:
            if post_timer is not None:post_timer.cancel()
            atomic_json(out/'failure.json',dict(error=repr(e),completed_jobs=len(rows),no_automatic_retry=True));raise
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,rows=rows,excluded_from_research=True,
        holdout_consumed=False,disk_mb=disk_mb(out)))

if __name__=='__main__':main()
