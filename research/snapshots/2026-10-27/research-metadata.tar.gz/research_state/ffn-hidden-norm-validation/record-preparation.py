"""Preserve source-only preparation while the prior frozen study trains."""
import ast,datetime,hashlib,json,tarfile
from pathlib import Path
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');dev=Path('/private/tmp/rsi-ffn-hidden-norm-development');folder=root/'research_state/ffn-hidden-norm-validation'
files=['src/models/ffn_hidden_norm.py','src/models/mlp.py','src/models/blocks.py','src/models/gpt.py','src/train/optimizers.py','tests/test_ffn_hidden_norm_math.py','research/FFN_HIDDEN_NORM_PROTOCOL.md']
for f in files:
 if f.endswith('.py'):ast.parse((dev/f).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=folder/'prototype001.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for f in files:t.add(dev/f,arcname=f)
archive.chmod(0o444)
algebra=folder/'reference-algebra-first.json';a=json.loads(algebra.read_text());assert a['status']=='reference_algebra_verified' and a['model_tests_run']==0 and len(a['cases'])==8
review=dict(status='source_prepared_not_model_verified',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),development_root=str(dev),base_commit='047008b4b59d8141f5463f793c39798fee006a17',
 active_study='output-gate-quality-001',active_source_modified=False,primary_kimi_modified=False,model_tests_run=0,training_runs=0,holdout_consumed=False,
 exact_arms=['none','rms','layer'],norm_epsilon=1e-5,placement='after_SwiGLU_product_before_down_projection',new_parameters64_256=dict(none=[0,0],rms=[672,2688],layer=[1344,5376]),
 reference_algebra_cases=8,reference_algebra_scope=a['scope'],
 checks=['Python syntax parsed without importing model or launching tests','Independent NumPy analytic derivative agrees with directional finite differences in8cases','Separate-copy integration only; live source untouched','Proposed18screen+18confirmation+0/6reference finite panel; final predecessor not resolved yet'],
 required_before_launch=['Final complete output-gate evidence and adopted-backbone resolver','Independent PyTorch primitive/fullSwiGLU/model tests and actual trainer/resume/averaging tests','FullprojectCPU suite after source integration','SixactualserialMPS correctness/resource pilots and independent prerequisite review','Freshseedallplancheck,source/runtime/corpus/fullbank,cleancommitpush,newuniquepreregistration'],
 limitations=['No PyTorch correctness or quality evidence yet','This is an FFN-location adaptation, not fullNormFormer','RMS/LN differ in centering and learned beta; normalizedvsnone also changes magnitudes/gradients','VectorAdam/baseLR and hiddenMuon widthrules do not prove optimalLRtransfer'],
 artifacts=[dict(path=str(archive),sha256=sha(archive)),dict(path=str(algebra),sha256=sha(algebra))]+[dict(path=str(dev/f),sha256=sha(dev/f)) for f in files])
p=folder/'preparation-review.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');p.chmod(0o444)
bank=KnowledgeBank(root/'research_state/knowledge')
lit=bank.add(dict(kind='literature',outcome='reported',created_by='continuing-quality-research',title='NormFormer motivates postactivation FFN normalization as a distinct local hypothesis',summary='NormFormer combines learned attention-head scaling, attention-output LayerNorm and LayerNorm after the FFN activation. The authors report benefits in larger language models and provide fairseq commands. The paper uses different data, architecture and training; it does not establish a gain for this project or diagnose this project’s gradient distribution. Our proposed SwiGLU-product normalization is one adaptation, not a replication of the combined method.',sources=[dict(title='NormFormer paper',url='https://arxiv.org/pdf/2110.09456',locator='Section2.1, equations on page3'),dict(title='Authors implementation guide',url='https://github.com/facebookresearch/fairseq/blob/main/examples/normformer/README.md',locator='Modify existing command and data caveats')],scope=dict(local_quality_measured=False)))
idea=bank.add(dict(kind='idea',outcome='untried',created_by='continuing-quality-research',title='Prepare FFN hidden normalization after final output-gate adoption',summary='A separate three-arm experiment would compare unchanged SwiGLU product, RMS normalization and LayerNorm immediately before the down projection. Explicit epsilon1e-5, gain/bias initialization, vectorAdam/baseLR, parameter counts and query-local behavior are specified. Source-only prototype and unexecuted independent derivative tests are preserved; eight tiny NumPy oracle checks pass. No competing model tests, training, MPS or quality scoring occurred. The final reviewed output-gate decision must resolve the common backbone before registration.',scope=dict(status='preparation_only',model_tests_run=0,holdout_consumed=False),details=review,artifacts=[dict(path=str(p),sha256=sha(p)),dict(path=str(archive),sha256=sha(archive))],related_ids=[lit,'kb_32f17c4c75d8825a53cf1d8f6bd8eb54fe19b0f324d992163e2a01d24c52744c','kb_70dd096b90560006bc8382b74f9cd7e13a63484d790f4fd3e6a14565a3747c78']))
snapshot=root/'research_state/ffn-hidden-norm-preparation001-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
record=dict(literature_id=lit,idea_id=idea,review=str(p),review_sha256=sha(p),snapshot=str(snapshot),snapshot_sha256=sha(snapshot));q=folder/'knowledge-record.json';q.write_text(json.dumps(record,indent=2)+'\n');q.chmod(0o444)
for filename in ('research-monitor.json','quality-evolution-progress.json'):
 q=root/'research_state'/filename;m=json.loads(q.read_text());m.update(next_candidate='ffn_hidden_norm',ffn_hidden_norm_development_root=str(dev),ffn_hidden_norm_preparation_review=str(p),ffn_hidden_norm_idea_id=idea,ffn_hidden_norm_status='source_prepared_unexecuted_modeltests_finalgatepredecessorpending');tmp=q.with_name(q.name+'.preparation-tmp');tmp.write_text(json.dumps(m,indent=2)+'\n');tmp.replace(q)
print(json.dumps(record))
