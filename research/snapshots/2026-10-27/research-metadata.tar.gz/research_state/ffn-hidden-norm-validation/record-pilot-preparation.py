"""Preserve unexecuted trainer/pilot/audit preparation and completed gate-screen audit."""
import ast,datetime,hashlib,json,re,shutil,tarfile
from pathlib import Path
from urllib.parse import unquote,urlparse
from src.research.team.knowledge import KnowledgeBank

root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');dev=Path('/private/tmp/rsi-ffn-hidden-norm-development')
folder=root/'research_state/ffn-hidden-norm-validation';gate=root/'research_state/output-gate-validation'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((folder/'development-review-v2.json').read_text())
files=[Path(a['path']) for a in old['artifacts'] if str(a['path']).startswith(str(dev)+'/')]
files.append(dev/'tests/test_ffn_hidden_norm_training.py')
helpers=[folder/n for n in ('pilot-driver.py','review-prerequisites.py','completion-audit.py','record-cpu-review.py','record-pilot-preparation.py')]
for p in files+helpers:
 if p.suffix=='.py':ast.parse(p.read_text())
log=folder/'full-collection-preparation.log';text=log.read_text()
assert '1485 tests collected' in text and 'ERROR collecting' not in text
assert len([line for line in text.splitlines() if line.startswith('tests/test_ffn_hidden_norm_training.py::')])==14
assert len([line for line in text.splitlines() if line.startswith('tests/test_ffn_hidden_norm_')])==220
archive=folder/'prototype003.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(dev)))
 for p in helpers:t.add(p,arcname='preparation-helpers/'+p.name)
archive.chmod(0o444)
review=dict(status='prepared_not_model_executed',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=old['base_commit'],development_root=str(dev),
 unique_synthetic_controller_cases_already_passed=100,new_collected_cases=220,total_project_cases_collected=1485,
 primitive_model_cases_pending=106,actual_training_cases_pending=14,model_cases_executed_this_preparation=0,mps_pilots_executed=0,
 checks=['Fourteen actual trainer cases prepared for raw/H200 optimizer, private RNG, pre/at averaging-boundary resume and architecture-change rejection','Six serial MPS pilot driver prepared with finite worker/post-worker limits and independent hidden-norm output/input/gain/bias gradients; not run','Independent prerequisite and final completion auditors adapted for per-family FFN norm vectors and a common final-reviewed attention gate; not run','CPU evidence recorder requires complete source-matched1485case suite, including14actual cases; not run','All1485 cases collected only; syntax parsed; this does not establish model correctness or quality'],
 next_required=['Finish and independently audit output-gate-quality-001; resolve common backbone from final review','Run106primitive/model+14actualtrainer gates, full source-matched suite after current worker exits','Review source, commit/push isolated source; actual six serialMPS pilots and resource audit','Fresh unique bounded registration with full shared knowledge; no old grid extension'],
 live_source_modified=False,holdout_consumed=False,artifacts=[dict(path=str(p),sha256=sha(p)) for p in files+helpers+[log,archive]])
path=folder/'pilot-preparation-review-v3.json';assert not path.exists();path.write_text(json.dumps(review,indent=2)+'\n');path.chmod(0o444)
partial=json.loads((gate/'partial-audit.json').read_text());assert partial['status']=='partial_verified' and partial['distinct_trajectories']==21 and partial['distinct_checkpoints']==42
partialpath=gate/'screen-plus-three-confirmation-checkpoint-audit.json';assert not partialpath.exists();shutil.copyfile(gate/'partial-audit.json',partialpath);partialpath.chmod(0o444)
bank=KnowledgeBank(root/'research_state/knowledge')
related=json.loads((folder/'controller-knowledge-record.json').read_text())['controller_knowledge_id']
k=bank.add(dict(kind='implementation',outcome='untried',created_by='continuing-quality-research',title='FFN hidden-normalization trainer, serial MPS and completion-audit gates prepared',summary='Prepared14actualCPUtraining/resume tests and six serialMPS pilot plus independent audit tools. Full1485cases collected only;100syntheticcontrollercases had previously passed,106primitive/model+14actualcases remain unexecuted. No source integration, model execution, registration or quality evidence. Current output-gate source stays frozen.',details=review,artifacts=[dict(path=str(path),sha256=sha(path)),dict(path=str(archive),sha256=sha(archive))],related_ids=[related]))
auditid=bank.add(dict(kind='execution',outcome='supported',created_by='continuing-quality-research',title='Output-gate screen plus first three confirmations pass saved-checkpoint audit',summary='21physicaltrajectories42raw/H200checkpoints verified from saved evidence:18screen and first3confirmation. Hashes, requests/results, source/corpus/runtime, strictfiniteCPUloads, shapes/counts, optimizerstates/factors, reconstructed private RNG, untouchedtestRNG, schedule/tokens/snapshots/fullcoverage and H200derivation pass. No training or evaluation rerun; fullconfirmation remains incomplete.',details=partial,artifacts=[dict(path=str(partialpath),sha256=sha(partialpath))],related_ids=[json.loads((gate/'screen-record.json').read_text())['knowledge_id']]))
html=root/'research_state/reports/pretraining-learning-guide/index.html';htmltext=html.read_text();links=re.findall(r'(?:href|src)="([^"]+)"',htmltext);local=[]
for link in links:
 if link.startswith('#') or link.startswith(('http:','https:','data:')):continue
 p=Path(unquote(urlparse(link).path)) if link.startswith('file:') else html.parent/unquote(link.split('#')[0])
 assert p.exists(),str(p);local.append(str(p))
assert 'Output-gate screen: mixed-seed gain, incumbent retained' in htmltext and '1.515522' in htmltext
hr=gate/'screen-guide-review.json';assert not hr.exists();hr.write_text(json.dumps(dict(status='content_and_local_links_verified',html_sha256=sha(html),local_link_count=len(local),screen_review_sha256=sha(gate/'screen-review.json'),no_browser_visual_review_claim=True),indent=2)+'\n');hr.chmod(0o444)
snapshot=root/'research_state/ffn-hidden-norm-preparation003-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
record=dict(preparation_knowledge_id=k,preparation_review=str(path),partial_audit_knowledge_id=auditid,partial_audit=str(partialpath),snapshot=str(snapshot),snapshot_sha256=sha(snapshot),screen_guide_review=str(hr))
out=folder/'pilot-preparation-record.json';out.write_text(json.dumps(record,indent=2)+'\n');out.chmod(0o444)
for name in ('research-monitor.json','quality-evolution-progress.json'):
 q=root/'research_state'/name;m=json.loads(q.read_text());m.update(ffn_hidden_norm_status='100syntheticcasespassed_106model_and14actualcasespending_1485collected',ffn_hidden_norm_pilot_preparation_review=str(path),ffn_hidden_norm_pilot_preparation_knowledge_id=k,output_gate_partial_verified_trajectories=21,output_gate_partial_verified_checkpoints=42,output_gate_latest_checkpoint_audit=str(partialpath),output_gate_partial_audit_knowledge_id=auditid,output_gate_screen_guide_review=str(hr));tmp=q.with_suffix('.preparation-tmp');tmp.write_text(json.dumps(m,indent=2)+'\n');tmp.replace(q)
print(json.dumps(record))
