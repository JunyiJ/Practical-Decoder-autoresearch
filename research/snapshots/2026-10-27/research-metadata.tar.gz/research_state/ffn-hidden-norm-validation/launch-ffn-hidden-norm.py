"""Launch only a newly frozen FFN hidden-normalization round after all predecessor/source gates."""
import argparse,datetime,json,os,re,subprocess,sys
from pathlib import Path
from src.research import ffn_hidden_norm_study as study
parser=argparse.ArgumentParser();parser.add_argument('--launch',action='store_true');args=parser.parse_args()
if not args.launch:parser.error('Explicit --launch required')
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();run=root/'research_runs/ffn-hidden-norm-quality-001';prior=root/'research_runs/output-gate-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
p=json.loads((run/'plan.json').read_text());assert not (run/'state.json').exists() and not (run/'controller.log').exists();study.verify_lineage(p)
fp=root/'research_state/active-campaign.json';active=json.loads(fp.read_text())
assert active['status']=='completed_reviewed' and active['campaign']==str(prior) and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)],'A known model/research process is live'
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
now=datetime.datetime.now(datetime.timezone.utc).isoformat();env=os.environ.copy();env.pop('PYTORCH_ENABLE_MPS_FALLBACK',None)
with (run/'controller.log').open('x') as log:
 proc=subprocess.Popen([sys.executable,'-m','src.research.ffn_hidden_norm_study','--plan',str(run/'plan.json'),'--output',str(run),'--allow-training'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
def write(path,data):
 tmp=path.with_name(path.name+'.launch-tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
history=active.setdefault('completed_algorithm_studies',[])
if not any(x.get('campaign')==str(prior) for x in history):history.append(dict(campaign=str(prior),source_commit=active['source_commit'],review=active['review'],result_id=active['result_id'],documentation_commit=active.get('documentation_commit'),status='completed_reviewed'))
active.update(campaign=str(run),kind='ffn_hidden_norm_quality',stage='ffn_hidden_norm_quality',status='running',pid=proc.pid,launched_at=now,source_commit=p['git_commit'],source_root=str(source),plan=str(run/'plan.json'),state_file=str(run/'state.json'),predecessor=str(prior),scope='SwiGLU-product RMS and LayerNorm versus unchanged FFN; equal bounded LR tuning and final-reviewed common attention/H200. 36 or 42 fresh trajectories, 72 or 84 correlated outputs; exact prospective aliases; holdout closed.',next_action='Verify and monitor one frozen worker; audit all physical raw/derived checkpoints, aliases, choices and independently reconstructed report at completion, then continue quality evolution until human interruption.')
for key in ['review','result_id','documentation_commit','completed_reviewed_at','completed_at']:active.pop(key,None)
write(fp,active)
fp=root/'research_state/research-monitor.json';m=json.loads(fp.read_text());m.update(active_stage='ffn_hidden_norm_quality',active_study=str(run),status='running',last_checked_at=now,last_live_controller_pid=proc.pid,ffn_hidden_norm_launch_notified=False,ffn_hidden_norm_record_count=0,next_action=active['next_action']);write(fp,m)
fp=root/'research_state/quality-evolution-progress.json';d=json.loads(fp.read_text());d.update(status='running',active_study=str(run),protocol=str(source/'research/FFN_HIDDEN_NORM_PROTOCOL.md'),source_commit=p['git_commit'],preregistration_id=p['preregistration_id'],implementation_id=p['implementation_id'],next_action=active['next_action'],last_checked_at=now,resolved_attention_recipe=p['recipe'],returned_half_life=200,ffn_hidden_norm_record_count=0,completion_audit=str(root/'research_state/ffn-hidden-norm-validation/completion-audit.py'));write(fp,d)
print(json.dumps(dict(pid=proc.pid,source_commit=p['git_commit'],recipe=p['recipe'],run=str(run))))
