"""Append evidence for synthetic controller gates and unexecuted model checks."""
import ast,datetime,hashlib,json,re,tarfile,shutil
from pathlib import Path
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');dev=Path('/private/tmp/rsi-ffn-hidden-norm-development');folder=root/'research_state/ffn-hidden-norm-validation';bank=KnowledgeBank(root/'research_state/knowledge')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((folder/'preparation-review.json').read_text())
files=[str(Path(x['path']).relative_to(dev)) for x in old['artifacts'] if str(x['path']).startswith(str(dev)+'/')]
files+=['src/research/ffn_hidden_norm_study.py','src/research/ffn_hidden_norm_predecessor.py','tests/test_ffn_hidden_norm_study.py','tests/test_ffn_hidden_norm_predecessor.py','tests/test_ffn_hidden_norm_integration.py']
for f in files:
 if f.endswith('.py'):ast.parse((dev/f).read_text())
logs=[folder/'controller-tests-first.log',folder/'controller-all-lrs.log',folder/'collection-first.log']
assert '86 passed in 2.16s' in logs[0].read_text() and '42 passed in 0.95s' in logs[1].read_text()
assert '206 tests collected' in logs[2].read_text()
assert all(not re.search(r'\b(?:FAILED|ERROR|failed|error|skipped|xfailed)\b',p.read_text()) for p in logs[:2])
assert 'ERROR collecting' not in logs[2].read_text() and 'Interrupted:' not in logs[2].read_text()
archive=folder/'prototype002.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for f in files:t.add(dev/f,arcname=f)
archive.chmod(0o444)
review=dict(status='controller_synthetic_verified_model_checks_pending',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),development_root=str(dev),base_commit=old['base_commit'],
 synthetic_controller_unique_cases_passed=100,execution_partition='Initial86passed; expanded shared-backbone/alias parameterizations from28to42 and reran42affectedcases, adding14 unique cases. No controller implementation change between runs.',
 collected_new_cases=206,primitive_and_model_cases_pending=106,model_tests_run=0,actual_training_tests_run=0,mps_pilots_run=0,
 checks=['Complete reviewed output-gate adoption required; all3possible attention gate families and all3inherited LRs retain common backbone','Partial/rehashedfalsepromotion/missingconfirmation reviews rejected','Finite36/42physical72/84outputs,aliases,frozenbestarm,noalternativefallback,conditionalintervalveto,firstfailure/noautoretry synthetic engine cases'],
 next_required=['Independent primitive and complete SwiGLU/model106cases','Actual trainer/resume/H200/RNG contracts','Final output-gate completionaudit and resolvedbackbone','Fullsuite and actualserialMPS pilots/resources/independentaudit/cleanpush/preregistration'],
 artifacts=[dict(path=str(x),sha256=sha(x)) for x in logs+[archive,folder/'preparation-review.json']]+[dict(path=str(dev/f),sha256=sha(dev/f)) for f in files],holdout_consumed=False,live_source_modified=False)
p=folder/'development-review-v2.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');p.chmod(0o444)
idea=json.loads((folder/'knowledge-record.json').read_text())['idea_id']
k=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='FFN hidden-normalization controller and final predecessor synthetic gates passed',summary='100 unique synthetic controller/predecessor cases passed; no model training or scoring. Final output-gate report reconstruction is required before propagating attention/LR. Three-arm finite selection, prospective aliases, no alternate fallback and first-failure stop are checked. 106 primitive/model tests are collected but unexecuted; actual trainer/fullsuite/MPS/resource/registration gates remain outstanding. This supports controller correctness only, not model quality.',scope=dict(model_tests_run=0,training_runs=0,holdout_consumed=False),details=review,artifacts=[dict(path=str(p),sha256=sha(p)),dict(path=str(archive),sha256=sha(archive))],related_ids=[idea]))
partial=root/'research_state/output-gate-validation/partial-audit.json';v=json.loads(partial.read_text());assert v['status']=='partial_verified' and v['distinct_trajectories']==11 and v['distinct_checkpoints']==22
preserved=partial.with_name('partial-audit-eleven-trajectories.json');assert not preserved.exists();shutil.copyfile(partial,preserved);preserved.chmod(0o444)
audit=bank.add(dict(kind='execution',outcome='supported',created_by='continuing-quality-research',title='Output-gate first eleven trajectories pass saved-checkpoint contract audit',summary='All eleven completed trajectories in the snapshot and their22raw/H200checkpoints passed hashes, requests/results, strictfiniteCPUloads, shapes/parametercounts, optimizerroles/states/widthfactors, privateRNGreconstruction, untouchedtestRNG, schedules/tokens/H200derivation andfullcoverage contracts. This is a partial execution audit, not completed screening, confirmation or quality adoption. No training/evaluation rerun.',scope=dict(source_commit=v['source_commit'],physical_trajectories=11,correlated_checkpoints=22,holdout_consumed=False),artifacts=[dict(path=str(preserved),sha256=sha(preserved))],related_ids=['kb_70dd096b90560006bc8382b74f9cd7e13a63484d790f4fd3e6a14565a3747c78']))
snapshot=root/'research_state/ffn-hidden-norm-preparation002-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
record=dict(controller_knowledge_id=k,partial_audit_id=audit,controller_review=str(p),partial_review=str(preserved),snapshot=str(snapshot),snapshot_sha256=sha(snapshot));q=folder/'controller-knowledge-record.json';q.write_text(json.dumps(record,indent=2)+'\n');q.chmod(0o444)
for name in ('research-monitor.json','quality-evolution-progress.json'):
 q=root/'research_state'/name;m=json.loads(q.read_text());m.update(ffn_hidden_norm_controller_review=str(p),ffn_hidden_norm_controller_knowledge_id=k,ffn_hidden_norm_status='100syntheticcontrollercasespassed_106primitive_modelcasesunexecuted',output_gate_partial_verified_trajectories=11,output_gate_partial_verified_checkpoints=22,output_gate_latest_checkpoint_audit=str(preserved),output_gate_partial_audit_knowledge_id=audit);tmp=q.with_name(q.name+'.preparation-tmp');tmp.write_text(json.dumps(m,indent=2)+'\n');tmp.replace(q)
print(json.dumps(record))
