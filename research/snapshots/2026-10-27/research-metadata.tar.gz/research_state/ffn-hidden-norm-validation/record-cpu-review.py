"""Record a complete source-matched partitioned CPU suite after execution."""
import argparse,datetime,json,re
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.suite import source_digest
parser=argparse.ArgumentParser();parser.add_argument('--actual',type=Path,required=True);parser.add_argument('--remaining',type=Path,required=True);parser.add_argument('--collection',type=Path,required=True);args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=base/'research_state/ffn-hidden-norm-validation'
prior=json.loads((base/'research_runs/output-gate-quality-001/review.json').read_text());assert prior['status']=='verified' and prior['distinct_trajectories'] in (36,42)
review=json.loads((folder/'separate-source-review.json').read_text());assert review['source_sha256']==source_digest(source)
for a in review['artifacts']:
 path=Path(a['path']);relative=path.relative_to('/private/tmp/rsi-ffn-hidden-norm-development');assert file_digest(source/relative)==a['sha256']
# Exact same source/test contents were reviewed in separate development.
def passed(path):
 text=path.read_text();m=re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s',text)
 assert m and not re.search(r'\b(?:FAILED|ERROR|failed|error|skipped|xfailed|xpassed)\b',text),str(path)
 return int(m[1]),float(m[3]),int(m[2] or 0)
a,seconds_a,warnings_a=passed(args.actual);b,seconds_b,warnings_b=passed(args.remaining);assert a==14
collection=args.collection.read_text();m=re.search(r'(\d+) tests collected',collection);assert m and int(m[1])==a+b and a+b>=1485
assert 'test_ffn_hidden_norm_training.py' in collection
files=[args.actual,args.remaining,args.collection,folder/'separate-source-review.json',folder/'record-cpu-review.py']+[source/f for f in review['changed_files']]
result=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=source_digest(source),base_commit=review['base_commit'],actual_ffn_hidden_norm_training_tests_passed=14,
 full_tests=dict(passed=a+b,collected=int(m[1]),failed=0,warnings=warnings_a+warnings_b,partition='Fourteen actual FFN hidden-normalization CPU training tests and remaining project tests, no duplicated case count',remaining_tests=b,actual_seconds=seconds_a,remaining_seconds=seconds_b,total_seconds=seconds_a+seconds_b),
 checks=['ActualCPU three FFN normalization arms xwidth64/256 plus normalized arms with both possible nondefault common attention gates: finite optimization/norm vector and common gate states, exact online averaging noninterference, pre/postboundaryresume, privateRNG, strict derivedweights and changedcontract rejection','Full source-matched collected project suite passed'],
 limitations=['Synthetic CPU correctness, not quality or MPS measurements','Six actual serialMPS pilots and resource audit still required'],artifacts=[dict(path=str(x.resolve()),sha256=file_digest(x)) for x in files])
p=folder/'cpu-review.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['full_tests']))
