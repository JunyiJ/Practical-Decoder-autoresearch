"""Preserve reviewed source and deferred completion/registration tools; no model execution."""
import ast,datetime,json,tarfile
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');folder=root/'research_state/ffn-hidden-norm-validation';gate=root/'research_state/output-gate-validation'
review=json.loads((folder/'separate-source-review.json').read_text())
assert len(review['changed_files'])==12 and review['test_evidence']['full_project_executed'] is False
for a in review['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
files=[folder/n for n in ('separate-source-review.json','record-source-review.py','freeze-ffn-hidden-norm.py','launch-ffn-hidden-norm.py')]+[gate/n for n in ('record-completion.py','plot-completion.py','render-completed-guide.mjs')]
for p in files:
 if p.suffix=='.py':ast.parse(p.read_text())
archive=folder/'handoff-tools001.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.parent.name+'/'+p.name)
archive.chmod(0o444)
evidence=dict(status='source_reviewed_tools_prepared_not_executed',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_review=str(folder/'separate-source-review.json'),development_source_sha256=review['source_sha256'],changed_python_files=12,
 checks=['Complete separate production/model/controller/predecessor/test source reviewed; source remains isolated and frozen live study unchanged.','New registration requires completed reviewed output-gate, clean pushed source, all1485CPUcases including14actualtrainer cases, sixMPS pilots and independent finite resource review.','Final output-gate recorder requires final36trajectory72checkpoint audit plus report reconstruction; frozen retention cannot change. Paired contrasts/costs/limitations/guide and figure tools are prepared but unexecuted.'],
 model_tests_run=0,training_runs=0,mps_runs=0,registration_run=False,live_source_modified=False,holdout_consumed=False,
 artifacts=[dict(path=str(p),sha256=file_digest(p)) for p in files+[archive]])
path=folder/'handoff-preparation-review.json';assert not path.exists();path.write_text(json.dumps(evidence,indent=2)+'\n');path.chmod(0o444)
previous=json.loads((folder/'pilot-preparation-record.json').read_text())['preparation_knowledge_id'];bank=KnowledgeBank(root/'research_state/knowledge')
k=bank.add(dict(kind='implementation',outcome='untried',created_by='continuing-quality-research',title='Reviewed FFN normalization source and prepared final-audit-to-next-round handoff',summary='Reviewed all12changed/new Python files and strict normalization/optimizer/predecessor/controller contracts. Source review does not substitute for106pending primitive/model or14actualtrainer tests, full1485suite or sixMPS pilots. Prepared guarded registration/launch and current gate completion/report/plot tools; none executed. Production gate source and primary human work remain untouched.',details=evidence,artifacts=[dict(path=str(path),sha256=file_digest(path))],related_ids=[previous]))
record=dict(knowledge_id=k,review=str(path),archive=str(archive));(folder/'handoff-preparation-record.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ('research-monitor.json','quality-evolution-progress.json'):
 p=root/'research_state'/name;data=json.loads(p.read_text());data.update(ffn_hidden_norm_source_review=str(folder/'separate-source-review.json'),ffn_hidden_norm_development_source_sha256=review['source_sha256'],ffn_hidden_norm_handoff_preparation=str(path),ffn_hidden_norm_handoff_knowledge_id=k,output_gate_final_recorder=str(gate/'record-completion.py'),output_gate_final_plotter=str(gate/'plot-completion.py'),output_gate_final_renderer=str(gate/'render-completed-guide.mjs'));tmp=p.with_suffix('.handoff-tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(p)
print(json.dumps(record))
