"""Tiny NumPy directional checks for future test oracles, no model or dataset."""
import json
from pathlib import Path
import numpy as np
rng=np.random.default_rng(9330);rows=[];eps=1e-5
for kind in ('rms','layer'):
 for regime in ('random','constant','zero','small'):
  z=rng.normal(size=(2,3,9));dy=rng.normal(size=z.shape);gain=np.linspace(.5,1.5,9)
  if regime=='constant':z.fill(.7)
  if regime=='zero':z.fill(0.)
  if regime=='small':z*=1e-8
  direction=rng.normal(size=z.shape);direction/=np.linalg.norm(direction)
  def value(x):
   c=x-x.mean(-1,keepdims=True) if kind=='layer' else x
   return np.sum(dy*gain*c/np.sqrt(np.mean(c*c,-1,keepdims=True)+eps))
  c=z-z.mean(-1,keepdims=True) if kind=='layer' else z
  inv=(np.mean(c*c,-1,keepdims=True)+eps)**-.5;v=dy*gain
  dx=inv*(v-c*inv**2*np.mean(v*c,-1,keepdims=True)-(v.mean(-1,keepdims=True) if kind=='layer' else 0.))
  step=1e-7;numeric=(value(z+step*direction)-value(z-step*direction))/(2*step);analytic=float(np.sum(dx*direction))
  assert np.isclose(numeric,analytic,rtol=2e-6,atol=2e-6),(kind,regime,numeric,analytic)
  rows.append(dict(kind=kind,regime=regime,analytic=analytic,numerical=numeric,absolute_error=abs(numeric-analytic)))
print(json.dumps(dict(status='reference_algebra_verified',cases=rows,model_tests_run=0,scope='Float64 NumPy directional finite differences for test oracle only; no PyTorch model, training, corpus, MPS or quality measurement'),indent=2))
