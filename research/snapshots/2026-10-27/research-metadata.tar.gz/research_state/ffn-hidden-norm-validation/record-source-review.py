"""Preserve reviewed separate prototype; actual model and integration gates remain pending."""
import ast,datetime,json,subprocess
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.suite import source_digest

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
dev=Path('/private/tmp/rsi-ffn-hidden-norm-development');folder=base/'research_state/ffn-hidden-norm-validation'
commit='047008b4b59d8141f5463f793c39798fee006a17'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
changed=[]
for directory in ('src','tests'):
 old={str(x.relative_to(source)):x for x in (source/directory).rglob('*.py')}
 new={str(x.relative_to(dev)):x for x in (dev/directory).rglob('*.py')}
 assert set(old)<=set(new)
 changed += [k for k in new if k not in old or new[k].read_bytes()!=old[k].read_bytes()]
expected=['src/models/mlp.py','src/models/blocks.py','src/models/gpt.py','src/models/ffn_hidden_norm.py','src/train/optimizers.py','src/research/ffn_hidden_norm_predecessor.py','src/research/ffn_hidden_norm_study.py']+['tests/test_ffn_hidden_norm_'+suffix+'.py' for suffix in ('math','integration','training','predecessor','study')]
assert sorted(changed)==sorted(expected)
for name in changed:ast.parse((dev/name).read_text())
assert (dev/'requirements.txt').read_bytes()==(source/'requirements.txt').read_bytes()
files=[dev/x for x in sorted(changed)]+[dev/'research/FFN_HIDDEN_NORM_PROTOCOL.md',dev/'requirements.txt']
review=dict(status='separate_source_reviewed_model_and_integration_gates_pending',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=commit,base_source_sha256=source_digest(source),source_sha256=source_digest(dev),changed_files=sorted(changed),
 checks=['Reviewed all four existing production-file diffs: only optional per-token SwiGLU-product normalization before unchanged down projection; default path retains arithmetic order, parameter keys and RNG order by construction, requiring execution verification.',
 'Reviewed new strict configuration contract: RMS or LayerNorm epsilon1e-5 over21D/8 product; ones gain, zero LayerNorm bias, no RNG; fixed4LMHA/SwiGLU/muP/context policies and unreviewed override rejection.',
 'Reviewed optimizer grouping: new gain/bias vectors remain AdamW baseLR and independentdecay; hidden matrices retain Muon width factors. Geometry changes do not establish optimal LR transfer.',
 'Reviewed final-predecessor resolver: complete36/42physical72/84checkpoint output-gate audit, source/report/selection hashes and full report reconstruction required; partial screen cannot set new backbone.',
 'Reviewed all finite controller paths:18screens/freshconfirmation, equalLRgrid, prospectiveexactaliases, best-arm-only eligibility, no alternativefallback, all3textinterval acceptance and firstfailure/noautoretry.',
 'Reviewed independent NumPy primitive gradient and manually expanded completeSwiGLU tests, default/commonRNG, optimizerroles, cache/causality/strictreload tests;106cases prepared but unexecuted.',
 'Reviewed14actualtrainer cases: all3normarms64/256 plus normalizedarms withpossibleinheritedgates, finiteoptimizerstates, H200noninterference, privateRNG/testreservation, exactCPUresume4/8 and changed-norm rejection. Unexecuted.',
 'Reviewed serialMPS pilot and independent prerequisite/completionaudit source: properfamily normvectors/counts, commonattentiongate, independent saved gradients, hardworker/postworker budgets, hashes/RNG/coverage and noautomaticretry. Unexecuted.'],
 test_evidence=dict(synthetic_controller_unique_passed=100,primitive_model_pending=106,actual_cpu_training_pending=14,full_project_collected=1485,full_project_executed=False,mps_pilots_run=0),
 pending=['Complete output-gate and final audit before source integration/model execution.','Match reviewed source/test hashes after integration; execute106primitive/model and14actualtrainer cases plus complete1485suite.','Cleanreviewedcommitpush, sixserialMPS/resourceaudit, freshfiniteprotocol/fullbank/uniquepreregistration.'],
 artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in files])
p=folder/'separate-source-review.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');p.chmod(0o444)
print(json.dumps(dict(review=str(p),changed_python_files=len(changed),source_sha256=review['source_sha256'],status=review['status'])))
