"""Deferred FFN hidden-normalization evidence audit. No training or evaluation; --partial is not final."""
import argparse,copy,datetime,json,math,statistics
from pathlib import Path
import numpy as np
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.research import ffn_hidden_norm_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result,disk_mb
from src.research.team.suite import _request
from src.train.weight_averaging import TailWeightAverages
from src.utils.checkpoint import read_checkpoint

parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);parser.add_argument('--partial',action='store_true');args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=args.run.resolve();folder=root/'research_state/ffn-hidden-norm-validation'
assert run.parent==root/'research_runs' and run.name.startswith('ffn-hidden-norm-quality-')
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());study.verify_lineage(p)
assert p==json.loads((root/'research_state/ffn-hidden-norm-plan.json').read_text()) and digest(p)==s['plan_sha256']
assert not any(r['status']=='failed' for r in s['records'])
records=[r for r in s['records'] if r['status']=='completed'];jobs=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())==study.freeze_selection(p,records[:18])
 jobs+=s['selection']['confirmation']['jobs']
 if s['records'][18:]:
  assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'][18:])
assert [[r[k] for k in ('family','lr','width','seed')] for r in s['records']]==jobs[:len(s['records'])]
assert len({r['trial_id'] for r in s['records']})==len(s['records']) and disk_mb(run)<4096
if not args.partial:assert s['status']=='completed' and len(records)==s['selection']['confirmation']['total_distinct_trials'] and s['active_seconds']<21600

torch.set_num_threads(1);checks=[];unique_paths=set();data_length=len(Path(p['config']['data']['path']).read_text())
for r in records:
 assert r['error'] is None and r['duration_seconds']<2400
 d=run/'trials'/r['trial_id'];req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model'];total,start=3000,2000;snapshots=1+(total-start)//10
 assert p['returned_half_life']==200
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['completed_steps']==total and raw['eval_iters']==30 and raw['eval_every']==300
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==total
 metrics=[json.loads(x) for x in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics'] and [x['step'] for x in metrics]==list(range(0,total,300))+[total-1]
 assert max(x['rss_mb'] for x in metrics)<4096
 for row in metrics:
  i=row['step'];ratio=1. if i<=start else 1.-.9*(i-start)/(total-start-1)
  if i==total-1:ratio=.1
  assert math.isclose(row['lr_multiplier'],ratio,rel_tol=0,abs_tol=1e-14)
  assert row['base_learning_rate']==r['lr'] and math.isclose(row['scheduled_learning_rate'],r['lr']*ratio,abs_tol=1e-15)
  completed=i+1;expected=0 if completed<start else 1+(completed-start)//10
  assert row['averaging_snapshots']==expected and row['tokens_processed']==completed*1024
  assert row['train_aux_loss'] is None and row['moe_usage'] is None
  assert row['train_ce_loss']==row['train_loss']==row['train_total_loss']
 cp=read_checkpoint(r['checkpoint']);assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==total and cp['parameter_layout_version']==2 and cp['model_math_version']==2
 assert 'averaged_weights' not in cp
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65;assert cp['cfg']==want
 assert t['max_iters']*t['batch_size']*m['block_size']==total*1024 and t['batch_layout']=='paired_blocks512'
 assert t['weight_averaging']==dict(kind='spaced_tail_ema',total_steps=total,start_step=start,interval=10,half_lives=[200]) and t['lr_schedule']==study.horizon.schedule('control3000')
 contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
  optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],data_sha256=p['data_sha256'],
  data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
  training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==contract and cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(total):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 model=GPT(OmegaConf.create(want['model']));model.load_state_dict(cp['model_state'],strict=True)
 assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
 named=dict(model.named_parameters());width=r['width'];depth=4
 hidden=21*width//8
 common_gate=p['recipe']['attention_output_gate'];assert common_gate in ('none','static_half','sigmoid_headwise_zero')
 norm_family='none' if r['family']=='incumbent_reference' else r['family'];assert norm_family in ('none','rms','layer')
 norm_extra=0 if norm_family=='none' else depth*hidden*(2 if norm_family=='layer' else 1)
 gate_extra=depth*width*(width//32) if common_gate=='sigmoid_headwise_zero' else 0
 expected_count=132*width+depth*(4*width*width+6*width+3*width*hidden)+gate_extra+norm_extra
 assert sum(v.numel() for v in named.values())==expected_count and len(model.transformer.h)==depth
 for layer in range(depth):
  prefix=f'transformer.h.{layer}.';weights=cp['model_state']
  assert list(weights[prefix+'attn.qkv.weight'].shape)==[3*width,width]
  assert list(weights[prefix+'attn.out.weight'].shape)==[width,width]
  for key in ('linear_gate','linear_up'):assert list(weights[prefix+'mlp.'+key+'.weight'].shape)==[hidden,width]
  assert list(weights[prefix+'mlp.linear_down.weight'].shape)==[width,hidden]
  assert list(weights[prefix+'freq_cos'].shape)==[128,16]
  assert 'qk_norm' not in m and m['depth_width_policy']=='depth4_unscaled' and m['attention_width_policy']=='mha_head32'
  assert not any(prefix+'attn.'+kind+'_norm.weight' in weights for kind in ('q','k'))
  gate=prefix+'attn.output_gate.weight'
  if common_gate=='sigmoid_headwise_zero':
   assert m['attention_output_gate']==common_gate and m['output_gate_width_policy']=='mha_head32_output_gate'
   assert list(weights[gate].shape)==[width//32,width] and torch.count_nonzero(weights[gate])>0
  else:
   assert gate not in weights
   if common_gate=='static_half':assert m['attention_output_gate']==common_gate and m['output_gate_width_policy']=='mha_head32_output_gate'
   else:assert 'attention_output_gate' not in m and 'output_gate_width_policy' not in m
  gain=prefix+'mlp.hidden_norm.weight';bias=prefix+'mlp.hidden_norm.bias';norm=model.transformer.h[layer].mlp.hidden_norm
  if norm_family=='none':
   assert norm is None and gain not in weights and bias not in weights
   assert 'ffn_hidden_norm' not in m and 'ffn_hidden_norm_policy' not in m
  else:
   assert m['ffn_hidden_norm']==norm_family and m['ffn_hidden_norm_policy']=='swiglu_product_norm_21_8'
   assert list(weights[gain].shape)==[hidden] and norm.eps==1e-5 and norm.elementwise_affine
   if norm_family=='layer':assert isinstance(norm,torch.nn.LayerNorm) and list(weights[bias].shape)==[hidden]
   else:assert isinstance(norm,torch.nn.RMSNorm) and bias not in weights
 seen=[];assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==.00006
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   assert len(g['params'])==len(g['parameter_names'])==1
   name=g['parameter_names'][0];seen.append(name);v=named[name];matrix=name.startswith('transformer.h.') and v.ndim==2
   scale=1/math.sqrt(width/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==r['lr']*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'} and g['momentum']==.95 and g['adjust_lr_fn']=='match_rms_adamw'
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total and g['betas']==(.9,.999)
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==v.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 state=cp['training_state']['weight_averaging_state'];tracker=TailWeightAverages(model,OmegaConf.create(t));tracker.load_state_dict(state,total)
 assert state['spec']==t['weight_averaging'] and state['completed_steps']==total and state['snapshots']==snapshots
 assert state['parameter_names']==list(named) and set(state['averages'])=={'200'}
 rawpath=Path(r['checkpoint']).resolve();assert rawpath not in unique_paths;unique_paths.add(rawpath)
 derived_checks=[]
 for h in (200,):
  item=r['averaged_outputs'][str(h)];path=Path(item['checkpoint']).resolve();assert path not in unique_paths;unique_paths.add(path)
  job=dict(checkpoint=str(path),checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=str(rawpath),
   parent_sha256=r['checkpoint_sha256'],half_life=h,completed_steps=total)
  derived=validate_derivation(job)
  assert 'training_state' not in derived and 'optimizer_state' not in derived
  assert derived['averaged_weights']['parameter_names']==list(named) and derived['cfg']==cp['cfg']
  assert derived['averaged_weights']['snapshots']==snapshots
  for name,value in derived['model_state'].items():
   reference=state['averages'][str(h)][name] if name in named else cp['model_state'][name]
   assert value.dtype==reference.dtype and value.shape==reference.shape and torch.equal(value,reference) and torch.isfinite(value).all()
  assert file_digest(path)==item['checkpoint_sha256']
  derived_checks.append(dict(half_life=h,path=str(path),sha256=item['checkpoint_sha256']))
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
  result_sha256=r['result_sha256'],parameter_count=expected_count,derived_checkpoints=derived_checks))
 print('Verified trajectory',r['trial_id'],flush=True)
review=dict(status='partial_verified' if args.partial else 'verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_trajectories=len(records),distinct_checkpoints=len(unique_paths),
 checkpoint_audit=checks,holdout_consumed=False)
if args.partial:
 (folder/'partial-audit.json').write_text(json.dumps(review,indent=2)+'\n');print('PARTIAL VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints');raise SystemExit


report=json.loads((run/'report.json').read_text());assert study.summarize(p,s)==report and report['holdout_consumed'] is False
screen=records[:18];selection=s['selection'];choices={}
for family in ('none','rms','layer'):
 grid=[dict(lr=lr,mean_ce=statistics.mean(study.endpoint(p,r)['mean_ce'] for r in screen if r['family']==family and r['lr']==lr)) for lr in (.00125,.0025,.005)]
 chosen=min(grid,key=lambda v:(v['mean_ce'],v['lr']))
 choices[family]={**chosen,'grid':grid,'at_grid_boundary':chosen['lr'] in (.00125,.005)}
assert selection['choices']==choices
panels={(family,lr):{r['seed']:study.endpoint(p,r)['mean_ce'] for r in screen if r['family']==family and r['lr']==lr} for family in ('none','rms','layer') for lr in (.00125,.0025,.005)}
for panel in panels.values():assert set(panel)=={2221,2222}
order=['none','rms','layer']
best=min(order,key=lambda f:(choices[f]['mean_ce'],order.index(f)))
local=[];references=[('incumbent_reference',p['recipe']['learning_rate'])]
if best!='none':references.append(('none',choices['none']['lr']))
for reference,lr in references:
 a=panels[best,choices[best]['lr']];b=panels['none',lr]
 ds={str(seed):a[seed]-b[seed] for seed in (2221,2222)}
 local.append(dict(reference=reference,reference_lr=lr,paired_seed_deltas=ds,mean_delta=statistics.mean(ds.values()),supported=statistics.mean(ds.values())<-.005 and max(ds.values())<0))
eligible=all(c['supported'] for c in local);winner=best if eligible else 'incumbent_unchanged'
assert selection['best_selected_arm']==best and selection['local_contrasts']==local
assert selection['candidate_eligible']==eligible and selection['winner']==winner
aliases={'incumbent_reference':'none'} if choices['none']['lr']==p['recipe']['learning_rate'] else {}
assert selection['confirmation']['reference_aliases']==report['reference_aliases']==aliases
assert len(records)==(36 if aliases else 42) and len(unique_paths)==2*len(records)
confirmation=records[18:];expanded=list(confirmation)
for alias,family in aliases.items():expanded += [{**r,'family':alias,'alias_of':r['trial_id']} for r in confirmation if r['family']==family]
required=['incumbent_reference'] if winner=='none' else ['incumbent_reference','none']
adoption=[]
for c in report['comparisons']:
 panels={f:{r['seed']:r for r in expanded if r['width']==c['width'] and r['family']==f} for f in (c['candidate'],c['reference'])}
 for panel in panels.values():assert set(panel)=={2231,2232,2233}
 assert (c['candidate'],c['reference']) in [('rms','none'),('layer','none'),('layer','rms'),('none','incumbent_reference'),('rms','incumbent_reference'),('layer','incumbent_reference')]
 for raw_endpoint,key in [(False,'sensitivity'),(True,'raw_sensitivity')]:
  aa=[study.endpoint(p,panels[c['candidate']][k],raw_endpoint) for k in (2231,2232,2233)]
  bb=[study.endpoint(p,panels[c['reference']][k],raw_endpoint) for k in (2231,2232,2233)]
  delta=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0)
  counts=np.array(aa[0]['block_target_counts']);seed_deltas={str(k):a['mean_ce']-b['mean_ce'] for k,a,b in zip((2231,2232,2233),aa,bb)}
  assert len(c[key])==3
  for n,v in zip((2048,4096,8192),c[key]):
   factor=n//2048;chunks=np.array([delta[j:j+factor].sum() for j in range(0,len(delta),factor)])
   cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
   idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)));boot=chunks[idx].sum(1)/cnt[idx].sum(1)
   assert v['text_block_tokens']==n and v['text_block_count']==len(cnt) and v['bootstrap_draws']==2000 and v['bootstrap_seed']==20261024
   assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
   assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],rel_tol=0,abs_tol=1e-12)
   assert v['paired_seed_deltas']==seed_deltas
  if not raw_endpoint:
   supported=statistics.mean(seed_deltas.values())<-.005 and max(seed_deltas.values())<0 and all(v['conditional_text_bootstrap_95pct'][1]<0 for v in c[key])
   assert c['quality_improvement']==supported
   if c['candidate']==winner and c['reference'] in required:adoption.append(supported)
assert len(report['comparisons'])==12
adopt=winner!='incumbent_unchanged' and len(adoption)==2*len(required) and all(adoption)
assert report['quality_decision']==dict(frozen_screen_winner=winner,qualifies_for_incumbent_replacement=adopt)
fixed=[]
for lr in (.00125,.0025,.005):
 for a,b in [('rms','none'),('layer','none'),('layer','rms')]:
  item=dict(lr=lr,candidate=a,reference=b)
  for raw_endpoint,key in [(False,'primary'),(True,'raw')]:
   panels={f:{r['seed']:study.endpoint(p,r,raw_endpoint)['mean_ce'] for r in screen if r['family']==f and r['lr']==lr} for f in (a,b)}
   ds={str(k):panels[a][k]-panels[b][k] for k in (2221,2222)}
   item[key]=dict(mean_delta=statistics.mean(ds.values()),paired_seed_deltas=ds)
  fixed.append(item)
assert report['fixed_lr_screen']==fixed
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),quality_decision=report['quality_decision'],
 active_seconds=s['active_seconds'],disk_mb=disk_mb(run),reference_aliases=aliases,
 checks=['Every raw/derived checkpoint and request/result hash, config/source/corpus/runtime/full-bank/prerequisite contract',
 'Strict finite CPU weights and optimizer state; exact common attention gate and FFN hidden-normalization gain/bias/epsilon shapes, QKV/FFN/depth/head/counts; AdamW vector and Muon matrix width factors',
 'Private training RNG independently reconstructed; untouched test RNG; full step/token/schedule/snapshot counters',
 'H200 tensors exactly equal registered raw shadow state; inference-only derivation; no raw optimizer substitution',
 '18 fresh screening trajectories freeze three LR choices and prospective winner; exact reference aliases, fresh2231/2232/2233 confirmation64/256',
 'Full report, every primary/raw conditional bootstrap interval, fixed-LR screening and frozen adoption independently reconstructed'],
 limitations=['The final state cannot reconstruct all historical EMA snapshots; recurrence is separately checked in synthetic correctness tests',
 '36or42 physical trajectories produce72or84 correlated endpoints; aliases are not independent repeats; adaptive validation without holdout or seed-population inference'])
assert not (run/'review.json').exists()
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints')
