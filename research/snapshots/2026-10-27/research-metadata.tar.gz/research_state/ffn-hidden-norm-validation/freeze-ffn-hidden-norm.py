"""Register exactly one new FFN-normalization round after actual source/test/pilot gates."""
import datetime,json,os,re,subprocess
from pathlib import Path
from src.research import ffn_hidden_norm_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
run=base/'research_runs/ffn-hidden-norm-quality-001';folder=base/'research_state/ffn-hidden-norm-validation';prior=base/'research_runs/output-gate-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text())
assert active['campaign']==str(prior) and active['status']=='completed_reviewed' and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
lines=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in lines if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]==p['git_commit']
review=folder/'review.json';v=json.loads(review.read_text());tests=v['tests']['full_tests']
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit']
assert v['recipe']==p['recipe'] and v['returned_half_life']==200 and v['predecessor_review']==p['predecessor_review']
assert tests['passed']==tests['collected']>=1485 and tests['failed']==0 and v['tests']['actual_ffn_hidden_norm_training_tests_passed']==14
assert len(v['pilot_audit'])==6 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (base/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/FFN_HIDDEN_NORM_PROTOCOL.md';con=json.loads((base/'research_state/output-gate-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
incumbent_path=base/'research_state/ffn-hidden-norm-incumbent.json';assert not incumbent_path.exists()
incumbent_path.write_bytes((base/'research_state/best-observed-config.json').read_bytes());incumbent_path.chmod(0o444)
incumbent=json.loads(incumbent_path.read_text());p['incumbent_snapshot']=dict(path=str(incumbent_path),sha256=file_digest(incumbent_path),result_id=incumbent['result_id'])
prior_preparation=json.loads((folder/'pilot-preparation-record.json').read_text())
idea=json.loads((folder/'knowledge-record.json').read_text())
controller=json.loads((folder/'controller-knowledge-record.json').read_text())
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='SwiGLU-product normalization with explicit vector optimizer and resume contracts',
 summary=f"The complete {tests['passed']}-case source-matched CPU suite and six serial MPS shortened pilots passed. Independent primitive and complete FFN derivatives, saved MPS normalization derivatives, full/cached logits, raw/H200 checkpoint contracts, private RNG, coverage and bounded resource estimates were checked. Correctness pilots are excluded from quality findings.",
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id'],idea['idea_id'],controller['controller_knowledge_id'],prior_preparation['preparation_knowledge_id']]))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',title='Preregistered FFN hidden-normalization quality001: RMS and LayerNorm of the SwiGLU product',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='Normalizing the SwiGLU product before its down projection may improve quality. No quantitative gain, diagnosed gradient mismatch, pure centering effect or exact NormFormer replication is assumed.',
 selection='18 width64 screens on2221/2222 choose three family LRs. Freeze best selected arm with ties none/RMS/LayerNorm. Require mean gain>.005 and every seed better versus fixed incumbent and tuned none for nondefault; otherwise retention, no alternate fallback. Fresh2231/2232/2233 confirmation64/256; only eligible frozen winner and all conditional text upper bounds<0 can qualify.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='Final completed output-gate review resolves the common attention/LR. Equal3000updates/3072000targets with cooldown start2000/H200. 36or42physical and72or84correlated raw/H200 outputs. Six fixed references alias selectednone only on exact config/LR match. No old trial continuation, grid extension or larger-width reselection; permanent stop006 retained.'),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in (protocol,review,prior/'review.json')],related_ids=[implementation,con['result_id'],idea['idea_id']]))
snapshot=base/'research_state/ffn-hidden-norm-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
artifacts=[incumbent_path,protocol,review,folder/'review-prerequisites.py',folder/'freeze-ffn-hidden-norm.py',folder/'launch-ffn-hidden-norm.py',base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/output-gate-conclusion.json',base/'research_state/output-gate-completed-knowledge-snapshot.md']+[prior/f for f in ('plan.json','report.json','review.json','selection.json')]
p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary kimi/KDA untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in (run/'plan.json',base/'research_state/ffn-hidden-norm-plan.json'):path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],recipe=p['recipe'],maximum_physical_trajectories=42,maximum_correlated_model_outputs=84,returned_half_life=200,completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
