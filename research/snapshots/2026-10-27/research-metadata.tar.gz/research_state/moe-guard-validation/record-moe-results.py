"""Record completed, audited MoE evidence; never runs training/evaluation."""
import copy,datetime,json,statistics
from pathlib import Path
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
from src.research import moe_study as study
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/moe-quality-001'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text())
r=json.loads((run/'report.json').read_text());rev=json.loads((run/'review.json').read_text())
assert s['status']=='completed' and rev['status']=='verified'
assert rev['plan_sha256']==digest(p)==r['plan_sha256']
assert rev['report_sha256']==file_digest(run/'report.json') and rev['selection_sha256']==file_digest(run/'selection.json')
assert rev['distinct_checkpoints']==len(r['records'])==48
study.verify_lineage(p)
rows=[v for v in r['records'] if v['stage']=='confirmation'];families=list(dict.fromkeys(v['family'] for v in rows))
means={f:{str(w):{k:statistics.mean(v[field] for v in rows if v['family']==f and v['width']==w) for k,field in [('ce128','metric'),('training_seconds','training_time_sec'),('rss_mb','rss_mb'),('mps_current_allocated_mb','accel_mem_mb')]} for w in [64,256]} for f in families}
def comparison(f,ref,w):
 found=[c for c in r['comparisons'] if c['candidate']==f and c['reference']==ref and c['width']==w]
 assert len(found)==1;return found[0]
winner=r['selection']['winner'];adopt=rev['quality_decision']['qualifies_for_incumbent_replacement']
assert winner=='moe4_top2'
assert adopt==all(comparison(winner,ref,w)['sensitivity'][0]['mean_delta']<-.005 and max(comparison(winner,ref,w)['sensitivity'][0]['paired_seed_deltas'].values())<0 for w in [64,256] for ref in ['dense','deep_reference'])
cost={f:{str(w):100*(means[f][str(w)]['training_seconds']/means['dense'][str(w)]['training_seconds']-1) for w in [64,256]} for f in ['dense_wide','moe4_top2']}
routing={}
for w in [64,256]:
 snapshots=[v['routing_snapshots'][-1] for v in rows if v['family']=='moe4_top2' and v['width']==w]
 assert len(snapshots)==3 and all(x['step']==2999 for x in snapshots)
 values=[u for snap in snapshots for layer in snap['moe_usage']['per_layer'] for u in layer['usage']]
 routing[str(w)]=dict(final_logged_assignment_fraction_min=min(values),final_logged_assignment_fraction_max=max(values),mean_final_logged_auxiliary_loss=statistics.mean(x['train_aux_loss'] for x in snapshots),scope='Final sampled training batch only,three seeds x four layers x four experts;fraction of top2 assignments,not token fraction or whole-run exposure')
deltas={str(w):comparison('moe4_top2','dense',w)['sensitivity'][0]['mean_delta'] for w in [64,256]}
summary=(f'MoE quality001 completed and reviewed48/48. All three families selected LR.0025 inside the frozen grid. MoE was the width64 screen winner. Fresh confirmation MoE-minus-dense mean CE is {deltas["64"]:+.6f}/{deltas["256"]:+.6f} at widths64/256. '+('The frozen winner passes mean gain>.005 and every-seed improvement at both widths versus tuned dense and the prospectively aliased fixed deep reference; MoE becomes the most promising observed quality recipe.' if adopt else 'The frozen winner fails the complete adoption rule; the historical dense quality incumbent is retained.')+' Wider dense and MoE use additional stored capacity; comparisons are equal-token recipes, not equal compute or pure routing effects. Test split stays closed.')
limits=['Fresh development seeds on adaptively reused Shakespeare validation; no holdout or population/seed uncertainty claim. Conditional text bootstrap is descriptive.',
 'MoE has roughly the active FFN weights of ordinary dense and roughly the stored FFN weights of wider dense, plus router weights; no equal compute, pure routing attribution or inference benefit claim.',
 'Top2-of4 half-width experts, fixed auxiliary coefficient.01 and explicit engineering router scaling; no optimal MoE muP or universal architecture claim.',
 'Experts without gradients skip update and independent decay; active expert exposure and per-parameter cumulative shrinkage are not matched.',
 'Sampled per-layer routing snapshots do not measure whole-run balance; current MPS allocation is not peak unified memory.',
 'Deep reference aliases selected dense in six cells prospectively; it is not an independent repeat. No completed-trial rerun, grid extension or larger-width reselection.']
artifacts=[run/f for f in ['plan.json','selection.json','report.json','review.json']]+[root/'research_state/moe-guard-validation/completion-audit.py']
entry=dict(kind='result',title='MoE quality comparison with ordinary and wider dense SwiGLU',summary=summary,outcome='supported' if adopt else 'mixed',created_by='continuing-quality-research',scope=dict(source_commit=rev['source_commit'],screen_seeds=[2081,2082],confirmation_seeds=[2091,2092,2093],widths=[64,256],updates=3000,targets_per_trial=3072000,batch_layout='paired_blocks512',validation_targets=111538,primary_context=128,holdout_consumed=False),details=dict(means=means,routing_diagnostics=routing,training_time_change_percent=cost,comparisons=r['comparisons'],fixed_lr_screening=r['screening_fixed_lr_comparisons'],quality_decision=rev['quality_decision'],reference_aliases=r['reference_aliases'],active_seconds=rev['active_seconds'],limitations=limits),artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in artifacts],related_ids=['kb_f78b8e2b0c5398346300f36d72759fb2cad30f21b3362d17b8e6959e3d35cc3d','kb_99c0df501b8697638f75c1350d4417b80c7a133cd8253ba37a9e8147de753f2d','kb_c2a568079b5917ec060c9abb57311d21782a4b31b09c490c816320db5ce7bdb6','kb_679efb244ca95cbcc6f098063fc5fb7364638022d97952609fbe096fc432686f'])
assert max(comparison('moe4_top2','dense_wide',256)['sensitivity'][0]['paired_seed_deltas'].values())>0
assert min(comparison('moe4_top2','dense_wide',256)['sensitivity'][0]['paired_seed_deltas'].values())>0
assert sum(v>0 for v in comparison('moe4_top2','dense',256)['sensitivity'][0]['paired_seed_deltas'].values())==2
assert all(max(comparison('dense_wide','dense',w)['sensitivity'][0]['paired_seed_deltas'].values())<0 for w in [64,256])
conpath=root/'research_state/moe-conclusion.json';assert not conpath.exists()
bank=KnowledgeBank(root/'research_state/knowledge');kid=bank.add(entry)
con=dict(result_id=kid,summary=summary,means=means,routing_diagnostics=routing,training_time_change_percent=cost,comparisons=r['comparisons'],quality_decision=rev['quality_decision'],limitations=limits,review=str(run/'review.json'),historical_incumbent_unchanged=not adopt)
conpath.write_text(json.dumps(con,indent=2)+'\n')
bpath=root/'research_state/best-observed-config.json';old=json.loads(bpath.read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
if adopt:
 archive=root/'research_state/best-observed-before-moe-quality001.json';assert not archive.exists();archive.write_bytes(bpath.read_bytes());archive.chmod(0o444)
 cfg=study.suite_spec(p,winner,.0025)['candidate']['config'];base=copy.deepcopy(p['config'])
 overrides=[]
 for section in ['model','training']:
  for k,v in cfg[section].items():
   if base[section].get(k)!=v:overrides.append(dict(path=section+'.'+k,value_json=json.dumps(v)))
 b=dict(label='Most promising observed quality recipe: four-layer top2-of4 SwiGLU MoE with MHA',baseline_commit=rev['source_commit'],baseline_config=base,config_overrides=overrides,reference_overrides={},result_id=kid,source_campaign=str(run),source_iteration=None,evidence_path=str(run/'report.json'),source_contract=dict(source_sha256=p['source_sha256'],data_sha256=p['data_sha256']),previous_best=dict(path=str(archive),sha256=file_digest(archive),result_id=old['result_id']),cheaper_reference=dict(path=str(archive),description='Prior four-layer dense SwiGLU/MHA quality recipe; original GELU baseline and two-layer reference retained.'),selection=dict(path=str(run/'selection.json'),winner=winner,rule=rev['quality_decision']['rule']),quality_decision=rev['quality_decision'],local_outcome='supported',transfer_outcome='supported_at_tested_widths',metrics=[dict(target=f'width-{w}',metric='full_validation_context128_ce_delta',candidate_mean=means[winner][str(w)]['ce128'],baseline_mean=means['dense'][str(w)]['ce128'],**comparison(winner,'dense',w)['sensitivity'][0]) for w in [64,256]],comparators=means,training_steps=3000,widths=[64,256],seeds=[2091,2092,2093],holdout_consumed=False,stage1_control_retained_as_reference=True,ranking_scope=limits[0],limitations=limits,last_reviewed_at=now,learning_ids=[])
else:
 b=old;b.setdefault('subsequent_architecture_studies',[]).append(dict(campaign=str(run),result_id=kid,review=str(run/'review.json'),summary=summary,means=means,quality_decision=rev['quality_decision']));b['last_reviewed_at']=now
bpath.write_text(json.dumps(b,indent=2)+'\n')
snap=root/'research_state/moe-completed-knowledge-snapshot.md';assert not snap.exists();snap.write_text(bank.export_markdown());snap.chmod(0o444)
lines=['# MoE quality results','',summary,'',f'Historical source: `{rev["source_commit"]}`. Result: `{kid}`. All48 checkpoint/raw request/result hashes and saved model, sampler, optimizer and runtime contracts were audited. Final private training RNG was reconstructed; saved test RNG is untouched. Every report aggregate and conditional bootstrap interval was independently reconstructed. No training or quality evaluation was rerun.','',f'18 full-budget screening trials plus30 distinct confirmation/reference trials. Six fixed deep references alias selected dense checkpoints prospectively. Active controller time: {rev["active_seconds"]:.2f}seconds ({rev["active_seconds"]/3600:.2f}hours). Output before review: {rev["disk_mb"]:.2f}MiB. [Frozen protocol](MOE_QUALITY_PROTOCOL.md).','','## Recipes and validation scores','','All three families independently selected LR.0025, an interior grid point, using width64 seeds2081/2082. The screen winner and complete manifest were frozen before fresh2091/2092/2093 confirmation at widths64/256. All runs process3,072,000 targets over3000 updates; final full-validation128 evaluates111,538 targets once per model. No historical pooling or holdout access.','','| Recipe | LR | CE64 | CE256 | Training seconds64 | Training seconds256 |','|---|---:|---:|---:|---:|---:|']
for f in families:
 a,z=means[f]['64'],means[f]['256'];lr=next(v['lr'] for v in rows if v['family']==f);lines.append(f'| {f} | {lr:g} | {a["ce128"]:.6f} | {z["ce128"]:.6f} | {a["training_seconds"]:.2f} | {z["training_seconds"]:.2f} |')
lines+=['','## Paired confirmation contrasts','','Positive CE delta is worse. Seed values are2091/2092/2093. Intervals use4096-token text blocks; all2048/4096/8192 intervals are preserved and verified in the report. They are conditional on these trained models and this reused validation text, not population seed uncertainty.','','| Width | Candidate minus reference | Mean delta | Paired seed deltas | Conditional95% text interval |','|---:|---|---:|---|---|']
for c in r['comparisons']:
 v=c['sensitivity'][1];lo,hi=v['conditional_text_bootstrap_95pct'];ds=' / '.join(f'{v["paired_seed_deltas"][str(seed)]:+.6f}' for seed in [2091,2092,2093]);lines.append(f'| {c["width"]} | {c["candidate"]} − {c["reference"]} | {v["mean_delta"]:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] |')
lines+=['','At width64, MoE versus wider dense has mixed seed signs and a4096-block interval including zero. At width256, MoE is worse than wider dense on every confirmation seed and worse than ordinary dense on two of three seeds. The local MoE gain therefore does not transfer under the frozen rule. Wider dense improves every seed versus ordinary dense at both widths, but it was not the frozen screen winner and cannot be promoted retrospectively from this round. These observations motivate later prospective work, not a revised selection. Extra stored capacity and routed computation change together; the study does not isolate routing as the cause.','','## Fixed-LR screening and costs','','Screening contrasts below use LR.0025 on both sides and seeds2081/2082; they are distinct from the confirmation evidence.','','| Candidate minus reference | Mean delta | Seed2081 | Seed2082 |','|---|---:|---:|---:|']
for c in r['screening_fixed_lr_comparisons']:
 v=c['sensitivity'][0];lines.append(f'| {c["candidate"]} − {c["reference"]} | {v["mean_delta"]:+.6f} | {v["paired_seed_deltas"]["2081"]:+.6f} | {v["paired_seed_deltas"]["2082"]:+.6f} |')
lines+=['','| Recipe | Time change64 vs dense | Time change256 vs dense |','|---|---:|---:|']
for f in cost:lines.append(f'| {f} | {cost[f]["64"]:+.2f}% | {cost[f]["256"]:+.2f}% |')
lines+=['','Final logged routing diagnostics (three confirmation seeds; fractions of top2 assignments):','','| Width | Minimum per-expert assignment fraction | Maximum | Mean auxiliary loss |','|---:|---:|---:|---:|']
for w,v in routing.items():lines.append(f'| {w} | {v["final_logged_assignment_fraction_min"]:.4f} | {v["final_logged_assignment_fraction_max"]:.4f} | {v["mean_final_logged_auxiliary_loss"]:.4f} |')
lines+=['','Each row summarizes the last sampled training batch across four layers and three seeds. These are not cumulative token-exposure statistics or evidence that balanced routing caused the quality change. Auxiliary loss is excluded from validation CE.']
lines+=['','Training seconds exclude process overhead and final full validation. Ordinary dense stores/activates204,544 and3,152,896 parameters at widths64/256; wider dense333,568 and5,217,280. MoE stores334,592 and5,221,376 and activates205,568 and3,156,992 per token including routers. These counts do not equalize measured compute or establish inference efficiency.','','## Decision and continuing research','',rev['quality_decision']['rule'],'',('MoE passes and is recorded as the current observed quality incumbent. The prior four-layer dense incumbent is archived and retained as a reference.' if adopt else 'MoE does not pass the complete rule. The prior dense incumbent remains, while all narrower observations are preserved.'),'','The next finite round tests constant, cosine-decay and late-cooldown learning rates on the reviewed incumbent with fresh constant and historical references. Implementation, resume correctness, source/resource checks and a separate preregistration are required before launch. This is a future protocol, not measured evidence. The continuing human quality objective remains active; all completed studies and campaign006 remain closed.','','## Limitations','']+['- '+v for v in limits]+['','Evidence: `research_runs/moe-quality-001/{plan,selection,state,report,review}.json`, all immutable per-trial artifacts, `research_state/moe-guard-validation/completion-audit.py`, and full knowledge snapshots. The human kimi checkout remains untouched.']
Path('/private/tmp/MOE_QUALITY_RESULTS.md').write_text('\n'.join(lines)+'\n')
guide='## Completed MoE quality round\n\n'+summary+'\n\n'+'\n'.join(lines[lines.index('| Recipe | LR | CE64 | CE256 | Training seconds64 | Training seconds256 |'):lines.index('## Paired confirmation contrasts')])+'\nMoE improves locally but fails width256 transfer. Wider dense remains a promising later candidate; the frozen screen winner is not revised. Equal tokens do not mean equal compute. [Complete MoE results and paired evidence](MOE_QUALITY_RESULTS.md).\n'
Path('/private/tmp/moe-guide-addition.md').write_text(guide)
print(kid);print(summary);print(json.dumps(cost))
