"""Read-only CPU audit of frozen MoE evidence. --partial never writes final review."""
import argparse
import copy
import datetime
import json
import math
from pathlib import Path
import numpy as np
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.research import moe_study as study
from src.research.protocol import digest, file_digest
from src.research.runner import validate_result, disk_mb
from src.research.team.suite import _request

parser=argparse.ArgumentParser()
parser.add_argument('--partial',action='store_true')
args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
run=root/'research_runs/moe-quality-001'
p=json.loads((run/'plan.json').read_text())
s=json.loads((run/'state.json').read_text())
study.verify_lineage(p)
assert digest(p)==s['plan_sha256']=='5b4087081879dc815a51348f42ef9c1bce8886c01ab455bedbcd041a7ce5453d'
assert p==json.loads((root/'research_state/moe-plan.json').read_text())
records=[r for r in s['records'] if r['status']=='completed']
assert len({r['trial_id'] for r in s['records']})==len(s['records'])
screen=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())
 assert study.freeze_selection(p,records[:18])==s['selection']
 expected=screen+s['selection']['confirmation']['jobs']
 assert s['selection']['confirmation']['reference_aliases']==(
     {'deep_reference':'dense'} if s['selection']['choices']['dense']['lr']==.0025 else {})
else:
 expected=screen
assert [[r[k] for k in ['family','lr','width','seed']] for r in s['records']]==expected[:len(s['records'])]
assert disk_mb(run)<4096
if not args.partial:
 assert s['status']=='completed' and len(records)==len(expected)==s['selection']['confirmation']['total_distinct_trials']
 assert len(records) in (48,54) and s['active_seconds']<28800
 assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in records[18:])

torch.set_num_threads(1)
checks=[]
data_length=len(Path(p['config']['data']['path']).read_text())
for i,r in enumerate(records):
 assert r['error'] is None and r['duration_seconds']<1800
 d=run/'trials'/r['trial_id']
 req=json.loads((d/'request.json').read_text())
 raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):
  assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model']
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['eval_iters']==30 and raw['eval_every']==300
 assert [x['step'] for x in raw['metrics']]==list(range(0,3000,300))+[2999]
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==3000
 metrics=[json.loads(line) for line in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics']
 assert max(x['rss_mb'] for x in metrics)<4096
 cp=torch.load(r['checkpoint'],map_location='cpu',weights_only=False)
 assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==3000 and cp['model_math_version']==2 and cp['parameter_layout_version']==2
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65
 assert cp['cfg']==want
 assert t['batch_size']==8 and t['max_iters']==3000 and m['block_size']==128
 assert cp['step']*t['batch_size']*m['block_size']==3072000
 assert t['weight_decay']==.00006 and t['batch_layout']=='paired_blocks512'
 assert cp['training_state']['contract']==dict(batch_layout='paired_blocks512',
     optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],
     data_sha256=p['data_sha256'],data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,
     torch_version=p['runtime']['packages']['torch'],device='mps',
     training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(3000):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==.00006
 torch.manual_seed(r['seed'])
 model=GPT(OmegaConf.create(want['model']))
 initial={name:param.detach().clone() for name,param in model.named_parameters()}
 weights=cp['model_state'];model.load_state_dict(weights,strict=True)
 assert all(torch.isfinite(value).all() for value in weights.values())
 named=dict(model.named_parameters());seen=[];inactive=[]
 for opt in cp['optimizer_state']['optimizers']:
  for group in opt['param_groups']:
   assert len(group['parameter_names'])==len(group['params'])==1
   name=group['parameter_names'][0];seen.append(name);param=named[name]
   router=m['mlp_type']=='moe' and name.endswith('.mlp.router.weight')
   hidden=name.startswith('transformer.h.') and param.ndim==2 and not router
   scale=1/math.sqrt(r['width']/64) if hidden else 1.
   assert group['width_lr_scale']==scale and group['lr']==r['lr']*scale and group['weight_decay']==0
   slots=opt['state'].get(group['params'][0])
   if slots is None:
    # Only never-selected experts may lack optimizer state. Their weights must
    # remain exactly initialized because the optimizer skips missing gradients.
    assert '.mlp.experts.' in name
    assert torch.equal(param,initial[name]);inactive.append(name)
    continue
   if hidden:
    assert group['momentum']==.95 and group['adjust_lr_fn']=='match_rms_adamw'
    assert set(slots)=={'momentum_buffer'}
   else:
    assert group['betas']==(.9,.999) and slots['step'].item()==3000
    assert set(slots)=={'step','exp_avg','exp_avg_sq'}
   for key,value in slots.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==param.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 w=r['width'];sett=study.settings(r['family']);depth=sett['depth']
 assert len(model.transformer.h)==depth and model.cfg.n_heads==w//32
 active=total=sum(param.numel() for param in model.parameters())
 for layer in range(depth):
  prefix=f'transformer.h.{layer}.'
  assert list(weights[prefix+'attn.qkv.weight'].shape)==[3*w,w]
  assert list(weights[prefix+'attn.out.weight'].shape)==[w,w]
  assert list(weights[prefix+'freq_cos'].shape)==[128,16]
  if r['family']=='moe4_top2':
   hidden=21*w//16
   assert list(weights[prefix+'mlp.router.weight'].shape)==[4,w]
   assert model.transformer.h[layer].mlp.router_width_mult==w/64
   for expert in range(4):
    ep=prefix+f'mlp.experts.{expert}.'
    for name in ('linear_gate','linear_up'):assert list(weights[ep+name+'.weight'].shape)==[hidden,w]
    assert list(weights[ep+'linear_down.weight'].shape)==[w,hidden]
   active-=2*3*w*hidden
  elif r['family']!='gelu_reference':
   hidden=21*w//(4 if r['family']=='dense_wide' else 8)
   for name in ('linear_gate','linear_up'):assert list(weights[prefix+'mlp.'+name+'.weight'].shape)==[hidden,w]
   assert list(weights[prefix+'mlp.linear_down.weight'].shape)==[w,hidden]
  else:
   assert list(weights[prefix+'mlp.0.weight'].shape)==[4*w,w]
   assert list(weights[prefix+'mlp.2.weight'].shape)==[w,4*w]
 assert not any('wpe' in name for name in weights)
 if r['family'] in study.CELLS:
  expected_counts={'dense':{64:204544,256:3152896},'dense_wide':{64:333568,256:5217280},'moe4_top2':{64:334592,256:5221376}}
  assert total==expected_counts[r['family']][w]
  if r['family']=='moe4_top2':assert active=={64:205568,256:3156992}[w]
 if m['mlp_type']=='moe':
  assert len(r['routing_snapshots'])==11
  for row in metrics:
   assert [v['layer_idx'] for v in row['moe_usage']['per_layer']]==list(range(4))
   assert math.isclose(row['train_loss'],row['train_ce_loss']+.01*row['train_aux_loss'],abs_tol=2e-6)
   assert row['train_aux_loss']>=0 and row['val_aux_loss'] is None
   layers=np.array([v['usage'] for v in row['moe_usage']['per_layer']])
   assert np.allclose(layers.mean(0),row['moe_usage']['aggregate'],rtol=0,atol=1e-7)
   assert np.allclose(layers*2048,np.round(layers*2048),rtol=0,atol=1e-6)
 assert set(r['coverage'])=={'128'}
 ev=r['coverage']['128'];assert ev['block_target_counts']==[2048]*54+[946]
 assert ev['target_count']==111538 and ev['eval_batch_size']==8 and ev['window_count']==872
 assert math.isclose(sum(ev['block_loss_sums'])/111538,ev['mean_ce'],abs_tol=1e-12)
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
     result_sha256=r['result_sha256'],total_parameters=total,active_parameters_per_token=active,never_updated_expert_parameters=inactive))
 if (i+1)%12==0:print('Verified',i+1,flush=True)

review=dict(status='partial_verified' if args.partial else 'verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_checkpoints=len(records),
    holdout_consumed=False,training_rerun=False,checkpoint_audit=checks)
if args.partial:
 (root/'research_state/moe-guard-validation/partial-audit.json').write_text(json.dumps(review,indent=2)+'\n')
 print('PARTIAL VERIFIED',len(records))
 raise SystemExit(0)

report=json.loads((run/'report.json').read_text())
assert study.summarize(p,s)==report
for c in report['comparisons']+[{**v,'width':64,'screening':True} for v in report['screening_fixed_lr_comparisons']]:
 rows={(r['family'],r['width'],r['seed']):r for r in records
       if r['stage']==('local' if c.get('screening') else 'confirmation') and (not c.get('screening') or r['lr']==.0025)}
 if not c.get('screening'):
  for alias,family in s['selection']['confirmation']['reference_aliases'].items():
   for w in (64,256):
    for seed in study.CONFIRM_SEEDS:rows[alias,w,seed]=rows[family,w,seed]
 seeds=study.SCREEN_SEEDS if c.get('screening') else study.CONFIRM_SEEDS
 for v in c['sensitivity']:
  aa=[rows[c['candidate'],c['width'],seed]['coverage']['128'] for seed in seeds]
  bb=[rows[c['reference'],c['width'],seed]['coverage']['128'] for seed in seeds]
  diffs=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0)
  counts=np.array(aa[0]['block_target_counts']);factor=v['text_block_tokens']//2048
  chunks=np.array([diffs[j:j+factor].sum() for j in range(0,len(diffs),factor)])
  cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
  idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)))
  boot=chunks[idx].sum(1)/cnt[idx].sum(1)
  assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
  assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],abs_tol=1e-12)
  for seed,a,b in zip(seeds,aa,bb):assert math.isclose(a['mean_ce']-b['mean_ce'],v['paired_seed_deltas'][str(seed)],abs_tol=1e-12)
 if 'near_neutral_common128' in c:
  assert c['near_neutral_common128']==all(v['mean_delta']<=.01 and max(v['paired_seed_deltas'].values())<=.01
     and v['conditional_text_bootstrap_95pct'][1]<=.01 for v in c['sensitivity'])
 if 'quality_improvement' in c:
  v=c['sensitivity'][0];assert c['quality_improvement']==(v['mean_delta']<-.005 and max(v['paired_seed_deltas'].values())<0)

# Independent architecture and LR decisions, without relying on report helper.
choices={}
for family in study.CELLS:
 scores={lr:math.fsum(r['metric'] for r in records[:18] if r['family']==family and r['lr']==lr)/2 for lr in study.LRS}
 lr=min(scores,key=lambda x:(scores[x],x));choices[family]=(lr,scores[lr])
 assert lr==s['selection']['choices'][family]['lr']
def panel(f,lr):return {r['seed']:r['metric'] for r in records[:18] if r['family']==f and r['lr']==lr}
eligible=[]
for f in ('dense_wide','moe4_top2'):
 a=panel(f,choices[f][0]);pass_all=True
 for lr in (choices['dense'][0],.0025):
  b=panel('dense',lr);delta=[a[seed]-b[seed] for seed in study.SCREEN_SEEDS]
  pass_all &= math.fsum(delta)/2<-.005 and max(delta)<0
 if pass_all:eligible.append(f)
winner=min(eligible,key=lambda f:(choices[f][1],f)) if eligible else 'historical_incumbent_unchanged'
assert winner==s['selection']['winner']
adoption_checks=[]
if winner!='historical_incumbent_unchanged':
 for width in (64,256):
  for reference in ('dense','deep_reference'):
   match=[c for c in report['comparisons'] if c['width']==width and
          c['candidate']==winner and c['reference']==reference]
   assert len(match)==1
   v=match[0]['sensitivity'][0]
   adoption_checks.append(dict(width=width,reference=reference,
       mean_delta=v['mean_delta'],paired_seed_deltas=v['paired_seed_deltas'],
       supported=v['mean_delta'] < -p['min_improvement'] and
                 all(delta<0 for delta in v['paired_seed_deltas'].values())))
quality_decision=dict(frozen_screen_winner=winner,
    qualifies_for_incumbent_replacement=bool(adoption_checks) and all(c['supported'] for c in adoption_checks),
    confirmation_checks=adoption_checks,
    rule='Only the width64 screen winner can qualify; confirmation mean gain>.005 and every seed improves at widths64 and256 versus tuned dense and fixed deep reference.',
    limitations='Adaptive validation; conditional text bootstrap is descriptive, not independent seed uncertainty or holdout. No larger-width reselection.')
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),screen_trials=18,
 confirmation_and_reference_trials=len(records)-18,reference_aliases=s['selection']['confirmation']['reference_aliases'],
 active_seconds=s['active_seconds'],disk_mb=disk_mb(run),quality_decision=quality_decision,
 checks=['All distinct raw request/result/checkpoint hashes, configs, runtime, final3000updates and3072000targets',
 'Strict finite CPU weight/optimizer loads; exact router/attention/expert/group scaling; step counts for Adam parameters; inactive experts validated if any',
 'Reconstructed final private train RNG and untouched test RNG; bound sampler and resume model contracts',
 'Layer/head/QKV/FFN/expert/router shapes and total/active parameter counts; full111538target coverage',
 'Training CE+.01aux and per-layer assignment snapshots checked separately from trusted validation CE',
 'Exact18screen and freshconfirmation schedule; frozen LR/architecture selection and reference aliases independently checked',
 'Entire report reproduced from evidence; every paired bootstrap, mean and reported quality gate independently reconstructed',
 'Source/corpus/runtime/fullbank/prerequisite artifacts verified; no training/evaluation reruns or holdout access'])
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print('VERIFIED',len(records),review['active_seconds'],review['disk_mb'])
