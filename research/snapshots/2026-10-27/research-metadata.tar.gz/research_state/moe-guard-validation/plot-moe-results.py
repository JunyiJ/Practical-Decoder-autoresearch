import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
c=json.loads((root/'research_state/moe-conclusion.json').read_text())
rev=json.loads(Path(c['review']).read_text());assert rev['status']=='verified'
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,3,figsize=(13,4),gridspec_kw={'width_ratios':[1,1,1.15]})
colors={'dense_wide':'#287c9d','moe4_top2':'#ae4a52'}
for ax,w in zip(axes[:2],[64,256]):
 for i,f in enumerate(['dense_wide','moe4_top2']):
  vals=next(x for x in c['comparisons'] if x['candidate']==f and x['reference']=='dense' and x['width']==w)['sensitivity'][1]
  ds=list(vals['paired_seed_deltas'].values());ax.scatter(np.array([i]*3)+[-.10,0,.10],ds,color=colors[f],s=28,label='Paired seeds' if i==0 else None)
  ax.scatter(i,vals['mean_delta'],marker='D',s=65,color=colors[f],edgecolor='white',zorder=4)
 ax.axhline(0,color='#555',linewidth=.8);ax.axhline(-.005,color='#999',linewidth=.8,linestyle=':')
 ax.set_xticks([0,1],['Wider dense','Top2 MoE']);ax.set_title(f'Width {w}: quality versus dense');ax.set_ylabel('Paired validation CE difference');ax.grid(axis='y',alpha=.15)
ax=axes[2]
for i,f in enumerate(['dense_wide','moe4_top2']):
 ax.bar(np.arange(2)+(i-.5)*.32,[c['training_time_change_percent'][f][str(w)] for w in [64,256]],width=.30,color=colors[f],label='Wider dense' if f=='dense_wide' else 'Top2 MoE')
ax.set_xticks([0,1],['Width64','Width256']);ax.set_ylabel('Training time change versus dense (%)');ax.set_title('Measured training cost');ax.legend(frameon=False);ax.grid(axis='y',alpha=.15)
fig.suptitle('MoE quality001 — fresh confirmation, equal training targets',fontsize=14)
fig.text(.02,.02,'Dots: three paired development seeds. Diamonds: means. Adaptive validation; no holdout. Equal tokens do not mean equal compute.',fontsize=9,color='#555')
fig.tight_layout(rect=[0,.06,1,.93]);out=root/'research_state/reports/pretraining-learning-guide/moe-quality001.png';fig.savefig(out,dpi=180);print(out)
