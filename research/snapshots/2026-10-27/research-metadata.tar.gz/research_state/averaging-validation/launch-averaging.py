"""Launch only a newly frozen averaging round, serially, after reviewed capacity."""
import argparse,datetime,json,os,re,subprocess,sys
from pathlib import Path
from src.research import averaging_study as study
parser=argparse.ArgumentParser();parser.add_argument('--launch',action='store_true');args=parser.parse_args()
if not args.launch:parser.error('Explicit --launch is required')
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();run=root/'research_runs/averaging-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
p=json.loads((run/'plan.json').read_text());assert not (run/'state.json').exists() and not (run/'controller.log').exists();study.verify_lineage(p)
fp=root/'research_state/active-campaign.json';active=json.loads(fp.read_text());prior=root/'research_runs/capacity-quality-001'
assert active['status']=='completed_reviewed' and active['campaign']==str(prior) and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|context_interaction|context256_study|batch_study)|src\.train\.train',x)],'A known model/research process is live'
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
now=datetime.datetime.now(datetime.timezone.utc).isoformat();env=os.environ.copy();env.pop('PYTORCH_ENABLE_MPS_FALLBACK',None)
with (run/'controller.log').open('x') as log:
 proc=subprocess.Popen([sys.executable,'-m','src.research.averaging_study','--plan',str(run/'plan.json'),'--output',str(run),'--allow-training'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
def write(path,data):
 temporary=path.with_name(path.name+'.launch-tmp');temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(path)
history=active.setdefault('completed_algorithm_studies',[])
if not any(x.get('campaign')==str(prior) for x in history):history.append(dict(campaign=str(prior),source_commit=active['source_commit'],review=active['review'],result_id=active['result_id'],documentation_commit=active.get('documentation_commit'),status='completed_reviewed'))
active.update(campaign=str(run),kind='averaging_quality',stage='averaging_quality',status='running',pid=proc.pid,launched_at=now,source_commit=p['git_commit'],source_root=str(source),plan=str(run/'plan.json'),state_file=str(run/'state.json'),predecessor=str(prior),scope='Eight fresh trajectories; raw and3registered spaced-tail averages per trajectory,32correlated final outputs.2screens then6fresh confirmations,context128,3072000targets,holdoutclosed.',next_action='Verify launch and monitor one frozen averaging worker; audit all8raw+24derived checkpoints and full report at completion, then pursue the next justified finite quality round until human interruption.')
for key in ['review','result_id','documentation_commit','completed_reviewed_at','completed_at']:active.pop(key,None)
write(fp,active)
fp=root/'research_state/research-monitor.json';m=json.loads(fp.read_text());m.update(active_stage='averaging_quality',active_study=str(run),status='running',last_checked_at=now,last_live_controller_pid=proc.pid,averaging_launch_notified=False,averaging_record_count=0,next_action=active['next_action']);write(fp,m)
fp=root/'research_state/quality-evolution-progress.json';d=json.loads(fp.read_text());d.update(status='running',active_study=str(run),protocol=str(source/'research/AVERAGING_QUALITY_PROTOCOL.md'),source_commit=p['git_commit'],preregistration_id=p['preregistration_id'],implementation_id=p['implementation_id'],next_action=active['next_action'],last_checked_at=now,averaging_recipe=p['recipe'],averaging_record_count=0,completion_audit=str(root/'research_state/averaging-validation/completion-audit.py'));write(fp,d)
print(json.dumps(dict(pid=proc.pid,source_commit=p['git_commit'],recipe=p['recipe'],run=str(run))))
