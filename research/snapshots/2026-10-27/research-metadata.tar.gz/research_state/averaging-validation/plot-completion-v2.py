"""Plot only completed reviewed averaging evidence; no new model scoring."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');con=json.loads((root/'research_state/averaging-conclusion.json').read_text());review=json.loads(Path(con['review']).read_text());assert review['status']=='verified' and review['distinct_checkpoints']==32
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,2,figsize=(11,4.6),sharex=True)
for ax,w in zip(axes,[64,256]):
 for i,h in enumerate([10,50,200]):
  c=next(x for x in con['comparisons'] if x['width']==w and x['half_life']==h);v=c['sensitivity'][1];ds=[v['paired_seed_deltas'][str(s)] for s in [2151,2152,2153]];color='#087d87' if h==con['selection']['half_life'] else '#668097'
  ax.scatter(ds,np.array([i]*3)+[-.11,0,.11],s=32,color=color,zorder=3)
  lo,hi=v['conditional_text_bootstrap_95pct'];ax.plot([lo,hi],[i,i],color=color,linewidth=2,alpha=.75)
  ax.scatter(v['mean_delta'],i,marker='D',color=color,s=68,edgecolor='white',zorder=4)
 ax.set_xlim(-.020,.001);ax.set_xticks([-.020,-.015,-.010,-.005,0]);ax.set_xticklabels(['−0.020','−0.015','−0.010','−0.005','0.000']);ax.axvline(0,color='#555',linewidth=.8);ax.axvline(-.002,color='#888',linewidth=.8,linestyle=':');ax.set_yticks([0,1,2],['Half-life 10','Half-life 50','Half-life 200']);ax.invert_yaxis();ax.set_title(f'Width {w}');ax.set_xlabel('CE difference versus own raw endpoint');ax.grid(axis='x',alpha=.15)
fig.suptitle('Tail averaging — fresh paired confirmation',fontsize=15)
fig.text(.02,.035,'Lower is better. Dots: paired seeds. Diamonds: means. Lines: conditional text intervals. Dotted line: mean-gain threshold.\nThe colored half-life was frozen at width64 before confirmation; adaptive validation, no holdout.',fontsize=9,color='#555')
fig.tight_layout(rect=[0,.12,1,.93]);out=root/'research_state/reports/pretraining-learning-guide/averaging-quality001.png';fig.savefig(out,dpi=180);print(out)
