import datetime,json,hashlib,subprocess,difflib
from pathlib import Path
from src.research.team.knowledge import KnowledgeBank
from src.research.team.suite import source_digest
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');dev=Path('/private/tmp/rsi-averaging-quality-development');out=root/'research_state/averaging-validation'
source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');base='ae566ead098f11aeb72f5aa0901930e6c69ec7e8'
def artifact(p):return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
plans=sorted(set(root.glob('research_runs/*/plan.json'))|set(root.glob('research_state/*plan.json')));seeds={2141,2142,2151,2152,2153};conflicts=[]
def visit(x,name):
 if isinstance(x,dict):
  for k,v in x.items():
   if 'seed' in k.lower():
    vals=v if isinstance(v,list) else [v];hit=seeds.intersection(z for z in vals if type(z)is int)
    if hit:conflicts.append(dict(path=name,field=k,seeds=sorted(hit)))
   visit(v,name)
 elif isinstance(x,list):
  for v in x:visit(v,name)
for p in plans:visit(json.loads(p.read_text()),str(p))
assert not conflicts
seedpath=out/'expanded-prospective-seed-check.json';assert not seedpath.exists();seedpath.write_text(json.dumps(dict(status='verified_no_overlap_provisional',seeds=sorted(seeds),plans=[artifact(p) for p in plans],conflicts=conflicts,repeat_before_preregistration=True),indent=2)+'\n');seedpath.chmod(0o444)
files=['src/train/weight_averaging.py','src/train/train.py','src/utils/checkpoint.py','src/research/team/suite.py','src/research/runner.py','src/research/averaging_eval.py','src/research/averaging_study.py','tests/test_weight_averaging.py','tests/test_averaging_training.py','tests/test_averaging_study.py']
patch=[]
for name in files:
 result=subprocess.run(['git','show',base+':'+name],cwd=source,capture_output=True,text=True)
 old=result.stdout if result.returncode==0 else ''
 patch.extend(difflib.unified_diff(old.splitlines(True),(dev/name).read_text().splitlines(True),fromfile='a/'+name if result.returncode==0 else '/dev/null',tofile='b/'+name))
patchpath=out/'controller-development.patch';assert not patchpath.exists();patchpath.write_text(''.join(patch));patchpath.chmod(0o444)
review=dict(status='controller_preparation_not_launch_ready',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=base,
 development_root=str(dev),source_sha256=source_digest(dev),code=[artifact(dev/x) for x in files],patch=artifact(patchpath),
 synthetic_tests=dict(passed=75,seconds=1.84,log=artifact(out/'controller-tensor-tests-third.log'),scope='39 tiny tensor/configuration plus36 controller/metadata/bootstrap gates; no actual model training or MPS'),
 controller=dict(physical_trajectories=8,returned_models=32,half_lives=[10,50,200],screen_seeds=[2141,2142],confirmation_seeds=[2151,2152,2153],
 tests=['Fixed family and LR contracts','Shorter-half-life tie and bad-seed veto','No larger-width reselection, no adoption after failed local eligibility','Positive conditional text upper bound vetoes otherwise all-seed mean gain','Real serial engine freezes after two mock trajectories, first failure stops without automatic retry','Strict derived metadata, raw-parent hashes and full validation target counts']),
 seed_check=artifact(seedpath),deferred_pilot_driver=artifact(out/'pilot-driver.py'),
 remaining=['Six actual CPU trainer tests written but deferred: online bitwise invariance and exact resume before/at/after averaging start acrossall3backbones/bothwidths; strict derived exports and corruption guards','Full project CPU suite and actual serialMPS6workerpilots notrun','Pilotdriver requires completed capacity pointer, no live researchprocesses, finalcapacityreview and cleancommitted source matching CPUreview; tracked/raw/resumed40update checks at64/256 with18totalfullcoverageoutputs, no researchqualityclaim','Actual resource/time/cpoutput gates stillpending; no preregistration or launch','Final backbone resolves only from reviewed capacity adoption; current partial winner doesnotselectaveragingbackbone'],
 current_active_source_frozen=True,primary_human_checkout_untouched=True)
path=out/'controller-preparation-review.json';assert not path.exists();path.write_text(json.dumps(review,indent=2)+'\n');path.chmod(0o444)
kid=KnowledgeBank(root/'research_state/knowledge').add(dict(kind='learning',outcome='inconclusive',created_by='continuing-quality-research',title='Averaging prospective controller: finite paired trajectories and selection gates verified synthetically',summary='The separate averaging controller passed75 CPU tensor/configuration/synthetic control tests. Eight proposed trajectories return32 correlated raw/average models; screenhalf-life frozenbeforefreshconfirmation, withallseedandconditionaltext gates. Actual trainer/export/MPS/resource gates remain deferred while capacity researchruns; no launch or qualityfinding.',scope=dict(stage='preparation',training_launched=False,holdout_consumed=False),details=review,artifacts=[artifact(path),artifact(patchpath),artifact(seedpath)],related_ids=['kb_d8530492057a845304c9359f5e6a940bf6b31bcea025b221e994501e611145e7']))
(out/'controller-preparation-knowledge.json').write_text(json.dumps(dict(result_id=kid),indent=2)+'\n');print(kid);print('seedplans',len(plans));print('patchbytes',patchpath.stat().st_size)
