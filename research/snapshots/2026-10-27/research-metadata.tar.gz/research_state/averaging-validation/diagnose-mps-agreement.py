"""Three bounded raw-only diagnostics after preserved averaging pilot failure."""
import copy,json,time
from pathlib import Path
import torch
from src.research import averaging_study as study,capacity_study
from src.research.team.suite import _request,_launch,source_digest
from src.research.runner import atomic_json,session_lock,validate_result
from src.utils.checkpoint import read_checkpoint
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();out=root/'research_state/averaging-mps-diagnostic-001';out.mkdir(exist_ok=False)
p=study.make_plan(source,root/'research_runs/capacity-quality-001/review.json');began=time.monotonic();cps={};rows=[]
atomic_json(out/'intent.json',dict(purpose='Diagnose independent MPS raw-training agreement and deterministic-algorithm setting after preserved pilot001 failure; no quality research',source_commit=p['git_commit'],source_sha256=p['source_sha256'],jobs=['default_raw','deterministic_raw_a','deterministic_raw_b'],width=64,steps=40,seed=9304,max_job_seconds=180,max_round_seconds=600,max_disk_mb=512,holdout_consumed=False))
with session_lock(out) as fd:
 for mode in ['default_raw','deterministic_raw_a','deterministic_raw_b']:
  d=out/mode;d.mkdir();row=dict(family='trajectory',lr=.005,width=64,n_heads=2,seed=9304,stage='local',arm='candidate',trial_id=mode)
  req=_request(study.suite_spec(p,'trajectory',.005),row,d);t=req['config']['training'];t.update(max_iters=40,eval_every=20,eval_iters=2,checkpoint_every=0);t['lr_schedule'].update(total_steps=40,start_step=26);del t['weight_averaging'];atomic_json(d/'request.json',req)
  deterministic=mode!='default_raw';bootstrap=('import torch\ntorch.use_deterministic_algorithms(True)\n' if deterministic else '')+capacity_study.BOOTSTRAP
  status,error=_launch(d/'request.json',out,min(180,600-(time.monotonic()-began)),512,fd,root=source,bootstrap=bootstrap)
  if status!='completed':atomic_json(out/'failure.json',dict(mode=mode,status=status,error=error));raise RuntimeError(error)
  raw=json.loads((d/'result.json').read_text());checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);cps[mode]=read_checkpoint(checked['checkpoint']);rows.append(dict(mode=mode,checkpoint=checked['checkpoint'],checkpoint_sha256=checked['checkpoint_sha256'],training_seconds=raw['training_time_sec']));print(mode,'completed',flush=True)
old=json.loads((root/'research_state/averaging-pilots-001/w64_raw/result.json').read_text());cps['prior_default_raw']=read_checkpoint(old['final_checkpoint']);comparisons=[]
for a,b in [('prior_default_raw','default_raw'),('deterministic_raw_a','deterministic_raw_b')]:
 diffs=[(float((v-cps[b]['model_state'][k]).abs().max()),k) for k,v in cps[a]['model_state'].items()];comparisons.append(dict(a=a,b=b,max_abs_difference=max(diffs)[0],largest_tensor=max(diffs)[1],all_tensors_equal=all(torch.equal(v,cps[b]['model_state'][k]) for k,v in cps[a]['model_state'].items())))
atomic_json(out/'review.json',dict(status='diagnostic_completed',rows=rows,comparisons=comparisons,limitations='Small same-device diagnostic does not identify a specific nondeterministic kernel or establish universal reproducibility; no quality evidence.'))
print(json.dumps(comparisons),flush=True)
