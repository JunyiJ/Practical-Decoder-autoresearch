"""Direct MPS averaging noninterference and shared-gradient resume check.

Independent backward trajectories are deliberately not used as an arithmetic oracle.
CPU tests already verify exact full-training continuation; this check isolates MPS
shadow updates and resume using the same realized gradients for both continuations.
"""
import copy,json,time,datetime
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.train.optimizers import build_optimizer
from src.train.weight_averaging import TailWeightAverages
from src.research import averaging_study as study
from src.research.protocol import file_digest
from src.research.runner import atomic_json
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();out=root/'research_state/averaging-mps-coupled-001';out.mkdir(exist_ok=False)
p=study.make_plan(source,root/'research_runs/capacity-quality-001/review.json');torch.set_num_threads(4);began=time.monotonic();rows=[]
def cpu(x):
 if isinstance(x,torch.Tensor):return x.detach().cpu().clone()
 if isinstance(x,dict):return {k:cpu(v) for k,v in x.items()}
 if isinstance(x,list):return [cpu(v) for v in x]
 if isinstance(x,tuple):return tuple(cpu(v) for v in x)
 return copy.deepcopy(x)
def equal(a,b):
 if isinstance(a,torch.Tensor):assert torch.equal(a,b.cpu())
 elif isinstance(a,dict):
  assert set(a)==set(b)
  for k in a:equal(a[k],b[k])
 elif isinstance(a,(tuple,list)):
  assert len(a)==len(b)
  for x,y in zip(a,b):equal(x,y)
 else:assert a==b
atomic_json(out/'intent.json',dict(source_commit=p['git_commit'],source_sha256=p['source_sha256'],widths=[64,256],steps=8,batch=8,context=128,vocab=16,seed=9305,tail_start=4,interval=2,half_lives=[10,50,200],max_seconds=120,purpose='Synthetic MPS arithmetic/noninterference/shared-gradient resume; no quality measurement',tolerance=dict(atol=1e-4,rtol=2e-5)))
for width in [64,256]:
 cfg=OmegaConf.create(copy.deepcopy(p['config']));cfg.model.update(dim=width,n_heads=width//32,vocab_size=16)
 cfg.training.max_iters=8;cfg.training.weight_averaging.update(total_steps=8,start_step=4,interval=2)
 torch.manual_seed(9305);model=GPT(cfg.model).to('mps');optimizer=build_optimizer(model,cfg.training);tracker=TailWeightAverages(model,cfg.training)
 g=torch.Generator().manual_seed(9305);expected={};resumed=None;max_ema=0.;max_resume=0.;checks=0
 for step in range(1,9):
  assert time.monotonic()-began<120
  x=torch.randint(0,16,(8,128),generator=g).to('mps');y=torch.randint(0,16,(8,128),generator=g).to('mps')
  optimizer.zero_grad(set_to_none=True);loss=model(x,y)[1];loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
  if resumed:
   rm,ro,rt=resumed;ro.zero_grad(set_to_none=True)
   for (_,a),(_,b) in zip(model.named_parameters(),rm.named_parameters()):b.grad=a.grad.detach().clone()
   ro.step();rt.update(step)
  optimizer.step();torch.mps.synchronize()
  before=cpu(model.state_dict());optim_before=cpu(optimizer.state_dict());rng=torch.get_rng_state().clone();mrng=torch.mps.get_rng_state().clone()
  tracker.update(step);torch.mps.synchronize();equal(before,model.state_dict());equal(optim_before,optimizer.state_dict());assert torch.equal(rng,torch.get_rng_state()) and torch.equal(mrng,torch.mps.get_rng_state());checks+=1
  current={n:v.detach().cpu().double() for n,v in model.named_parameters()}
  if step==4:expected={str(h):{n:v.clone() for n,v in current.items()} for h in [10,50,200]}
  elif step>4 and (step-4)%2==0:
   for h,panel in expected.items():
    beta=2**(-2/int(h))
    for n in panel:panel[n]=beta*panel[n]+(1-beta)*current[n]
  if expected:
   for h,panel in expected.items():
    for n,want in panel.items():
     got=tracker.averages[h][n].cpu();torch.testing.assert_close(got,want.float(),atol=1e-4,rtol=2e-5);max_ema=max(max_ema,float((got.double()-want).abs().max()))
  if resumed:
   for n,v in model.state_dict().items():
    other=rm.state_dict()[n];torch.testing.assert_close(other,v,atol=1e-4,rtol=2e-5);max_resume=max(max_resume,float((other-v).abs().max()))
   for h,panel in tracker.averages.items():
    for n,v in panel.items():torch.testing.assert_close(rt.averages[h][n],v,atol=1e-4,rtol=2e-5)
  if step==4:
   path=out/f'w{width}-midpoint.pt';torch.save(dict(model=cpu(model.state_dict()),optimizer=cpu(optimizer.state_dict()),tracker=cpu(tracker.state_dict()),step=step),path)
   saved=torch.load(path,map_location='cpu',weights_only=False)
   with torch.random.fork_rng(devices=[]):rm=GPT(cfg.model).to('mps')
   rm.load_state_dict(saved['model'],strict=True);ro=build_optimizer(rm,cfg.training);ro.load_state_dict(saved['optimizer']);rt=TailWeightAverages(rm,cfg.training);rt.load_state_dict(saved['tracker'],4);resumed=(rm,ro,rt)
 row=dict(width=width,status='verified',noninterference_steps=checks,shared_gradient_resume_steps=4,snapshots=tracker.snapshots,max_cpu_float64_recurrence_error=max_ema,max_shared_gradient_resume_weight_error=max_resume,midpoint_sha256=file_digest(out/f'w{width}-midpoint.pt'));rows.append(row);print(json.dumps(row),flush=True)
 del model,optimizer,tracker,resumed,rm,ro,rt;torch.mps.empty_cache()
atomic_json(out/'review.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=p['source_sha256'],rows=rows,elapsed_seconds=time.monotonic()-began,limitations=['Synthetic correctness only, no research quality','Shared gradients isolate continuation from independently varying MPS backward results; does not establish full independent-trajectory reproducibility','CPU float64 recurrence uses observed MPS online snapshots; no prediction of model quality']))
