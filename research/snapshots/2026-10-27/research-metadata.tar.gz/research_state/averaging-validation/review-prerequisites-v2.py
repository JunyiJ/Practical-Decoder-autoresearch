"""Deferred review of completed averaging CPU/MPS gates; launches no model work."""
import argparse,datetime,json,math
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.research import averaging_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint,load_model_weights

parser=argparse.ArgumentParser();parser.add_argument('--pilots',type=Path,required=True);args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();folder=root/'research_state/averaging-validation'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
prior=root/'research_runs/capacity-quality-001/review.json';p=study.make_plan(source,prior)
cpu_path=folder/'cpu-review-v2.json';cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text());sha=source_digest(source)
assert cpu['status']=='cpu_verified' and pilot['status']=='verified'
assert cpu['source_sha256']==pilot['source_sha256']==p['source_sha256']==sha
assert pilot['source_commit']==p['git_commit'] and pilot['recipe']==p['recipe']
assert cpu['trainer_integration']['passed']==6 and cpu['full_tests']['failed']==0 and cpu['full_tests']['passed']>=900
assert len(pilot['pilots'])==6 and {(x['width'],x['mode']) for x in pilot['pilots']}=={(w,m) for w in (64,256) for m in ('tracked','raw','resumed')}
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
artifacts=[cpu_path,pilot_path,args.pilots/'pilot-source.json',folder/'pilot-driver-v2.py',folder/'completion-audit.py',source/'research/AVERAGING_QUALITY_PROTOCOL.md',prior]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
coupled_path=root/'research_state/averaging-mps-coupled-001/review.json';coupled=json.loads(coupled_path.read_text())
assert coupled['status']=='verified' and coupled['source_sha256']==sha and pilot['coupled_review_sha256']==file_digest(coupled_path)
assert {x['width'] for x in coupled['rows']}=={64,256}
assert all(x['noninterference_steps']==8 and x['shared_gradient_resume_steps']==4 and x['max_cpu_float64_recurrence_error']<1e-4 and x['max_shared_gradient_resume_weight_error']<1e-4 for x in coupled['rows'])
artifacts += [coupled_path,root/'research_state/averaging-mps-coupled-001/intent.json',folder/'mps-coupled-check.py',root/'research_state/averaging-pilots-001/failure.json',root/'research_state/averaging-mps-diagnostic-001/review.json',folder/'mps-diagnostic-knowledge.json']
torch.set_num_threads(1)
def finite(value):
 if isinstance(value,torch.Tensor):assert torch.isfinite(value).all()
 elif isinstance(value,dict):
  for v in value.values():finite(v)
 elif isinstance(value,(list,tuple)):
  for v in value:finite(v)
 elif isinstance(value,float):assert math.isfinite(value)
checks=[]
for v in pilot['pilots']:
 w,mode=v['width'],v['mode'];d=args.pilots/f'w{w}_{mode}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==v[name+'_sha256'];artifacts.append(a)
 t=req['config']['training'];checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 assert checked['checkpoint_sha256']==v['checkpoint_sha256'] and raw['completed_steps']==40
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==40 and 'optimizer_state' in cp
 cfg=OmegaConf.create(cp['cfg'])
 with torch.random.fork_rng(devices=[]):
  model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
 assert sum(x.numel() for x in model.parameters())>0
 assert cfg.model.dim==w and cfg.model.n_layers==(6 if p['recipe']['family']=='dense6' else 4)
 assert raw['coverage']['evaluations']['128']['target_count']==111538
 assert len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 assert len(v['derived'])==(0 if mode=='raw' else 3)
 derived_bytes=0
 if mode!='raw':
  assert set(raw['averaged_outputs'])=={'10','50','200'}
  for h,item in raw['averaged_outputs'].items():
   job=dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=int(h),completed_steps=40)
   saved=validate_derivation(job);assert 'optimizer_state' not in saved and 'training_state' not in saved
   assert item['coverage']['evaluations']['128']['target_count']==111538
   derived_bytes+=Path(item['checkpoint']).stat().st_size
  assert cp['training_state']['weight_averaging_state']['snapshots']==11
 else:assert cp['training_state'].get('weight_averaging_state') is None
 assert v['sampled_peak_rss_mb']<4096 and 0<v['training_seconds']<=v['wall_seconds']<180
 checks.append(dict(width=w,mode=mode,total_parameters=sum(x.numel() for x in model.parameters()),training_seconds=v['training_seconds'],wall_seconds=v['wall_seconds'],sampled_peak_rss_mb=v['sampled_peak_rss_mb'],raw_checkpoint_bytes=Path(checked['checkpoint']).stat().st_size,derived_checkpoint_bytes=derived_bytes,checkpoint_sha256=checked['checkpoint_sha256']))
 artifacts.append(d/'review.json')
for w in (64,256):
 a=args.pilots/f'w{w}-paired-check.json';c=json.loads(a.read_text());assert c['status']=='verified' and set(c['comparisons'])=={'raw','resumed'} and c['coupled_review_sha256']==file_digest(coupled_path);artifacts.append(a)
index={x['width']:x for x in checks if x['mode']=='tracked'};seconds=0;bytes_=0;trial_proxies={}
for w,count in [(64,5),(256,3)]:
 x=index[w];projection=1.5*(x['training_seconds']*3000/40+x['wall_seconds']-x['training_seconds']);assert projection<1800
 trial_proxies[str(w)]=projection;seconds+=count*projection
 # Persisted final raw includes three average states; all three inference-only exports count.
 # Add25MiB per trajectory for longer metrics and JSON evidence before the50% margin.
 bytes_+=count*(x['raw_checkpoint_bytes']+x['derived_checkpoint_bytes']+25*1024**2)
assert seconds<14400 and bytes_*1.5/1024**2<2048
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 result=set()
 if 'seed' in k:
  if type(v) is int:result.add(v)
  elif isinstance(v,list):result.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for key,value in v.items():result|=seeds(value,key)
 elif isinstance(v,list):
  for value in v:result|=seeds(value,k)
 return result
plans=list((root/'research_runs').glob('*/plan.json'))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=sha,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,coupled_mps_review=coupled,prerequisite_revision='v2: preserved pilot001 failure and raw-only diagnostic; direct arithmetic gate, no quality-rule change',
 resource_proxy=dict(hours=seconds/3600,trial_seconds_with_50pct_margin=trial_proxies,checkpoint_mb_with_50pct_margin=bytes_*1.5/1024**2,method='Scale tracked40-update pilot training to3000, add measured four-output overhead and50% margin. Count final raw shadow states plus3derived files,25MiB per-trajectory metadata allowance and50% margin. Estimates, not full-run measurements.'),
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Six actual CPU model/trainer/export/resume tests plus full project suite passed','Six serial MPS tracked/raw/resumed pilots and18full validation outputs passed; no holdout','Direct MPS noninterference, independent CPU float64 recurrence and shared-gradient saved-state continuation pass original tolerances; independent full trajectories remain descriptive differences; private sampler RNG agrees exactly','All saved tensors finite and strict CPU model loads; derived weights exactly match final registered parent shadow states and buffers','Fixed backbone resolved only from completed audited capacity adoption','One finite8trajectory round,3registered correlated averages each, no LR retuning or completed study extension'],
 limitations=['All40-update pilot scores excluded from research quality','Final checkpoints do not independently reconstruct the101historical online snapshots; recurrence relies on tested frozen training code','Independent MPS full-trajectory agreement is not established and may fail original tolerance; direct shared-gradient continuation isolates averaging arithmetic without attributing the independent variability to a specific kernel','Resource proxies are forecasts; independent live watchdog/caps remain required','Current MPS allocation is not peak memory; watchdog samples processRSS/driverallocation'],
 artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=folder/'review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy']))
