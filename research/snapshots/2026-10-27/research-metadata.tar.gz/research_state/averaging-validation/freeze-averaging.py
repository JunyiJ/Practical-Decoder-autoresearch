"""Freeze a unique averaging round only after completed predecessor and actual gates."""
import datetime,json,os,re,subprocess
from pathlib import Path
from src.research import averaging_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();run=root/'research_runs/averaging-quality-001';folder=root/'research_state/averaging-validation'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((root/'research_state/active-campaign.json').read_text());prior_run=root/'research_runs/capacity-quality-001'
assert active['campaign']==str(prior_run) and active['status']=='completed_reviewed' and not active.get('human_stopped')
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|context_interaction|context256_study|batch_study)|src\.train\.train',x)],'Known model/research process is live'
p=study.make_plan(source,prior_run/'review.json')
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]==p['git_commit']
review=folder/'review.json';v=json.loads(review.read_text());assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit'] and v['recipe']==p['recipe']
assert v['tests']['trainer_integration']['passed']==6 and v['tests']['full_tests']['failed']==0 and v['tests']['full_tests']['passed']>=900
assert len(v['pilot_audit'])==6 and {(x['width'],x['mode']) for x in v['pilot_audit']}=={(w,m) for w in (64,256) for m in ('tracked','raw','resumed')}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['hours']<4 and v['resource_proxy']['checkpoint_mb_with_50pct_margin']<2048
assert all(x<1800 for x in v['resource_proxy']['trial_seconds_with_50pct_margin'].values())
# Repeat fresh seed nonuse at registration, not only at the earlier prerequisite review.
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (root/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/AVERAGING_QUALITY_PROTOCOL.md';con=json.loads((root/'research_state/capacity-conclusion.json').read_text());bank=KnowledgeBank(root/'research_state/knowledge')
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='Spaced tail averaging: actual continuation, derivation and serial MPS gates',summary='Optional three-half-life tail averaging preserves the online trajectory and resumable optimizer state. Six actual CPU trainer/export/resume cases and the full project suite passed; six serial MPS tracked/raw/resumed pilots produced18fullcoverage correctness outputs. Derived inference weights match final raw shadow states and preserve buffers; optimizer resume from derived weights is forbidden. Pilot quality is excluded from research.',scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],holdout_consumed=False),details=v,artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id'],'kb_c335aa4b7b501e03fbe11a89845c5286b6c7269929c36f0b9dac6feb04bd99c9','kb_477766defe6ce87441876278d54bfaecdbdc023aca7aa956b013ee988df7e1b3']))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',title='Preregistered averaging-quality-001: eight fresh trajectories and32correlated endpoints',summary=protocol.read_text(),scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],holdout_consumed=False),details=dict(prediction='Averaging nearby online iterates may reduce noise or may lag improvement during cooldown. No quantitative quality prediction; this bounded test preserves the raw endpoint and all registered averages.',selection='Two width64 screens select half-life10/50/200; freeze before fresh3seed confirmation at64/256. Mean gain>.002 and every seed, plus all conditional text upper bounds<0 at both widths. Screen eligibility remains required.',limits={k:p[k] for k in ['max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb']},lineage='Exact backbone resolved only from final audited capacity adoption. Fresh trajectories; all old evidence and006permanentstop preserved. Final checkpoints do not reconstruct every historic online snapshot.'),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in [protocol,review,prior_run/'review.json']],related_ids=[implementation,con['result_id'],'kb_515dd8687f458de37efcb88b39abd1d726c5fb712f55a531178928c064954479']))
snapshot=root/'research_state/averaging-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
artifacts=[protocol,review,root/'research_state/quality-evolution-intent.json',root/'research_state/stage1-conclusion.json',root/'research_state/capacity-conclusion.json',root/'research_state/capacity-completed-knowledge-snapshot.md',root/'research_state/schedule-validation/late-curve-diagnostic.json']+[prior_run/f for f in ['plan.json','report.json','review.json','selection.json']]
p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(root),predecessor=str(prior_run),human_edit_policy='Primary kimi checkout untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in [run/'plan.json',root/'research_state/averaging-plan.json']:path.write_text(serialized);path.chmod(0o444)
(run/'lineage.json').write_text(json.dumps(dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,recipe=p['recipe'],knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],physical_training_trajectories=8,model_evaluations=32,half_lives=study.HALF_LIVES,completed_study_reruns=0),indent=2)+'\n')
print(json.dumps(dict(source_commit=p['git_commit'],recipe=p['recipe'],plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation)))
