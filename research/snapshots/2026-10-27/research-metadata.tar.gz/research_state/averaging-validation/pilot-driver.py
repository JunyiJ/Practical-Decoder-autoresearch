"""Deferred serial MPS correctness pilots; require completed capacity and CPU review."""
import argparse,copy,json,os,re,subprocess,time
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run-pilots',action='store_true')
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--cpu-review',type=Path,required=True)
    args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):raise ValueError('Unset MPS fallback')
    root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');prior=root/'research_runs/capacity-quality-001'
    active=json.loads((root/'research_state/active-campaign.json').read_text())
    if Path(active['campaign']).resolve()!=prior or active['status'] not in ('completed','completed_reviewed'):
        raise ValueError('Active pointer must name completed capacity predecessor')
    if json.loads((prior/'state.json').read_text())['status']!='completed':raise ValueError('Capacity not completed')
    processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
    live=[x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|context_interaction|context256_study|batch_study)|src\.train\.train',x)]
    if live:raise ValueError('A research/training process is live: '+str(live))
    import torch
    from src.research import averaging_study as study
    from src.research import capacity_study
    from src.research.context_interaction import adapter as coverage_adapter
    from src.research.averaging_eval import validate_derivation
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest,_request,_launch
    from src.research.runner import atomic_json,session_lock,validate_result,disk_mb
    from src.utils.checkpoint import read_checkpoint
    torch.set_num_threads(1)
    source=Path.cwd().resolve();sha=source_digest(source);cpu=json.loads(args.cpu_review.read_text())
    if cpu.get('status')!='cpu_verified' or cpu.get('source_sha256')!=sha:
        raise ValueError('Matching complete CPU review required')
    if cpu.get('trainer_integration',{}).get('passed')!=6 or cpu.get('full_tests',{}).get('failed')!=0 or cpu.get('full_tests',{}).get('passed',0)<900:
        raise ValueError('Actual averaging trainer and complete project test gates required')
    for a in cpu['artifacts']:
        if file_digest(Path(a['path']))!=a['sha256']:raise ValueError('CPU evidence changed')
    p=study.make_plan(source,prior/'review.json');out=args.output.resolve()
    if not out.is_relative_to(root/'research_state'):raise ValueError('Output must be shared research_state')
    out.mkdir(exist_ok=False);began=time.monotonic();results=[]
    atomic_json(out/'pilot-source.json',dict(source_commit=p['git_commit'],source_sha256=sha,recipe=p['recipe'],
        predecessor_review=p['predecessor_review'],cpu_review_sha256=file_digest(args.cpu_review),
        purpose='Synthetic 40-update serial MPS correctness/resource pilots; not research quality evidence',
        seed=9304,max_jobs=6,seconds_per_job=180,round_seconds=1800,max_disk_mb=1024,
        online_comparison_tolerance=dict(atol=1e-4,rtol=2e-5)))
    with session_lock(out) as fd:
        for width in (64,256):
            endpoints={};middle=None
            for mode in ('tracked','raw','resumed'):
                if source_digest(source)!=sha:raise ValueError('Pilot source changed')
                d=out/f'w{width}_{mode}';d.mkdir();job_start=time.monotonic()
                row=dict(family='trajectory',lr=p['recipe']['learning_rate'],width=width,n_heads=width//32,
                    seed=9304,stage='local',arm='candidate',trial_id=f'pilot-w{width}-{mode}')
                req=_request(study.suite_spec(p,'trajectory',row['lr']),row,d);t=req['config']['training']
                t.update(max_iters=40,eval_every=20,eval_iters=2,checkpoint_every=20 if mode=='tracked' else 0)
                t['lr_schedule'].update(total_steps=40,start_step=26)
                t['weight_averaging'].update(total_steps=40,start_step=20,interval=2)
                if mode=='raw':del t['weight_averaging']
                if mode=='resumed':t['resume_from']=str(middle)
                atomic_json(d/'request.json',req)
                allowance=min(180,1800-(time.monotonic()-began))
                if allowance<=0:raise ValueError('Pilot time budget exhausted')
                status,error=_launch(d/'request.json',out,allowance,1024,fd,root=source,
                    bootstrap=capacity_study.BOOTSTRAP if mode=='raw' else study.BOOTSTRAP)
                if status!='completed':
                    atomic_json(out/'failure.json',dict(width=width,mode=mode,status=status,error=error,no_automatic_retry=True))
                    raise RuntimeError((status,error))
                raw=json.loads((d/'result.json').read_text())
                checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
                extra=(coverage_adapter if mode=='raw' else study.adapter)(p,raw,checked,req,d)
                cp=read_checkpoint(checked['checkpoint']);endpoints[mode]=cp
                assert cp['step']==40 and raw['completed_steps']==40 and extra['coverage']['128']['target_count']==111538
                assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
                gen=torch.Generator().manual_seed(9304);length=len(Path(req['config']['data']['path']).read_text())
                for _ in range(40):torch.randint(int(.8*length)-512,(2,),generator=gen)
                assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
                assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
                if mode=='tracked':
                    saved=list(Path(checked['checkpoint']).parent.glob('step_000020_*.pt'));assert len(saved)==1;middle=saved[0]
                derived=[]
                if mode!='raw':
                    for h,item in extra['averaged_outputs'].items():
                        job=dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],
                            parent_sha256=checked['checkpoint_sha256'],half_life=int(h),completed_steps=40)
                        validate_derivation(job);derived.append(dict(half_life=int(h),checkpoint_sha256=item['checkpoint_sha256'],target_count=item['coverage']['evaluations']['128']['target_count']))
                result=dict(status='verified',width=width,mode=mode,wall_seconds=time.monotonic()-job_start,
                    training_seconds=raw['training_time_sec'],request_sha256=file_digest(d/'request.json'),result_sha256=file_digest(d/'result.json'),
                    checkpoint_sha256=checked['checkpoint_sha256'],derived=derived,
                    sampled_peak_rss_mb=max(x['rss_mb'] for x in raw['metrics']),disk_mb=disk_mb(d))
                atomic_json(d/'review.json',result);results.append(result);print(result,flush=True)
            comparisons={}
            for mode in ('raw','resumed'):
                errors=[]
                for name,want in endpoints['tracked']['model_state'].items():
                    got=endpoints[mode]['model_state'][name];torch.testing.assert_close(got,want,atol=1e-4,rtol=2e-5)
                    errors.append(float((got-want).abs().max()))
                for name in ('train','val','test'):
                    assert torch.equal(endpoints[mode]['training_state']['loader_rng'][name],endpoints['tracked']['training_state']['loader_rng'][name])
                comparisons[mode]=dict(max_abs_weight_difference=max(errors),atol=1e-4,rtol=2e-5)
            for h,panel in endpoints['tracked']['training_state']['weight_averaging_state']['averages'].items():
                for name,value in panel.items():
                    torch.testing.assert_close(endpoints['resumed']['training_state']['weight_averaging_state']['averages'][h][name],value,atol=1e-4,rtol=2e-5)
            atomic_json(out/f'w{width}-paired-check.json',dict(status='verified',comparisons=comparisons,
                scope='Synthetic 40-update MPS check; tolerance-based, not a universal bitwise reproducibility claim'))
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,recipe=p['recipe'],pilots=results,
        excluded_from_research=True,holdout_consumed=False,disk_mb=disk_mb(out)))

if __name__=='__main__':main()
