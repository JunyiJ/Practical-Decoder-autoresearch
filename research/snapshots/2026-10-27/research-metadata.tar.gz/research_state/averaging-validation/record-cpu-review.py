"""Record completed test evidence without running model work."""
import datetime,json,re,subprocess
from pathlib import Path
from src.research.team.suite import source_digest
from src.research.protocol import file_digest
source=Path.cwd().resolve();root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');folder=root/'research_state/averaging-validation'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
a=folder/'actual-model-tests-first.log';b=folder/'remaining-tests-first.log'
assert '6 passed in 171.95s' in a.read_text()
m=re.search(r'937 passed in ([0-9.]+)s',b.read_text());assert m,'Remaining project suite must complete first'
assert not re.search(r'\b(?:FAILED|ERRORS|failed,|error,)\b',a.read_text()+b.read_text())
review_path=folder/'integrated-source-review.json';review=json.loads(review_path.read_text())
for item in review['artifacts']:assert file_digest(Path(item['path']))==item['sha256']
sha=source_digest(source);assert sha==json.loads((folder/'collection-review.json').read_text())['source_sha256']
artifacts=[a,b,review_path,folder/'collection-review.json']+[Path(x['path']) for x in review['artifacts']]
v=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),trainer_integration=dict(passed=6,failed=0,seconds=171.95,scope='Actual CPU models across3backbones x2widths; exact online trajectory, optimizer/RNG and resumed averages; strict derivation and rejection checks'),full_tests=dict(passed=943,failed=0,partition='6 actual averaging trainer cases plus937 remaining project tests; no duplicated cases in total',remaining_tests=937,remaining_seconds=float(m.group(1)),total_seconds=171.95+float(m.group(1))),limitations=['Synthetic CPU correctness evidence, not quality or MPS performance','MPS correctness and resource pilots remain required before research registration'],artifacts=[dict(path=str(p),sha256=file_digest(p)) for p in dict.fromkeys(artifacts)])
p=folder/'cpu-review.json';assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ('status','source_sha256','full_tests')}))
