"""Deferred averaging evidence audit. No training or evaluation; --partial is not final."""
import argparse,copy,datetime,json,math,statistics
from pathlib import Path
import numpy as np
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.research import averaging_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result,disk_mb
from src.research.team.suite import _request
from src.train.weight_averaging import TailWeightAverages
from src.utils.checkpoint import read_checkpoint

parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);parser.add_argument('--partial',action='store_true');args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=args.run.resolve();folder=root/'research_state/averaging-validation'
assert run.parent==root/'research_runs' and run.name.startswith('averaging-quality-')
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());study.verify_lineage(p)
assert p==json.loads((root/'research_state/averaging-plan.json').read_text()) and digest(p)==s['plan_sha256']
assert not any(r['status']=='failed' for r in s['records'])
records=[r for r in s['records'] if r['status']=='completed'];jobs=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())==study.freeze_selection(p,records[:2])
 jobs+=s['selection']['confirmation']['jobs']
 if s['records'][2:]:
  assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'][2:])
assert [[r[k] for k in ('family','lr','width','seed')] for r in s['records']]==jobs[:len(s['records'])]
assert len({r['trial_id'] for r in s['records']})==len(s['records']) and disk_mb(run)<2048
if not args.partial:assert s['status']=='completed' and len(records)==8 and s['active_seconds']<14400

torch.set_num_threads(1);checks=[];unique_paths=set();data_length=len(Path(p['config']['data']['path']).read_text())
for r in records:
 assert r['error'] is None and r['duration_seconds']<1800
 d=run/'trials'/r['trial_id'];req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model']
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['completed_steps']==3000 and raw['eval_iters']==30 and raw['eval_every']==300
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==3000
 metrics=[json.loads(x) for x in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics'] and [x['step'] for x in metrics]==list(range(0,3000,300))+[2999]
 assert max(x['rss_mb'] for x in metrics)<4096
 for row in metrics:
  i=row['step'];ratio=1. if i<=2000 else 1.-.9*(i-2000)/999
  if i==2999:ratio=.1
  assert math.isclose(row['lr_multiplier'],ratio,rel_tol=0,abs_tol=1e-14)
  assert row['base_learning_rate']==r['lr'] and math.isclose(row['scheduled_learning_rate'],r['lr']*ratio,abs_tol=1e-15)
  completed=i+1;expected=0 if completed<2000 else 1+(completed-2000)//10
  assert row['averaging_snapshots']==expected and row['tokens_processed']==completed*1024
  assert row['train_aux_loss'] is None and row['moe_usage'] is None
  assert row['train_ce_loss']==row['train_loss']==row['train_total_loss']
 cp=read_checkpoint(r['checkpoint']);assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==3000 and cp['parameter_layout_version']==2 and cp['model_math_version']==2
 assert 'averaged_weights' not in cp
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65;assert cp['cfg']==want
 assert t['max_iters']*t['batch_size']*m['block_size']==3072000 and t['batch_layout']=='paired_blocks512'
 assert t['weight_averaging']==study.AVERAGING and t['lr_schedule']==study.capacity.schedule_spec('linear_cooldown')
 contract=dict(weight_averaging=study.AVERAGING,lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
  optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],data_sha256=p['data_sha256'],
  data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
  training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==contract and cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(3000):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 model=GPT(OmegaConf.create(want['model']));model.load_state_dict(cp['model_state'],strict=True)
 assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
 named=dict(model.named_parameters());width=r['width'];depth=6 if p['recipe']['family']=='dense6' else 4
 hidden=21*width//(4 if p['recipe']['family']=='wide4' else 8)
 expected_count=132*width+depth*(4*width*width+6*width+3*width*hidden)
 assert sum(v.numel() for v in named.values())==expected_count and len(model.transformer.h)==depth
 for layer in range(depth):
  prefix=f'transformer.h.{layer}.';weights=cp['model_state']
  assert list(weights[prefix+'attn.qkv.weight'].shape)==[3*width,width]
  assert list(weights[prefix+'attn.out.weight'].shape)==[width,width]
  for key in ('linear_gate','linear_up'):assert list(weights[prefix+'mlp.'+key+'.weight'].shape)==[hidden,width]
  assert list(weights[prefix+'mlp.linear_down.weight'].shape)==[width,hidden]
  assert list(weights[prefix+'freq_cos'].shape)==[128,16]
 seen=[];assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==.00006
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   assert len(g['params'])==len(g['parameter_names'])==1
   name=g['parameter_names'][0];seen.append(name);v=named[name];matrix=name.startswith('transformer.h.') and v.ndim==2
   scale=1/math.sqrt(width/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==r['lr']*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'} and g['momentum']==.95 and g['adjust_lr_fn']=='match_rms_adamw'
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==3000 and g['betas']==(.9,.999)
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==v.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 state=cp['training_state']['weight_averaging_state'];tracker=TailWeightAverages(model,OmegaConf.create(t));tracker.load_state_dict(state,3000)
 assert state['spec']==study.AVERAGING and state['completed_steps']==3000 and state['snapshots']==101
 assert state['parameter_names']==list(named) and set(state['averages'])=={'10','50','200'}
 rawpath=Path(r['checkpoint']).resolve();assert rawpath not in unique_paths;unique_paths.add(rawpath)
 derived_checks=[]
 for h in (10,50,200):
  item=r['averaged_outputs'][str(h)];path=Path(item['checkpoint']).resolve();assert path not in unique_paths;unique_paths.add(path)
  job=dict(checkpoint=str(path),checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=str(rawpath),
   parent_sha256=r['checkpoint_sha256'],half_life=h,completed_steps=3000)
  derived=validate_derivation(job)
  assert 'training_state' not in derived and 'optimizer_state' not in derived
  assert derived['averaged_weights']['parameter_names']==list(named) and derived['cfg']==cp['cfg']
  assert derived['averaged_weights']['snapshots']==101
  for name,value in derived['model_state'].items():
   reference=state['averages'][str(h)][name] if name in named else cp['model_state'][name]
   assert value.dtype==reference.dtype and value.shape==reference.shape and torch.equal(value,reference) and torch.isfinite(value).all()
  assert file_digest(path)==item['checkpoint_sha256']
  derived_checks.append(dict(half_life=h,path=str(path),sha256=item['checkpoint_sha256']))
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
  result_sha256=r['result_sha256'],parameter_count=expected_count,derived_checkpoints=derived_checks))
 print('Verified trajectory',r['trial_id'],flush=True)
review=dict(status='partial_verified' if args.partial else 'verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_trajectories=len(records),distinct_checkpoints=len(unique_paths),
 checkpoint_audit=checks,holdout_consumed=False)
if args.partial:
 (folder/'partial-audit.json').write_text(json.dumps(review,indent=2)+'\n');print('PARTIAL VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints');raise SystemExit

report=json.loads((run/'report.json').read_text());assert study.summarize(p,s)==report and report['holdout_consumed'] is False
screen=records[:2];scores={h:statistics.mean(study.endpoint(r,h)['mean_ce'] for r in screen) for h in (10,50,200)}
winner=min(scores,key=lambda h:(scores[h],h));assert winner==s['selection']['half_life']
ds=[study.endpoint(r,winner)['mean_ce']-study.endpoint(r,'raw')['mean_ce'] for r in screen]
local=statistics.mean(ds)<-.002 and max(ds)<0;assert s['selection']['screen_eligible']==local
adoption=[]
for c in report['comparisons']:
 rows={r['seed']:r for r in records[2:] if r['width']==c['width']};assert set(rows)=={2151,2152,2153}
 aa=[study.endpoint(rows[k],c['half_life']) for k in sorted(rows)];bb=[study.endpoint(rows[k],'raw') for k in sorted(rows)]
 delta=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0)
 counts=np.array(aa[0]['block_target_counts']);seed_deltas={str(k):a['mean_ce']-b['mean_ce'] for k,a,b in zip(sorted(rows),aa,bb)}
 assert len(c['sensitivity'])==3
 for n,v in zip((2048,4096,8192),c['sensitivity']):
  factor=n//2048;chunks=np.array([delta[j:j+factor].sum() for j in range(0,len(delta),factor)])
  cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
  idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)));boot=chunks[idx].sum(1)/cnt[idx].sum(1)
  assert v['text_block_tokens']==n and v['text_block_count']==len(cnt) and v['bootstrap_draws']==2000 and v['bootstrap_seed']==20261024
  assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
  assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],rel_tol=0,abs_tol=1e-12)
  assert v['paired_seed_deltas']==seed_deltas
 supported=statistics.mean(seed_deltas.values())<-.002 and max(seed_deltas.values())<0 and all(v['conditional_text_bootstrap_95pct'][1]<0 for v in c['sensitivity'])
 assert c['quality_improvement']==supported
 if c['half_life']==winner:adoption.append(supported)
assert len(adoption)==2 and report['quality_decision']==dict(frozen_half_life=winner,qualifies_for_incumbent_replacement=local and all(adoption))
assert len(unique_paths)==32
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),quality_decision=report['quality_decision'],
 active_seconds=s['active_seconds'],disk_mb=disk_mb(run),checks=['8raw+24derivedcheckpoint/rawrequest/result hashes; exactconfig/source/corpus/runtime/fullbank/prerequisites',
 'Raw weights/optimizer slots finite and strictCPUload; depth/head/QKV/FFN/counts/widthfactors; 3000updates3072000targets',
 'Private training RNG reconstructed; heldout RNG untouched; schedule and snapshot counters independently reconstructed',
 'Every averaged tensor exactly equals its registered final raw shadow state; all nonlearned buffers copied unchanged; nooptimizer/resumestate',
 'Two screening trajectories and six fresh confirmation trajectories, frozen half-life/eligibility; no larger-width reselection',
 'Entire report and every conditional bootstrap/paired mean/adoption rule independently reconstructed'],
 limitations=['EMA recurrence was independently checked in synthetic correctness tests; final checkpoints alone do not reconstruct all101 historical online snapshots',
 'Eight correlated trajectory output panels, not32 independent training seeds; no holdout or seed-population inference'])
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints')
