import json,datetime,hashlib,subprocess,difflib
from pathlib import Path
from src.research.team.knowledge import KnowledgeBank
from src.research.team.suite import source_digest
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');out=root/'research_state/averaging-validation';dev=Path('/private/tmp/rsi-averaging-quality-development');source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');base='ae566ead098f11aeb72f5aa0901930e6c69ec7e8'
def artifact(p):return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
old=json.loads((out/'controller-preparation-review.json').read_text());assert source_digest(dev)==old['source_sha256']
files=[Path(x['path']).relative_to(dev).as_posix() for x in old['code']];patch=[]
for name in files:
 r=subprocess.run(['git','show',base+':'+name],cwd=source,capture_output=True,text=True);a=r.stdout if r.returncode==0 else ''
 patch.extend(difflib.unified_diff(a.splitlines(True),(dev/name).read_text().splitlines(True),fromfile='a/'+name if r.returncode==0 else '/dev/null',tofile='b/'+name))
patchpath=out/'auditor-development.patch';assert not patchpath.exists();patchpath.write_text(''.join(patch));patchpath.chmod(0o444)
review=dict(status='preparation_only_actual_model_gates_pending',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=base,source_sha256=source_digest(dev),
 synthetic_tests=dict(passed=77,seconds=1.17,log=artifact(out/'bootstrap-controller-tests.log'),new_coverage='Executes actual worker orchestration string with training/scoring endpoints mocked: ordered3exports, correct request/data/parent hashes, partial artifacts retained after first scoring failure. No model instantiation or MPS.'),
 current_patch=artifact(patchpath),current_test_code=[artifact(dev/x) for x in files if x.startswith('tests/')],
 deferred_completion_auditor=artifact(out/'completion-audit.py'),deferred_pilot_driver=artifact(out/'pilot-driver.py'),
 development_protocol=artifact(root/'research_state/averaging-quality-development-v2.md'),analytical_coefficients=artifact(out/'averaging-coefficient-calculations.json'),
 remaining=['Actual six CPU model/trainer/export/resume/invariance tests and full project suite','Actual6serialMPS correctness/resource pilots,18coverageoutputs,aftercapacitycompleteandreviewed','Fresh finaladoptionresolver/config/source/resource checks, cleancommitpush,fullknowledge/preregistration','Completion auditor is syntax-checked only and has no real averaging study evidence yet'],
 audit_scope='All8raw+24derivedCPs and requests/results, rawopt/RNG/schedule/shape contracts, exactderivedparametersvsrawshadowstate/buffers, frozenhalf-life and independentallbootstrapadoption checks; finalCPs cannot reconstruct everyhistoricalonlineEMAsnapshot')
path=out/'audit-preparation-review.json';assert not path.exists();path.write_text(json.dumps(review,indent=2)+'\n');path.chmod(0o444)
kid=KnowledgeBank(root/'research_state/knowledge').add(dict(kind='learning',outcome='inconclusive',created_by='continuing-quality-research',title='Averaging orchestration and completion audit prepared; model gates remain pending',summary='77smallCPUtests pass, including execution of actual worker orchestration with training/scoring mocked and firstfailurepreservation. Deferred8raw+24derivedcompletionaudit and6MPSjobpilotdriver prepared. Analytical EMAweights show meanlags10/67.25/274.71updates forH10/50/200; these are calculations,notqualityfindings. No averaging training or preregistration.',scope=dict(stage='preparation',training_launched=False,holdout_consumed=False),details=review,artifacts=[artifact(path),artifact(patchpath)],related_ids=['kb_cc6cd9c867c3b95ec2b1d6853eedc2e8039751751d608d731ed1cb1fcea9979a']))
(out/'audit-preparation-knowledge.json').write_text(json.dumps(dict(result_id=kid),indent=2)+'\n');print(kid)
