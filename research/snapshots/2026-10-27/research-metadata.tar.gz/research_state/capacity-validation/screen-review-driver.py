import copy,json,math,datetime
from pathlib import Path
from src.research.protocol import digest,file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/capacity-quality-001';folder=root/'research_state/capacity-validation'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());sel=json.loads((run/'selection.json').read_text());audit=json.loads((folder/'partial-audit.json').read_text())
assert audit['status']=='partial_verified' and audit['distinct_checkpoints']>=18 and audit['plan_sha256']==digest(p)
rows=[r for r in s['records'] if r['stage']=='local'];assert len(rows)==18 and all(r['status']=='completed' for r in rows)
assert sel==s['selection'] and sel['plan_sha256']==digest(p)
families=['dense4','wide4','dense6'];lrs=[.00125,.0025,.005];seeds=[2121,2122]
assert {(r['family'],r['lr'],r['width'],r['seed']) for r in rows}=={(f,lr,64,seed) for f in families for lr in lrs for seed in seeds}
choices={}
for f in families:
 grid={lr:math.fsum(r['metric'] for r in rows if r['family']==f and r['lr']==lr)/2 for lr in lrs}
 lr=min(grid,key=lambda lr:(grid[lr],lr));choices[f]=dict(lr=lr,mean_ce=grid[lr])
 assert sel['choices'][f]['lr']==lr and math.isclose(sel['choices'][f]['mean_ce'],grid[lr],abs_tol=1e-12)
def panel(f,lr):return {r['seed']:r['metric'] for r in rows if r['family']==f and r['lr']==lr}
eligible=[];contrasts={};fixed={}
for f in families[1:]:
 a=panel(f,choices[f]['lr']);checks=[]
 for lr in (choices['dense4']['lr'],p['incumbent_schedule']['learning_rate']):
  b=panel('dense4',lr);ds={str(seed):a[seed]-b[seed] for seed in seeds};mean=math.fsum(ds.values())/2
  checks.append(dict(reference_lr=lr,mean_delta=mean,paired_seed_deltas=ds,supported=mean<-.005 and max(ds.values())<0))
 contrasts[f]=checks
 if all(c['supported'] for c in checks):eligible.append(f)
 a=panel(f,.0025);b=panel('dense4',.0025);ds={str(seed):a[seed]-b[seed] for seed in seeds};fixed[f]=dict(mean_delta=math.fsum(ds.values())/2,paired_seed_deltas=ds)
winner=min(eligible,key=lambda f:(choices[f]['mean_ce'],f)) if eligible else 'historical_incumbent_unchanged';assert winner==sel['winner']
for f in contrasts:
 for a,b in zip(contrasts[f],sel['local_capacity_contrasts'][f]):
  assert a['supported']==b['supported'] and a['paired_seed_deltas']==b['paired_seed_deltas'] and math.isclose(a['mean_delta'],b['mean_delta'],abs_tol=1e-12)
assert all(v['lr']==.005 for v in choices.values())
assert sel['confirmation']['reference_aliases']=={'incumbent_reference':'dense4'} and sel['confirmation']['total_distinct_trials']==54
expected=[]
for w in (64,256):
 for i,seed in enumerate((2131,2132,2133)):
  order=families+['gelu_reference','shallow_reference','deep_reference']
  if i%2:order=order[::-1]
  for f in order:expected.append([f,choices[f]['lr'] if f in families else (.002 if f=='gelu_reference' else .0025),w,seed])
assert sel['confirmation']['jobs']==expected
assert len({tuple(x) for x in expected})==36
first=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'] if r['stage']=='confirmation')
assert (run/'selection.json').stat().st_mtime<=first
out=folder/'screen-review.json';assert not out.exists();saved=folder/'screen-checkpoint-audit.json';assert not saved.exists();saved.write_bytes((folder/'partial-audit.json').read_bytes());saved.chmod(0o444)
review=dict(status='screen_verified_not_final',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],plan_sha256=digest(p),selection_sha256=file_digest(run/'selection.json'),screen_trials=18,choices=choices,winner=winner,local_contrasts=contrasts,fixed_lr_0025_contrasts=fixed,confirmation_manifest=sel['confirmation'],checkpoint_audit=dict(path=str(saved),sha256=file_digest(saved)),limitations=['Only width64 screening seeds2121/2122; selected recipes require fresh2131/2132/2133 confirmation at64/256','All three arms selected upper LR boundary; no extension or larger-width reselection','Tuned contrasts include LR choice; fixed-LR contrasts reported separately; capacity/init/compute differ','Current cooldown4L incumbent unchanged; no holdout access or training rerun','Six incumbent-reference cells prospectively alias dense4 because the selected recipes are identical; not independent repeats'])
out.write_text(json.dumps(review,indent=2)+'\n');out.chmod(0o444)
summary=f'Capacity quality001 screening18/18 audited. Dense4 cooldown LR.005 CE{choices["dense4"]["mean_ce"]:.6f}; wide4 .005 CE{choices["wide4"]["mean_ce"]:.6f}; dense6 .005 CE{choices["dense6"]["mean_ce"]:.6f}. Both larger-capacity arms improve both screen seeds versus dense4; dense6 is the frozen local winner. Fresh confirmation64/256 running; no adoption yet. All LRs upperboundary, no extension.54 distinct trials; six additional incumbent-reference cells use prospective aliases.'
bank=KnowledgeBank(root/'research_state/knowledge');kid=bank.add(dict(kind='result',outcome='supported',created_by='continuing-quality-research',title='Capacity screening: six layers chosen before fresh confirmation',summary=summary,scope=dict(stage='screening_only',widths=[64],seeds=seeds,holdout_consumed=False,incumbent_unchanged=True),details=review,artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in [out,saved,run/'selection.json']],related_ids=[p['preregistration_id'],p['implementation_id']]))
(folder/'screen-knowledge.json').write_text(json.dumps(dict(result_id=kid,summary=summary),indent=2)+'\n')
for name in ['research-monitor.json','quality-evolution-progress.json']:
 path=root/'research_state'/name;d=json.loads(path.read_text());d.update(capacity_screen_review=str(out),capacity_screen_result_id=kid,capacity_screen_notified=True,capacity_frozen_winner=winner,capacity_record_count=sum(r['status']=='completed' for r in s['records']),last_checked_at=review['reviewed_at']);path.write_text(json.dumps(d,indent=2)+'\n')
print(kid);print(summary);print('Fixed .0025 screening contrasts:',json.dumps(fixed))
