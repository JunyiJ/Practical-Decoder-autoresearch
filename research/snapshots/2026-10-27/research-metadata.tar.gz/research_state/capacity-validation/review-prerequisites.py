"""Review completed CPU/MPS dense capacity prerequisites; no model work is launched."""
import argparse,datetime,json
from pathlib import Path
from src.research import capacity_study as study
from src.research.protocol import file_digest
from src.research.team.suite import source_digest
parser=argparse.ArgumentParser();parser.add_argument('--pilots',type=Path,required=True);args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=root/'research_state/capacity-validation'
cpu_path=folder/'cpu-review.json';cpu=json.loads(cpu_path.read_text());pilots_path=args.pilots/'pilots.json';pilot=json.loads(pilots_path.read_text())
sha=source_digest(source);assert cpu['status']=='cpu_verified' and pilot['status']=='verified'
assert cpu['source_sha256']==pilot['source_sha256']==sha
assert cpu['trainer_integration']['passed']==12 and cpu['model_checks']['passed']==10 and cpu['full_tests']['failed']==0
assert cpu['full_tests']['passed']>=860
old=json.loads((root/'research_runs/schedule-quality-001/plan.json').read_text());p=study.make_plan(source,old['config'],root/'research_runs/schedule-quality-001/review.json')
assert p['git_commit']==pilot['source_commit'] and p['incumbent_schedule']==pilot['incumbent_schedule']
expected={(f,w) for f in study.CELLS for w in [64,256]}
refs=['gelu_reference','shallow_reference']+(['deep_reference'] if p['incumbent_schedule']['kind']!='constant' else [])
expected|={(f,w) for f in refs for w in [64,256]}
assert {(v['family'],v['width']) for v in pilot['pilots']}==expected
assert len(pilot['pilots'])==len(expected)
checks=[];artifacts=[cpu_path,pilots_path,args.pilots/'pilot-source.json',folder/'pilot-driver.py',source/'research/CAPACITY_QUALITY_PROTOCOL.md']
for a in cpu['artifacts']:assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
for v in pilot['pilots']:
 f,w=v['family'],v['width'];directory=args.pilots/f'w{w}_{f}'
 for name in ['request','result']:
  path=directory/f'{name}.json';assert file_digest(path)==v[name+'_sha256'];artifacts.append(path)
 cp=Path(v['checked']['checkpoint']);assert file_digest(cp)==v['checkpoint_sha256']
 assert v['status']=='verified' and v['coverage']['coverage']['128']['target_count']==111538
 assert v['peak_rss_mb']<4096
 train=v['checked']['training_time_sec'];wall=v['wall_seconds'];assert 0<train<=wall<180
 projection=1.5*(train*3000/v['steps']+wall-train)
 assert projection<1800
 checks.append(dict(family=f,width=w,pilot_steps=v['steps'],training_seconds=train,wall_seconds=wall,peak_process_rss_mb=v['peak_rss_mb'],checkpoint_bytes=cp.stat().st_size,checkpoint_sha256=v['checkpoint_sha256'],projected_trial_seconds_with_50pct_margin=projection))
 artifacts.append(directory/'review.json')
index={(x['family'],x['width']):x for x in checks}
# Worst-case manifest with no alias:9 small+3large runs per schedule; each
# fixed reference adds3 per width. The incumbent reference uses constant's pilot.
seconds=0;bytes_=0
for f in study.CELLS:
 for w,count in [(64,9),(256,3)]:
  v=index[f,w];seconds+=count*v['projected_trial_seconds_with_50pct_margin'];bytes_+=count*v['checkpoint_bytes']
for f in study.fixed_references(p['incumbent_schedule']):
 pf='dense4' if f=='incumbent_reference' or (f=='deep_reference' and p['incumbent_schedule']['kind']=='constant') else f
 for w in [64,256]:
  v=index[pf,w];seconds+=3*v['projected_trial_seconds_with_50pct_margin'];bytes_+=3*v['checkpoint_bytes']
assert seconds<28800 and bytes_*1.5/1024**2<4096
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seed_values(value,key=''):
 out=set()
 if 'seed' in key:
  if isinstance(value,int):out.add(value)
  elif isinstance(value,list):out.update(x for x in value if isinstance(x,int))
 if isinstance(value,dict):
  for k,v in value.items():out|=seed_values(v,k)
 elif isinstance(value,list):
  for v in value:out|=seed_values(v,key)
 return out
plans=list((root/'research_runs').glob('*/plan.json'))
for path in plans:
 assert not new&seed_values(json.loads(path.read_text())),str(path)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=sha,incumbent_schedule=p['incumbent_schedule'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,resource_proxy=dict(hours=seconds/3600,checkpoint_mb_with_50pct_margin=bytes_*1.5/1024**2,method='Worst-case no-alias manifest; scale measured pilot training time to3000updates, add measured overhead,1.5margin. Pilot proxy, not a research-duration measurement.'),fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),checks=['59 configuration/synthetic controller tests plus10 actual shape/group/causality and12 trainer resume cases; full project suite recorded','Every capacity family and distinct fixed reference schedule/shape passed serial MPS training/save/reload/full111538targetvalidation with finiteCPUweights/optimizer','Configured immutable basegroupLRs survive optimizer restore; each absolute-step multiplier applied once; schedule horizon bound in resume','Common schedule derived only from completed predecessor adoption review, never partial results','Pilot RNG/sample/update/coverage/optimizer-group contracts verified; no holdout scoring or previous trial reruns'],limitations=['Pilot quality excluded from research','Dense recipes have equal per-step decay and targets; depth, FFN aspect ratio, parameter count and compute differ','Explicit unscaled six-layer recipe is not optimal depth/muP transfer or population/independentholdout evidence','Current MPS allocation notpeakmemory; watchdog samplesRSS/driverallocation'],artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=folder/'review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy']))
