"""Apply reviewed capacity documentation only after final evidence recording.
Run from the isolated source root. Never touches primary human source.
"""
import json
from pathlib import Path
from src.research import capacity_study as study
from src.research.protocol import file_digest,digest
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/capacity-quality-001';p=json.loads((run/'plan.json').read_text());source=Path.cwd().resolve();assert source==Path(p['source_root']).resolve()
study.verify_lineage(p)
rev=json.loads((run/'review.json').read_text());con=json.loads((root/'research_state/capacity-conclusion.json').read_text())
assert rev['status']=='verified' and rev['plan_sha256']==digest(p) and rev['report_sha256']==file_digest(run/'report.json')
assert con['review']==str(run/'review.json') and con['quality_decision']==rev['quality_decision']
result=Path('/private/tmp/CAPACITY_QUALITY_RESULTS.md').read_text();addition=Path('/private/tmp/capacity-guide-addition.md').read_text()
assert con['result_id'] in result and con['summary'] in result and con['summary'] in addition
out=source/'research/CAPACITY_QUALITY_RESULTS.md';assert not out.exists()
guide=source/'research/LEARNING_GUIDE.md';arch=source/'research/ARCHITECTURE_STAGE2.md';original_guide=guide.read_text();original_arch=arch.read_text()
assert '## Completed dense capacity quality round' not in original_guide and '## Completed capacity quality001' not in original_arch
folder=root/'research_state/capacity-validation';backup=folder/'pre-documentation-source';backup.mkdir(exist_ok=False)
for f in [guide,arch]:(backup/f.name).write_bytes(f.read_bytes())
out.write_text(result);guide.write_text(original_guide.rstrip()+'\n\n'+addition.rstrip()+'\n')
arch.write_text(original_arch.rstrip()+'\n\n## Completed capacity quality001\n\n'+con['summary']+'\n\n[Full capacity results](CAPACITY_QUALITY_RESULTS.md). The next prospective experiment compares raw and spaced-tail averaged weights from eight fresh trajectories on the recipe resolved from this final audited adoption. It requires actual trainer/export/resume tests, the full project suite, serial MPS correctness/resource pilots, clean source and a unique finite preregistration before launch. Final averaged checkpoints cannot independently reconstruct every historical online snapshot; synthetic recurrence checks and the frozen trainer contract must be distinguished from model-quality measurements. All closed studies and permanent human stop006 remain closed. The continuing human quality objective remains active.\n')
print('Applied reviewed documentation in',source)
