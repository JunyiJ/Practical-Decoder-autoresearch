"""Read-only CPU audit of frozen dense capacity evidence. --partial never writes final review."""
import argparse
import copy
import datetime
import json
import math
from pathlib import Path
import numpy as np
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.research import capacity_study as study
from src.train.lr_schedule import multiplier, schedule_contract
from src.research.protocol import digest, file_digest
from src.research.runner import validate_result, disk_mb
from src.research.team.suite import _request

parser=argparse.ArgumentParser()
parser.add_argument('--partial',action='store_true')
parser.add_argument('--run',type=Path,required=True)
args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
run=args.run.resolve()
assert run.parent==root/'research_runs' and run.name.startswith('capacity-quality-')
p=json.loads((run/'plan.json').read_text())
s=json.loads((run/'state.json').read_text())
study.verify_lineage(p)
assert digest(p)==s['plan_sha256']
assert p==json.loads((root/'research_state/capacity-plan.json').read_text())
records=[r for r in s['records'] if r['status']=='completed']
assert len({r['trial_id'] for r in s['records']})==len(s['records'])
screen=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())
 assert study.freeze_selection(p,records[:18])==s['selection']
 expected=screen+s['selection']['confirmation']['jobs']
 assert s['selection']['confirmation']['reference_aliases']==(
     study.reference_cells(p['incumbent_schedule']) if s['selection']['choices']['dense4']['lr']==p['incumbent_schedule']['learning_rate'] else {})
else:
 expected=screen
assert [[r[k] for k in ['family','lr','width','seed']] for r in s['records']]==expected[:len(s['records'])]
assert disk_mb(run)<4096
if not args.partial:
 assert s['status']=='completed' and len(records)==len(expected)==s['selection']['confirmation']['total_distinct_trials']
 assert len(records) in ((48,54) if p['incumbent_schedule']['kind']=='constant' else (54,60)) and s['active_seconds']<28800
 assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in records[18:])

torch.set_num_threads(1)
checks=[]
data_length=len(Path(p['config']['data']['path']).read_text())
for i,r in enumerate(records):
 assert r['error'] is None and r['duration_seconds']<1800
 d=run/'trials'/r['trial_id']
 req=json.loads((d/'request.json').read_text())
 raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):
  assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model']
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['eval_iters']==30 and raw['eval_every']==300
 assert [x['step'] for x in raw['metrics']]==list(range(0,3000,300))+[2999]
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==3000
 metrics=[json.loads(line) for line in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics']
 schedule=schedule_contract(OmegaConf.create(t))
 assert r['schedule_snapshots']==[{k:row[k] for k in ('step','lr_multiplier','base_learning_rate','scheduled_learning_rate')} for row in metrics]
 for row in metrics:
  step=row['step'];kind=schedule['kind']
  # Independent reconstruction, including endpoints, rather than relying only
  # on the production helper used by validate_result.
  if kind=='constant':ratio=1.
  elif kind=='cosine':ratio=.1+.9*(1+math.cos(math.pi*step/2999))/2
  else:
   assert kind=='linear_cooldown'
   ratio=1. if step<=2000 else 1.-.9*(step-2000)/999
  if step==2999 and kind!='constant':ratio=.1
  assert math.isclose(row['lr_multiplier'],ratio,rel_tol=0,abs_tol=1e-14)
  assert row['base_learning_rate']==r['lr']
  assert math.isclose(row['scheduled_learning_rate'],r['lr']*ratio,rel_tol=0,abs_tol=1e-15)
 assert max(x['rss_mb'] for x in metrics)<4096
 cp=torch.load(r['checkpoint'],map_location='cpu',weights_only=False)
 assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==3000 and cp['model_math_version']==2 and cp['parameter_layout_version']==2
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65
 assert cp['cfg']==want
 assert t['batch_size']==8 and t['max_iters']==3000 and m['block_size']==128
 assert cp['step']*t['batch_size']*m['block_size']==3072000
 assert t['weight_decay']==.00006 and t['batch_layout']=='paired_blocks512'
 assert cp['training_state']['contract']==dict(batch_layout='paired_blocks512',lr_schedule=schedule_contract(OmegaConf.create(t)),
     optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],
     data_sha256=p['data_sha256'],data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,
     torch_version=p['runtime']['packages']['torch'],device='mps',
     training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(3000):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==.00006
 torch.manual_seed(r['seed'])
 model=GPT(OmegaConf.create(want['model']))
 assert m['mlp_type']=='dense'
 weights=cp['model_state'];model.load_state_dict(weights,strict=True)
 assert all(torch.isfinite(value).all() for value in weights.values())
 named=dict(model.named_parameters());seen=[];inactive=[]
 for opt in cp['optimizer_state']['optimizers']:
  for group in opt['param_groups']:
   assert len(group['parameter_names'])==len(group['params'])==1
   name=group['parameter_names'][0];seen.append(name);param=named[name]
   hidden=name.startswith('transformer.h.') and param.ndim==2
   scale=1/math.sqrt(r['width']/64) if hidden else 1.
   assert group['width_lr_scale']==scale and group['lr']==r['lr']*scale*multiplier(schedule_contract(OmegaConf.create(t)),2999) and group['weight_decay']==0
   slots=opt['state'].get(group['params'][0])
   assert slots is not None
   if hidden:
    assert group['momentum']==.95 and group['adjust_lr_fn']=='match_rms_adamw'
    assert set(slots)=={'momentum_buffer'}
   else:
    assert group['betas']==(.9,.999) and slots['step'].item()==3000
    assert set(slots)=={'step','exp_avg','exp_avg_sq'}
   for key,value in slots.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==param.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 w=r['width'];sett=study.settings(r['family']);depth=sett['depth']
 assert len(model.transformer.h)==depth and model.cfg.n_heads==w//32
 active=total=sum(param.numel() for param in model.parameters())
 for layer in range(depth):
  prefix=f'transformer.h.{layer}.'
  assert list(weights[prefix+'attn.qkv.weight'].shape)==[3*w,w]
  assert list(weights[prefix+'attn.out.weight'].shape)==[w,w]
  assert list(weights[prefix+'freq_cos'].shape)==[128,16]
  if r['family']!='gelu_reference':
   hidden=21*w//(4 if r['family']=='wide4' else 8)
   for name in ('linear_gate','linear_up'):assert list(weights[prefix+'mlp.'+name+'.weight'].shape)==[hidden,w]
   assert list(weights[prefix+'mlp.linear_down.weight'].shape)==[w,hidden]
  else:
   assert list(weights[prefix+'mlp.0.weight'].shape)==[4*w,w]
   assert list(weights[prefix+'mlp.2.weight'].shape)==[w,4*w]
 assert not any('wpe' in name for name in weights)
 if r['family']=='gelu_reference':
  expected_count=132*w+depth*(12*w*w+11*w)
 else:
  h=21*w//(4 if r['family']=='wide4' else 8)
  expected_count=132*w+depth*(4*w*w+6*w+3*w*h)
 assert total==active==expected_count and not inactive
 if depth==6:
  assert m['depth_width_policy']=='depth6_dense_unscaled' and m['ffn_width_policy']=='swiglu_21_8'
 for row in metrics:
  assert math.isclose(row['train_loss'],row['train_ce_loss'],rel_tol=0,abs_tol=1e-12)
 assert set(r['coverage'])=={'128'}
 ev=r['coverage']['128'];assert ev['block_target_counts']==[2048]*54+[946]
 assert ev['target_count']==111538 and ev['eval_batch_size']==8 and ev['window_count']==872
 assert math.isclose(sum(ev['block_loss_sums'])/111538,ev['mean_ce'],abs_tol=1e-12)
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
     result_sha256=r['result_sha256'],total_parameters=total,active_parameters_per_token=active,never_updated_expert_parameters=inactive))
 if (i+1)%12==0:print('Verified',i+1,flush=True)

review=dict(status='partial_verified' if args.partial else 'verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_checkpoints=len(records),
    holdout_consumed=False,training_rerun=False,checkpoint_audit=checks)
if args.partial:
 (root/'research_state/capacity-validation/partial-audit.json').write_text(json.dumps(review,indent=2)+'\n')
 print('PARTIAL VERIFIED',len(records))
 raise SystemExit(0)

report=json.loads((run/'report.json').read_text())
assert study.summarize(p,s)==report
for c in report['comparisons']+[{**v,'width':64,'screening':True} for v in report['screening_fixed_lr_comparisons']]:
 rows={(r['family'],r['width'],r['seed']):r for r in records
       if r['stage']==('local' if c.get('screening') else 'confirmation') and (not c.get('screening') or r['lr']==.0025)}
 if not c.get('screening'):
  for alias,family in s['selection']['confirmation']['reference_aliases'].items():
   for w in (64,256):
    for seed in study.CONFIRM_SEEDS:rows[alias,w,seed]=rows[family,w,seed]
 seeds=study.SCREEN_SEEDS if c.get('screening') else study.CONFIRM_SEEDS
 for v in c['sensitivity']:
  aa=[rows[c['candidate'],c['width'],seed]['coverage']['128'] for seed in seeds]
  bb=[rows[c['reference'],c['width'],seed]['coverage']['128'] for seed in seeds]
  diffs=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0)
  counts=np.array(aa[0]['block_target_counts']);factor=v['text_block_tokens']//2048
  chunks=np.array([diffs[j:j+factor].sum() for j in range(0,len(diffs),factor)])
  cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
  idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)))
  boot=chunks[idx].sum(1)/cnt[idx].sum(1)
  assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
  assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],abs_tol=1e-12)
  for seed,a,b in zip(seeds,aa,bb):assert math.isclose(a['mean_ce']-b['mean_ce'],v['paired_seed_deltas'][str(seed)],abs_tol=1e-12)
 if 'near_neutral_common128' in c:
  assert c['near_neutral_common128']==all(v['mean_delta']<=.01 and max(v['paired_seed_deltas'].values())<=.01
     and v['conditional_text_bootstrap_95pct'][1]<=.01 for v in c['sensitivity'])
 if 'quality_improvement' in c:
  v=c['sensitivity'][0];assert c['quality_improvement']==(v['mean_delta']<-.005 and max(v['paired_seed_deltas'].values())<0)

# Independent capacity and LR decisions, without relying on report helper.
choices={}
for family in study.CELLS:
 scores={lr:math.fsum(r['metric'] for r in records[:18] if r['family']==family and r['lr']==lr)/2 for lr in study.LRS}
 lr=min(scores,key=lambda x:(scores[x],x));choices[family]=(lr,scores[lr])
 assert lr==s['selection']['choices'][family]['lr']
def panel(f,lr):return {r['seed']:r['metric'] for r in records[:18] if r['family']==f and r['lr']==lr}
eligible=[]
for f in ('wide4','dense6'):
 a=panel(f,choices[f][0]);pass_all=True
 for lr in (choices['dense4'][0],p['incumbent_schedule']['learning_rate']):
  b=panel('dense4',lr);delta=[a[seed]-b[seed] for seed in study.SCREEN_SEEDS]
  pass_all &= math.fsum(delta)/2<-.005 and max(delta)<0
 if pass_all:eligible.append(f)
winner=min(eligible,key=lambda f:(choices[f][1],f)) if eligible else 'historical_incumbent_unchanged'
assert winner==s['selection']['winner']
adoption_checks=[]
if winner!='historical_incumbent_unchanged':
 for width in (64,256):
  for reference in dict.fromkeys(('dense4','deep_reference' if p['incumbent_schedule']['kind']=='constant' else 'incumbent_reference','deep_reference')):
   match=[c for c in report['comparisons'] if c['width']==width and
          c['candidate']==winner and c['reference']==reference]
   assert len(match)==1
   v=match[0]['sensitivity'][0]
   adoption_checks.append(dict(width=width,reference=reference,
       mean_delta=v['mean_delta'],paired_seed_deltas=v['paired_seed_deltas'],
       supported=v['mean_delta'] < -p['min_improvement'] and
                 all(delta<0 for delta in v['paired_seed_deltas'].values())))
quality_decision=dict(frozen_screen_winner=winner,
    qualifies_for_incumbent_replacement=bool(adoption_checks) and all(c['supported'] for c in adoption_checks),
    confirmation_checks=adoption_checks,
    rule='Only the width64 screen winner can qualify; confirmation mean gain>.005 and every seed improves at widths64 and256 versus tuned dense4, fixed reviewed incumbent and original deep dense constant reference.',
    limitations='Adaptive validation; conditional text bootstrap is descriptive, not independent seed uncertainty or holdout. No larger-width reselection.')
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),screen_trials=18,
 confirmation_and_reference_trials=len(records)-18,reference_aliases=s['selection']['confirmation']['reference_aliases'],
 active_seconds=s['active_seconds'],disk_mb=disk_mb(run),quality_decision=quality_decision,
 checks=['All distinct raw request/result/checkpoint hashes, configs, runtime, final3000updates and3072000targets',
 'Strict finite CPU weight/optimizer loads; exact attention/FFN/group scaling and Adam step counts; no inactive dense parameters',
 'Reconstructed final private train RNG and untouched test RNG; bound sampler and resume model contracts',
 'Layer/head/QKV/FFN shapes and independently calculated total/active parameter counts; full111538target coverage',
 'Dense training objective equals pure CE; no routing or auxiliary loss',
 'Explicit schedule resume contract, independently reconstructed logged LR sequence and final optimizer group rates',
 'Exact18screen and freshconfirmation schedule; frozen LR/capacity selection and reference aliases independently checked',
 'Entire report reproduced from evidence; every paired bootstrap, mean and reported quality gate independently reconstructed',
 'Source/corpus/runtime/fullbank/prerequisite artifacts verified; no training/evaluation reruns or holdout access'])
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print('VERIFIED',len(records),review['active_seconds'],review['disk_mb'])
