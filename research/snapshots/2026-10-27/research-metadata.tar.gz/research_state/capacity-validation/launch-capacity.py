import json,os,re,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
from src.research import capacity_study as study
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();run=root/'research_runs/capacity-quality-001';p=json.loads((run/'plan.json').read_text());assert not (run/'state.json').exists();study.verify_lineage(p)
f=root/'research_state/active-campaign.json';a=json.loads(f.read_text());assert a['status']=='completed_reviewed' and a['campaign']==str(root/'research_runs/schedule-quality-001')
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [line for line in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|context_interaction|context256_study|batch_study|capacity_study)|src\.train\.train',line)],'A known training process is live'
now=datetime.now(timezone.utc).isoformat();env=os.environ.copy();env.pop('PYTORCH_ENABLE_MPS_FALLBACK',None)
with (run/'controller.log').open('x') as log:
 proc=subprocess.Popen([sys.executable,'-m','src.research.capacity_study','--plan',str(run/'plan.json'),'--output',str(run),'--allow-training'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
a.update(campaign=str(run),kind='capacity_quality',stage='capacity_quality',status='running',pid=proc.pid,launched_at=now,source_commit=p['git_commit'],source_root=str(source),plan=str(run/'plan.json'),state_file=str(run/'state.json'),predecessor=str(root/'research_runs/schedule-quality-001'),scope='18 width64screens;freshconfirmation64/256,48/54/60distinct with exactreferences. Dense4/wide4/dense6 with one reviewed schedule, equal3072000targets/3000updates;holdoutclosed.',next_action='Monitor and audit frozen dense capacity round; pursue the next justified finite quality experiment until human interruption.')
for key in ['review','result_id','documentation_commit','completed_reviewed_at','completed_at']:a.pop(key,None)
f.write_text(json.dumps(a,indent=2)+'\n')
f=root/'research_state/research-monitor.json';m=json.loads(f.read_text());m.update(active_stage='capacity_quality',active_study=str(run),status='running',last_checked_at=now,last_live_controller_pid=proc.pid,capacity_launch_notified=True,capacity_record_count=0);f.write_text(json.dumps(m,indent=2)+'\n')
f=root/'research_state/quality-evolution-progress.json';d=json.loads(f.read_text());d.update(status='running',active_study=str(run),protocol=str(source/'research/CAPACITY_QUALITY_PROTOCOL.md'),source_commit=p['git_commit'],preregistration_id=p['preregistration_id'],implementation_id=p['implementation_id'],next_action=a['next_action'],last_checked_at=now,capacity_incumbent_schedule=p['incumbent_schedule'],capacity_record_count=0,completion_audit=str(root/'research_state/capacity-validation/completion-audit.py'));f.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(dict(pid=proc.pid,source=p['git_commit'],incumbent_schedule=p['incumbent_schedule'],run=str(run))))
