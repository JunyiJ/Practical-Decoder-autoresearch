"""Partial width64 confirmation review. Requires a fresh checkpoint audit first."""
import json,math,statistics,datetime
from pathlib import Path
import numpy as np
from src.research.protocol import digest,file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/capacity-quality-001';folder=root/'research_state/capacity-validation'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());sel=json.loads((run/'selection.json').read_text());audit=json.loads((folder/'partial-audit.json').read_text())
assert s['status'] in ('running','completed') and sel==s['selection'] and digest(p)==audit['plan_sha256']==sel['plan_sha256']
assert audit['status']=='partial_verified' and audit['distinct_checkpoints']>=36
completed=[r for r in s['records'] if r['status']=='completed'];assert sum(r['stage']=='confirmation' and r['width']==256 for r in completed)<18
indexed={r['trial_id']:r for r in completed}
for a in audit['checkpoint_audit']:
 for key in ['checkpoint_sha256','request_sha256','result_sha256']:assert a[key]==indexed[a['trial_id']][key]
rows=[r for r in completed if r['stage']=='confirmation' and r['width']==64]
assert len(rows)==18 and {r['trial_id'] for r in rows}<={a['trial_id'] for a in audit['checkpoint_audit']}
assert sel['confirmation']['reference_aliases']=={'incumbent_reference':'dense4'}
rows += [dict(r,family='incumbent_reference',alias_of=r['trial_id']) for r in rows if r['family']=='dense4']
seeds=[2131,2132,2133];families=['dense4','wide4','dense6','gelu_reference','shallow_reference','deep_reference','incumbent_reference']
panels={f:{r['seed']:r for r in rows if r['family']==f} for f in families};assert all(set(v)==set(seeds) for v in panels.values())
means={f:dict(ce128=statistics.mean(x['metric'] for x in panel.values()),training_seconds=statistics.mean(x['training_time_sec'] for x in panel.values())) for f,panel in panels.items()}
comparisons=[]
for a,b in [('wide4','dense4'),('dense6','dense4'),('dense6','wide4')]+[(f,ref) for f in families[:3] for ref in families[3:]]:
 ds={str(seed):panels[a][seed]['metric']-panels[b][seed]['metric'] for seed in seeds}
 av=[panels[a][seed]['coverage']['128'] for seed in seeds];bv=[panels[b][seed]['coverage']['128'] for seed in seeds]
 counts=np.array(av[0]['block_target_counts']);diff=np.array([np.array(x['block_loss_sums'])-y['block_loss_sums'] for x,y in zip(av,bv)]).mean(0);intervals={}
 for blocksize in (2048,4096,8192):
  factor=blocksize//2048;chunks=np.array([diff[i:i+factor].sum() for i in range(0,len(diff),factor)]);cnt=np.array([counts[i:i+factor].sum() for i in range(0,len(counts),factor)])
  idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)));boot=chunks[idx].sum(1)/cnt[idx].sum(1)
  intervals[str(blocksize)]=list(np.quantile(boot,[.025,.975]))
  assert math.isclose(chunks.sum()/cnt.sum(),statistics.mean(ds.values()),rel_tol=0,abs_tol=1e-12)
 comparisons.append(dict(candidate=a,reference=b,width=64,mean_delta=statistics.mean(ds.values()),paired_seed_deltas=ds,conditional_text_bootstrap_95pct=intervals,mean_gain_gt005_and_every_seed=statistics.mean(ds.values())<-.005 and max(ds.values())<0))
winner=sel['winner'];winner_checks=[c for c in comparisons if c['candidate']==winner and c['reference'] in ('dense4','incumbent_reference','deep_reference')]
assert len(winner_checks)==3
supported=all(c['mean_gain_gt005_and_every_seed'] for c in winner_checks)
now=datetime.datetime.now(datetime.timezone.utc).isoformat();out=folder/'width64-confirmation-review.json';assert not out.exists();cp=folder/'width64-checkpoint-audit.json';assert not cp.exists();cp.write_bytes((folder/'partial-audit.json').read_bytes());cp.chmod(0o444)
review=dict(status='partial_width64_confirmation_verified_not_final',reviewed_at=now,source_commit=p['git_commit'],plan_sha256=digest(p),selection_sha256=file_digest(run/'selection.json'),distinct_width64_confirmation_trials=18,reference_aliases={'incumbent_reference':'dense4'},confirmation_seeds=seeds,widths=[64],means=means,comparisons=comparisons,frozen_screen_winner=winner,width64_winner_supported=supported,incumbent_unchanged=True,checkpoint_audit=dict(path=str(cp),sha256=file_digest(cp)),limitations=['Width256 confirmation still required; no final adoption or source change','Three fresh development seeds, reused validation text; intervals conditional on these models/text, not population/seed uncertainty','Six incumbent reference cells alias selected dense4; at this width three aliases are not independent repeats','Capacity, initialization and compute differ; equal targets/updates with shared cooldown; heldoutclosed'])
out.write_text(json.dumps(review,indent=2)+'\n');out.chmod(0o444)
delta=next(c['mean_delta'] for c in winner_checks if c['reference']=='dense4')
summary=f'Capacity quality001 fresh width64 confirmation reviewed on2131/2132/2133. Frozen{winner} minus tuned dense4 meanCE {delta:+.6f}; width64 mean>.005/everyseed rule {"passes" if supported else "fails"}. Width256 remains pending; incumbent unchanged. Full111538-targetcoverage and savedcheckpoint/LR/optimizer/RNG contracts audited, no training/evaluation rerun.'
kid=KnowledgeBank(root/'research_state/knowledge').add(dict(kind='result',outcome='supported' if supported else 'mixed',created_by='continuing-quality-research',title='Fresh width64 capacity confirmation, wider transfer still pending',summary=summary,scope=dict(stage='width64_confirmation_only',widths=[64],seeds=seeds,holdout_consumed=False,incumbent_unchanged=True),details=review,artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in [out,cp,run/'selection.json']],related_ids=[p['preregistration_id'],'kb_1d83bebd985c89d50d95e3f9e24469ddc7beaa7343e446afa99d4470f8ba3106']))
(folder/'width64-knowledge.json').write_text(json.dumps(dict(result_id=kid,summary=summary),indent=2)+'\n')
for name in ['research-monitor.json','quality-evolution-progress.json']:
 path=root/'research_state'/name;d=json.loads(path.read_text());d.update(capacity_width64_review=str(out),capacity_width64_result_id=kid,capacity_width64_notified=True,capacity_record_count=len(completed),last_checked_at=now);path.write_text(json.dumps(d,indent=2)+'\n')
print(kid);print(summary);print(json.dumps(means));print(json.dumps(winner_checks))
