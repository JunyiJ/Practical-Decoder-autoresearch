"""Bounded CPU synthetic correctness diagnostic; run only with no research worker.
Nine initial models, one synthetic forward/backward/update each. Not quality data.
"""
import datetime,hashlib,json,math,os,subprocess,sys
from pathlib import Path
import torch
from src.models.gpt import GPT
from src.train.optimizers import build_optimizer
from src.research.team.suite import source_digest
from tests.test_capacity_training import cfg_for
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
out=root/'research_state/capacity-validation/activation-diagnostic.json'
assert not out.exists(), 'Preserve previous diagnostic; no automatic rerun'
state=json.loads((root/'research_runs/schedule-quality-001/state.json').read_text())
assert state['status']=='completed'
ps=subprocess.check_output(['ps','-axo','pid,command'],text=True)
for line in ps.splitlines():
 if str(os.getpid())==line.strip().split(' ',1)[0]:continue
 if ' -m src.research.' in line or ('--request ' in line and '/research_runs/' in line):
  raise RuntimeError('Research process still active: '+line[:200])
torch.set_num_threads(1)
rows=[]
for family in ('dense4','wide4','dense6'):
 for width in (64,128,256):
  torch.manual_seed(9304);cfg=cfg_for(family,width);model=GPT(cfg.model)
  optimizer=build_optimizer(model,cfg.training);acts={};hooks=[]
  def capture(name):
   def hook(module,args,value):
    tensor=value[0] if isinstance(value,tuple) else value
    assert torch.isfinite(tensor).all(),name
    acts[name]={'rms':float(tensor.detach().double().square().mean().sqrt()),'max_abs':float(tensor.detach().abs().max())}
   return hook
  for i,block in enumerate(model.transformer.h):hooks.append(block.register_forward_hook(capture('block_'+str(i))))
  x=(torch.arange(2*128).reshape(2,128)*7+3)%65;y=(x+1)%65
  logits,loss=model(x,y);assert torch.isfinite(loss) and torch.isfinite(logits).all()
  loss.backward();gradient_norm=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.))
  assert math.isfinite(gradient_norm)
  before={n:p.detach().clone() for n,p in model.named_parameters()};norms={}
  for name,p in model.named_parameters():
   assert p.grad is not None and torch.isfinite(p.grad).all(),name
   norms[name]={'parameter_rms':float(p.detach().double().square().mean().sqrt()),'clipped_gradient_rms':float(p.grad.detach().double().square().mean().sqrt())}
  optimizer.step()
  for name,p in model.named_parameters():
   assert torch.isfinite(p).all(),name
   update=float((p.detach()-before[name]).double().square().mean().sqrt())
   norms[name]['update_rms']=update
   denom=norms[name]['parameter_rms'];norms[name]['update_to_parameter_rms']=update/denom if denom else None
  for hook in hooks:hook.remove()
  rows.append({'family':family,'width':width,'synthetic_ce':float(loss.detach()),'unclipped_gradient_norm':gradient_norm,'block_activations':acts,'parameter_diagnostics':norms,'parameter_count':sum(p.numel() for p in model.parameters())})
  del model,optimizer,before,logits,loss
result={'status':'verified_finite_synthetic_correctness_only','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(Path.cwd()),'source_sha256':source_digest(Path.cwd()),'seed':9304,'device':'cpu','models':9,'updates_per_model':1,'tokens_per_model':256,'learning_rate':.0025,'gradient_clip':1.,'scope':'Synthetic initialization/activation/gradient/update diagnostic only. Not research quality, training stability over full horizon, optimal depth scaling or empirical transfer proof. One sample per shape; no statistical comparison.','rows':rows}
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(out)
for r in rows:print(r['family'],r['width'],'gradient norm',r['unclipped_gradient_norm'],'last block RMS',list(r['block_activations'].values())[-1]['rms'])
