"""Record completed audited capacity evidence before any source documentation edit.
No training/evaluation. New-only conclusion, best-config archive and bank snapshot.
"""
import copy,datetime,json,statistics
from pathlib import Path
from src.research import capacity_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/capacity-quality-001'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());r=json.loads((run/'report.json').read_text());rev=json.loads((run/'review.json').read_text())
assert s['status']=='completed' and rev['status']=='verified'
assert rev['plan_sha256']==digest(p)==r['plan_sha256']
assert rev['report_sha256']==file_digest(run/'report.json') and rev['selection_sha256']==file_digest(run/'selection.json')
assert rev['distinct_checkpoints']==len(r['records'])==r['selection']['confirmation']['total_distinct_trials']
assert len(r['records']) in (54,60) and p['incumbent_schedule']=={'kind':'linear_cooldown','learning_rate':.005}
study.verify_lineage(p)
rows=[x for x in r['records'] if x['stage']=='confirmation']
for alias,family in r['reference_aliases'].items():rows += [dict(x,family=alias,alias_of=x['trial_id']) for x in rows if x['family']==family]
families=list(study.CELLS)+list(study.fixed_references(p['incumbent_schedule']));means={}
audit={x['trial_id']:x for x in rev['checkpoint_audit']}
for f in families:
 means[f]={}
 for w in (64,256):
  panel=[x for x in rows if x['family']==f and x['width']==w];assert sorted(x['seed'] for x in panel)==study.CONFIRM_SEEDS
  counts={audit[x['trial_id']]['total_parameters'] for x in panel};assert len(counts)==1
  means[f][str(w)]={key:statistics.mean(x[field] for x in panel) for key,field in [('ce128','metric'),('training_seconds','training_time_sec'),('rss_mb','rss_mb'),('mps_current_allocated_mb','accel_mem_mb')]}
  means[f][str(w)]['total_parameters']=counts.pop()
def comparison(f,ref,w):
 matches=[c for c in r['comparisons'] if c['candidate']==f and c['reference']==ref and c['width']==w];assert len(matches)==1;return matches[0]
winner=r['selection']['winner'];adopt=rev['quality_decision']['qualifies_for_incumbent_replacement']
assert rev['quality_decision']['frozen_screen_winner']==winner
qualified=(winner!='historical_incumbent_unchanged' and all(comparison(winner,ref,w)['sensitivity'][0]['mean_delta']<-.005 and max(comparison(winner,ref,w)['sensitivity'][0]['paired_seed_deltas'].values())<0 for w in (64,256) for ref in ('dense4','incumbent_reference','deep_reference')))
assert adopt==qualified
choices=r['selection']['choices'];cost={f:{str(w):100*(means[f][str(w)]['training_seconds']/means['dense4'][str(w)]['training_seconds']-1) for w in (64,256)} for f in ('wide4','dense6')}
parameters={f:{str(w):100*(means[f][str(w)]['total_parameters']/means['dense4'][str(w)]['total_parameters']-1) for w in (64,256)} for f in ('wide4','dense6')}
choice_text=', '.join(f'{f} {choices[f]["lr"]:g} ({"boundary" if choices[f]["at_grid_boundary"] else "interior"})' for f in study.CELLS)
summary=f'Capacity quality001 completed and reviewed {len(r["records"])}/{len(r["records"])}. Frozen peak LRs: {choice_text}. '
if winner=='historical_incumbent_unchanged':summary+='Neither larger-capacity model qualified under the width64 screening rule; the incumbent is retained. '
else:
 ds=[comparison(winner,'dense4',w)['sensitivity'][0]['mean_delta'] for w in (64,256)]
 summary+=f'The frozen screen winner was {winner}; its tuned-dense4 CE deltas at widths64/256 are {ds[0]:+.6f}/{ds[1]:+.6f}. '
 summary+=('It passes the mean gain>.005 and every-seed rule versus tuned dense4, fixed cooldown incumbent and original constant-deep reference at both widths, and becomes the current observed quality incumbent. ' if adopt else 'It fails the complete adoption rule, so the prior incumbent remains. ')
summary+='All selected models use final-third cooldown,3000 updates and3,072,000 targets, with different capacity and compute. Held-out test remains closed.'
limits=['Fresh development seeds on adaptively reused validation; no holdout or population/seed uncertainty claim. Conditional text intervals are descriptive.',
 'Depth, hidden width, parameter counts and initialization draws differ. Equal tokens and updates do not mean equal compute or isolate a pure capacity/depth mechanism.',
 'A common cooldown schedule shape was fixed before this study. Each capacity had equal bounded peak-LR tuning at width64; tuned comparisons can include different LR choices. Fixed-LR screening contrasts are separate.',
 'Grid boundary selection does not authorize extension, prove optimal muP/depth transfer, or justify choosing a different winner from width256.',
 'Only the frozen screen winner can be adopted. Exact incumbent-reference aliases are the same checkpoints, not independent repeats; other controls are fresh.',
 'Training time is measured separately from controller/full-validation overhead. Current MPS allocation is not peak memory or inference efficiency.']
artifacts=[run/f for f in ['plan.json','selection.json','report.json','review.json']]+[root/'research_state/capacity-validation/completion-audit.py']
entry=dict(kind='result',title='Four-layer standard/wide FFN and six-layer dense capacity with reviewed cooldown',summary=summary,outcome='supported' if adopt else 'mixed',created_by='continuing-quality-research',scope=dict(source_commit=rev['source_commit'],screen_seeds=study.SCREEN_SEEDS,confirmation_seeds=study.CONFIRM_SEEDS,widths=study.WIDTHS,updates=3000,targets_per_trial=3072000,batch_layout='paired_blocks512',validation_targets=111538,primary_context=128,holdout_consumed=False),details=dict(means=means,selected_lrs=choices,training_time_change_percent=cost,parameter_change_percent=parameters,comparisons=r['comparisons'],fixed_lr_screening=r['screening_fixed_lr_comparisons'],quality_decision=rev['quality_decision'],reference_aliases=r['reference_aliases'],active_seconds=rev['active_seconds'],limitations=limits),artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in artifacts],related_ids=[p['preregistration_id'],p['implementation_id'],'kb_c6a54b5a4fd0d7ef57510cdad7fb7d5072d26235a795961177913ca3bea3bcbd'])
conpath=root/'research_state/capacity-conclusion.json';assert not conpath.exists();bpath=root/'research_state/best-observed-config.json';old=json.loads(bpath.read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
archive=root/'research_state/best-observed-before-capacity-quality001.json'
if adopt:assert not archive.exists()
bank=KnowledgeBank(root/'research_state/knowledge');kid=bank.add(entry)
con=dict(result_id=kid,summary=summary,means=means,selected_lrs=choices,training_time_change_percent=cost,parameter_change_percent=parameters,comparisons=r['comparisons'],reference_aliases=r['reference_aliases'],quality_decision=rev['quality_decision'],limitations=limits,review=str(run/'review.json'),historical_incumbent_unchanged=not adopt)
conpath.write_text(json.dumps(con,indent=2)+'\n')
if adopt:
 archive.write_bytes(bpath.read_bytes());archive.chmod(0o444)
 cfg=study.suite_spec(p,winner,choices[winner]['lr'])['candidate']['config'];base=copy.deepcopy(p['config']);overrides=[]
 for section in ('model','training'):
  for k,v in cfg[section].items():
   if base[section].get(k)!=v:overrides.append(dict(path=section+'.'+k,value_json=json.dumps(v)))
 b=dict(label=f'Most promising observed quality recipe: {winner} dense SwiGLU MHA with final-third cooldown',baseline_commit=rev['source_commit'],baseline_config=base,config_overrides=overrides,reference_overrides={},result_id=kid,source_campaign=str(run),source_iteration=None,evidence_path=str(run/'report.json'),source_contract=dict(source_sha256=p['source_sha256'],data_sha256=p['data_sha256']),previous_best=dict(path=str(archive),sha256=file_digest(archive),result_id=old['result_id']),prior_incumbent_reference=dict(path=str(archive),description='Prior standard four-layer dense cooldown LR.005 retained'),constant_reference=copy.deepcopy(old['constant_reference']),selection=dict(path=str(run/'selection.json'),winner=winner,rule=rev['quality_decision']['rule']),quality_decision=rev['quality_decision'],local_outcome='supported',transfer_outcome='supported_at_tested_widths',metrics=[dict(target=f'width-{w}',metric='full_validation_context128_ce_delta',candidate_mean=means[winner][str(w)]['ce128'],baseline_mean=means['dense4'][str(w)]['ce128'],**comparison(winner,'dense4',w)['sensitivity'][0]) for w in (64,256)],comparators=means,training_steps=3000,widths=[64,256],seeds=study.CONFIRM_SEEDS,holdout_consumed=False,stage1_control_retained_as_reference=True,ranking_scope=limits[0],limitations=limits,last_reviewed_at=now,learning_ids=[])
else:
 b=old;b.setdefault('subsequent_algorithm_studies',[]).append(dict(campaign=str(run),result_id=kid,review=str(run/'review.json'),summary=summary,means=means,quality_decision=rev['quality_decision']));b['last_reviewed_at']=now
bpath.write_text(json.dumps(b,indent=2)+'\n')
snapshot=root/'research_state/capacity-completed-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
lines=['# Dense capacity quality results','',summary,'',f'Historical source `{rev["source_commit"]}`. Result `{kid}`. Every distinct checkpoint/raw request/result and saved configuration, LR schedule, sampler/private RNG, optimizer group/rate/state, layer/head/FFN shape and parameter count, and validation coverage contract was verified. The complete report and every conditional bootstrap interval were independently reconstructed. No training or quality evaluation rerun.','',f'18 screening trials plus {len(r["records"])-18} distinct confirmation/reference trials. Prospective reference aliases: `{json.dumps(r["reference_aliases"],sort_keys=True)}`. Active controller time {rev["active_seconds"]:.2f} seconds ({rev["active_seconds"]/3600:.2f} hours); output before review {rev["disk_mb"]:.2f} MiB. [Frozen protocol](CAPACITY_QUALITY_PROTOCOL.md).','','## Scores and frozen choices','','Peak LRs were selected on width64 seeds2121/2122 before any confirmation. Fresh2131/2132/2133 confirmation used widths64/256. Full validation covers111538 targets exactly once at context128. Historical results are not pooled.','','| Recipe | Peak LR | Schedule | CE64 | CE256 | Train seconds64 | Train seconds256 | Parameters64 | Parameters256 |','|---|---:|---|---:|---:|---:|---:|---:|---:|']
for f in families:
 lr=choices[f]['lr'] if f in study.CELLS else study.fixed_references(p['incumbent_schedule'])[f]
 kind='linear_cooldown' if f in study.CELLS or f=='incumbent_reference' else 'constant'
 a,z=means[f]['64'],means[f]['256'];label=f+(f' (alias of {r["reference_aliases"][f]})' if f in r['reference_aliases'] else '')
 lines.append(f'| {label} | {lr:g} | {kind} | {a["ce128"]:.6f} | {z["ce128"]:.6f} | {a["training_seconds"]:.2f} | {z["training_seconds"]:.2f} | {a["total_parameters"]:,} | {z["total_parameters"]:,} |')
lines+=['','The selected models share context128, batch8, paired_blocks512 sampling, Muon/AdamW muP base64, head32 MHA, bias-free SwiGLU, unscaled residuals and independent per-step decay.00006. Wider four-layer FFNs use hidden width21d/4; standard four/six-layer FFNs use21d/8. The six-layer policy is explicitly depth6_dense_unscaled; algebraic width factors do not establish optimal depth/LR transfer. Cooldown starts at zero-based update2000 and ends at10% of peak. No boundary grid is extended.','','## Paired confirmation contrasts','','Positive CE delta is worse. Values are fresh seeds2131/2132/2133. The table shows4096-token conditional text intervals; all2048/4096/8192 intervals are retained and verified. These intervals condition on these models and reused text, not seed-population uncertainty.','','| Width | Candidate minus reference | Mean delta | Paired seeds | Conditional95% text interval |','|---:|---|---:|---|---|']
for c in r['comparisons']:
 v=c['sensitivity'][1];lo,hi=v['conditional_text_bootstrap_95pct'];ds=' / '.join(f'{v["paired_seed_deltas"][str(seed)]:+.6f}' for seed in study.CONFIRM_SEEDS)
 lines.append(f'| {c["width"]} | {c["candidate"]} − {c["reference"]} | {v["mean_delta"]:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] |')
lines+=['','## Fixed-LR screening contrasts and costs','','The screening contrasts hold peak LR at.0025 and use2121/2122, separately from tuned confirmation.','','| Candidate minus reference | Mean delta | Seed2121 | Seed2122 |','|---|---:|---:|---:|']
for c in r['screening_fixed_lr_comparisons']:
 v=c['sensitivity'][0];lines.append(f'| {c["candidate"]} − {c["reference"]} | {v["mean_delta"]:+.6f} | {v["paired_seed_deltas"]["2121"]:+.6f} | {v["paired_seed_deltas"]["2122"]:+.6f} |')
lines+=['','| Capacity | Training time change64/256 vs tuned dense4 | Parameter change64/256 |','|---|---|---|']
for f,v in cost.items():lines.append(f'| {f} | {v["64"]:+.2f}% / {v["256"]:+.2f}% | {parameters[f]["64"]:+.2f}% / {parameters[f]["256"]:+.2f}% |')
lines+=['','## Frozen decision and next research','',rev['quality_decision']['rule'],'',('The audited frozen winner qualifies and becomes the current observed quality incumbent. The prior four-layer cooldown, original constant deep model, GELU and cheaper shallow references remain preserved.' if adopt else 'The frozen rule does not support replacement. All narrower findings remain recorded and the previous incumbent is retained.'),'','A separate prospective weight-averaging follow-up is prepared. It will resolve its fixed backbone only from this final reviewed adoption, train eight fresh trajectories and compare raw endpoints with three registered spaced tail averages from each trajectory. It still requires actual trainer/export/resume tests, full project tests, serial MPS correctness/resource gates, clean reviewed source and unique preregistration. It is not a completed-grid extension or a rerun for interpretation. No human-stopped campaign006 resumes.','','## Limits','']+['- '+v for v in limits]+['','Evidence: `research_runs/capacity-quality-001/{plan,selection,state,report,review}.json`, per-trial artifacts, completion audit and knowledge snapshots. Human kimi source remains untouched.']
Path('/private/tmp/CAPACITY_QUALITY_RESULTS.md').write_text('\n'.join(lines)+'\n')
start=next(i for i,x in enumerate(lines) if x.startswith('| Recipe |'));end=lines.index('## Paired confirmation contrasts')
guide='## Completed dense capacity quality round\n\n'+summary+'\n\n'+'\n'.join(lines[start:end])+'\n[Complete capacity results and paired evidence](CAPACITY_QUALITY_RESULTS.md). Findings remain adaptive validation with conditional text uncertainty.\n'
Path('/private/tmp/capacity-guide-addition.md').write_text(guide)
print(kid);print(summary)
