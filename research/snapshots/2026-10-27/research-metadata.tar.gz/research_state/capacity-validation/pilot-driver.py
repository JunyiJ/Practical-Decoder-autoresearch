"""Serial correctness pilots. Never run alongside research training.

Requires a completed schedule audit, clean committed schedule source, and a recorded
CPU review. Output is new-only; failures preserve evidence and stop immediately.
"""
import argparse
import copy
import datetime
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-pilots',action='store_true')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-review',type=Path,required=True)
    args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):
        raise ValueError('Unset PYTORCH_ENABLE_MPS_FALLBACK')
    root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
    predecessor=root/'research_runs/schedule-quality-001'
    state=json.loads((predecessor/'state.json').read_text())
    if state['status']!='completed':raise ValueError('Schedule training must finish first')
    active=json.loads((root/'research_state/active-campaign.json').read_text())
    if Path(active['campaign']).resolve()!=predecessor or active['status'] not in {'completed','completed_reviewed'}:
        raise ValueError('Active pointer must still name the completed predecessor')
    # Also inspect all live project workers; a terminal marker alone is not enough.
    processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
    live=[line for line in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|context_interaction|context256_study|batch_study|capacity_study)|src\.train\.train',line)]
    if live:raise ValueError('Known research/training process is still live: '+str(live))

    import torch
    from omegaconf import OmegaConf
    from src.models.gpt import GPT
    from src.research import capacity_study as study
    from src.research.protocol import file_digest
    from src.research.team.suite import _request,_launch,source_digest
    from src.research.runner import atomic_json,session_lock,validate_result
    from src.train.lr_schedule import multiplier,schedule_contract

    torch.set_num_threads(1)  # CPU checkpoint inspection; workers explicitly use4.
    source=Path.cwd().resolve();sha=source_digest(source)
    cpu=json.loads(args.cpu_review.read_text())
    if cpu.get('status')!='cpu_verified' or cpu.get('source_sha256')!=sha:
        raise ValueError('Matching full CPU validation review required')
    if cpu.get('model_checks',{}).get('passed')!=10:raise ValueError('Ten actual shape/group/causality checks required')
    if cpu.get('trainer_integration',{}).get('passed')!=12 or cpu.get('full_tests',{}).get('failed')!=0:
        raise ValueError('Full trainer and project validation required')
    if cpu.get('full_tests',{}).get('passed',0)<800:
        raise ValueError('Project test evidence incomplete')
    if len(cpu.get('artifacts',[]))<2:raise ValueError('Saved full-project and trainer test logs required')
    for item in cpu['artifacts']:
        if file_digest(Path(item['path']))!=item['sha256']:raise ValueError('CPU test artifact changed')
    old=json.loads((predecessor/'plan.json').read_text())
    p=study.make_plan(source,old['config'],predecessor/'review.json')
    out=args.output.resolve()
    if not out.is_relative_to(root/'research_state'):raise ValueError('Pilot output must stay in shared research_state')
    out.mkdir(exist_ok=False)
    atomic_json(out/'pilot-source.json',dict(purpose='Correctness/resource pilots only;not preregistered research',
        source_sha256=sha,source_commit=p['git_commit'],incumbent_schedule=p['incumbent_schedule'],cpu_review_sha256=file_digest(args.cpu_review),
        predecessor_review=p['predecessor_review'],pilot_seed=9303,max_jobs=12,seconds_per_job=180,round_seconds=2160,max_disk_mb=1024))
    jobs=[(w,f) for w in (64,256) for f in study.CELLS]
    # Exercise every fixed-control shape too; constant already covers the dense
    # deep constant reference when the common schedule remains constant.
    refs=['gelu_reference','shallow_reference']
    if p['incumbent_schedule']['kind']!='constant':refs.append('deep_reference')
    jobs += [(w,f) for w in (64,256) for f in refs]
    assert len(jobs) in (10,12)
    results=[];started=time.monotonic()
    with session_lock(out) as fd:
        for width,family in jobs:
            if source_digest(source)!=sha:raise ValueError('Pilot source changed')
            directory=out/f'w{width}_{family}';directory.mkdir()
            lr=study.fixed_references(p['incumbent_schedule']).get(family,.005)
            spec=study.suite_spec(p,family,lr)
            row=dict(family=family,lr=lr,width=width,n_heads=width//32,seed=9303,
                     stage='local',arm='candidate',trial_id=f'pilot-w{width}-{family}')
            req=_request(spec,row,directory);t=req['config']['training'];m=req['config']['model']
            steps=40
            t.update(max_iters=steps,eval_every=steps//2,eval_iters=2)
            if t['lr_schedule']['kind']!='constant':
                t['lr_schedule']['total_steps']=steps
                if t['lr_schedule']['kind']=='linear_cooldown':t['lr_schedule']['start_step']=2*steps//3
            atomic_json(directory/'request.json',req);job_start=time.monotonic()
            allowance=min(180,2160-(job_start-started))
            if allowance<=0:raise ValueError('Pilot round time budget exhausted')
            status,error=_launch(directory/'request.json',out,allowance,1024,fd,root=source,bootstrap=study.BOOTSTRAP)
            if status!='completed':
                atomic_json(out/'failure.json',dict(family=family,width=width,status=status,error=error,no_automatic_retry=True))
                raise RuntimeError((status,error))
            raw=json.loads((directory/'result.json').read_text())
            checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),directory)
            extra=study.adapter(p,raw,checked,req,directory)
            cp=torch.load(checked['checkpoint'],map_location='cpu',weights_only=True)
            assert cp['step']==steps and raw['completed_steps']==steps
            assert extra['coverage']['128']['target_count']==111538
            assert cp['training_state']['contract']['lr_schedule']==schedule_contract(OmegaConf.create(t))
            want=copy.deepcopy(req['config']);want['model']['vocab_size']=65
            assert cp['cfg']==want
            model=GPT(OmegaConf.create(cp['cfg']['model']))
            model.load_state_dict(cp['model_state'],strict=True)
            w=width;depth=want['model']['n_layers']
            if family=='gelu_reference':expected_count=132*w+depth*(12*w*w+11*w)
            else:
                hidden=21*w//(4 if family=='wide4' else 8)
                expected_count=132*w+depth*(4*w*w+6*w+3*w*hidden)
            assert len(model.transformer.h)==depth
            assert sum(v.numel() for v in model.parameters())==expected_count
            assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
            assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
            gen=torch.Generator().manual_seed(9303)
            n=len(Path(want['data']['path']).read_text())
            for _ in range(steps):torch.randint(int(.8*n)-512,(2,),generator=gen)
            assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
            ratio=multiplier(schedule_contract(OmegaConf.create(t)),steps-1)
            for optimizer in cp['optimizer_state']['optimizers']:
                for group in optimizer['param_groups']:
                    assert group['lr']==t['learning_rate']*group['width_lr_scale']*ratio
                for slot in optimizer['state'].values():
                    assert all(torch.isfinite(value).all() for value in slot.values() if isinstance(value,torch.Tensor))
            result=dict(status='verified',purpose='MPS correctness/resource pilot;quality excluded from research',
                family=family,width=width,steps=steps,targets=steps*1024,wall_seconds=time.monotonic()-job_start,
                peak_rss_mb=max(x['rss_mb'] for x in raw['metrics']),checked=checked,coverage=extra,
                checkpoint_sha256=file_digest(Path(checked['checkpoint'])),request_sha256=file_digest(directory/'request.json'),
                result_sha256=file_digest(directory/'result.json'))
            atomic_json(directory/'review.json',result);results.append(result)
            print(dict(family=family,width=width,steps=steps,wall_seconds=result['wall_seconds']),flush=True)
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,
        incumbent_schedule=p['incumbent_schedule'],reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        pilots=results,holdout_consumed=False,excluded_from_research=True))


if __name__=='__main__':main()
