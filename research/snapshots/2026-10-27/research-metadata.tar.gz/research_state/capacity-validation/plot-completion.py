"""Render only completed, reviewed capacity measurements."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
c=json.loads((root/'research_state/capacity-conclusion.json').read_text())
rev=json.loads(Path(c['review']).read_text());assert rev['status']=='verified' and rev['distinct_checkpoints'] in (54,60)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,4,figsize=(15.5,4.5))
colors={'wide4':'#287c9d','dense6':'#b36a31'};labels={'wide4':'Wider FFN, 4L','dense6':'Standard FFN, 6L'}
for ax,w in zip(axes[:2],[64,256]):
 for i,f in enumerate(['wide4','dense6']):
  v=next(x for x in c['comparisons'] if x['candidate']==f and x['reference']=='dense4' and x['width']==w)['sensitivity'][1]
  ds=[v['paired_seed_deltas'][str(seed)] for seed in (2131,2132,2133)]
  ax.scatter(np.array([i]*3)+[-.10,0,.10],ds,color=colors[f],s=28)
  ax.scatter(i,v['mean_delta'],marker='D',s=65,color=colors[f],edgecolor='white',zorder=4)
 ax.axhline(0,color='#555',linewidth=.8);ax.axhline(-.005,color='#999',linewidth=.8,linestyle=':')
 ax.set_xticks([0,1],['Wider FFN\n4 layers','Standard FFN\n6 layers']);ax.set_title(f'Width {w}: quality')
 ax.set_ylabel('CE difference versus standard 4 layers');ax.grid(axis='y',alpha=.15)
for ax,key,title,ylabel in [(axes[2],'training_time_change_percent','Measured training time','Time change versus standard 4 layers (%)'),
                           (axes[3],'parameter_change_percent','Saved parameter counts','Parameter change versus standard 4 layers (%)')]:
 for i,f in enumerate(['wide4','dense6']):
  ax.bar(np.arange(2)+(i-.5)*.32,[c[key][f][str(w)] for w in [64,256]],width=.30,color=colors[f],label=labels[f])
 ax.set_xticks([0,1],['Width64','Width256']);ax.set_ylabel(ylabel);ax.set_title(title);ax.grid(axis='y',alpha=.15)
axes[3].legend(frameon=False,fontsize=9)
fig.suptitle('Capacity quality001 — fresh confirmation, equal training targets',fontsize=14)
fig.text(.02,.025,'Dots: three paired development seeds. Diamonds: means. Dotted line: mean-gain threshold. Shared cooldown; peak LRs selected at width64. Adaptive validation; no holdout.',fontsize=9,color='#555')
fig.tight_layout(rect=[0,.08,1,.93]);out=root/'research_state/reports/pretraining-learning-guide/capacity-quality001.png';fig.savefig(out,dpi=180);print(out)
