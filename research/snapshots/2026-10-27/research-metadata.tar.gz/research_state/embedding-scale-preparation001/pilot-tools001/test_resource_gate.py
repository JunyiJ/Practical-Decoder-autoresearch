"""Synthetic feasibility checks, not measured resource evidence."""
import copy
import importlib.util
from pathlib import Path
import pytest

path=Path(__file__).with_name('resource-gate.py')
spec=importlib.util.spec_from_file_location('embedding_resource_gate',path)
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)


def rows():
    return [dict(width=w,family=f,attention_family='mha',peak_learning_rate=.01,
        warmup_steps=2,input_embedding_scale={'baseline':1.,'half':.5,'quarter':.25}[f],input_width_policy='mha4_input_scale',steps=40,cooldown_start=20,
        snapshots=3,status='verified',training_seconds=2.,wall_seconds=5.,
        raw_checkpoint_bytes=1024**2,derived_checkpoint_bytes=1024**2,
        sampled_peak_rss_mb=500.,current_driver_mb=20.,driver_allocation_is_not_peak=True)
        for w in (64,256) for f in ('baseline','half','quarter')]


def test_exact_counts_and_forecast_not_measurement():
    r=gate.forecast(rows())
    assert r['status']=='feasible' and r['physical_trajectories']==42
    assert [p['trajectories'] for p in r['trial_proxies']]==[12,9,9,6,3,3]
    assert r['hours']==42*1.5*(2*75+3)/3600
    assert r['total_mb_with_margin']==42*1.5*27
    assert r['measured_research_duration'] is False


@pytest.mark.parametrize('damage',['missing','duplicate','steps','warmup','snapshots','status',
    'attention','lr','negative','nan','boolean','wall','rss','driver','peak_claim','scale','policy'])
def test_invalid_pilot_evidence_rejected(damage):
    r=rows()
    if damage=='missing': r.pop()
    elif damage=='duplicate': r[-1]=copy.deepcopy(r[0])
    elif damage=='steps': r[0]['steps']=20
    elif damage=='warmup': r[0]['warmup_steps']=4
    elif damage=='snapshots': r[0]['snapshots']=2
    elif damage=='status': r[0]['status']='failed'
    elif damage=='attention': r[0]['attention_family']='kda'
    elif damage=='lr': r[0]['peak_learning_rate']=.0025
    elif damage=='negative': r[0]['training_seconds']=-1
    elif damage=='nan': r[0]['training_seconds']=float('nan')
    elif damage=='boolean': r[0]['raw_checkpoint_bytes']=True
    elif damage=='wall': r[0]['wall_seconds']=1
    elif damage=='rss': r[0]['sampled_peak_rss_mb']=4096
    elif damage=='driver': r[0]['current_driver_mb']=6144
    elif damage=='scale': r[0]['input_embedding_scale']=.5
    elif damage=='policy': r[0]['input_width_policy']='wrong'
    elif damage=='peak_claim': r[0]['driver_allocation_is_not_peak']=False
    with pytest.raises(ValueError): gate.forecast(r)


@pytest.mark.parametrize('limit',['trial','round','disk'])
def test_forecast_exceeding_any_research_cap_is_infeasible(limit):
    r=rows()
    if limit=='trial': r[0].update(training_seconds=22.,wall_seconds=25.)
    elif limit=='round':
        for row in r: row.update(training_seconds=9.,wall_seconds=12.)
    else:
        for row in r: row['raw_checkpoint_bytes']=100*1024**2
    assert gate.forecast(r)['status']=='infeasible'


@pytest.mark.parametrize('warmup',[0,2,4])
def test_all_reviewed_schedule_options(warmup):
    r=rows()
    for row in r: row['warmup_steps']=warmup
    assert gate.forecast(r)['status']=='feasible'
