"""Audit saved input-scale pilot evidence and forecast bounded resources; no training/scoring."""
import argparse,datetime,json,math,subprocess,re
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--pilots',type=Path,required=True)
parser.add_argument('--cpu-review',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=Path(__file__).resolve().parent
prior=base/'research_runs/warmup-quality-001'
active=json.loads((base/'research_state/active-campaign.json').read_text())
if Path(active['campaign'])!=prior or active['status']!='completed_reviewed' or json.loads((prior/'state.json').read_text())['status']!='completed':
 raise ValueError('Completed reviewed warmup predecessor required before CPU checkpoint audit')
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
live=[line for line in processes if re.search(r'src\.research\.(?:worker|kda_quality_study|warmup_quality_study|embedding_scale_study)|src\.train\.train|python.*-m pytest',line)]
if live:raise ValueError('Competing model work: '+str(live))
if args.output.exists() or not args.output.resolve().is_relative_to(base/'research_state'):
 raise ValueError('New review output inside research_state required')
import torch
from omegaconf import OmegaConf
from src.research import embedding_scale_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint,load_model_weights

p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
attention='mha';lr=.01;short_warmup={0:0,100:2,300:4}[p['recipe']['warmup_steps']]
cpu_path=args.cpu_review;cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
tests=cpu['full_tests'];assert cpu['status']=='cpu_verified' and tests['passed']==tests['collected']>=2056 and tests['failed']==0
assert cpu['actual_embedding_training_tests_passed']==6 and cpu['actual_embedding_geometry_tests_passed']==6 and cpu['embedding_metadata_tests_passed']==153
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==6
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
intent=json.loads((args.pilots/'intent.json').read_text())
assert intent['source_commit']==p['git_commit'] and intent['source_sha256']==p['source_sha256']
assert intent['cpu_review_sha256']==file_digest(cpu_path) and intent['pilot_driver_sha256']==file_digest(folder/'pilot-driver.py')
assert intent['predecessor_review']==p['predecessor_review'] and intent['resolved_recipe']==p['recipe']
assert intent['seed']==9377 and intent['holdout_consumed'] is False
assert intent['hard_limits']==dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024)
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
artifacts=[cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver.py',folder/'resource-gate.py',folder/'test_resource_gate.py',source/'research/EMBEDDING_SCALE_PROTOCOL.md',Path(p['predecessor_review']['path']),folder/'pilot-geometry.py',Path(__file__).resolve()]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
# Preserve earlier failed MPS agreement evidence; only unchanged general averaging
# arithmetic is inherited, not a claim about independent trajectory reproducibility.
for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 current=(source/rel).read_bytes()
 if rel=='src/utils/checkpoint.py':
  guard=b'    from ..models.embedding_scale import validate_input_scale_load\n    validate_input_scale_load(model, checkpoint)\n'
  assert current.count(guard)==1
  current=current.replace(guard,b'',1)
 assert current==subprocess.check_output(['git','show','280ea428792d4dd31780123d14846d5302d43227:'+rel],cwd=source)
for rel in ['averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-mps-coupled-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
artifacts.append(source/'src/models/embedding_scale.py')
checks=[];torch.set_num_threads(1)
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=40,20
 job=dict(family=f,lr=lr,width=w,n_heads=w//32,seed=9377,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,lr),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 if short_warmup:t['lr_schedule']['warmup_steps']=short_warmup
 assert row['attention_family']==attention and row['peak_learning_rate']==lr and row['warmup_steps']==t['lr_schedule'].get('warmup_steps',0)
 assert row['input_embedding_scale']==study.SCALES[f] and row['input_width_policy']=='mha4_input_scale'
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 assert raw['runtime']==dict(torch=p['runtime']['packages']['torch'],cpu_threads=req['cpu_threads'],requested_device='mps')
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total
 desired=json.loads(json.dumps(req['config']));desired['model']['vocab_size']=65;assert cp['cfg']==desired
 expected_contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
     optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=desired['model'],
     data_sha256=file_digest(Path(desired['data']['path'])),data_split=dict(train_fraction=.8,val_fraction=.1),
     eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
     training={key:t[key] for key in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==expected_contract
 avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True);names=dict(model.named_parameters())
 # Independently enumerate all named parameter shapes, without deriving them
 # from the model implementation. Strict load separately checks saved buffers.
 import importlib.util
 geometry_spec=importlib.util.spec_from_file_location('embedding_independent_geometry',folder/'pilot-geometry.py')
 geometry=importlib.util.module_from_spec(geometry_spec);geometry_spec.loader.exec_module(geometry)
 shapes=geometry.parameter_shapes(w,attention)
 for i in range(4):
  pre=f'transformer.h.{i}.'
  assert cp['model_state'][pre+'freq_cos'].shape==(128,16)
  assert cp['model_state'][pre+'freq_sin'].shape==(128,16)
 assert cfg.model.input_embedding_scale==model.input_embedding_scale==study.SCALES[f]
 assert cfg.model.input_width_policy=='mha4_input_scale'
 cfg.model.input_embedding_scale=.5 if study.SCALES[f]==1. else 1.
 try: load_model_weights(model,cp)
 except ValueError: pass
 else: raise AssertionError('Wrong input-scale checkpoint accepted')
 cfg.model.input_embedding_scale=study.SCALES[f]
 assert set(shapes)==set(names)
 assert all(tuple(names[n].shape)==shape for n,shape in shapes.items())
 expected_count=sum(math.prod(shape) for shape in shapes.values())
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 assert model.position_encoding=='rope'
 assert cp['cfg']['model']['attn_type']==attention
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==p['recipe']['weight_decay']
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 for metric in raw['metrics']:
  step=metric['step'];warmup=row['warmup_steps']
  expected_ratio=(.1 if step==39 else .1+.9*step/(warmup-1) if warmup and step<warmup-1
                  else 1. if step<=20 else 1-.9*(step-20)/19)
  assert math.isclose(metric['lr_multiplier'],expected_ratio,rel_tol=0,abs_tol=1e-15)
  assert metric['base_learning_rate']==lr
  assert math.isclose(metric['scheduled_learning_rate'],lr*expected_ratio,rel_tol=0,abs_tol=1e-15)
 seen=set()
 assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   name,=g['parameter_names'];assert name not in seen;seen.add(name)
   matrix=name.startswith('transformer.h.') and names[name].ndim==2;scale=1/math.sqrt(w/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==lr*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'}
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==names[name].shape
 assert seen==set(names)
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved)
 for name,value in saved['model_state'].items():assert torch.equal(value,avg['averages']['200'][name] if name in names else cp['model_state'][name])
 gen=torch.Generator().manual_seed(9377);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
 valgen=torch.Generator().manual_seed(2026);val_length=int(.9*n)-int(.8*n)
 for _ in range(t['eval_iters']):torch.randint(val_length-128,(8,),generator=valgen)
 assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 cache_path=d/'cache-check.pt';assert file_digest(cache_path)==row['cached_evidence_sha256'];artifacts.append(cache_path)
 cache=torch.load(cache_path,map_location='cpu',weights_only=True);finite(cache)
 assert cache['derived_checkpoint_sha256']==item['checkpoint_sha256'] and cache['atol']==1e-4 and cache['rtol']==2e-5
 assert cache['full_logits'].shape==cache['cached_logits'].shape==(2,11,65)
 assert torch.equal(cache['tokens'],torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9377)))
 torch.testing.assert_close(cache['full_logits'],cache['cached_logits'],atol=1e-4,rtol=2e-5)
 assert math.isclose((cache['full_logits']-cache['cached_logits']).abs().max().item(),row['cached_full_max_abs_error'],abs_tol=0,rel_tol=0)
 expected_cache_bytes=4*2*2*128*w*4
 assert row['actual_cache_bytes']==expected_cache_bytes and row['cache_batch_size']==2
 assert 0<row['training_seconds']<=row['wall_seconds']<240 and row['sampled_peak_rss_mb']<4096 and row['current_driver_mb']<6144
 assert row['driver_allocation_is_not_peak'] is True
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.extend([d/'review.json',Path(checked['checkpoint']),Path(item['checkpoint'])]);checks.append(row)
# Independently reconstruct the worst-case42-run bound, then compare the separately
# synthetic-tested resource function; never treat these forecasts as measurements.
seconds=0.;storage=0.;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=(12 if f=='baseline' else 9) if w==64 else (6 if f=='baseline' else 3)
 estimate=1.5*(row['training_seconds']*75+row['wall_seconds']-row['training_seconds'])
 size=(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)*1.5
 seconds+=count*estimate;storage+=count*size
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate,artifact_mb_per_trajectory_with_margin=size/1024**2,within_trial_limit=estimate<2400))
assert sum(x['trajectories'] for x in proxies)==42
import importlib.util
spec=importlib.util.spec_from_file_location('embedding_resource_gate',folder/'resource-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
resource=gate.forecast(checks)
assert resource['trial_proxies']==proxies and resource['hours']==seconds/3600 and resource['total_mb_with_margin']==storage/1024**2
if resource['status']!='feasible':
 rejection=args.output.with_name(args.output.stem+'-resource-infeasible.json');assert not rejection.exists()
 rejection.write_text(json.dumps(dict(status='infeasible_no_launch',source_commit=p['git_commit'],source_sha256=p['source_sha256'],resource_proxy=resource,pilot_path=str(pilot_path),pilot_sha256=file_digest(pilot_path),action='Preserve all pilots; no automatic retry or cap extension; review another algorithm or a distinct implementation change.'),indent=2)+'\n')
 raise ValueError('Embedding-scale resource forecast exceeds frozen limits; no research launch')
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=list((base/'research_runs').glob('*/plan.json'))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=resource,
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Full collected CPU suite,153 input-scale metadata cases andtwelve actual MHA width64/256 geometry/training/resume cases passed',
 'Six serial MPS baseline/half/quarter width64/25640-update jobs; twelve full validation panels, strict finite CPU loads and exact raw/H200 derivation',
 'Every MHA/FFN/head/norm parameter shape independently enumerated; all optimizer roles, states and width factors verified',
 'Saved cached/full logits and cache-byte algebra checked; no latency or peak-memory claim',
 'Exact private train and reset-validation RNG, untouched test RNG; warmup/cooldown and H200 counters; no historical training/evaluation rerun',
 'Final reviewed warmup decision resolves common schedule; upper-grid LR .01 pilots and prospective36/42-trajectory protocol, fresh seeds and exact prospective reference aliases'],
 limitations=['Short synthetic pilots excluded from quality findings','Resource forecasts are estimates; watchdog and hard caps stillapply','Current driver allocation is not peak memory','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness relies on separately tested frozen implementation','No optimalLR/muP transfer, seed-population inference or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=args.output;assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
