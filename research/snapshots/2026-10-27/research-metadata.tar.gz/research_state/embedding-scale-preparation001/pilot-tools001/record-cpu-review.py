"""Bind every executed CPU case and unchanged source before input-scale MPS pilots."""
import argparse
import datetime
import json
from pathlib import Path
import re


def verify_partition_logs(collection, runs):
    names={line.strip() for line in collection.splitlines() if line.startswith('tests/') and '::' in line}
    collected=re.search(r'(\d+) tests collected',collection)
    if not collected or int(collected[1])!=len(names):
        raise ValueError('Collection count or complete case identifiers missing')
    if set(runs)!={'actual','remaining'}:
        raise ValueError('Both actual and remaining partitions are required')
    actual={n for n in names if n.startswith(('tests/test_embedding_scale_training.py::','tests/test_embedding_scale_geometry.py::'))}
    if any(sum(n.startswith('tests/'+f+'::') for n in actual)!=6 for f in ('test_embedding_scale_training.py','test_embedding_scale_geometry.py')):
        raise ValueError('Six geometry and six trainer cases required separately')
    if len(actual)!=12: raise ValueError('Exactly twelve actual embedding-scale geometry/trainer cases required')
    partitions={}; seconds=0.; warnings=0
    for label,(exit_code,text) in runs.items():
        if exit_code!=0: raise ValueError('A CPU partition did not exit successfully')
        # Match execution statuses, not words inside negative-test fixture IDs.
        statuses=re.findall(r'^(tests/.+?)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)\b',text,re.M)
        executed=[name for name,status in statuses if status=='PASSED']
        if (any(status!='PASSED' for _,status in statuses)
                or len(executed)!=len(set(executed))
                or re.search(r'\b\d+ (?:failed|errors?|skipped|xfailed|xpassed)\b',text)):
            raise ValueError('Failed, skipped, duplicate or unexpected CPU execution')
        summary=re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s',text)
        selected=actual if label=='actual' else names-actual
        if not summary or int(summary[1])!=len(selected) or set(executed)!=selected:
            raise ValueError('Executed case IDs do not cover the full selected partition')
        partitions[label]=selected;seconds+=float(summary[3]);warnings+=int(summary[2] or 0)
    if partitions['actual'] & partitions['remaining'] or partitions['actual'] | partitions['remaining']!=names:
        raise ValueError('CPU partitions do not exactly cover collection')
    expected_metadata={'test_embedding_scale_contract.py':47,'test_embedding_scale_study.py':55,
        'test_embedding_scale_predecessor.py':15,'test_embedding_scale_report_audit.py':36}
    counts={f:sum(n.startswith('tests/'+f+'::') for n in names) for f in expected_metadata}
    if counts!=expected_metadata or len(names)<2056:
        raise ValueError('Complete project and153 input-scale metadata cases required')
    return dict(passed=len(names),collected=len(names),failed=0,warnings=warnings,
        actual_tests=12,remaining_tests=len(names)-12,total_seconds=seconds,
        partition='Twelve actual input-scale geometry/trainer/resume cases plus every other collected project case; exact case-ID coverage, no duplicates')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--folder',type=Path,required=True)
    args=parser.parse_args();folder=args.folder.resolve();source=Path.cwd()
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest
    manifest=json.loads((folder/'cpu-execution-manifest.json').read_text())
    if manifest['source_sha256']!=source_digest(source): raise ValueError('CPU source changed')
    collection_path=folder/'full-collection.log'
    artifacts=[folder/'cpu-execution-manifest.json',folder/'integration-review.json',collection_path,Path(__file__)]
    runs={}
    for label,record in manifest['partitions'].items():
        path=Path(record['log']);artifacts.append(path)
        runs[label]=(record['exit_code'],path.read_text())
    tests=verify_partition_logs(collection_path.read_text(),runs)
    integration=json.loads((folder/'integration-review.json').read_text())
    for item in integration['files']:
        path=source/item['path']
        if file_digest(path)!=item['prototype_sha256']: raise ValueError('Integrated test or source artifact changed')
        artifacts.append(path)
    review=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_sha256=source_digest(source),actual_embedding_training_tests_passed=6,actual_embedding_geometry_tests_passed=6,
        embedding_metadata_tests_passed=153,full_tests=tests,
        checks=['Every collected project case passed on matching source',
            'Twelve actual MHA width64/256 input-scale1/.5/.25 CPU geometry/trainer cases: same initial weights/RNG, exact hook reference/gradients, causal cached logits, exact resume and finite optimizer states/width factors',
            'Private paired sampler/test RNG, raw/H200 noninterference and strict derived weights; changed input-scale contracts cannot resume',
            'Explicit input scaling/legacy behavior, complete worker metrics, frozen controller/predecessor and independent report/bootstrap checks'],
        limitations=['CPU correctness is not a model quality or MPS measurement',
            'Serial MPS correctness pilots and independent resource/checkpoint prerequisites remain required'],
        artifacts=[dict(path=str(p.resolve()),sha256=file_digest(p)) for p in dict.fromkeys(artifacts)])
    output=folder/'cpu-review.json'
    if output.exists(): raise ValueError('Preserve the existing CPU review; use a new named repair if required')
    output.write_text(json.dumps(review,indent=2)+'\n')
    print(json.dumps(tests))


if __name__=='__main__': main()
