"""Synthetic log parser tests; these logs are never accepted as actual CPU evidence."""
import importlib.util
from pathlib import Path
import pytest

path=Path(__file__).with_name('record-cpu-review.py')
spec=importlib.util.spec_from_file_location('embedding_cpu_recorder',path)
rec=importlib.util.module_from_spec(spec);spec.loader.exec_module(rec)


def fixture():
    actual=[f'tests/{f}::test_actual[{i}]' for f in ('test_embedding_scale_training.py','test_embedding_scale_geometry.py') for i in range(6)]
    counts={'test_embedding_scale_contract.py':47,'test_embedding_scale_study.py':55,
        'test_embedding_scale_predecessor.py':15,'test_embedding_scale_report_audit.py':36}
    meta=[f'tests/{file}::test_scalar[{i}]' for file,count in counts.items() for i in range(count)]
    other=[f'tests/test_existing.py::test_other[{i}]' for i in range(1891)]
    other[0]='tests/test_existing.py::test_negative_fixture[failed]'
    names=actual+meta+other
    collection='\n'.join(names)+'\n2056 tests collected in 1.0s\n'
    def log(items): return '\n'.join(n+' PASSED [100%]' for n in items)+f'\n{len(items)} passed in 2.0s\n'
    return collection,{'actual':(0,log(actual)),'remaining':(0,log(meta+other))}


def test_full_named_coverage_accepts_failed_word_inside_passing_fixture():
    collection,runs=fixture();result=rec.verify_partition_logs(collection,runs)
    assert result['passed']==result['collected']==2056
    assert result['actual_tests']==12 and result['remaining_tests']==2044


@pytest.mark.parametrize('damage',['exit','missing_partition','skip','fail','error','duplicate',
    'missing_case','wrong_case','summary','collection_count','actual_count','quiet_log','metadata_file'])
def test_incomplete_or_inconsistent_execution_rejected(damage):
    collection,runs=fixture();code,text=runs['remaining']
    if damage=='exit': code=1
    elif damage=='missing_partition': del runs['actual']
    elif damage=='skip': text=text.replace(' PASSED',' SKIPPED',1)
    elif damage=='fail': text=text.replace(' PASSED',' FAILED',1)
    elif damage=='error': text+='\n1 error in 2.0s\n'
    elif damage=='duplicate': text=text.splitlines()[0]+'\n'+text
    elif damage=='missing_case': text='\n'.join(text.splitlines()[1:])
    elif damage=='wrong_case': text=text.replace('test_scalar[0]','test_scalar[9999]',1)
    elif damage=='summary': text=text.replace('2044 passed','2043 passed')
    elif damage=='collection_count': collection=collection.replace('2056 tests collected','2055 tests collected')
    elif damage=='actual_count': collection=collection.replace('tests/test_embedding_scale_training.py::test_actual[0]','tests/test_existing.py::moved_case')
    elif damage=='quiet_log': text='2044 passed in 2.0s\n'
    elif damage=='metadata_file':
        collection=collection.replace('test_embedding_scale_predecessor.py','test_wrong_module.py')
        text=text.replace('test_embedding_scale_predecessor.py','test_wrong_module.py')
    runs['remaining']=(code,text)
    with pytest.raises(ValueError): rec.verify_partition_logs(collection,runs)


def test_missing_geometry_cannot_be_replaced_with_extra_training():
    collection,runs=fixture()
    collection=collection.replace('test_embedding_scale_geometry.py','test_embedding_scale_training_extra.py')
    code,text=runs['actual']
    runs['actual']=(code,text.replace('test_embedding_scale_geometry.py','test_embedding_scale_training_extra.py'))
    with pytest.raises(ValueError): rec.verify_partition_logs(collection,runs)
