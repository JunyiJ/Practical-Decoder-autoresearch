"""Prospective 42-trajectory worst-case forecast from six real correctness pilots.

This is a resource proxy with fixed margin, never a quality or timing finding.
"""
import math


def forecast(rows):
    expected={(w,f) for w in (64,256) for f in ('baseline','half','quarter')}
    if (not isinstance(rows,list) or len(rows)!=6 or
            {(r.get('width'),r.get('family')) for r in rows}!=expected):
        raise ValueError('Exactly six distinct width/input-scale pilot cells required')
    attention={r.get('attention_family') for r in rows}
    rates={r.get('peak_learning_rate') for r in rows}
    if attention!={'mha'} or rates!={.01}:
        raise ValueError('All pilot cells must use the reviewed MHA backbone and upper-grid peak LR .01')
    warmups={r.get('warmup_steps') for r in rows}
    if len(warmups)!=1 or not warmups<={0,2,4}:
        raise ValueError('All pilot cells require the same shortened reviewed warmup')
    proxies=[];seconds=0.;storage=0.
    for row in rows:
        if (row.get('status')!='verified' or row.get('steps')!=40
                or row.get('cooldown_start')!=20 or row.get('snapshots')!=3
                or row.get('input_embedding_scale')!={'baseline':1.,'half':.5,'quarter':.25}[row['family']]
                or row.get('input_width_policy')!='mha4_input_scale'):
            raise ValueError('Pilot budget, warmup, cooldown or H200 contract changed')
        for key in ('training_seconds','wall_seconds','raw_checkpoint_bytes','derived_checkpoint_bytes',
                    'sampled_peak_rss_mb','current_driver_mb'):
            value=row.get(key)
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
                raise ValueError('Pilot resource measurements must be finite positive numbers')
        if (row['training_seconds']>row['wall_seconds'] or row['wall_seconds']>=240
                or row['sampled_peak_rss_mb']>=4096 or row['current_driver_mb']>=6144
                or row.get('driver_allocation_is_not_peak') is not True):
            raise ValueError('Pilot resource limit or memory interpretation failed')
        count=(12 if row['family']=='baseline' else 9) if row['width']==64 else (6 if row['family']=='baseline' else 3)
        time=1.5*(row['training_seconds']*75+row['wall_seconds']-row['training_seconds'])
        size=1.5*(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)
        proxies.append(dict(width=row['width'],family=row['family'],trajectories=count,
            seconds_per_trajectory_with_margin=time,artifact_mb_per_trajectory_with_margin=size/1024**2,
            within_trial_limit=time<2400))
        seconds+=count*time;storage+=count*size
    feasible=seconds<21600 and storage/1024**2<4096 and all(p['within_trial_limit'] for p in proxies)
    return dict(status='feasible' if feasible else 'infeasible',physical_trajectories=42,
        hours=seconds/3600,total_mb_with_margin=storage/1024**2,trial_proxies=proxies,
        method='40-update training time scaled75x plus measured two-output/check overhead;50% time and artifact margins;25MiB metadata allowance per trajectory.',
        measured_research_duration=False)
