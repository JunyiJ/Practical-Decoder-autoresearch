"""Independent named parameter geometry for the prospective input-scale pilot audit."""


def parameter_shapes(width, attention):
    if type(width) is not int or width not in (64,256) or attention != 'mha':
        raise ValueError('Only the frozen width64/256 MHA pilot geometry is supported')
    w=width
    shapes={'transformer.wte.weight':(65,w),'lm_head.weight':(65,w),
            'transformer.ln_f.weight':(w,),'transformer.ln_f.bias':(w,)}
    for i in range(4):
        pre=f'transformer.h.{i}.'
        local={'ln1.weight':(w,),'ln2.weight':(w,),
            'mlp.linear_gate.weight':(21*w//8,w),'mlp.linear_up.weight':(21*w//8,w),
            'mlp.linear_down.weight':(w,21*w//8)}
        local.update({'attn.qkv.weight':(3*w,w),'attn.qkv.bias':(3*w,),
                      'attn.out.weight':(w,w),'attn.out.bias':(w,)})
        shapes.update({pre+key:value for key,value in local.items()})
    return shapes
