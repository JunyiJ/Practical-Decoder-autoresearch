"""Integer geometry checks; no model construction or tensors."""
import importlib.util
import math
from pathlib import Path
import pytest

spec=importlib.util.spec_from_file_location('pilot_geometry',Path(__file__).with_name('pilot-geometry.py'))
geometry=importlib.util.module_from_spec(spec);spec.loader.exec_module(geometry)


@pytest.mark.parametrize('width,attention,count',[(64,'mha',204544),(256,'mha',3152896)])
def test_exact_named_parameter_counts(width,attention,count):
    shapes=geometry.parameter_shapes(width,attention)
    assert sum(math.prod(shape) for shape in shapes.values())==count
    assert set(n.split('.')[2] for n in shapes if n.startswith('transformer.h.'))=={'0','1','2','3'}
    assert not any('hidden_norm' in n or 'wpe' in n for n in shapes)


@pytest.mark.parametrize('width,attention',[(True,'mha'),(64.,'mha'),(128,'mha'),(64,'gqa'),(256,'moe'),(64,'kda')])
def test_unsupported_geometry_rejected(width,attention):
    with pytest.raises(ValueError): geometry.parameter_shapes(width,attention)
