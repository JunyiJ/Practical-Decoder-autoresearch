from pathlib import Path
import json,os,signal,subprocess,sys,time,datetime
BASE=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');ROOT=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');FOLDER=BASE/'research_state/embedding-scale-preparation001'
assert Path.cwd()==ROOT
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((BASE/'research_state/active-campaign.json').read_text());assert active['kind']=='warmup_quality' and active['status']=='completed_reviewed'
import re
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
live=[line for line in processes if re.search(r'src\.research\.(?:worker|[a-z_]+study)|src\.train\.train|python.*-m pytest',line)]
if live: raise ValueError('Competing model work: '+str(live))
from src.research.team.suite import source_digest
source=source_digest(ROOT);assert source==json.loads((FOLDER/'integration-review.json').read_text())['source_sha256']
manifest=FOLDER/'cpu-execution-manifest.json';assert not manifest.exists()
record=dict(source_sha256=source,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),status='running',partitions={})
def save():manifest.write_text(json.dumps(record,indent=2)+'\n')
save()
env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONUNBUFFERED='1',PYTHONPATH='.')
wrapper='import torch; torch.set_num_threads(1); import pytest,sys; sys.exit(pytest.main(sys.argv[1:]))'
jobs=[('collection',['tests','--collect-only','-q','--color=no','-p','no:cacheprovider'],120,'full-collection.log'),('actual',['tests/test_embedding_scale_training.py','tests/test_embedding_scale_geometry.py','-vv','--color=no','-p','no:cacheprovider','-x'],900,'actual-cpu-first.log'),('remaining',['tests','--ignore=tests/test_embedding_scale_training.py','--ignore=tests/test_embedding_scale_geometry.py','-vv','--color=no','-p','no:cacheprovider','-x'],3600,'remaining-cpu-first.log')]
for label,args,limit,name in jobs:
 assert source_digest(ROOT)==source
 log=FOLDER/name;assert not log.exists();started=time.monotonic()
 with log.open('x') as out:
  child=subprocess.Popen([sys.executable,'-u','-c',wrapper,*args],cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  record['active_partition']=label;record['active_pid']=child.pid;save();print('Started',label,'PID',child.pid,'log',log,flush=True)
  try:code=child.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   code=124
 item=dict(log=str(log),exit_code=code,seconds=time.monotonic()-started)
 if label=='collection':record['collection']=item
 else:record['partitions'][label]=item
 record['active_pid']=None;save();print('Finished',label,'exit',code,flush=True)
 if code:
  record['status']='failed';save();raise SystemExit(code)
record.update(status='completed',active_partition=None,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
print('CPU validation partitions completed; independent log review still required',flush=True)
