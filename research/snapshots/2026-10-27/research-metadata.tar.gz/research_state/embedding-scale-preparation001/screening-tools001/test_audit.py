"""Pure metadata checks only; immutable real files are never modified."""
from pathlib import Path
import copy,importlib.util,json,sys,unittest
folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('screen_audit',folder/'audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=base/'research_runs/embedding-scale-quality-001'
p=json.loads((run/'plan.json').read_text());state=json.loads((run/'state.json').read_text());real=next(r for r in state['records'] if r['status']=='completed')
def panel(best,alias):
    selected=dict(baseline=.005 if alias else .01,half=.01,quarter=.005)
    levels=dict(baseline=1.3,half=1.4,quarter=1.4);levels[best]=1.2
    rows=[]
    for f,lr,w,s in p['screen_jobs']:
        value=levels[f] if lr==selected[f] else 1.6
        rows.append(dict(family=f,lr=lr,width=w,seed=s,stage='local',status='completed',averaged_outputs={'200':{'coverage':{'evaluations':{'128':{'mean_ce':value}}}}}))
    return rows,selected
class TestMetadata(unittest.TestCase):
    def test_real_completed_worker_schema(self):a.check_row(p,real,run)
    def test_real_wrong_family_rejected(self):
        r=copy.deepcopy(real);r['family']='half'
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_real_wrong_learning_rate_rejected(self):
        r=copy.deepcopy(real);r['lr']=.01
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_real_wrong_seed_rejected(self):
        r=copy.deepcopy(real);r['seed']=2302
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_real_wrong_endpoint_rejected(self):
        r=copy.deepcopy(real);r['metric']+=.01
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_real_wrong_checkpoint_hash_rejected(self):
        r=copy.deepcopy(real);r['checkpoint_sha256']='0'*64
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_real_wrong_steps_rejected(self):
        r=copy.deepcopy(real);r['tokens_processed']=1
        with self.assertRaises(AssertionError):a.check_row(p,r,run)
    def test_all_winner_alias_routes(self):
        for best in a.FAMILIES:
            for alias in (False,True):
                with self.subTest(best=best,alias=alias):
                    rows,selected=panel(best,alias);v=a.reconstruct(p,rows)
                    self.assertEqual({f:c['lr'] for f,c in v['choices'].items()},selected)
                    self.assertEqual(v['best_selected_arm'],best)
                    self.assertEqual(v['candidate_eligible'],not(best=='baseline' and alias))
                    self.assertEqual(v['winner'],'incumbent_unchanged' if best=='baseline' and alias else best)
                    c=v['confirmation'];self.assertEqual(c['reference_aliases'],{a.REFERENCE:'baseline'} if alias else {})
                    self.assertEqual(c['total_distinct_trials'],36 if alias else 42)
                    self.assertEqual(c['total_model_evaluations'],72 if alias else 84)
                    self.assertEqual({x[3] for x in c['jobs']},{2311,2312,2313})
                    self.assertEqual({x[2] for x in c['jobs']},{64,256})
    def test_ties_choose_lower_lr_then_baseline(self):
        rows,_=panel('half',True)
        for r in rows:r['averaged_outputs']['200']['coverage']['evaluations']['128']['mean_ce']=1.3
        v=a.reconstruct(p,rows);self.assertEqual(v['best_selected_arm'],'baseline');self.assertEqual(v['winner'],'incumbent_unchanged')
        self.assertTrue(all(x['lr']==.0025 for x in v['choices'].values()))
    def test_one_bad_seed_blocks_good_mean(self):
        rows,_=panel('half',True)
        for r in rows:
            if r['family']=='half' and r['lr']==.01:r['averaged_outputs']['200']['coverage']['evaluations']['128']['mean_ce']=1.28 if r['seed']==2301 else 1.305
        v=a.reconstruct(p,rows);self.assertEqual(v['best_selected_arm'],'half');self.assertFalse(v['candidate_eligible']);self.assertEqual(v['winner'],'incumbent_unchanged')
    def test_missing_screen_rejected(self):
        rows,_=panel('half',True)
        with self.assertRaises(AssertionError):a.reconstruct(p,rows[:-1])
    def test_duplicate_screen_rejected(self):
        rows,_=panel('half',True);rows[-1]=copy.deepcopy(rows[0])
        with self.assertRaises(AssertionError):a.reconstruct(p,rows)
    def test_changed_screen_seed_rejected(self):
        rows,_=panel('half',True);rows[0]['seed']=2311
        with self.assertRaises(AssertionError):a.reconstruct(p,rows)
    def test_changed_scale_contract_rejected(self):
        rows,_=panel('half',True);bad=copy.deepcopy(p);bad['input_scales']['quarter']=.5
        with self.assertRaises(AssertionError):a.reconstruct(bad,rows)
    def test_changed_screen_order_rejected(self):
        rows,_=panel('half',True);rows[0],rows[1]=rows[1],rows[0]
        with self.assertRaises(AssertionError):a.reconstruct(p,rows)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TestMetadata))
    assert 'torch' not in sys.modules
    print('No torch import, model execution, tensor load, scoring, or evidence mutation.')
    raise SystemExit(not result.wasSuccessful())
