"""Synthetic recorder decisions only; no result recording or model execution."""
import copy
import importlib.util
from pathlib import Path
import pytest
from tests.test_embedding_scale_report_audit import nonuniform
spec=importlib.util.spec_from_file_location('embedding_recorder',Path(__file__).with_name('record-completion.py'))
rec=importlib.util.module_from_spec(spec);spec.loader.exec_module(rec)

@pytest.mark.parametrize('warmup',[0,100,300])
@pytest.mark.parametrize('alias',[False,True])
@pytest.mark.parametrize('winner',['baseline','half','quarter'])
def test_synthetic_recipe_decision_routes(warmup,alias,winner):
    p,state,r=nonuniform(warmup,winner,alias)
    result=rec.verified_decision(r)
    assert result==(r['selection']['winner'],r['quality_decision']['qualifies_for_incumbent_replacement'])

@pytest.mark.parametrize('damage',['choice','grid','best','local_delta','local_seed','local_reference',
    'eligible','winner','confirmation_seed','upper','mean','missing','duplicate','adopt'])
def test_inconsistent_adoption_rejected(damage):
    p,state,r=nonuniform(100,'quarter',False);r=copy.deepcopy(r);s=r['selection']
    assert s['candidate_eligible']
    c=next(c for c in r['comparisons'] if c['candidate']=='quarter' and c['reference']=='baseline' and c['width']==256)
    if damage=='choice':s['choices']['quarter']['lr']=.0125
    elif damage=='grid':s['choices']['quarter']['grid'].pop()
    elif damage=='best':s['best_selected_arm']='half'
    elif damage=='local_delta':s['local_contrasts'][0]['mean_delta']+=.1
    elif damage=='local_seed':s['local_contrasts'][0]['paired_seed_deltas']['999']=0.
    elif damage=='local_reference':s['local_contrasts'].pop()
    elif damage=='eligible':s['candidate_eligible']=False
    elif damage=='winner':s['winner']='half'
    elif damage=='confirmation_seed':c['sensitivity'][0]['paired_seed_deltas']['999']=0.
    elif damage=='upper':c['sensitivity'][2]['conditional_text_bootstrap_95pct'][1]=.1
    elif damage=='mean':c['sensitivity'][1]['mean_delta']+=.1
    elif damage=='missing':r['comparisons'].remove(c)
    elif damage=='duplicate':r['comparisons'].append(copy.deepcopy(c))
    elif damage=='adopt':r['quality_decision']['qualifies_for_incumbent_replacement']=not r['quality_decision']['qualifies_for_incumbent_replacement']
    with pytest.raises(AssertionError):rec.verified_decision(r)
