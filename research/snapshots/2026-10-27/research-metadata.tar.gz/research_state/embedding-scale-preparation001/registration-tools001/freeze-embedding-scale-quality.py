"""Register exactly one new input-scale round after actual source/test/pilot gates."""
import argparse,datetime,json,os,re,subprocess
from pathlib import Path

parser=argparse.ArgumentParser();parser.add_argument('--register',action='store_true');args=parser.parse_args()
if not args.register:parser.error('Explicit --register required')

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
run=base/'research_runs/embedding-scale-quality-001';folder=Path(__file__).resolve().parent;prep=folder.parent;prior=base/'research_runs/warmup-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text())
if active['campaign']!=str(prior) or active['status']!='completed_reviewed' or active.get('human_stopped'):
 raise ValueError('Final reviewed warmup completion required before input-scale registration')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
lines=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in lines if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|decay_quality_study|kda_quality_study|warmup_quality_study|embedding_scale_study|context_interaction|context256_study|batch_study)|src\.train\.train|pytest\.main|run-cpu-validation|pilot-driver|python.*-m pytest',x)]
from src.research import embedding_scale_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
remote_main = subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]
# A later human merge must not silently enter an already tested study.
subprocess.check_call(['git','merge-base','--is-ancestor',p['git_commit'],remote_main])
p['publication_lineage'] = dict(tested_commit=p['git_commit'], observed_remote_main=remote_main,
    tested_commit_is_remote_ancestor=True, later_remote_changes_excluded=True)
review=prep/'review.json';v=json.loads(review.read_text());tests=v['tests']['full_tests']
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit']
assert v['recipe']==p['recipe'] and v['returned_half_life']==200 and v['predecessor_review']==p['predecessor_review']
assert tests['passed']==tests['collected']>=2056 and tests['failed']==0 and v['tests']['actual_embedding_training_tests_passed']==6 and v['tests']['actual_embedding_geometry_tests_passed']==6 and v['tests']['embedding_metadata_tests_passed']==153
assert len(v['pilot_audit'])==6 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['status']=='feasible' and v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (base/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/EMBEDDING_SCALE_PROTOCOL.md';con=json.loads((base/'research_state/warmup-quality-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
incumbent_path=base/'research_state/embedding-scale-quality-incumbent.json';assert not incumbent_path.exists()
snapshot=base/'research_state/embedding-scale-quality-knowledge-snapshot.md'
assert not snapshot.exists() and not (base/'research_state/embedding-scale-quality-plan.json').exists()
artifacts=[incumbent_path,protocol,review,prep/'pilot-tools001/review-prerequisites.py',folder/'freeze-embedding-scale-quality.py',folder/'launch-embedding-scale-quality.py',prep/'pilot-tools001/completion-audit.py',prep/'completion-tools001/record-completion.py',prep/'completion-tools001/test_completion_recorder.py',prep/'completion-tools001/recorder-tests-first.log',prep/'pilot-tools-review001.json',prep/'completion-tools001/review.json',base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/warmup-quality-conclusion.json',base/'research_state/warmup-quality-completed-knowledge-snapshot.md']+[prior/f for f in ('plan.json','report.json','review.json','selection.json')]

# Verify every required artifact before creating an incumbent snapshot or bank entry.
for artifact in artifacts:
 if artifact!=incumbent_path:assert artifact.is_file(),str(artifact)
prior_review=json.loads((prior/'review.json').read_text())
assert con['quality_decision']==prior_review['quality_decision']
current_best=json.loads((base/'research_state/best-observed-config.json').read_text())
if con['quality_decision']['qualifies_for_incumbent_replacement']:
 assert current_best['result_id']==con['result_id']
else:
 prior_plan=json.loads((prior/'plan.json').read_text());frozen_prior=prior_plan['incumbent_snapshot']
 assert file_digest(Path(frozen_prior['path']))==frozen_prior['sha256']
 frozen_best=json.loads(Path(frozen_prior['path']).read_text())
 assert current_best['result_id']==frozen_best['result_id']==frozen_prior['result_id']
 for key in ('baseline_commit','baseline_config','config_overrides','returned_weights','selection'):
  assert current_best.get(key)==frozen_best.get(key),'Concurrent incumbent change: '+key
assert json.loads((base/'research_state/active-campaign.json').read_text())==active

incumbent_path.write_bytes((base/'research_state/best-observed-config.json').read_bytes());incumbent_path.chmod(0o444)
incumbent=json.loads(incumbent_path.read_text());p['incumbent_snapshot']=dict(path=str(incumbent_path),sha256=file_digest(incumbent_path),result_id=incumbent['result_id'])
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',
 title='Input embedding scale validated with exact geometry/trainer/resume and serial MPS gates',
 summary=f"All {tests['passed']} source-matched CPU tests, including twelve actual input-scale geometry/trainer/resume cases, and six shortened serial MPS pilots passed. Independent saved shape/optimizer/schedule/RNG/raw-H200/full-coverage/cache contracts and the worst-case42-trial resource forecast were reviewed. Correctness pilots are excluded from quality evidence.",
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,
 artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id']]))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',
 title='Preregistered input-scale quality001: three input multipliers, equal finite LR tuning',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='Reducing input embeddings before the first residual block may improve final quality by changing their relative contribution and gradients. No quantitative quality gain, causal mechanism or optimal width transfer is assumed; selected-recipe contrasts include LR tuning. Numeric quality/throughput/RSS forecasts are unspecified; the measured correctness-pilot resource proxy is separate from research findings.',
 selection='Eighteen width64 screens on2301/2302 choose one LR per scale, ties lower LR. Freeze family winner, ties baseline/half/quarter. Baseline LR-only candidate must improve fixed incumbent; changed-scale candidate must improve both fixed incumbent and tuned baseline. Require mean gain>.005/every seed, no alternative fallback. Freeze before18selected fresh2311/2312/2313 width64/256 cells plus0/6 fixed references; exact baseline .005 reference alias prospectively. Only frozen eligible winner may adopt with mean gain>.005/every seed/all text upper bounds<0 at both widths against required comparators.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='Final reviewed warmup decision supplies common MHA/warmup/cooldown/H200 and independent decay .00006. Same3000updates/3072000targets. Inputscales1/.5/.25 x peakLRs.0025/.005/.01;36/42physical72/84correlatedoutputs, exact prospective aliases only. No changed init/shape/group factors; unchanged optimizer betas/clipping. No completed-grid extension/largerwidth reselection/interpretation rerun.006permanentstop; primaryhuman checkout untouched.'),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in (protocol,review,prior/'review.json')],related_ids=[implementation,con['result_id']]))
assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)

p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary human checkout untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in (run/'plan.json',base/'research_state/embedding-scale-quality-plan.json'):path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],recipe=p['recipe'],maximum_physical_trajectories=42,maximum_correlated_model_outputs=84,returned_half_life=200,completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
