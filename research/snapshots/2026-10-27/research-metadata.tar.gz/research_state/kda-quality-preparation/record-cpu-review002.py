"""Verify partitioned executed CPU tests and bind source/evidence before MPS pilots."""
import datetime,json,re
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.suite import source_digest
source=Path.cwd(); folder=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/kda-quality-preparation')
manifest=json.loads((folder/'cpu-execution-manifest.json').read_text())
assert manifest['source_sha256']==source_digest(source)
files=[folder/'cpu-execution-manifest.json',folder/'integration-review.json',folder/'full-collection.log',Path(__file__)]
collection=(folder/'full-collection.log').read_text()
names={x.strip() for x in collection.splitlines() if x.startswith('tests/') and '::' in x}
count=int(re.search(r'(\d+) tests collected',collection)[1]);assert count==len(names)
partitions={};seconds=0.;warnings=0
for label,run in manifest['partitions'].items():
 path=Path(run['log']);text=path.read_text();files.append(path)
 assert run['exit_code']==0
 assert not re.search(r'\s(?:FAILED|ERROR|SKIPPED|XFAIL|XPASS)(?:\s|$)',text)
 assert not re.search(r'\b\d+ (?:failed|errors?|skipped|xfailed|xpassed)\b',text)
 m=re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s',text);assert m
 selected={n for n in names if any(n.startswith(f+'::') for f in run['files'])} if label=='actual' else {n for n in names if not any(n.startswith(f+'::') for f in manifest['partitions']['actual']['files'])}
 assert len(selected)==int(m[1]);partitions[label]=selected;seconds+=float(m[3]);warnings+=int(m[2] or 0)
 if label=='remaining':
  executed={line.split(' PASSED',1)[0].strip() for line in text.splitlines() if line.startswith('tests/') and ' PASSED' in line}
  assert executed==selected
assert not partitions['actual'] & partitions['remaining']
assert partitions['actual'] | partitions['remaining']==names
assert len(partitions['actual'])==58 and count>=1608
assert sum(n.startswith('tests/test_kda_training.py::') for n in partitions['actual'])==2
integration=json.loads((folder/'integration-review.json').read_text())
for f in integration['files']:
 path=source/f['path'];assert file_digest(path)==f['prototype_sha256'];files.append(path)
review=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=source_digest(source),actual_kda_training_tests_passed=2,human_kda_reference_tests_passed=True,kda_geometry_optimizer_gradient_tests_passed=True,
 full_tests=dict(passed=count,collected=count,failed=0,warnings=warnings,actual_tests=58,remaining_tests=len(partitions['remaining']),total_seconds=seconds,partition='58 human KDA/model/optimizer/gradient/actual trainer cases plus all remaining collected project tests; no duplicates'),
 checks=['Human KDA equations, causal/cache/default behavior and gradients','Explicit alpha-width geometry, parameter counts, optimizer roles and independent decay','Actual CPU training at widths64/256; strict finite saved states, exact resume, private RNG, raw/H200 noninterference and cached inference','Every collected project test passed on identical source'],
 limitations=['CPU correctness is not quality evidence or an MPS measurement','Serial MPS pilots and independent finite resource gates remain required'],artifacts=[dict(path=str(x.resolve()),sha256=file_digest(x)) for x in files])
out=folder/'cpu-review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['full_tests']))
