"""Audit saved KDA/MHA pilot evidence and forecast bounded resources; no training/scoring."""
import argparse,datetime,json,math,subprocess
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.research import kda_quality_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint,load_model_weights
from src.train.lr_schedule import multiplier

parser=argparse.ArgumentParser();parser.add_argument('--pilots',type=Path,required=True);args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=base/'research_state/kda-quality-preparation'
p=study.make_plan(source,base/'research_runs/decay-quality-001/review.json');assert p['returned_half_life']==200
cpu_path=folder/'cpu-review.json';cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
tests=cpu['full_tests'];assert cpu['status']=='cpu_verified' and tests['passed']==tests['collected']>=1608 and tests['failed']==0
assert cpu['actual_kda_training_tests_passed']==2 and cpu['human_kda_reference_tests_passed'] and cpu['kda_geometry_optimizer_gradient_tests_passed']
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==4
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
intent=json.loads((args.pilots/'intent.json').read_text())
assert intent['source_commit']==p['git_commit'] and intent['source_sha256']==p['source_sha256']
assert intent['cpu_review_sha256']==file_digest(cpu_path) and intent['pilot_driver_sha256']==file_digest(folder/'pilot-driver002.py')
assert intent['predecessor_review']==p['predecessor_review'] and intent['resolved_recipe']==p['recipe']
assert intent['seed']==9363 and intent['holdout_consumed'] is False
assert intent['hard_limits']==dict(jobs=4,job_seconds=240,round_seconds=1800,disk_mb=1024)
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
artifacts=[cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver002.py',folder/'resource-gate.py',folder/'test-resource-gate.py',source/'research/KDA_QUALITY_PROTOCOL.md',Path(p['predecessor_review']['path'])]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
# Preserve earlier failed MPS agreement evidence; only unchanged general averaging
# arithmetic is inherited, not a claim about independent trajectory reproducibility.
for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 assert (source/rel).read_bytes()==subprocess.check_output(['git','show','280ea428792d4dd31780123d14846d5302d43227:'+rel],cwd=source)
for rel in ['averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-mps-coupled-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
checks=[];torch.set_num_threads(1)
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=20,10
 job=dict(family=f,lr=.005,width=w,n_heads=w//32,seed=9363,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,.005),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total
 desired=json.loads(json.dumps(req['config']));desired['model']['vocab_size']=65;assert cp['cfg']==desired
 avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True);names=dict(model.named_parameters())
 # Independently enumerate all named parameter shapes, without deriving them
 # from the model implementation. Strict load separately checks saved buffers.
 shapes={'transformer.wte.weight':(65,w),'lm_head.weight':(65,w),
         'transformer.ln_f.weight':(w,),'transformer.ln_f.bias':(w,)}
 for i in range(4):
  pre=f'transformer.h.{i}.'
  common={'ln1.weight':(w,),'ln2.weight':(w,),
          'mlp.linear_gate.weight':(21*w//8,w),'mlp.linear_up.weight':(21*w//8,w),
          'mlp.linear_down.weight':(w,21*w//8)}
  if f=='mha':
   attention={'attn.qkv.weight':(3*w,w),'attn.qkv.bias':(3*w,),
              'attn.out.weight':(w,w),'attn.out.bias':(w,)}
   assert cp['model_state'][pre+'freq_cos'].shape==(128,16)
   assert cp['model_state'][pre+'freq_sin'].shape==(128,16)
  else:
   assert 'dim_alpha' not in cp['cfg']['model']
   assert cp['cfg']['model']['attention_width_policy']=='kda_head32_alpha_quarter'
   assert cp['cfg']['model']['depth_width_policy']=='depth4_kda_unscaled'
   assert model.transformer.h[i].attn.dim_alpha==w//4
   attention={'attn.qkv.weight':(3*w,w),'attn.qkv.bias':(3*w,),
              'attn.q_conv.weight':(w,1,4),'attn.k_conv.weight':(w,1,4),'attn.v_conv.weight':(w,1,4),
              'attn.beta_proj.weight':(w//32,w),'attn.beta_proj.bias':(w//32,),
              'attn.z1.weight':(w//4,w),'attn.z2.weight':(w,w//4),'attn.z2.bias':(w,),
              'attn.A':(w//32,),'attn.head_norm.weight':(32,),
              'attn.output_gate.weight':(w,w),'attn.out_proj.weight':(w,w)}
   assert pre+'freq_cos' not in cp['model_state'] and pre+'freq_sin' not in cp['model_state']
  shapes.update({pre+k:v for k,v in {**common,**attention}.items()})
 assert set(shapes)==set(names)
 assert all(tuple(names[n].shape)==shape for n,shape in shapes.items())
 expected_count=sum(math.prod(shape) for shape in shapes.values())
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 assert model.position_encoding==('rope' if f=='mha' else 'none')
 assert cp['cfg']['model']['attn_type']==f
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==p['recipe']['weight_decay']
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 for metric in raw['metrics']:assert metric['lr_multiplier']==multiplier(t['lr_schedule'],metric['step'])
 seen=set()
 assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   name,=g['parameter_names'];assert name not in seen;seen.add(name)
   matrix=name.startswith('transformer.h.') and names[name].ndim==2;scale=1/math.sqrt(w/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==.005*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'}
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==names[name].shape
 assert seen==set(names)
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved)
 for name,value in saved['model_state'].items():assert torch.equal(value,avg['averages']['200'][name] if name in names else cp['model_state'][name])
 gen=torch.Generator().manual_seed(9363);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 cache_path=d/'cache-check.pt';assert file_digest(cache_path)==row['cached_evidence_sha256'];artifacts.append(cache_path)
 cache=torch.load(cache_path,map_location='cpu',weights_only=True);finite(cache)
 assert cache['derived_checkpoint_sha256']==item['checkpoint_sha256'] and cache['atol']==1e-4 and cache['rtol']==2e-5
 assert cache['full_logits'].shape==cache['cached_logits'].shape==(2,11,65)
 assert torch.equal(cache['tokens'],torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9363)))
 torch.testing.assert_close(cache['full_logits'],cache['cached_logits'],atol=1e-4,rtol=2e-5)
 assert math.isclose((cache['full_logits']-cache['cached_logits']).abs().max().item(),row['cached_full_max_abs_error'],abs_tol=0,rel_tol=0)
 expected_cache_bytes=4*2*41*w*4 if f=='kda' else 4*2*2*128*w*4
 assert row['actual_cache_bytes']==expected_cache_bytes and row['cache_batch_size']==2
 assert 0<row['training_seconds']<=row['wall_seconds']<240 and row['sampled_peak_rss_mb']<4096 and row['current_driver_mb']<6144
 assert row['driver_allocation_is_not_peak'] is True
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.append(d/'review.json');checks.append(row)
# Independently reconstruct the maximum30-run bound, then compare the separately
# synthetic-tested resource function; never treat these forecasts as measurements.
seconds=0.;storage=0.;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=(12 if f=='mha' else 9) if w==64 else (6 if f=='mha' else 3)
 estimate=1.5*(row['training_seconds']*150+row['wall_seconds']-row['training_seconds'])
 size=(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)*1.5
 seconds+=count*estimate;storage+=count*size
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate,artifact_mb_per_trajectory_with_margin=size/1024**2,within_trial_limit=estimate<2400))
assert sum(x['trajectories'] for x in proxies)==30
import importlib.util
spec=importlib.util.spec_from_file_location('kda_resource_gate',folder/'resource-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
resource=gate.forecast(checks)
assert resource['trial_proxies']==proxies and resource['hours']==seconds/3600 and resource['total_mb_with_margin']==storage/1024**2
if resource['status']!='feasible':
 rejection=folder/'resource-infeasible.json';assert not rejection.exists()
 rejection.write_text(json.dumps(dict(status='infeasible_no_launch',source_commit=p['git_commit'],source_sha256=p['source_sha256'],resource_proxy=resource,pilot_path=str(pilot_path),pilot_sha256=file_digest(pilot_path),action='Preserve all pilots; no automatic retry or cap extension; review another algorithm or a distinct implementation change.'),indent=2)+'\n')
 raise ValueError('KDA resource forecast exceeds frozen limits; no research launch')
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=list((base/'research_runs').glob('*/plan.json'))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=resource,
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Full collected CPU suite, human reference and explicit width/optimizer/all-parameter-gradient gates, and two actual training/resume cases passed',
 'Four serial MPS MHA/KDA width64/25620-update jobs; eight full validation panels, strict finite CPU loads and exact raw/H200 derivation',
 'Every attention/FFN/head/alpha/convolution/gate/norm parameter shape independently enumerated; all optimizer roles, states and width factors verified',
 'Saved cached/full logits and cache-byte algebra checked; no latency or peak-memory claim',
 'Exact private paired-block sampler RNG and untouched test RNG; cooldown and H200 counters; no historical training/evaluation rerun',
 'Final reviewed decay resolves common LR/coefficient; prospective24/30-trajectory protocol, fresh seeds and exact aliases'],
 limitations=['Short synthetic pilots excluded from quality findings','Resource forecasts are estimates; watchdog and hard caps stillapply','Current driver allocation is not peak memory','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness relies on separately tested frozen implementation','No optimalLR/muP transfer, seed-population inference or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=folder/'review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
