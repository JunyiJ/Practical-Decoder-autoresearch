"""Deferred KDA evidence audit. No training or evaluation; --partial is not final."""
import argparse,copy,datetime,json,math,statistics
from pathlib import Path
import numpy as np
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.research import kda_quality_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result,disk_mb
from src.research.team.suite import _request
from src.train.weight_averaging import TailWeightAverages
from src.utils.checkpoint import read_checkpoint

parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);parser.add_argument('--partial',action='store_true');args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=args.run.resolve();folder=root/'research_state/kda-quality-preparation'
assert run.parent==root/'research_runs' and run.name.startswith('kda-quality-')
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());study.verify_lineage(p)
assert p==json.loads((root/'research_state/kda-quality-plan.json').read_text()) and digest(p)==s['plan_sha256']
assert not any(r['status']=='failed' for r in s['records'])
records=[r for r in s['records'] if r['status']=='completed'];jobs=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())==study.freeze_selection(p,records[:12])
 jobs+=s['selection']['confirmation']['jobs']
 if s['records'][12:]:
  assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'][12:])
assert [[r[k] for k in ('family','lr','width','seed')] for r in s['records']]==jobs[:len(s['records'])]
assert len({r['trial_id'] for r in s['records']})==len(s['records']) and disk_mb(run)<4096
if not args.partial:assert s['status']=='completed' and len(records)==s['selection']['confirmation']['total_distinct_trials'] and s['active_seconds']<21600

torch.set_num_threads(1);checks=[];unique_paths=set();data_length=len(Path(p['config']['data']['path']).read_text())
for r in records:
 assert r['error'] is None and r['duration_seconds']<2400
 d=run/'trials'/r['trial_id'];req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model'];total,start=3000,2000;snapshots=1+(total-start)//10
 assert p['returned_half_life']==200
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['completed_steps']==total and raw['eval_iters']==30 and raw['eval_every']==300
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==total
 metrics=[json.loads(x) for x in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics'] and [x['step'] for x in metrics]==list(range(0,total,300))+[total-1]
 assert max(x['rss_mb'] for x in metrics)<4096
 for row in metrics:
  i=row['step'];ratio=1. if i<=start else 1.-.9*(i-start)/(total-start-1)
  if i==total-1:ratio=.1
  assert math.isclose(row['lr_multiplier'],ratio,rel_tol=0,abs_tol=1e-14)
  assert row['base_learning_rate']==r['lr'] and math.isclose(row['scheduled_learning_rate'],r['lr']*ratio,abs_tol=1e-15)
  completed=i+1;expected=0 if completed<start else 1+(completed-start)//10
  assert row['averaging_snapshots']==expected and row['tokens_processed']==completed*1024
  assert row['train_aux_loss'] is None and row['moe_usage'] is None
  assert row['train_ce_loss']==row['train_loss']==row['train_total_loss']
 cp=read_checkpoint(r['checkpoint']);assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==total and cp['parameter_layout_version']==2 and cp['model_math_version']==2
 assert 'averaged_weights' not in cp
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65;assert cp['cfg']==want
 assert t['max_iters']*t['batch_size']*m['block_size']==total*1024 and t['batch_layout']=='paired_blocks512'
 assert t['weight_averaging']==dict(kind='spaced_tail_ema',total_steps=total,start_step=start,interval=10,half_lives=[200]) and t['lr_schedule']==study.horizon.schedule('control3000')
 contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
  optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],data_sha256=p['data_sha256'],
  data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
  training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==contract and cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(total):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 model=GPT(OmegaConf.create(want['model']));model.load_state_dict(cp['model_state'],strict=True)
 assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
 named=dict(model.named_parameters());width=r['width'];depth=4
 hidden=21*width//8
 coefficient=p['recipe']['weight_decay']
 assert t['decay_mode']=='independent' and t['weight_decay']==coefficient
 family='mha' if r['family']=='incumbent_reference' else r['family']
 assert m['attn_type']==family and len(model.transformer.h)==4
 shapes={'transformer.wte.weight':(65,width),'lm_head.weight':(65,width),'transformer.ln_f.weight':(width,),'transformer.ln_f.bias':(width,)}
 for layer in range(4):
  prefix=f'transformer.h.{layer}.'
  common={'ln1.weight':(width,),'ln2.weight':(width,),
   'mlp.linear_gate.weight':(hidden,width),'mlp.linear_up.weight':(hidden,width),'mlp.linear_down.weight':(width,hidden)}
  if family=='mha':
   attn={'attn.qkv.weight':(3*width,width),'attn.qkv.bias':(3*width,),'attn.out.weight':(width,width),'attn.out.bias':(width,)}
   assert cp['model_state'][prefix+'freq_cos'].shape==cp['model_state'][prefix+'freq_sin'].shape==(128,16)
   assert m['depth_width_policy']=='depth4_unscaled' and m['attention_width_policy']=='mha_head32' and model.position_encoding=='rope'
  else:
   attn={'attn.qkv.weight':(3*width,width),'attn.qkv.bias':(3*width,),
    'attn.q_conv.weight':(width,1,4),'attn.k_conv.weight':(width,1,4),'attn.v_conv.weight':(width,1,4),
    'attn.beta_proj.weight':(width//32,width),'attn.beta_proj.bias':(width//32,),
    'attn.z1.weight':(width//4,width),'attn.z2.weight':(width,width//4),'attn.z2.bias':(width,),
    'attn.A':(width//32,),'attn.head_norm.weight':(32,),
    'attn.output_gate.weight':(width,width),'attn.out_proj.weight':(width,width)}
   assert m['depth_width_policy']=='depth4_kda_unscaled' and m['attention_width_policy']=='kda_head32_alpha_quarter'
   assert 'dim_alpha' not in m and model.transformer.h[layer].attn.dim_alpha==width//4
   assert prefix+'freq_cos' not in cp['model_state'] and prefix+'freq_sin' not in cp['model_state'] and model.position_encoding=='none'
  shapes.update({prefix+k:v for k,v in {**common,**attn}.items()})
 assert set(named)==set(shapes) and all(tuple(named[k].shape)==v for k,v in shapes.items())
 expected_count=sum(math.prod(v) for v in shapes.values());assert sum(v.numel() for v in named.values())==expected_count
 assert not any('.mlp.hidden_norm.' in n for n in named)
 seen=[];assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==coefficient
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   assert len(g['params'])==len(g['parameter_names'])==1
   name=g['parameter_names'][0];seen.append(name);v=named[name];matrix=name.startswith('transformer.h.') and v.ndim==2
   scale=1/math.sqrt(width/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==r['lr']*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'} and g['momentum']==.95 and g['adjust_lr_fn']=='match_rms_adamw'
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total and g['betas']==(.9,.999)
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==v.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 state=cp['training_state']['weight_averaging_state'];tracker=TailWeightAverages(model,OmegaConf.create(t));tracker.load_state_dict(state,total)
 assert state['spec']==t['weight_averaging'] and state['completed_steps']==total and state['snapshots']==snapshots
 assert state['parameter_names']==list(named) and set(state['averages'])=={'200'}
 rawpath=Path(r['checkpoint']).resolve();assert rawpath not in unique_paths;unique_paths.add(rawpath)
 derived_checks=[]
 for h in (200,):
  item=r['averaged_outputs'][str(h)];path=Path(item['checkpoint']).resolve();assert path not in unique_paths;unique_paths.add(path)
  job=dict(checkpoint=str(path),checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=str(rawpath),
   parent_sha256=r['checkpoint_sha256'],half_life=h,completed_steps=total)
  derived=validate_derivation(job)
  assert 'training_state' not in derived and 'optimizer_state' not in derived
  assert derived['averaged_weights']['parameter_names']==list(named) and derived['cfg']==cp['cfg']
  assert derived['averaged_weights']['snapshots']==snapshots
  for name,value in derived['model_state'].items():
   reference=state['averages'][str(h)][name] if name in named else cp['model_state'][name]
   assert value.dtype==reference.dtype and value.shape==reference.shape and torch.equal(value,reference) and torch.isfinite(value).all()
  assert file_digest(path)==item['checkpoint_sha256']
  derived_checks.append(dict(half_life=h,path=str(path),sha256=item['checkpoint_sha256']))
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
  result_sha256=r['result_sha256'],parameter_count=expected_count,derived_checkpoints=derived_checks))
 print('Verified trajectory',r['trial_id'],flush=True)
review=dict(status='partial_verified' if args.partial else 'verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_trajectories=len(records),distinct_checkpoints=len(unique_paths),
 checkpoint_audit=checks,holdout_consumed=False)
if args.partial:
 (folder/'partial-audit.json').write_text(json.dumps(review,indent=2)+'\n');print('PARTIAL VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints');raise SystemExit


report=json.loads((run/'report.json').read_text());assert study.summarize(p,s)==report
import importlib.util
spec=importlib.util.spec_from_file_location('independent_kda_report_audit',folder/'report-audit.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
independent=module.audit(p,s,report)
assert independent['physical_trajectories']==len(records) and independent['correlated_outputs']==len(unique_paths)
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),quality_decision=report['quality_decision'],active_seconds=s['active_seconds'],disk_mb=disk_mb(run),reference_aliases=report['reference_aliases'],independent_report_review=independent,
 checks=['Every checkpoint/raw request/result hash, config/source/corpus/runtime/full-bank/prerequisite contract',
 'All MHA/KDA named shapes independently enumerated including QKV/derived alpha/causal convolution/head RMS/gate/FFN and exact parameter counts; strict finite CPU loads',
 'Actual optimizer slots/steps/width factors/constant independent decay/zero child decay; reconstructed private train RNG and untouched test RNG',
 'Step/token/cooldown/H200 counters, derived-parent shadow equality and inference-only contract; full111538-target coverage',
 '12 fresh screens freeze two LRs/eligible family; exact prospective aliases; fresh2271/2272/2273 confirmation64/256',
 'Complete report and every primary/raw paired conditional bootstrap/fixed-LR screen/adoption independently reconstructed'],
 limitations=['Saved final shadows cannot reconstruct every historical averaging snapshot; separate correctness tests cover recurrence',
 '24or30 trajectories produce48or60 correlated raw/H200 outputs; aliases are not independent repeats; adaptive validation, no holdout/seed-population inference',
 'KDA changes recurrence/convolution/position/gating and initializer draws jointly; not isolated causal mechanism or exact-paper reproduction'])
assert not (run/'review.json').exists()
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints')
