"""Synthetic arithmetic and refusal checks, not measured KDA feasibility."""
import copy,importlib.util,math
from pathlib import Path
import pytest
spec=importlib.util.spec_from_file_location('resource_gate',Path(__file__).with_name('resource-gate.py'))
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)

def rows():
 return [dict(width=w,family=f,status='verified',steps=20,cooldown_start=10,snapshots=2,training_seconds=10.,wall_seconds=15.,raw_checkpoint_bytes=20*1024**2,derived_checkpoint_bytes=5*1024**2,sampled_peak_rss_mb=100.,current_driver_mb=100.) for w in (64,256) for f in ('mha','kda')]

def test_maximum_manifest_and_manual_forecast():
 r=rows()
 for x in r:x.update(training_seconds=1.,wall_seconds=6.)
 v=gate.forecast(r)
 assert v['status']=='feasible'
 assert math.isclose(v['hours'],30*1.5*155/3600)
 assert v['total_mb_with_margin']==30*1.5*50
 assert {(x['width'],x['family']):x['trajectories'] for x in v['trial_proxies']}=={(64,'mha'):12,(64,'kda'):9,(256,'mha'):6,(256,'kda'):3}

def test_slow_pilot_records_infeasibility_without_new_limit():
 v=gate.forecast(rows());assert v['status']=='infeasible'
 assert v['hours']>6

@pytest.mark.parametrize('key,value',[('status','running'),('steps',10),('cooldown_start',5),('snapshots',3),('training_seconds',float('nan')),('wall_seconds',240),('training_seconds',16),('sampled_peak_rss_mb',4096),('current_driver_mb',6144),('raw_checkpoint_bytes',-1)])
def test_invalid_pilot_rejected(key,value):
 r=rows();r[0][key]=value
 with pytest.raises(ValueError):gate.forecast(r)

def test_duplicate_missing_cell_rejected():
 r=rows();r[3]=copy.deepcopy(r[0])
 with pytest.raises(ValueError):gate.forecast(r)

def test_per_worker_and_storage_bounds_are_included():
 r=rows();r[0]['training_seconds']=20;r[0]['wall_seconds']=30
 v=gate.forecast(r);assert v['status']=='infeasible' and not v['trial_proxies'][0]['within_trial_limit']
 for x in r:x.update(training_seconds=1,wall_seconds=6,raw_checkpoint_bytes=200*1024**2)
 v=gate.forecast(r);assert v['status']=='infeasible' and v['total_mb_with_margin']>4096
