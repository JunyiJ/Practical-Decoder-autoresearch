"""Independent KDA report arithmetic. No training or model construction.

This checks report/selection/manifest/bootstrap arithmetic only. A complete
checkpoint/hash/config/source/runtime audit is additionally required.
"""
import math
import statistics
import numpy as np
from src.research.protocol import digest


def endpoint(row,raw=False):
    return row['coverage']['128'] if raw else row['averaged_outputs']['200']['coverage']['evaluations']['128']


def audit(p,state,report):
    records=state['records']
    assert report['plan_sha256']==digest(p) and report['records']==records and report['selection']==state['selection']
    assert report['holdout_consumed'] is False and report['adoption_requires_completion_review'] is True
    assert report['physical_training_trajectories']==len(records) and report['model_evaluations']==2*len(records)
    assert report['scope']==p['scope']
    assert all(r['status']=='completed' for r in records)
    assert len({r['trial_id'] for r in records})==len(records)
    expected_screens=[(f,lr,64,seed) for lr in (.00125,.0025,.005) for i,seed in enumerate((2261,2262)) for f in (('mha','kda') if i==0 else ('kda','mha'))]
    assert [(r['family'],r['lr'],r['width'],r['seed']) for r in records[:12]]==expected_screens
    assert all(r['stage']=='local' for r in records[:12]) and all(r['stage']=='confirmation' for r in records[12:])
    for r in records:
        for raw in (False,True):
            v=endpoint(r,raw)
            assert v['target_count']==111538 and len(v['block_loss_sums'])==len(v['block_target_counts'])==55
            assert v['block_target_counts']==[2048]*54+[946]
            assert all(math.isfinite(x) for x in v['block_loss_sums'])
            assert math.isclose(sum(v['block_loss_sums'])/111538,v['mean_ce'],abs_tol=1e-12,rel_tol=0)
    screen=records[:12];selection=state['selection'];choices={}
    for family in ('mha','kda'):
     grid=[dict(lr=lr,mean_ce=statistics.mean(endpoint(r)['mean_ce'] for r in screen if r['family']==family and r['lr']==lr)) for lr in (.00125,.0025,.005)]
     chosen=min(grid,key=lambda v:(v['mean_ce'],v['lr']))
     choices[family]={**chosen,'grid':grid,'at_grid_boundary':chosen['lr'] in (.00125,.005)}
    assert selection['choices']==choices
    panels={(family,lr):{r['seed']:endpoint(r)['mean_ce'] for r in screen if r['family']==family and r['lr']==lr} for family in ('mha','kda') for lr in (.00125,.0025,.005)}
    for panel in panels.values():assert set(panel)=={2261,2262}
    order=['mha','kda']
    best=min(order,key=lambda f:(choices[f]['mean_ce'],order.index(f)))
    local=[];references=[('incumbent_reference',p['recipe']['learning_rate'])]
    if best!='mha':references.append(('mha',choices['mha']['lr']))
    for reference,lr in references:
     a=panels[best,choices[best]['lr']];b=panels['mha',lr]
     ds={str(seed):a[seed]-b[seed] for seed in (2261,2262)}
     local.append(dict(reference=reference,reference_lr=lr,paired_seed_deltas=ds,mean_delta=statistics.mean(ds.values()),supported=statistics.mean(ds.values())<-.005 and max(ds.values())<0))
    eligible=all(c['supported'] for c in local);winner=best if eligible else 'incumbent_unchanged'
    assert selection['best_selected_arm']==best and selection['local_contrasts']==local
    assert selection['candidate_eligible']==eligible and selection['winner']==winner
    aliases={'incumbent_reference':'mha'} if choices['mha']['lr']==p['recipe']['learning_rate'] else {}
    assert selection['confirmation']['reference_aliases']==report['reference_aliases']==aliases
    assert len(records)==(24 if aliases else 30)
    confirmation=records[12:];expanded=list(confirmation)
    for alias,family in aliases.items():expanded += [{**r,'family':alias,'alias_of':r['trial_id']} for r in confirmation if r['family']==family]
    required=['incumbent_reference'] if winner=='mha' else ['incumbent_reference','mha']
    adoption=[]
    for c in report['comparisons']:
     panels={f:{r['seed']:r for r in expanded if r['width']==c['width'] and r['family']==f} for f in (c['candidate'],c['reference'])}
     for panel in panels.values():assert set(panel)=={2271,2272,2273}
     assert (c['candidate'],c['reference']) in [('kda','mha'),('mha','incumbent_reference'),('kda','incumbent_reference')]
     for raw_endpoint,key in [(False,'sensitivity'),(True,'raw_sensitivity')]:
      aa=[endpoint(panels[c['candidate']][k],raw_endpoint) for k in (2271,2272,2273)]
      bb=[endpoint(panels[c['reference']][k],raw_endpoint) for k in (2271,2272,2273)]
      delta=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0)
      counts=np.array(aa[0]['block_target_counts']);seed_deltas={str(k):a['mean_ce']-b['mean_ce'] for k,a,b in zip((2271,2272,2273),aa,bb)}
      assert len(c[key])==3
      for n,v in zip((2048,4096,8192),c[key]):
       factor=n//2048;chunks=np.array([delta[j:j+factor].sum() for j in range(0,len(delta),factor)])
       cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
       idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)));boot=chunks[idx].sum(1)/cnt[idx].sum(1)
       assert v['text_block_tokens']==n and v['text_block_count']==len(cnt) and v['bootstrap_draws']==2000 and v['bootstrap_seed']==20261024
       assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
       assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],rel_tol=0,abs_tol=1e-12)
       assert v['paired_seed_deltas']==seed_deltas
      if not raw_endpoint:
       supported=statistics.mean(seed_deltas.values())<-.005 and max(seed_deltas.values())<0 and all(v['conditional_text_bootstrap_95pct'][1]<0 for v in c[key])
       assert c['quality_improvement']==supported
       if c['candidate']==winner and c['reference'] in required:adoption.append(supported)
    assert len(report['comparisons'])==6
    adopt=winner!='incumbent_unchanged' and len(adoption)==2*len(required) and all(adoption)
    assert report['quality_decision']==dict(frozen_screen_winner=winner,qualifies_for_incumbent_replacement=adopt)
    fixed=[]
    for lr in (.00125,.0025,.005):
     for a,b in [('kda','mha')]:
      item=dict(lr=lr,candidate=a,reference=b)
      for raw_endpoint,key in [(False,'primary'),(True,'raw')]:
       panels={f:{r['seed']:endpoint(r,raw_endpoint)['mean_ce'] for r in screen if r['family']==f and r['lr']==lr} for f in (a,b)}
       ds={str(k):panels[a][k]-panels[b][k] for k in (2261,2262)}
       item[key]=dict(mean_delta=statistics.mean(ds.values()),paired_seed_deltas=ds)
      fixed.append(item)
    assert report['fixed_lr_screen']==fixed
    assert selection['plan_sha256']==digest(p) and selection['local_evidence_sha256']==digest(screen)
    expected_jobs=[]
    for width in (64,256):
        for i,seed in enumerate((2271,2272,2273)):
            families=['mha','kda']+([] if aliases else ['incumbent_reference'])
            if i%2:families.reverse()
            for family in families:
                lr=p['recipe']['learning_rate'] if family=='incumbent_reference' else choices[family]['lr']
                expected_jobs.append([family,lr,width,seed])
    assert selection['confirmation']==dict(jobs=expected_jobs,reference_aliases=aliases,total_distinct_trials=12+len(expected_jobs),total_model_evaluations=2*(12+len(expected_jobs)))
    assert [[r[k] for k in ('family','lr','width','seed')] for r in confirmation]==expected_jobs
    expected_comparisons={(width,a,b) for width in (64,256) for a,b in [('kda','mha'),('mha','incumbent_reference'),('kda','incumbent_reference')]}
    assert {(c['width'],c['candidate'],c['reference']) for c in report['comparisons']}==expected_comparisons
    return dict(status='report_arithmetic_verified',physical_trajectories=len(records),correlated_outputs=2*len(records),quality_decision=report['quality_decision'])
