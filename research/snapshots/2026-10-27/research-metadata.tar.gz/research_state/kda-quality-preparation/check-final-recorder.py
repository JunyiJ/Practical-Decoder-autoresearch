"""Synthetic adversarial promotion metadata; no models, training or quality measurements."""
import copy,importlib.util,json
from pathlib import Path
folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('kda_recorder',folder/'record-completion.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def report():
 local=[dict(reference=ref,paired_seed_deltas={'2261':-.01,'2262':-.01},mean_delta=-.01,supported=True) for ref in ('incumbent_reference','mha')]
 comparisons=[]
 for w in (64,256):
  for ref in ('incumbent_reference','mha'):
   intervals=[dict(text_block_tokens=n,mean_delta=-.01,paired_seed_deltas={str(k):-.01 for k in (2271,2272,2273)},conditional_text_bootstrap_95pct=[-.015,-.005]) for n in (2048,4096,8192)]
   comparisons.append(dict(candidate='kda',reference=ref,width=w,sensitivity=intervals,quality_improvement=True))
 return dict(selection=dict(choices={'mha':dict(mean_ce=1.5),'kda':dict(mean_ce=1.49)},winner='kda',best_selected_arm='kda',candidate_eligible=True,local_contrasts=local),comparisons=comparisons,quality_decision=dict(frozen_screen_winner='kda',qualifies_for_incumbent_replacement=True))
checks=[]
r=report();assert m.verified_decision(r)==('kda',True);checks.append('KDA needs both references at both widths')
r=report();r['selection']['choices']['mha']['mean_ce']=1.48;r['selection'].update(winner='mha',best_selected_arm='mha');r['selection']['local_contrasts']=r['selection']['local_contrasts'][:1];r['comparisons']=[{**c,'candidate':'mha'} for c in r['comparisons'] if c['reference']=='incumbent_reference'];r['quality_decision']['frozen_screen_winner']='mha'
assert m.verified_decision(r)==('mha',True);checks.append('MHA improved LR only needs fixed reference')
r=report();r['comparisons'][-1]['sensitivity'][-1]['conditional_text_bootstrap_95pct'][1]=.001;r['comparisons'][-1]['quality_improvement']=False;r['quality_decision']['qualifies_for_incumbent_replacement']=False
assert m.verified_decision(r)==('kda',False);checks.append('Any block interval vetoes adoption')
r=report()
for c in r['selection']['local_contrasts']:c.update(paired_seed_deltas={'2261':-.011,'2262':.001},mean_delta=-.005,supported=False)
r['selection'].update(winner='incumbent_unchanged',candidate_eligible=False);r['quality_decision']=dict(frozen_screen_winner='incumbent_unchanged',qualifies_for_incumbent_replacement=False)
assert m.verified_decision(r)==('incumbent_unchanged',False);checks.append('Local failure cannot be reversed by confirmation')
def rejects(label,mutate):
 r=report();mutate(r)
 try:m.verified_decision(r)
 except (AssertionError,ValueError,KeyError):checks.append(label)
 else:raise AssertionError(label)
rejects('False local supported flag',lambda r:r['selection']['local_contrasts'][0].update(paired_seed_deltas={'2261':-.03,'2262':.01},mean_delta=-.01))
rejects('Alternative fallback',lambda r:r['selection'].update(winner='mha'))
rejects('Changed best-arm ordering',lambda r:r['selection']['choices']['mha'].update(mean_ce=1.48))
rejects('Missing width contrast',lambda r:r['comparisons'].pop())
rejects('Duplicate comparison',lambda r:r['comparisons'].append(copy.deepcopy(r['comparisons'][0])))
rejects('Changed fresh seeds',lambda r:r['comparisons'][0]['sensitivity'][0]['paired_seed_deltas'].update({'9999':-.01}))
rejects('False every-seed gain',lambda r:r['comparisons'][0]['sensitivity'][0]['paired_seed_deltas'].update({'2273':.001}))
rejects('False interval support',lambda r:r['comparisons'][0]['sensitivity'][2].update(conditional_text_bootstrap_95pct=[-.01,.001]))
rejects('Wrong adoption flag',lambda r:r['quality_decision'].update(qualifies_for_incumbent_replacement=False))
print(json.dumps(dict(status='synthetic_metadata_checks_passed',count=len(checks),checks=checks,quality_measurement=False,model_work=False),indent=2))
