"""Register exactly one new KDA round after actual source/test/pilot gates."""
import argparse,datetime,json,os,re,subprocess
from pathlib import Path
from src.research import kda_quality_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank

parser=argparse.ArgumentParser();parser.add_argument('--register',action='store_true');args=parser.parse_args()
if not args.register:parser.error('Explicit --register required')

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
run=base/'research_runs/kda-quality-001';folder=base/'research_state/kda-quality-preparation';prior=base/'research_runs/decay-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text())
assert active['campaign']==str(prior) and active['status']=='completed_reviewed' and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
lines=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in lines if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|decay_quality_study|kda_quality_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
remote_main = subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]
# A later human merge must not silently enter an already tested study.
subprocess.check_call(['git','merge-base','--is-ancestor',p['git_commit'],remote_main])
p['publication_lineage'] = dict(tested_commit=p['git_commit'], observed_remote_main=remote_main,
    tested_commit_is_remote_ancestor=True, later_remote_changes_excluded=True)
review=folder/'review.json';v=json.loads(review.read_text());tests=v['tests']['full_tests']
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit']
assert v['recipe']==p['recipe'] and v['returned_half_life']==200 and v['predecessor_review']==p['predecessor_review']
assert tests['passed']==tests['collected']>=1608 and tests['failed']==0 and v['tests']['actual_kda_training_tests_passed']==2 and v['tests']['human_kda_reference_tests_passed'] and v['tests']['kda_geometry_optimizer_gradient_tests_passed']
assert len(v['pilot_audit'])==4 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['status']=='feasible' and v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (base/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/KDA_QUALITY_PROTOCOL.md';con=json.loads((base/'research_state/decay-quality-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
incumbent_path=base/'research_state/kda-quality-incumbent.json';assert not incumbent_path.exists()
incumbent_path.write_bytes((base/'research_state/best-observed-config.json').read_bytes());incumbent_path.chmod(0o444)
incumbent=json.loads(incumbent_path.read_text());p['incumbent_snapshot']=dict(path=str(incumbent_path),sha256=file_digest(incumbent_path),result_id=incumbent['result_id'])
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='KDA width policy with actual model/trainer and bounded serial MPS gates',
 summary=f"All {tests['passed']} source-matched CPU tests and four serial shortened MPS MHA/KDA pilots passed. Human recurrence/default compatibility, explicit alpha geometry/all-parameter gradients, optimizer roles, exact CPU resume, raw/H200 derivation/noninterference, private RNG, full coverage and cached logits were checked. The independently verified maximum30-trial resource forecast fits finite limits. Correctness pilots are excluded from quality findings.",
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id'],'kb_aa69db77ad0465d79ab272f3059753f5c439771b0b65fe2b55e4fd7764187372','kb_ee9578cdd92cd6f743d01f30824fc502efba7b90dee83f43cad35b36a43f7a4f']))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',title='Preregistered KDA quality001: finite recurrent-attention comparison',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='KDA recurrence/convolution/gating may change quality at the fixed training exposure. No quantitative gain, speedup, isolated-mechanism or optimal muP-transfer prediction is assumed. The all-KDA dense-SwiGLU adaptation differs from the cited hybrid system.',
 selection='12 width64 screens on2261/2262 choose two family LRs; freeze best selected arm, ties MHA before KDA. Require mean gain>.005/every seed better against fixed incumbent and tunedMHA for KDA, otherwise retention with no alternate fallback. Fresh2271/2272/2273 confirmation64/256; only eligible frozen winner can qualify with all required both-width contrasts and all conditional text upper bounds negative.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='Final reviewed decay retention supplies commonLR.005/decay.00006; same3000updates/3072000targets, cooldownstart2000 andH200.24or30physical/48or60correlatedoutputs. FixedMHAreference aliases selectedMHA only on exactrecipe/LR equality. No completed-study rerun/gridextension/largerwidthreselection;006permanentstop. Primary human checkout untouched.'),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in (protocol,review,prior/'review.json')],related_ids=[implementation,con['result_id'],'kb_ee9578cdd92cd6f743d01f30824fc502efba7b90dee83f43cad35b36a43f7a4f']))
snapshot=base/'research_state/kda-quality-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
artifacts=[incumbent_path,protocol,review,folder/'review-prerequisites.py',folder/'freeze-kda-quality.py',folder/'launch-kda-quality.py',folder/'completion-audit.py',folder/'report-audit.py',folder/'record-completion.py',folder/'check-final-recorder.py',folder/'final-recorder-checks.json',base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/decay-quality-conclusion.json',base/'research_state/decay-quality-completed-knowledge-snapshot002.md']+[prior/f for f in ('plan.json','report.json','review.json','selection.json')]
p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary human checkout untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in (run/'plan.json',base/'research_state/kda-quality-plan.json'):path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],recipe=p['recipe'],maximum_physical_trajectories=30,maximum_correlated_model_outputs=60,returned_half_life=200,completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
