"""Read completed screening metadata only; no model or training work."""
import datetime,hashlib,json,math,statistics
from pathlib import Path
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=base/'research_runs/kda-quality-001'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
p=json.loads((run/'plan.json').read_text());state=json.loads((run/'state.json').read_text());s=json.loads((run/'selection.json').read_text());rows=state['records'][:12]
assert state['selection']==s and len(rows)==12 and all(r['status']=='completed' and r['stage']=='local' for r in rows)
expected=[(f,lr,64,seed) for lr in (.00125,.0025,.005) for i,seed in enumerate((2261,2262)) for f in (('mha','kda') if i==0 else ('kda','mha'))]
assert [tuple(r[k] for k in ('family','lr','width','seed')) for r in rows]==expected
assert s['plan_sha256']==digest(p) and s['local_evidence_sha256']==digest(rows)
artifacts=[]
for r in rows:
 for name in ('request','result'):
  path=run/'trials'/r['trial_id']/(name+'.json');assert sha(path)==r[name+'_sha256'];artifacts.append(dict(path=str(path),sha256=sha(path)))
 v=r['averaged_outputs']['200']['coverage']['evaluations']['128']
 assert v['target_count']==111538 and v['block_target_counts']==[2048]*54+[946]
 assert math.isclose(sum(v['block_loss_sums'])/111538,v['mean_ce'],abs_tol=1e-12,rel_tol=0)
 assert r['metric']==v['mean_ce'] and r['tokens_processed']==3072000
choices={}
for f in ('mha','kda'):
 grid=[dict(lr=lr,mean_ce=statistics.mean(r['metric'] for r in rows if r['family']==f and r['lr']==lr)) for lr in (.00125,.0025,.005)]
 best=min(grid,key=lambda v:(v['mean_ce'],v['lr']));choices[f]={**best,'grid':grid,'at_grid_boundary':best['lr'] in (.00125,.005)}
assert choices==s['choices']
assert min(('mha','kda'),key=lambda f:(choices[f]['mean_ce'],('mha','kda').index(f)))==s['best_selected_arm']=='mha'
assert choices['mha']['lr']==p['recipe']['learning_rate']==.005
assert s['local_contrasts']==[dict(reference='incumbent_reference',reference_lr=.005,paired_seed_deltas={'2261':0.,'2262':0.},mean_delta=0.,supported=False)]
assert s['candidate_eligible'] is False and s['winner']=='incumbent_unchanged'
jobs=[]
for w in (64,256):
 for i,seed in enumerate((2271,2272,2273)):
  for f in (('mha','kda') if i%2==0 else ('kda','mha')):jobs.append([f,.005,w,seed])
assert s['confirmation']==dict(jobs=jobs,reference_aliases={'incumbent_reference':'mha'},total_distinct_trials=24,total_model_evaluations=48)
assert [[r[k] for k in ('family','lr','width','seed')] for r in state['records'][12:]]==jobs[:len(state['records'])-12]
for name in ('plan.json','selection.json'):
 path=run/name;artifacts.append(dict(path=str(path),sha256=sha(path)))
# Preserve the exact local evidence used here, without snapshotting a moving pending worker.
out=base/'research_state/kda-quality-preparation/screening-review001';out.mkdir(exist_ok=False)
(out/'screening-records.json').write_text(json.dumps(rows,indent=2)+'\n');artifacts.append(dict(path=str(out/'screening-records.json'),sha256=sha(out/'screening-records.json')))
review=dict(status='screening_arithmetic_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),physical_screening_trials=12,total_planned_physical_trials=24,choices=choices,frozen_winner=s['winner'],reference_aliases=s['confirmation']['reference_aliases'],kda_minus_mha_selected_mean=choices['kda']['mean_ce']-choices['mha']['mean_ce'],holdout_consumed=False,training_rerun=False,limitations=['Screening metadata and request/result hashes only; complete checkpoint/config/runtime/report audit deferred until round completion.','Adaptive development; no independent holdout or seed-population inference.','Do not revise choices using fresh confirmation or extend the LR grid.'],artifacts=artifacts)
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({k:v for k,v in review.items() if k!='artifacts'}))
