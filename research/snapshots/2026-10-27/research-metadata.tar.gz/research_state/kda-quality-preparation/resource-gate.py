"""Prospective KDA resource forecast; metadata only, never launches model work."""
import math


def forecast(rows):
    expected={(w,f) for w in (64,256) for f in ('mha','kda')}
    if len(rows)!=4 or {(r['width'],r['family']) for r in rows}!=expected:
        raise ValueError('Exactly four distinct pilot cells required')
    proxies=[];seconds=0.;storage=0.
    for r in rows:
        if r['status']!='verified' or r['steps']!=20 or r['cooldown_start']!=10 or r['snapshots']!=2:
            raise ValueError('Wrong shortened-pilot contract')
        values=[r[k] for k in ('training_seconds','wall_seconds','raw_checkpoint_bytes','derived_checkpoint_bytes','sampled_peak_rss_mb','current_driver_mb')]
        if any(type(v) not in (int,float) or not math.isfinite(v) or v<=0 for v in values):
            raise ValueError('Invalid pilot resource measurement')
        if not r['training_seconds']<=r['wall_seconds']<240 or r['sampled_peak_rss_mb']>=4096 or r['current_driver_mb']>=6144:
            raise ValueError('Pilot exceeded a hard resource bound')
        count=(12 if r['family']=='mha' else 9) if r['width']==64 else (6 if r['family']=='mha' else 3)
        estimate=1.5*(r['training_seconds']*3000/r['steps']+r['wall_seconds']-r['training_seconds'])
        artifact=1.5*(r['raw_checkpoint_bytes']+r['derived_checkpoint_bytes']+25*1024**2)
        proxies.append(dict(width=r['width'],family=r['family'],trajectories=count,seconds_per_trajectory_with_margin=estimate,artifact_mb_per_trajectory_with_margin=artifact/1024**2,within_trial_limit=estimate<2400))
        seconds+=count*estimate;storage+=count*artifact
    assert sum(r['trajectories'] for r in proxies)==30
    return dict(status='feasible' if all(r['within_trial_limit'] for r in proxies) and seconds<21600 and storage/1024**2<4096 else 'infeasible',
        hours=seconds/3600,total_mb_with_margin=storage/1024**2,trial_proxies=proxies,
        method='Maximum30 physical trajectories; measured20-update training time scaled by150, retain measured two-output evaluation/cache overhead, add50%time margin. Raw/H200 bytes plus25MiBmetadata per trajectory and50%storage margin. Forecast, not measured production cost; no cap extension.')
