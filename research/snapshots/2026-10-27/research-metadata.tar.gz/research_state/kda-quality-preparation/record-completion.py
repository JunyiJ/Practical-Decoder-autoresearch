"""Prepare or record only a complete independently reviewed KDA result.

Default is a read-only evidence preview. --record appends findings and updates the
best recipe only after frozen eligibility and both-width support are rechecked.
No model training, scoring, or checkpoint rewriting occurs here.
"""
import argparse
import copy
import datetime
import json
import statistics
from pathlib import Path

BASE = Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
FAMILIES = ('mha', 'kda')
SEEDS = (2271, 2272, 2273)


def verified_decision(report):
    """Independently enforce the prospective decision; never choose another arm."""
    selection = report['selection']
    winner = selection['winner']
    best = min(FAMILIES, key=lambda f:(selection['choices'][f]['mean_ce'], FAMILIES.index(f)))
    assert best == selection['best_selected_arm']
    local_refs = ['incumbent_reference'] if best == 'mha' else ['incumbent_reference', 'mha']
    assert [c['reference'] for c in selection['local_contrasts']] == local_refs
    local_support = []
    for c in selection['local_contrasts']:
        ds = c['paired_seed_deltas']
        assert set(ds) == {'2261', '2262'}
        assert abs(statistics.mean(ds.values()) - c['mean_delta']) < 1e-12
        ok = c['mean_delta'] < -.005 and max(ds.values()) < 0
        assert c['supported'] == ok
        local_support.append(ok)
    local_eligible = all(local_support)
    assert selection['candidate_eligible'] == local_eligible
    assert winner == (best if local_eligible else 'incumbent_unchanged')
    if winner == 'incumbent_unchanged':
        assert selection['candidate_eligible'] is False
        eligible = False
    else:
        assert winner in FAMILIES and selection['candidate_eligible'] is True
        assert selection['best_selected_arm'] == winner
        assert all(c['supported'] for c in selection['local_contrasts'])
        references = ('incumbent_reference',) if winner == 'mha' else ('incumbent_reference', 'mha')
        eligible = True
        for width in (64, 256):
            for reference in references:
                found = [c for c in report['comparisons'] if
                         (c['candidate'], c['reference'], c['width']) == (winner, reference, width)]
                assert len(found) == 1
                c = found[0]
                v = c['sensitivity']
                assert [x['text_block_tokens'] for x in v] == [2048, 4096, 8192]
                assert set(v[0]['paired_seed_deltas']) == set(map(str, SEEDS))
                supported = (v[0]['mean_delta'] < -.005
                             and max(v[0]['paired_seed_deltas'].values()) < 0
                             and all(x['conditional_text_bootstrap_95pct'][1] < 0 for x in v))
                assert c['quality_improvement'] == supported
                eligible = eligible and supported
    expected = dict(frozen_screen_winner=winner, qualifies_for_incumbent_replacement=eligible)
    assert report['quality_decision'] == expected
    return winner, eligible


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--record', action='store_true')
    args = parser.parse_args()
    # Imports are deferred so pure metadata decision checks need no model modules.
    from src.research import kda_quality_study as study
    from src.research.protocol import digest, file_digest
    from src.research.team.knowledge import KnowledgeBank
    run = BASE/'research_runs/kda-quality-001'
    folder = BASE/'research_state/kda-quality-preparation'
    p, s, r, v = [json.loads((run/name).read_text()) for name in
                   ('plan.json', 'state.json', 'report.json', 'review.json')]
    n = r['physical_training_trajectories']
    assert s['status'] == 'completed' and v['status'] == 'verified'
    assert n in (24, 30) and v['distinct_trajectories'] == n
    assert v['distinct_checkpoints'] == r['model_evaluations'] == 2*n
    assert digest(p) == r['plan_sha256'] == v['plan_sha256']
    assert v['report_sha256'] == file_digest(run/'report.json')
    assert v['selection_sha256'] == file_digest(run/'selection.json')
    study.verify_lineage(p)
    assert study.summarize(p, s) == r and r['quality_decision'] == v['quality_decision']
    winner, adopt = verified_decision(r)
    rows = [x for x in r['records'] if x['stage'] == 'confirmation']
    for alias, family in r['reference_aliases'].items():
        rows += [{**x, 'family':alias} for x in rows if x['family'] == family]
    means, cost = {}, {}
    for f in FAMILIES + ('incumbent_reference',):
        means[f], cost[f] = {}, {}
        for w in (64, 256):
            panel = [x for x in rows if x['width'] == w and x['family'] == f]
            assert sorted(x['seed'] for x in panel) == list(SEEDS)
            means[f][str(w)] = {key:statistics.mean(study.endpoint(p, x, raw)['mean_ce'] for x in panel)
                               for key, raw in (('H200', False), ('raw', True))}
            cost[f][str(w)] = dict(mean_training_seconds=statistics.mean(x['training_time_sec'] for x in panel),
                mean_trajectory_wall_seconds=statistics.mean(x['duration_seconds'] for x in panel),
                mean_sampled_rss_mb=statistics.mean(x['rss_mb'] for x in panel))
    for f in cost:
        for w in ('64', '256'):
            cost[f][w]['training_time_ratio_vs_mha'] = cost[f][w]['mean_training_seconds']/cost['mha'][w]['mean_training_seconds']
    def deltas(a, b):
        return '/'.join(f"{next(c for c in r['comparisons'] if c['candidate']==a and c['reference']==b and c['width']==w)['sensitivity'][0]['mean_delta']:+.6f}" for w in (64, 256))
    choices = ', '.join(f"{f} LR {r['selection']['choices'][f]['lr']:g}" for f in FAMILIES)
    summary = (f'KDA comparison completed {n} physical trajectories and {2*n} correlated raw/H200 outputs, independently reviewed. '
               f'Frozen choices: {choices}; eligible winner: {winner}. Fresh H200 KDA-minus-MHA deltas at widths64/256: {deltas("kda", "mha")}. ' +
               (f'The frozen {winner} recipe passes the full adoption rule and becomes the observed incumbent.' if adopt else
                'The complete frozen adoption rule is not met; retain the prior incumbent.'))
    chosen_lrs={r['selection']['choices'][f]['lr'] for f in FAMILIES}
    tuning = ('Both arms selected the same peak LR; confirmation compares the family changes at that LR.' if len(chosen_lrs)==1 else
              'The arms selected different peak LRs, so tuned confirmation includes both attention-family and LR changes. Fixed-LR screens are reported separately.')
    limits = [
        'Fresh development seeds and reused full validation remain adaptive evidence. Conditional text intervals are not seed-population uncertainty, independent holdout, or adjusted significance.',
        f'{n} physical trajectories produce {2*n} correlated raw/H200 outputs. Exact prospective reference aliases are not independent repeats.',
        'Only the frozen width-64 winner is eligible for adoption. No alternate fallback, larger-width reselection, LR-grid extension or completed-trial rerun.',
        'The KDA adaptation derives alpha bottleneck D/4 under its named policy; the human default outside this policy is unchanged. Matrix width factors are prospective conventions, not demonstrated optimal muP transfer.',
        'KDA changes recurrence, causal convolution, positional mechanism, gating and initializer draws jointly. It is an all-KDA dense-SwiGLU local adaptation, not a reproduction of the cited hybrid system.',
        'Shared final-reviewed constant independent decay,3000-update cooldown and H200 policy; inner optimizer decay stays zero. '+tuning,
        'Equal3,000 updates and3,072,000 targets do not imply equal compute. Training time is measured separately; no serving-speed or peak-accelerator-memory claim.',
        'H200 tensors match final raw-parent shadows, but saved endpoints cannot reconstruct every historical averaging snapshot. Preserve earlier MPS reproducibility failures without an identified cause.',
        'H200 checkpoints are inference-only; optimizer continuation requires the original raw training parent.'
    ]
    con = dict(summary=summary, means=means, cost=cost, comparisons=r['comparisons'], fixed_lr_screen=r['fixed_lr_screen'],
        selection=r['selection'], quality_decision=v['quality_decision'], limitations=limits,
        review=str(run/'review.json'), historical_incumbent_unchanged=not adopt)
    if not args.record:
        print(json.dumps(con, indent=2))
        return
    conpath = BASE/'research_state/kda-quality-conclusion.json'
    snapshot = BASE/'research_state/kda-quality-completed-knowledge-snapshot.md'
    archive = BASE/'research_state/best-observed-before-kda-quality001.json'
    bestpath = BASE/'research_state/best-observed-config.json'
    old = json.loads(bestpath.read_text())
    # Preserve any appended learnings, but never overwrite a concurrently changed incumbent.
    frozen = p['incumbent_snapshot']
    assert file_digest(Path(frozen['path'])) == frozen['sha256']
    prior = json.loads(Path(frozen['path']).read_text())
    assert old['result_id'] == prior['result_id'] == frozen['result_id']
    for key in ('baseline_commit', 'baseline_config', 'config_overrides', 'returned_weights', 'selection'):
        assert old.get(key) == prior.get(key), 'Incumbent changed during this round: '+key
    assert not conpath.exists() and not snapshot.exists()
    if adopt:
        assert not archive.exists()
    entry = dict(campaign=str(run), review=str(run/'review.json'), summary=summary,
                 means=means, quality_decision=v['quality_decision'])
    # Build the full new recipe before mutating any authoritative artifact.
    if adopt:
        lr = r['selection']['choices'][winner]['lr']
        cfg = copy.deepcopy(study.suite_spec(p, winner, lr)['candidate']['config'])
        assert cfg['training']['weight_averaging']['half_lives'] == [200]
        selected = [c for c in r['comparisons'] if c['candidate']==winner and c['reference']=='incumbent_reference']
        assert sorted(c['width'] for c in selected) == [64, 256]
        b = dict(label=f'Most promising observed recipe: four-layer {winner.upper()}/SwiGLU, H200',
            baseline_commit=p['git_commit'], baseline_config=cfg, config_overrides=[], reference_overrides={},
            source_campaign=str(run), source_iteration=None, evidence_path=str(run/'report.json'),
            source_contract=dict(source_sha256=p['source_sha256'], data_sha256=p['data_sha256']),
            previous_best=dict(path=str(archive), sha256=file_digest(bestpath), result_id=old['result_id']),
            returned_weights=dict(kind='spaced_tail_ema', half_life=200, purpose='inference_only_not_optimizer_resume',
                                  raw_training_parent_required=True, observed_training_config_has_three_shadows=False),
            selection=dict(path=str(run/'selection.json'), family=winner, learning_rate=lr, independent_decay=p['recipe']['weight_decay'],
                           rule='Only frozen eligible winner; mean gain>.005, every seed negative, all conditional text upper bounds<0 at both widths against required references'),
            quality_decision=v['quality_decision'], local_outcome='supported', transfer_outcome='supported_at_tested_widths',
            metrics=[dict(target=f'width-{c["width"]}', metric='full_validation_context128_ce_delta',
                          candidate_mean=means[winner][str(c['width'])]['H200'], baseline_mean=means['incumbent_reference'][str(c['width'])]['H200'],
                          **c['sensitivity'][0]) for c in selected],
            comparators=means, training_cost=cost, training_steps=3000, widths=[64, 256], seeds=list(SEEDS),
            holdout_consumed=False, stage1_control_retained_as_reference=True, ranking_scope=limits[0], limitations=limits,
            learning_ids=[], subsequent_algorithm_studies=[])
        for key in ('constant_reference', 'raw_cooldown_reference'):
            if key in old: b[key] = copy.deepcopy(old[key])
    else:
        b = copy.deepcopy(old)
    artifacts = [run/x for x in ('plan.json', 'selection.json', 'report.json', 'review.json')]
    artifacts += [folder/x for x in ('completion-audit.py', 'record-completion.py', 'review.json')]
    bank = KnowledgeBank(BASE/'research_state/knowledge')
    kid = bank.add(dict(kind='result', outcome='supported' if adopt else 'mixed', created_by='continuing-quality-research',
        title='KDA versus MHA on the reviewed cooldown/H200 recipe', summary=summary,
        scope=dict(source_commit=p['git_commit'], screen_seeds=[2261, 2262], confirmation_seeds=list(SEEDS), widths=[64, 256],
                   physical_trajectories=n, correlated_outputs=2*n, validation_targets=111538, holdout_consumed=False),
        details={**con, 'active_seconds':v['active_seconds'], 'disk_mb':v['disk_mb']},
        artifacts=[dict(path=str(a), sha256=file_digest(a)) for a in artifacts],
        related_ids=[p['preregistration_id'], p['implementation_id'], old['result_id']]))
    con['result_id'] = kid
    entry['result_id'] = kid
    if adopt:
        archive.write_bytes(bestpath.read_bytes()); archive.chmod(0o444)
        b['result_id'] = kid
    else:
        b.setdefault('subsequent_algorithm_studies', []).append(entry)
    b['last_reviewed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conpath.write_text(json.dumps(con, indent=2)+'\n')
    bestpath.write_text(json.dumps(b, indent=2)+'\n')
    snapshot.write_text(bank.export_markdown()); snapshot.chmod(0o444)
    lines = ['# KDA quality results', '', summary, '',
        f'Historical source `{p["git_commit"]}`. Result `{kid}`. All {2*n} raw/H200 checkpoint hashes and payload contracts, requests/results, optimizer/decay/RNG/schedule/attention-alpha-convolution-head-FFN-shape/full-coverage contracts, frozen choices, aliases and complete report/bootstrap were independently reviewed. No training/evaluation rerun or holdout access.', '',
        f'Controller active time {v["active_seconds"]:.2f} seconds; output before review {v["disk_mb"]:.2f} MiB. [Frozen protocol](KDA_QUALITY_PROTOCOL.md).', '',
        '## Fresh confirmation means', '', 'Seeds 2271/2272/2273; 111,538 validation targets once each. H200 is primary; raw is a correlated diagnostic.', '',
        '| Recipe | Decay | Selected LR | H200 CE64 | H200 CE256 | Raw CE64 | Raw CE256 |', '|---|---:|---:|---:|---:|---:|---:|']
    for f in FAMILIES + ('incumbent_reference',):
        lr = p['recipe']['learning_rate'] if f=='incumbent_reference' else r['selection']['choices'][f]['lr']
        coefficient=p['recipe']['weight_decay']
        lines.append(f'| {f} | {coefficient:g} | {lr:g} | {means[f]["64"]["H200"]:.6f} | {means[f]["256"]["H200"]:.6f} | {means[f]["64"]["raw"]:.6f} | {means[f]["256"]["raw"]:.6f} |')
    lines += ['', '## Paired contrasts', '', 'Positive is worse. Intervals use 4,096-token blocks; all three block sizes were audited. Contrast support alone does not determine adoption.', '',
        '| Endpoint | Width | Contrast | Mean delta | Paired seed deltas | Conditional 95% text interval | Primary support |', '|---|---:|---|---:|---|---|---|']
    for c in r['comparisons']:
        for key, label in (('sensitivity', 'H200'), ('raw_sensitivity', 'Raw')):
            z=c[key][1]; lo, hi=z['conditional_text_bootstrap_95pct']
            ds=' / '.join(f'{z["paired_seed_deltas"][str(k)]:+.6f}' for k in SEEDS)
            support=str(c['quality_improvement']) if label=='H200' else 'Diagnostic'
            lines.append(f'| {label} | {c["width"]} | {c["candidate"]} minus {c["reference"]} | {z["mean_delta"]:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] | {support} |')
    lines += ['', '## Fixed-LR screens', '', '| LR | Contrast | H200 mean delta | Two seed deltas | Raw mean delta |', '|---|---|---:|---|---:|']
    for x in r['fixed_lr_screen']:
        ds=' / '.join(f'{x["primary"]["paired_seed_deltas"][str(k)]:+.6f}' for k in (2261,2262))
        lines.append(f'| {x["lr"]} | {x["candidate"]} minus {x["reference"]} | {x["primary"]["mean_delta"]:+.6f} | {ds} | {x["raw"]["mean_delta"]:+.6f} |')
    lines += ['', '## Measured training costs', '', '| Recipe | Width | Training seconds | Trajectory wall seconds | Ratio versus MHA | Sampled RSS MiB |', '|---|---:|---:|---:|---:|---:|']
    for f in cost:
        for w,x in cost[f].items():
            lines.append(f'| {f} | {w} | {x["mean_training_seconds"]:.2f} | {x["mean_trajectory_wall_seconds"]:.2f} | {x["training_time_ratio_vs_mha"]:.3f} | {x["mean_sampled_rss_mb"]:.2f} |')
    lines += ['', '## Limits', ''] + ['- '+x for x in limits]
    Path('/private/tmp/KDA_QUALITY_RESULTS.md').write_text('\n'.join(lines)+'\n')
    Path('/private/tmp/kda-quality-completed-guide-addition.md').write_text('## Completed KDA round\n\n'+summary+'\n\n[Full paired results and costs](KDA_QUALITY_RESULTS.md). Adaptive validation; no holdout.\n')
    print(kid); print(summary)


if __name__ == '__main__':
    main()
