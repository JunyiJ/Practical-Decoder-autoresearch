"""Synthetic report corruption checks; no KDA quality measurements."""
import copy,importlib.util
from pathlib import Path
import pytest
from src.research import kda_quality_study as study
from tests.test_kda_quality_study import plan,complete
from tests.test_schedule_study import coverage
spec=importlib.util.spec_from_file_location('independent_report_audit',Path(__file__).with_name('report-audit.py'))
independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)

@pytest.mark.parametrize('lr',[.005,.0025,.00125])
@pytest.mark.parametrize('best',['mha','kda'])
def test_alias_and_distinct_reference_frozen_decisions(lr,best):
 p=plan();s=complete(p,lr,best);r=study.summarize(p,s)
 v=independent.audit(p,s,r)
 assert v['physical_trajectories']==(24 if lr==.005 else 30)
 assert v['quality_decision']==r['quality_decision']

def test_largest_width_failure_is_not_reselection():
 p=plan();s=complete(p)
 for row in s['records']:
  if row['stage']=='confirmation' and row['family']=='kda' and row['width']==256:
   row['averaged_outputs']['200']['coverage']['evaluations']['128']=coverage(2.1)
 r=study.summarize(p,s);v=independent.audit(p,s,r)
 assert not v['quality_decision']['qualifies_for_incumbent_replacement']

@pytest.mark.parametrize('mutation',['interval','raw_interval','paired_seed','fixed_lr','count','alias','decision','duplicate_comparison','missing_comparison','manifest','local_mean','local_hash','primary_mean','coverage_boundary','holdout'])
def test_corrupted_report_rejected(mutation):
 p=plan();s=complete(p);r=copy.deepcopy(study.summarize(p,s))
 if mutation=='interval':r['comparisons'][0]['sensitivity'][1]['conditional_text_bootstrap_95pct'][1]+=.1
 elif mutation=='raw_interval':r['comparisons'][0]['raw_sensitivity'][2]['conditional_text_bootstrap_95pct'][0]+=.1
 elif mutation=='paired_seed':r['comparisons'][0]['sensitivity'][0]['paired_seed_deltas']['2271']+=.1
 elif mutation=='fixed_lr':r['fixed_lr_screen'][0]['primary']['mean_delta']+=.1
 elif mutation=='count':r['physical_training_trajectories']+=1
 elif mutation=='alias':r['reference_aliases']={}
 elif mutation=='decision':r['quality_decision']['qualifies_for_incumbent_replacement']=False
 elif mutation=='duplicate_comparison':r['comparisons'][-1]=copy.deepcopy(r['comparisons'][0])
 elif mutation=='missing_comparison':r['comparisons'].pop()
 elif mutation=='manifest':
  r['selection']['confirmation']['jobs'][-1][3]=2274;s['selection']=copy.deepcopy(r['selection'])
 elif mutation=='local_mean':
  r['selection']['choices']['kda']['mean_ce']+=.1;s['selection']=copy.deepcopy(r['selection'])
 elif mutation=='local_hash':
  r['selection']['local_evidence_sha256']='0'*64;s['selection']=copy.deepcopy(r['selection'])
 elif mutation=='primary_mean':
  r['records'][0]['averaged_outputs']['200']['coverage']['evaluations']['128']['mean_ce']+=.1;s['records']=copy.deepcopy(r['records'])
 elif mutation=='coverage_boundary':
  counts=r['records'][0]['coverage']['128']['block_target_counts'];counts[0]-=1;counts[1]+=1;s['records']=copy.deepcopy(r['records'])
 elif mutation=='holdout':r['holdout_consumed']=True
 with pytest.raises(AssertionError):independent.audit(p,s,r)
