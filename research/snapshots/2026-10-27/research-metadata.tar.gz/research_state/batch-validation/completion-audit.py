import json,math,datetime,copy
from pathlib import Path
import torch,numpy as np
from omegaconf import OmegaConf
from src.research import batch_study as ci
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result,disk_mb
from src.research.team.suite import _request
from src.models.gpt import GPT
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/batch-sensitivity-001'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());report=json.loads((run/'report.json').read_text())
ci.verify_lineage(p);assert s['status']=='completed' and len(s['records'])==48
assert digest(p)==s['plan_sha256']=='98393d5f07b8132fb3f06daa81884d42218527bb0a19867a768ada6ce2e1098d'
assert p==json.loads((root/'research_state/batch-plan.json').read_text())
assert s['selection']==json.loads((run/'selection.json').read_text())
expected=[list(x) for x in ci.local_jobs(p)]+s['selection']['confirmation']['jobs']
assert [[r[k] for k in ['family','lr','width','seed']] for r in s['records']]==expected
assert s['selection']['confirmation']['reference_aliases']=={'deep_reference':'d4_mha_b8'}
assert len({r['trial_id'] for r in s['records']})==48
assert s['active_seconds']<21600 and disk_mb(run)<2048
checks=[];torch.set_num_threads(1)
for i,r in enumerate(s['records']):
 assert r['status']=='completed' and r['error'] is None and r['duration_seconds']<1200
 d=run/'trials'/r['trial_id'];req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ['request','result']:assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(ci.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];checked=validate_result(raw,req,dict(device='mps',training={**cfg['training'],'block_size':cfg['model']['block_size']}),d)
 extra=ci.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert [m['step'] for m in raw['metrics']]==list(range(0,cfg['training']['max_iters'],cfg['training']['eval_every']))+[cfg['training']['max_iters']-1]
 assert raw['eval_iters']==30 and raw['eval_every']==cfg['training']['eval_every']
 cp=torch.load(r['checkpoint'],map_location='cpu',weights_only=False)
 assert cp['step']==cfg['training']['max_iters'] and cp['model_math_version']==2 and cp['parameter_layout_version']==2
 actual=cp['cfg'];want=copy.deepcopy(cfg);want['model']['vocab_size']=65
 assert actual==want,(r['trial_id'],'cfg')
 assert cp['step']*cfg['training']['batch_size']*128==3072000
 ratio=cfg['training']['batch_size']//8
 expected_decay=.00006 if ratio==1 else -math.expm1(ratio*math.log1p(-.00006))
 assert cfg['training']['weight_decay']==expected_decay
 contract=cp['training_state']['contract']
 assert contract==dict(batch_layout='paired_batch512',optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],data_sha256=p['data_sha256'],data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',training={k:want['training'][k] for k in ['batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters']})
 assert cp['training_state']['metrics']==raw['metrics']
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed']);max_start=int(.8*len(Path(cfg['data']['path']).read_text()))-512
 for _ in range(3000):torch.randint(max_start,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==expected_decay
 model=GPT(OmegaConf.create(want['model']));weights=cp['model_state'];model.load_state_dict(weights,strict=True)
 assert all(torch.isfinite(t).all().item() for t in weights.values())
 named=dict(model.named_parameters());seen=[]
 for opt in cp['optimizer_state']['optimizers']:
  for group in opt['param_groups']:
   name=group['parameter_names'][0];seen.append(name);param=named[name]
   hidden=name.startswith('transformer.h.') and param.ndim==2
   scale=1/math.sqrt(r['width']/64) if hidden else 1.0
   assert group['width_lr_scale']==scale and group['lr']==r['lr']*scale and group['weight_decay']==0
   assert len(group['params'])==1
   state=opt['state'][group['params'][0]]
   if hidden:assert group['momentum']==.95 and group['adjust_lr_fn']=='match_rms_adamw' and set(state)=={'momentum_buffer'}
   else:assert group['betas']==(.9,.999) and state['step'].item()==cp['step']
   for key,value in state.items():
    assert torch.isfinite(value).all().item()
    if key!='step':assert value.shape==param.shape
 assert set(seen)==set(named) and len(seen)==len(named)
 w=r['width'];sett=ci.settings(r['family']);depth=sett['depth'];gqa=sett['attention']=='gqa'
 for layer in range(depth):
  prefix=f'transformer.h.{layer}.'
  assert list(weights[prefix+'attn.qkv.weight'].shape)==[(2 if gqa else 3)*w,w]
  assert list(weights[prefix+'attn.out.weight'].shape)==[w,w]
  if r['family']!='gelu_reference':
   for n in ['linear_gate','linear_up']:assert list(weights[prefix+'mlp.'+n+'.weight'].shape)==[21*w//8,w]
   assert list(weights[prefix+'mlp.linear_down.weight'].shape)==[w,21*w//8]
  assert list(weights[prefix+'freq_cos'].shape)==[sett['context'],16]
 assert not any('wpe' in k for k in weights)
 params=sum(t.numel() for t in model.parameters())
 for ev in r['coverage'].values():
  assert ev['block_target_counts']==[2048]*54+[946]
  assert math.isclose(sum(ev['block_loss_sums'])/111538,ev['mean_ce'],abs_tol=1e-12)
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],result_sha256=r['result_sha256'],parameter_count=params))
 if (i+1)%30==0:print('Verified',i+1,flush=True)
assert ci.summarize(p,s)==report
assert ci.freeze_selection(p,s['records'][:18])==s['selection']
assert (run/'selection.json').stat().st_mtime <= min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'][18:])
# Independent arithmetic and conditional-bootstrap reconstruction for every reported contrast.
rows={(r['family'],r['width'],r['seed']):r for r in s['records'] if r['stage']=='confirmation'}
for c in report['comparisons'] + [{**v,'width':64,'screening':True} for v in report['screening_fixed_lr_comparisons']]:
 rows={(r['family'],r['width'],r['seed']):r for r in s['records'] if r['stage']==('local' if c.get('screening') else 'confirmation') and (not c.get('screening') or r['lr']==.0025)}
 if not c.get('screening'):
  for alias,family in s['selection']['confirmation']['reference_aliases'].items():
   for w in [64,256]:
    for seed in ci.CONFIRM_SEEDS:rows[alias,w,seed]=rows[family,w,seed]
 seeds=ci.SCREEN_SEEDS if c.get('screening') else ci.CONFIRM_SEEDS
 for key,context in [('sensitivity',128),('native_sensitivity',ci.settings(c['candidate'])['context'])]:
  if key not in c:continue
  for v in c[key]:
   aa=[rows[c['candidate'],c['width'],seed]['coverage'][str(context)] for seed in seeds];bb=[rows[c['reference'],c['width'],seed]['coverage'][str(context)] for seed in seeds]
   diffs=np.array([np.array(a['block_loss_sums'])-b['block_loss_sums'] for a,b in zip(aa,bb)]).mean(0);counts=np.array(aa[0]['block_target_counts']);factor=v['text_block_tokens']//2048
   chunks=np.array([diffs[j:j+factor].sum() for j in range(0,len(diffs),factor)]);cnt=np.array([counts[j:j+factor].sum() for j in range(0,len(counts),factor)])
   idx=np.random.default_rng(20261024).integers(len(cnt),size=(2000,len(cnt)));boot=chunks[idx].sum(1)/cnt[idx].sum(1)
   assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
   assert math.isclose(chunks.sum()/cnt.sum(),v['mean_delta'],abs_tol=1e-12)
   for seed,a,b in zip(seeds,aa,bb): assert math.isclose(a['mean_ce']-b['mean_ce'],v['paired_seed_deltas'][str(seed)],abs_tol=1e-12)
 if 'near_neutral_common128' in c:
  eligible=all(v['mean_delta']<=.01 and max(v['paired_seed_deltas'].values())<=.01 and v['conditional_text_bootstrap_95pct'][1]<=.01 for v in c['sensitivity'])
  assert eligible==c['near_neutral_common128']
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),distinct_checkpoints=48,screen_trials=18,confirmation_and_reference_trials=30,reference_aliases={'deep_reference':'d4_mha_b8'},active_seconds=s['active_seconds'],disk_mb=disk_mb(run),holdout_consumed=False,training_rerun=False,checks=['Every raw request/result and checkpoint hash; frozen recipes; runtime; 3000/1500/750 updates, batch8/16/32, matched nominal cumulative decay and3072000 targets','Every saved checkpoint configuration, sampler/optimizer/resume contract, reconstructed final private train RNG and untouched test RNG, optimizer slot shapes/finiteness/step counts/groups/width factors, layer/head/QKV/FFN shapes, strict CPU model loading and finite tensors','Full validation111538 targets, exact2048-block counts/sums, common context128 and evaluation batch8','Exact18 screening and30 fresh confirmation/reference order; frozen selection and six prospective deep-reference aliases','Complete report regenerated from saved records; all paired means/conditional bootstrap intervals independently reconstructed; quality gates checked','Source, corpus, runtime, full knowledge bank and all prerequisite artifacts verified before documentation changes','Controller and worker exited; no training/evaluation reruns or held-out access'],checkpoint_audit=checks)
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('VERIFIED',review['active_seconds'],review['disk_mb'])
