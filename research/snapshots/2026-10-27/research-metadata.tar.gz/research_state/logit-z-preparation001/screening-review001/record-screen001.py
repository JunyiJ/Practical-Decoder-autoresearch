import json,hashlib,shutil,statistics,html
from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
from src.research.team.knowledge import KnowledgeBank
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');P=B/'research_state/logit-z-preparation001';R=B/'research_runs/logit-z-quality-001';O=P/'screening-review001';now=datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,v):
 assert not p.exists(),p
 p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n' if not isinstance(v,str) else v);p.chmod(0o444)
r=json.loads((O/'review.json').read_text());state=json.loads((R/'state.json').read_text());rows=[x for x in state['records'] if x['stage']=='local'];assert len(rows)==18
assert r['selection_sha256']==sha(R/'selection.json')
sel=json.loads((R/'selection.json').read_text());assert r['winner']==sel['winner'] and r['choices']==sel['choices']
total=r['confirmation']['total_distinct_trials'];assert total in (36,42)
def score(f,lr,s):return next(x['metric'] for x in rows if x['family']==f and x['lr']==lr and x['seed']==s)
def compare(a,b,la,lb):
 d={str(s):score(a,la,s)-score(b,lb,s) for s in (2501,2502)}
 return dict(candidate=a,reference=b,candidate_lr=la,reference_lr=lb,paired_seed_deltas=d,mean_delta=statistics.mean(d.values()),every_seed_negative=max(d.values())<0)
pairs=[('z1e4','none'),('z1e3','none'),('z1e3','z1e4')]
fixed=[compare(a,b,lr,lr) for lr in (.0025,.005,.01) for a,b in pairs]
selected=[compare(a,b,r['choices'][a]['lr'],r['choices'][b]['lr']) for a,b in pairs]
write(O/'fixed-lr-comparisons.json',dict(fixed_lr=fixed,selected_lr=selected,scope='Screening seeds only; selected LR recipe contrasts separate from equal-LR screens; not fresh confirmation, no tensor/model evaluation rerun.'))
labels={'none':'Unpenalized','z1e4':'Z=0.0001','z1e3':'Z=0.001'}
choices='; '.join(f"{labels[f]} LR{r['choices'][f]['lr']:g}, H200 CE{r['choices'][f]['mean_ce']:.12f}" for f in labels)
decision=('unpenalized is the best selected arm and exactly matches the fixed incumbent, so retention is frozen.' if r['winner']=='incumbent_unchanged' and r['best_selected_arm']=='none' and all(x['mean_delta']==0 for x in r['local_contrasts']) else 'Retention is frozen because the best selected arm fails the prospective eligibility rule.' if r['winner']=='incumbent_unchanged' else f"{labels[r['winner']]} is the frozen locally eligible candidate; adoption still requires the complete fresh confirmation and final audit.")
aliases=r['confirmation']['reference_aliases']
alias_text=('Six fixed-reference confirmation cells prospectively alias selected unpenalized; they are not independent repeats.' if aliases else 'Six fresh fixed-reference confirmation trajectories are distinct from the selected arms.')
summary=f'Width64 logit-z screening18/18 independently audited. {choices}. {decision} No grid extension, alternative fallback or larger-width reselection; incumbent unchanged pending full audit.'
bank=KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='result',title=f"Logit-z screening18/18 independently audited: frozen {r['winner']}",summary=summary,created_by='codex',outcome='reported',scope=dict(study='logit-z-quality-001',stage='screening',source=r['source_commit']),details=dict(review=r,selected_comparisons=selected,fixed_lr_comparisons=fixed),artifacts=[art(O/'review.json'),art(O/'fixed-lr-comparisons.json'),art(P/'screening-audit-first.log')]))
write(O/'knowledge.json',dict(result_id=kid,recorded_at=now));write(P/'screen-completed-knowledge-snapshot001.md',bank.export_markdown())
prose=f'''### Logit-z screening: frozen choice; confirmation pending

All18 width64 screens passed independent request/result/config/runtime/prior/full-coverage and36 raw/H200 checkpoint-hash audit, without tensor loads or training/evaluation reruns. {choices}. {decision} No alternative fallback, grid extension or larger-width promotion.

Selected Z=0.0001 minus unpenalized is {selected[0]['mean_delta']:+.12f}; Z=0.001 minus unpenalized is {selected[1]['mean_delta']:+.12f}; Z=0.001 minus Z=0.0001 is {selected[2]['mean_delta']:+.12f}. Selected recipes may use different LRs; all nine fixed-LR screen contrasts are recorded separately. These are screening comparisons, not fresh confirmation. All selected arms continue at both widths. There are {total} physical trajectories/{2*total} correlated raw-H200 outputs. {alias_text} The incumbent is unchanged. Full checkpoint tensor/optimizer/RNG/objective/H200/report/bootstrap audit remains mandatory after completion and controller/worker exit. All rankings use pure CE; the training-only penalty changes logit coordinates and gradients. No identified instability, isolated confidence mechanism or optimal muP claim. Zero-objective logZ diagnostics remain null; nonzero telemetry is checked separately.
'''
write(P/'screen-guide-addition.md',prose)
page=B/'research_state/reports/pretraining-learning-guide/index.html';before=page.read_text();write(P/'screen-guide-before001.html',before)
old='<strong>Logit-z experiment launched; quality pending.</strong>'
assert before.count(old)==1
new=f'<strong>Logit-z screening18/18 is independently audited; fresh confirmation is running.</strong> {html.escape(choices)}. {html.escape(decision)} No fallback or larger-width reselection. All36 screening checkpoint hashes and request/result/full-coverage contracts passed; final tensor/optimizer/RNG/full-report audit is still required. <a href="{(O/"review.json").as_uri()}">Screen audit</a>.'
after=before.replace(old,new).replace('No quality result or incumbent change yet.','No incumbent change; full confirmation audit remains pending.');page.write_text(after)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.paths=[]
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ('src','href') and v:
    u=urlparse(v)
    if u.scheme=='file':self.paths.append(Path(unquote(u.path)))
    elif not u.scheme and u.path:self.paths.append((page.parent/unquote(u.path)).resolve())
p=Links();p.feed(after);assert all(x.exists() for x in p.paths),[str(x) for x in p.paths if not x.exists()]
write(P/'screen-guide-review001.json',dict(status='content_and_local_references_verified',at=now,html=art(page),prior_html=art(P/'screen-guide-before001.html'),local_references=len(p.paths),source_guide_unchanged=True,deferred_addition=art(P/'screen-guide-addition.md'),browser_layout_verified=False,limitation='Prior local-file URL policy refusal preserved; no workaround. Full final audit required.'))
for name in ('quality-evolution-progress.json','research-monitor.json'):
 f=B/'research_state'/name;data=json.loads(f.read_text());write(P/('screen-before-'+name),data)
 assert data['active_stage']=='logit_z' and data['status']=='running'
 data['logit_z_screening_review']=dict(path=str(O/'review.json'),result_id=kid,winner=r['winner'],physical_trajectories=total,correlated_outputs=2*total)
 data['logit_z_screening_notified']=True;data['last_meaningful_update_at']=now
 tmp=f.with_suffix('.tmp-logit-screen');tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');tmp.replace(f)
shutil.copyfile(__file__,O/'record-screen001.py');(O/'record-screen001.py').chmod(0o444);(P/'screening-audit-first.log').chmod(0o444)
print(json.dumps(dict(result_id=kid,choices=r['choices'],winner=r['winner'],local_contrasts=r['local_contrasts'],selected=selected,fixed_lr005=[x for x in fixed if x['candidate_lr']==.005],physical=total,local_refs=len(p.paths)),indent=2))
