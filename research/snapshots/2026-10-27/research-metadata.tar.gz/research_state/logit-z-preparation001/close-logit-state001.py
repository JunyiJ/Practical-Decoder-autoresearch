from pathlib import Path
import datetime,json,hashlib,subprocess,shutil
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');Z=B/'research_state/logit-z-preparation001';P=B/'research_state/null-attention-preparation001';R=B/'research_runs/logit-z-quality-001';now=datetime.datetime.now(datetime.timezone.utc).isoformat()
v=json.loads((R/'review.json').read_text());c=json.loads((B/'research_state/logit-z-quality-conclusion.json').read_text());assert v['status']=='verified' and v['distinct_checkpoints']==72
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert commit=='2f69633da1a2c560952b1738db2c47a0927e9133'
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=S,text=True).split()[0]==commit
for root in (B,S):assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='63d397017a5a692ded7847a61c7768871c72ee71'
before=Z/'completion-state-before001';before.mkdir()
for name in ['active-campaign.json','quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;raw=p.read_bytes();(before/name).write_bytes(raw);(before/name).chmod(0o444);x=json.loads(raw)
 x.setdefault('metadata_history',[]).append(dict(recorded_at=now,reason='Final logit-z audit and findings published; preserve stale observations as history',before=str(before/name)))
 x['status']='completed_reviewed';x['completed_reviewed_at']=now;x['findings_commit']=commit;x['completion_review']=str(R/'review.json');x['result_id']=c['result_id']
 if name!='active-campaign.json':
  x['next_stage']='review_null_attention_source_and_prepare_bounded_cpu_validation';x['logit_z_completion_notified']=True;x['logit_z_record_count']=36
  x['logit_z_latest_observation']=dict(observed_at=now,status='completed_reviewed',completed=36,controller_pids=[],worker_pids=[],source_commit=v['source_commit'],review=str(R/'review.json'))
  if 'logit_z_preparation' in x:x['logit_z_preparation'].update(status='completed_reviewed',pending='Closed study; never rerun or extend.',full_regression_passed=True,research_completed_reviewed=True)
  x['next_preparation']['inheritance_pending_final_logit_z']=False;x['next_preparation']['resolved_predecessor']=str(P/'resolved-final-predecessor001.json')
  x['next_preparation']['pending']='Manual full-source review, CPU bounded tools and prospective budget/count, integration after reviewed docs, actual28 plus full regression, six fresh serial MPS/resource/publication/new preregistration. No null research launched.'
 tmp=p.with_suffix('.tmp-logit-close');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
review=dict(status='completed_reviewed_published',recorded_at=now,findings_commit=commit,historical_source=v['source_commit'],result_id=c['result_id'],physical_trajectories=36,correlated_checkpoints=72,independent_auditor_first_try=True,recorder_preview_record_first_try=True,plot_render_first_try=True,figure_visually_reviewed=True,html_local_references=189,html_layout_verified=False,training_or_scoring_rerun=False,primary_clean_untouched=True,source_clean=True,next_preparation=str(P/'prototype-review003.json'))
p=Z/'completion-publication-review001.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');p.chmod(0o444)
for f in [__file__,'/private/tmp/document-logit-completion001.py','/private/tmp/verify-logit-docs001.py']:
 dst=Z/Path(f).name;assert not dst.exists();shutil.copyfile(f,dst);dst.chmod(0o444)
print(json.dumps(review))
