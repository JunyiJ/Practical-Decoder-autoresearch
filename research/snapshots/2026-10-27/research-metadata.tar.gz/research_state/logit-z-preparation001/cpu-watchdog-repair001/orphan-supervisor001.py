from pathlib import Path
import os,stat,time,json,subprocess,signal,shutil,datetime
P=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-preparation001');R=P/'cpu-watchdog-repair001';pid=49096;root=Path('/private/tmp/rsi-logit-z-cpu001/batch-0084');log=P/'cpu-batch-0084.log';birth=log.stat().st_birthtime
rows=[]
def size():
 total=0;missing=0
 for base,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=[d for d in dirs if not Path(base,d).is_symlink()]
  for name in files:
   try:s=Path(base,name).lstat()
   except FileNotFoundError:missing+=1;continue
   if stat.S_ISREG(s.st_mode):total+=s.st_size
 return total,missing
reason=None
try:
 while True:
  ps=subprocess.run(['ps','-p',str(pid),'-o','pid=,ppid=,stat=,command='],capture_output=True,text=True)
  if ps.returncode!=0 or not ps.stdout.strip():break
  if 'pytest.main' not in ps.stdout or 'test_position_family_training.py' not in ps.stdout:raise ValueError('PID identity changed')
  n,missing=size();free=shutil.disk_usage('/private/tmp').free;elapsed=time.time()-birth
  rows.append(dict(at=time.time(),bytes=n,free=free,elapsed=elapsed,missing=missing))
  if elapsed>600 or n>8*2**30 or free<2*2**30:raise RuntimeError('Orphan monitoring conservative reservation or resource cap exceeded')
  time.sleep(.5)
except BaseException as e:
 reason=repr(e)
 try:os.killpg(pid,signal.SIGTERM)
 except ProcessLookupError:pass
 finally:
  time.sleep(1)
  ps=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
  if 'test_position_family_training.py' in ps.stdout:
   try:os.killpg(pid,signal.SIGKILL)
   except ProcessLookupError:pass
finally:
 out=dict(status='worker_exited_observed' if reason is None else 'stopped_by_supervisor',error=reason,pid=pid,exit_code=None,exit_code_reason='Original parent exited; observer cannot recover wait status.',log=str(log),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),birthtime=birth,charged_wall_seconds=600,observations=rows)
 (R/'orphan-observation.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k!='observations'}))
