import unittest,sys,json,copy,ast
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'cpu-tools002'))
from recovery import validate_orphan
class Recovery(unittest.TestCase):
 def test_preserved_orphan_and_corruptions(self):
  r=P/'cpu-watchdog-repair001';item=json.loads((r/'orphan-batch.json').read_text());receipt=json.loads((r/'orphan-scratch-preserved.json').read_text());text=Path(item['log']).read_text();ids=item['expected_ids']
  self.assertEqual(len(validate_orphan(item,receipt,text,ids)['ids']),12)
  for key,val in [('exit_code',0),('seconds',601),('process_exit_status','exit_zero'),('file','tests/test_other.py')]:
   bad=copy.deepcopy(item);bad[key]=val
   with self.assertRaises(ValueError):validate_orphan(bad,receipt,text,ids,False)
  for key,val in [('status','passed_scratch_removed'),('exit_code',0),('bytes',0),('log_sha256','bad'),('batch','/tmp/other'),('verified',{})]:
   bad=copy.deepcopy(receipt);bad[key]=val
   with self.assertRaises(ValueError):validate_orphan(item,bad,text,ids,False)
  with self.assertRaises(ValueError):validate_orphan(item,receipt,text.replace('PASSED','FAILED',1),ids,False)
 def test_exact_continuation_boundary_and_no_recollection(self):
  r=P/'cpu-watchdog-repair001';m=json.loads((r/'cpu-execution-manifest.json').read_text());item=json.loads((r/'orphan-batch.json').read_text());ids=m['collection']['ids'];actual=['tests/test_logit_z_geometry.py','tests/test_logit_z_training.py'];files=actual+sorted({n.split('::')[0] for n in ids}-set(actual))
  complete=[n for b in m['batches']+[item] for n in b['expected_ids']];remaining=[n for f in files[85:] for n in ids if n.startswith(f+'::')]
  self.assertEqual(len(complete),3095);self.assertEqual(len(remaining),2594);self.assertFalse(set(complete)&set(remaining));self.assertEqual(set(complete+remaining),set(ids))
  tree=ast.parse((P/'cpu-tools002/continue-cpu-validation002.py').read_text());ranges=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='range']
  self.assertEqual(len(ranges),1);self.assertEqual(ast.literal_eval(ranges[0].args[0]),85)
  self.assertNotIn('--collect-only',(P/'cpu-tools002/continue-cpu-validation002.py').read_text())
  recorder=ast.parse((P/'cpu-tools002/record-cpu-review002.py').read_text());fn=next(x for x in recorder.body if isinstance(x,ast.FunctionDef) and x.name=='verify_records');ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'recorder','exec'),ns)
  with self.assertRaises(ValueError):ns['verify_records'](m,'',{}, {})
if __name__=='__main__':unittest.main(verbosity=2)
