import json,hashlib,re,datetime
from pathlib import Path
from urllib.parse import urlsplit,unquote
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');Z=B/'research_state/logit-z-preparation001';out=B/'research_state/reports/pretraining-learning-guide';c=json.loads((B/'research_state/logit-z-quality-conclusion.json').read_text());html=(out/'index.html').read_text();paths=[]
for uri in re.findall(r'(?:href|src)=["\']([^"\']+)',html):
 u=urlsplit(uri)
 if u.scheme not in ('','file') or not u.path:continue
 p=Path(unquote(u.path)) if u.scheme=='file' or u.path.startswith('/') else out/unquote(u.path)
 assert p.exists(),str(p);paths.append(str(p))
for f in ('none','z1e4','z1e3'):
 for w in ('64','256'):
  val=c['means'][f][w]['H200'];assert f'{val:.9f}' in html
  assert f'{val:.6f}' in (S/'research/LOGIT_Z_RESULTS.md').read_text()
assert 'Logit-z objective comparison is completed and independently reviewed.' in html
assert c['historical_incumbent_unchanged'] and c['quality_decision']['frozen_screen_winner']=='incumbent_unchanged'
review=dict(status='verified',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),local_references=len(paths),means_verified=6,figure_visually_reviewed=True,html_layout_verified=False,html_limitation='Prior local-file URL policy refusal preserved; no workaround.',paths=paths,files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [S/'research/LOGIT_Z_RESULTS.md',S/'research/LEARNING_GUIDE.md',S/'research/ARCHITECTURE_STAGE2.md',out/'logit-z-quality001.png',out/'logit-z-quality001.svg',out/'index.html']])
p=Z/'completion-documentation-review001.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');p.chmod(0o444);print(json.dumps({k:v for k,v in review.items() if k not in ('paths','files')}))
