from pathlib import Path
import ast
D=Path('/private/tmp/rsi-logit-z-development001')
def put(p,s):
 ast.parse(s);(D/p).write_text(s)
def family(s):
 for a,b in [('position_quality','logit_z'),('position-quality','logit-z-quality'),('2481','2501'),('2482','2502'),('2491','2511'),('2492','2512'),('2493','2513')]:s=s.replace(a,b)
 for a,b in [('rope','none'),('nope','z1e4'),('alibi','z1e3')]:
  s=s.replace("'"+a+"'","'"+b+"'").replace(a+'=',b+'=')
 return s
s=family((D/'src/research/position_quality_study.py').read_text())
s=s.replace('reviewed_value_residual','reviewed_position').replace('from . import value_residual_study as predecessor_study','from . import position_quality_study as predecessor_study').replace('from src.models.position_family import POLICY','from src.models.logit_z import POLICY, COEFFICIENTS, CONVENTION, logit_z_contract')
s=s.replace("POSITIONS = dict(none='none', z1e4='z1e4', z1e3='z1e3')", "OBJECTIVE = dict(convention=CONVENTION, training_only=True, validation_metric='pure_ce', ignore_index=-100, zero_diagnostics='null_without_extra_arithmetic')")
a=s.index('def backbone(');b=s.index('\n\ndef validate_plan',a)
s=s[:a]+'''def backbone(recipe, prior):
    expected={'warmup_steps','learning_rate','weight_decay','input_embedding_scale',
              'readout_norm_kind','readout_norm_epsilon','output_bias_kind',
              'weight_tying_kind','residual_topology_kind','attention_logit_scale',
              'gated_activation_kind','residual_gain_kind','value_residual_kind','position_family_kind'}
    if (not isinstance(recipe,dict) or set(recipe)!=expected
            or recipe['position_family_kind'] not in ('rope','nope','alibi')):
        raise ValueError('Invalid final reviewed position incumbent')
    m,t=predecessor_study.backbone({k:v for k,v in recipe.items() if k!='position_family_kind'},prior)
    m.update(position_family_kind=recipe['position_family_kind'],
             logit_z_kind='none',logit_z_coefficient=0.,logit_z_objective_policy=POLICY)
    logit_z_contract(m)
    return m,t
''' +s[b:]
s=s.replace('position_families=POSITIONS, position_family_policy=POLICY','logit_z_coefficients=COEFFICIENTS, logit_z_policy=POLICY, objective=OBJECTIVE')
s=s.replace("'gated_activation_kind','residual_gain_kind','value_residual_kind')", "'gated_activation_kind','residual_gain_kind','value_residual_kind','position_family_kind')")
s=s.replace("cfg['model']['position_family_kind']=POSITIONS['none' if family==REFERENCE else family]", "kind='none' if family==REFERENCE else family\n    cfg['model'].update(logit_z_kind=kind,logit_z_coefficient=COEFFICIENTS[kind])\n    logit_z_contract(cfg['model'])")
s=s.replace("for field in ('position_family_kind','position_family_width_policy'):", "for field in ('logit_z_kind','logit_z_coefficient','logit_z_objective_policy'):")
s=s.replace('Final value-residual','Final position').replace('final independently reviewed backbone','final independently reviewed position backbone')
s=s.replace('rope/nope/alibi','none/z1e4/z1e3').replace('tuned rope','tuned none').replace('changed position family','nonzero objective coefficient')
a=s.index("        scope='");b=s.index("')\n    p['screen_jobs']",a)
s=s[:a]+"        scope='Adaptive validation, equal updates/targets and bounded LR tuning on the FINAL reviewed position/value/gain/activation/attention/topology/table/bias/norm/input/cooldown/H200 recipe. Training CE plus lambda times mean squared logsumexp of final FP32 logits over the same valid targets; lambda 0/1e-4/1e-3, no centering, log-vocabulary subtraction, detach, clipping or width scaling. All sampled/full validation and selection use PURE CE. Zero arm preserves the historical CE arithmetic path with null logZ diagnostics. No new trainable parameters; same logit coordinate convention, common-shift penalty is not CE invariant. Penalty gradients alter the update path and LR interactions. Not optimal muP, identified instability, isolated confidence mechanism, equal compute, paper reproduction, holdout or seed-population evidence."+s[b:]
s=s.replace('Finite logit-z-quality comparison','Finite logit-z quality comparison')
put('src/research/logit_z_study.py',s)
# Final predecessor must reconstruct the whole completed POSITION study, not the live draft.
s=(D/'src/research/position_quality_predecessor.py').read_text()
s=s.replace('residual-gain','position-quality').replace('value-residual','position-quality').replace('value_residual_study','position_quality_study').replace('value_residual_audit','position_quality_audit').replace('reviewed_value_residual','reviewed_position')
s=s.replace('from src.models.value_residual import value_residual_contract','from src.models.value_residual import value_residual_contract\nfrom src.models.position_family import position_family_contract')
s=s.replace('    value_residual_contract(cfg[\'model\'])','    value_residual_contract(cfg[\'model\'])\n    position_family_contract(cfg[\'model\'])')
s=s.replace("residual_gain_kind=cfg['model']['residual_gain_kind'],value_residual_kind=cfg['model']['value_residual_kind'],config=cfg", "residual_gain_kind=cfg['model']['residual_gain_kind'],value_residual_kind=cfg['model']['value_residual_kind'],position_family_kind=cfg['model']['position_family_kind'],config=cfg")
put('src/research/logit_z_predecessor.py',s)
s=family((D/'src/research/position_quality_audit.py').read_text())
s=s.replace("assert p['position_families']==dict(none='none',z1e4='z1e4',z1e3='z1e3')", "assert p['logit_z_coefficients']==dict(none=0.,z1e4=.0001,z1e3=.001)\n    assert p['objective']==dict(convention='final_fp32_logsumexp_squared_valid_target_mean_v1',training_only=True,validation_metric='pure_ce',ignore_index=-100,zero_diagnostics='null_without_extra_arithmetic')")
s=s.replace("p['position_family_policy']=='mha4_position_family'", "p['logit_z_policy']=='mha4_final_logit_z'")
s=s.replace("assert p['recipe']['value_residual_kind'] in ('local','local_half','first_blend')", "assert p['recipe']['value_residual_kind'] in ('local','local_half','first_blend')\n    assert p['recipe']['position_family_kind'] in ('rope','nope','alibi')")
put('src/research/logit_z_audit.py',s)
# Controller metadata tests: change intervention fields without changing inherited position.
s=family((D/'tests/test_position_quality_study.py').read_text())
s=s.replace('from src.models.position_family import POLICY','from src.models.logit_z import POLICY, COEFFICIENTS')
s=s.replace('position_families=study.POSITIONS,position_family_policy=POLICY','logit_z_coefficients=COEFFICIENTS,logit_z_policy=POLICY,objective=study.OBJECTIVE')
s=s.replace("residual_gain_kind='unit',value_residual_kind='local'))", "residual_gain_kind='unit',value_residual_kind='local',position_family_kind='rope'))")
s=s.replace("assert m.pop('position_family_kind')==study.POSITIONS['none' if arm==study.REFERENCE else arm]", "kind='none' if arm==study.REFERENCE else arm\n    assert m.pop('logit_z_kind')==kind\n    assert m.pop('logit_z_coefficient')==COEFFICIENTS[kind]")
s=s.replace("expected.pop('position_family_kind');", "expected.pop('logit_z_kind');expected.pop('logit_z_coefficient');")
s=s.replace("('position_family_policy','arbitrary')", "('logit_z_policy','arbitrary')")
s=s.replace("m['none']==1", "m['rope']==1")
a=s.index('\ndef test_exact_position_study_name_and_fixed_bias_recipe():')
s=s[:a]+'''
@pytest.mark.parametrize('position',['rope','nope','alibi'])
@pytest.mark.parametrize('value',['local','local_half','first_blend'])
@pytest.mark.parametrize('gain',['unit','static_tenth','learned_tenth'])
def test_final_position_value_and_gain_shared_without_overwrite(position,value,gain):
    p=plan();p['recipe'].update(position_family_kind=position,value_residual_kind=value,residual_gain_kind=gain)
    p['config']['model'],p['config']['training']=study.backbone(p['recipe'],p['output_bias_prior'])
    study.validate_plan(p)
    for arm in study.FAMILIES+[study.REFERENCE]:
        m=study.suite_spec(p,arm,.01)['candidate']['config']['model']
        assert m['position_family_kind']==position and m['value_residual_kind']==value and m['residual_gain_kind']==gain
        kind='none' if arm==study.REFERENCE else arm
        assert m['logit_z_kind']==kind and type(m['logit_z_coefficient']) is float and m['logit_z_coefficient']==COEFFICIENTS[kind]
        assert m['position_family_width_policy']=='mha4_position_family' and m['rope']==1

@pytest.mark.parametrize('field,value',[('position_family_kind','unknown'),('position_family_kind',None),('position_family_kind',True)])
def test_invalid_position_inheritance_rejected(field,value):
    p=plan();p['recipe'][field]=value
    with pytest.raises(ValueError):study.validate_plan(p)

@pytest.mark.parametrize('field,value',[('training_only',False),('validation_metric','total_objective'),('ignore_index',0),('zero_diagnostics','compute_anyway'),('convention','centered')])
def test_objective_convention_and_pure_validation_are_frozen(field,value):
    p=plan();p['objective']=copy.deepcopy(p['objective']);p['objective'][field]=value
    with pytest.raises(ValueError):study.validate_plan(p)

def test_exact_study_identity_and_coefficient_grid():
    p=plan();assert p['study']=='logit-z-quality-v1'
    assert study.COEFFICIENTS==dict(none=0.,z1e4=.0001,z1e3=.001)
    p['logit_z_coefficients']=dict(none=0.,z1e4=.001,z1e3=.01)
    with pytest.raises(ValueError):study.validate_plan(p)
'''
put('tests/test_logit_z_study.py',s)
s=(D/'tests/test_position_quality_predecessor.py').read_text().replace('value_residual_study','position_quality_study').replace('position_quality_predecessor','logit_z_predecessor').replace('reviewed_value_residual','reviewed_position').replace('test_value_residual_study','test_position_quality_study').replace('2473','2493')
s=s.replace("family='local_half'", "family='nope'").replace("['local','local_half','first_blend']", "['rope','nope','alibi']").replace("tmp_path,'local'", "tmp_path,'rope'")
s=s.replace("expected_value=normalization.VALUES[family] if yes else 'local'", "expected_position=normalization.POSITIONS[family] if yes else 'rope'\n    expected_value='local'")
s=s.replace("assert r['value_residual_kind']", "assert r['position_family_kind']==r['config']['model']['position_family_kind']==expected_position\n    assert r['value_residual_kind']")
put('tests/test_logit_z_predecessor.py',s)
s=family((D/'tests/test_position_quality_report_audit.py').read_text())
put('tests/test_logit_z_report_audit.py',s)
print('Six new files AST parsed; no imports, model work or active-source edits.')
