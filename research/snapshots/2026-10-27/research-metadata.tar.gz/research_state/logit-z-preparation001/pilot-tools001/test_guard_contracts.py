"""Pure stdlib guard/wiring tests. Never execute a pilot, model or subprocess."""
import ast,copy,hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path
F=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pilot_preflight',F/'preflight.py');pf=importlib.util.module_from_spec(spec);spec.loader.exec_module(pf)
class Tests(unittest.TestCase):
 def test_publication_gate_and_corruptions(self):
  with tempfile.TemporaryDirectory(prefix='logit-pilot-metadata-') as d:
   root=Path(d).resolve();(root/'src').mkdir();(root/'src'/'x.py').write_text('x=1\n');(root/'requirements.txt').write_text('');original=root/'tested-original-protocol.md';original.write_text('original')
   path=root/'cpu-publication-review.json';cpu=dict(status='cpu_verified',source_sha256=pf.source_digest(root),full_tests=dict(passed=5689,collected=5689,failed=0,actual_tests=27,remaining_tests=5662,metadata_tests=535),actual_logit_z_geometry_tests_passed=15,actual_logit_z_training_tests_passed=12,logit_z_metadata_tests_passed=535,publication_status='protocol status only',publication_reviewed_at='synthetic',artifacts=[dict(path=str(original),sha256=pf.sha(original))])
   calls=[]
   def git(args,**kwargs):
    calls.append(args);return '' if args[1]=='status' else 'a'*40+'\n'
   def check(c,g=git):path.write_text(json.dumps(c));return pf.check(root,path,g)
   self.assertEqual(check(cpu)['source_commit'],'a'*40);self.assertEqual(len(calls),4)
   for key,val in [('status','running'),('source_sha256','b'*64),('actual_logit_z_geometry_tests_passed',14),('actual_logit_z_training_tests_passed',11),('logit_z_metadata_tests_passed',534),('publication_status',''),('publication_reviewed_at','')]:
    c=copy.deepcopy(cpu);c[key]=val
    with self.assertRaises(ValueError):check(c)
   for key,val in [('passed',5688),('collected',5688),('failed',1),('actual_tests',26),('remaining_tests',5661),('metadata_tests',534)]:
    c=copy.deepcopy(cpu);c['full_tests'][key]=val
    with self.assertRaises(ValueError):check(c)
   c=copy.deepcopy(cpu);c['artifacts'][0]['sha256']='b'*64
   with self.assertRaises(AssertionError):check(c)
   c=copy.deepcopy(cpu);c['artifacts']*=2
   with self.assertRaises(ValueError):check(c)
   c=copy.deepcopy(cpu);c['artifacts']=[]
   with self.assertRaises(ValueError):check(c)
   with self.assertRaises(ValueError):check(cpu,lambda args,**kw:'dirty' if args[1]=='status' else 'a'*40)
   with self.assertRaises(ValueError):check(cpu,lambda args,**kw:'' if args[1]=='status' else ('b' if args[1]=='merge-base' else 'a')*40)
   path.write_text(json.dumps(cpu));other=root/'cpu-review.json';other.write_text(path.read_text())
   with self.assertRaises(ValueError):pf.check(root,other,git)
 def test_gates_before_imports_and_output(self):
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   tree=ast.parse((F/name).read_text());body=next(n.body for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main') if name.startswith('pilot') else tree.body
   torchline=next(n.lineno for n in body if isinstance(n,ast.Import) and any(a.name=='torch' for a in n.names))
   guards=[n for n in body if isinstance(n,ast.If) and ('Completed reviewed position-family' in ast.unparse(n) or 'Competing model work' in ast.unparse(n))]
   self.assertEqual(len(guards),2)
   for g in guards:self.assertLess(g.lineno,torchline)
   call=next(n for n in body if isinstance(n,ast.Assign) and 'publication_preflight(source, args.cpu_review)' in ast.unparse(n));self.assertLess(call.lineno,torchline)
   live=next(n for n in guards if 'Competing' in ast.unparse(n));code=compile(ast.Module(body=[live],type_ignores=[]),'live','exec');exec(code,{'live':[]})
   with self.assertRaises(ValueError):exec(code,{'live':['synthetic-live-worker']})
 def test_objective_inheritance_and_saved_payload_wiring(self):
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   s=(F/name).read_text();ast.parse(s)
   for required in ('logit_z_study as study',"position_kind=p['recipe']['position_family_kind']",'position_family_signature==(position_kind,POSITION_POLICY,SLOPE_FORMULA,w//32)','logit_z_signature==(f,COEFFICIENTS[f],Z_POLICY,CONVENTION)','del cfg.model.logit_z_objective_policy','validate_logit_z_model(model)','111538','9491','5689'):
    self.assertIn(required,s)
   for absent in ("position_family_kind=f","position=f","(f,POSITION_POLICY","model(idx,target)",'table-math-check.pt','recovery','continuation'):
    if absent in ('recovery','continuation'):continue # preserved historical artifact path labels in independent reviewer
    self.assertNotIn(absent,s)
   self.assertIn("helpers['graph_audit'].verify",s)
   self.assertIn("helpers['evaluation_audit'].primitive",s)
  s=(F/'review-prerequisites001.py').read_text()
  self.assertIn('1.0/(10000.**(torch.arange(0,32,2,dtype=torch.float32)/32))',s)
  self.assertIn('atol=1e-6,rtol=0',s)
  self.assertIn("count=(12 if f=='none' else 9) if w==64 else (6 if f=='none' else 3)",s)
  self.assertIn('trainer_changed=True',s)
  self.assertIn("saved['model_state'][name],avg['averages']['200'][name]",s)
  self.assertIn("geometry.parameter_shapes(w,attention,norm,bias_kind,table_kind,gain_kind)",s)
 def test_fresh_dispatch_primitive_once_and_budgets(self):
  tree=ast.parse((F/'pilot-driver001.py').read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
  self.assertEqual(sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_launch' for n in ast.walk(main)),1)
  primitive=next(n for n in ast.walk(main) if isinstance(n,ast.If) and ast.unparse(n.test)=='not rows')
  self.assertIn("helpers['primitive_capture'].capture()",ast.unparse(primitive))
  self.assertNotIn('_launch',ast.unparse(primitive))
  order=ast.unparse(main)
  self.assertLess(order.index('post_timer = post_worker_watchdog'),order.index("helpers['primitive_capture'].capture()"))
  self.assertLess(order.index("torch.save(primitive"),order.index("helpers['evaluation_audit'].primitive"))
  self.assertLess(order.index("torch.save(graph"),order.index("helpers['graph_audit'].verify"))
  self.assertLess(order.index('rows.append(row)'),order.index('post_timer.cancel()'))
  self.assertIn('min(240 - (time.monotonic() - started), 1800 - (time.monotonic() - began))',order)
  self.assertIn('disk_mb(out) < 1024',order)
  self.assertIn('no_automatic_retry=True',order)
  watchdog=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='post_worker_watchdog')
  self.assertIn('os._exit(88)',ast.unparse(watchdog))
if __name__=='__main__':unittest.main(verbosity=2)
