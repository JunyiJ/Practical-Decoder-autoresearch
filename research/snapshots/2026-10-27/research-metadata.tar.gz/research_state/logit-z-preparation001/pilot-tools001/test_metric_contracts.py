"""Execute only independent scalar metric predicates extracted from auditor AST."""
import ast,copy,math,unittest
from pathlib import Path
F=Path(__file__).resolve().parent
class Tests(unittest.TestCase):
 def test_saved_objective_metric_algebra(self):
  tree=ast.parse((F/'review-prerequisites001.py').read_text())
  loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='metric')
  stop=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='step' for t in n.targets))
  code=compile(ast.Module(body=loop.body[:stop],type_ignores=[]),'independent-metric-predicates','exec')
  coefs={'none':0.,'z1e4':.0001,'z1e3':.001}
  def check(m,f):exec(code,{'metric':m,'f':f,'COEFFICIENTS':coefs,'math':math})
  for f,c in coefs.items():
   m=dict(train_logit_z_coefficient=c,train_aux_loss=None,val_aux_loss=None,val_loss=2.,val_ce_loss=2.,train_loss=2.+c*17,train_total_loss=2.+c*17,train_ce_loss=2.,train_logit_z_squared_mean=17. if c else None,train_logit_z_mean=4. if c else None,train_logit_z_penalty=c*17 if c else None)
   check(m,f)
   mutations=[('train_logit_z_coefficient',False),('train_aux_loss',.1),('val_aux_loss',.1),('val_loss',3.),('train_total_loss',3.)]
   mutations += [('train_logit_z_squared_mean',1.),('train_logit_z_penalty',.7),('train_logit_z_mean',float('nan'))] if c else [('train_logit_z_squared_mean',0.),('train_logit_z_penalty',0.),('train_logit_z_mean',0.)]
   for k,v in mutations:
    bad=copy.deepcopy(m);bad[k]=v
    with self.assertRaises(AssertionError):check(bad,f)
 def test_valid_family_change_guard_and_restore(self):
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   text=(F/name).read_text();ast.parse(text)
   self.assertIn("cfg.model.logit_z_kind=other_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[other_kind]",text)
   self.assertIn("cfg.model.logit_z_kind=f;cfg.model.logit_z_coefficient=COEFFICIENTS[f]",text)
   self.assertIn("Changed valid same-shaped objective family accepted",text)
if __name__=='__main__':unittest.main(verbosity=2)
