from pathlib import Path
import sys,json,os,datetime,hashlib
P=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-preparation001');R=P/'cpu-watchdog-repair001';sys.path.insert(0,str(P/'cpu-tools002'));from bounded_cpu import inventory,sha
old=Path('/private/tmp/rsi-logit-z-cpu001/batch-0084');new=R/'preserved-batch-0084';receipt=json.loads((R/'orphan-scratch-preserved.json').read_text());m=json.loads((P/'cpu-execution-manifest.json').read_text())
assert m['status']=='running' and m['pid']==49786 and not new.exists() and old.is_dir() and not old.is_symlink()
assert inventory(old)==receipt['inventory']
record=dict(status='reviewed_pending_atomic_relocation',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_path=str(old),preserved_path=str(new),inventory_receipt=str(R/'orphan-scratch-preserved.json'),inventory_receipt_sha256=sha(R/'orphan-scratch-preserved.json'),bytes=receipt['bytes'],reason='Preserve completed orphan failure evidence outside active temporary scratch. Unchanged8GiB active scratch limit and free-disk guard remain enforced; no files deleted/no reruns/source/helper changes.',restore_required_before_cpu_review=True,restore_only_after_terminal_manifest_and_no_live_model_work=True)
p=R/'orphan-evidence-relocation001.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
os.rename(old,new)
assert inventory(new)==receipt['inventory'] and not old.exists()
record.update(status='relocated_verified',verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat());p.write_text(json.dumps(record,indent=2)+'\n');p.chmod(0o444)
print(json.dumps({k:v for k,v in record.items() if k!='reason'}))
