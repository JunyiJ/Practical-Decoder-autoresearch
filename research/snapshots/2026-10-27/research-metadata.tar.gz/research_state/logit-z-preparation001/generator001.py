from pathlib import Path
D=Path('/private/tmp/rsi-logit-z-development001')
def edit(path,old,new):
 p=D/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old));p.write_text(s.replace(old,new))
(D/'src/models/logit_z.py').write_text('''"""Explicit training-only output log-normalizer objective; evaluation is pure CE.

Metadata contracts import no tensor runtime. No parameter/buffer/RNG is added.
The coefficient applies to FINAL returned FP32 logits, after all readout scales
and output bias. This is unrelated to router auxiliary losses.
"""
from collections.abc import Mapping
import math

POLICY = 'mha4_final_logit_z'
COEFFICIENTS = {'none': 0., 'z1e4': .0001, 'z1e3': .001}
FIELDS = ('logit_z_kind', 'logit_z_coefficient', 'logit_z_objective_policy')
CONVENTION = 'final_fp32_logsumexp_squared_valid_target_mean_v1'

def _get(c,k,d=None): return c.get(k,d) if isinstance(c,Mapping) else getattr(c,k,d)
def _has(c,k): return k in c if isinstance(c,Mapping) else hasattr(c,k)

def logit_z_contract(cfg):
    if not any(_has(cfg,k) for k in FIELDS): return None
    kind, coefficient, policy = (_get(cfg,k) for k in FIELDS)
    if type(kind) is not str or kind not in COEFFICIENTS or policy != POLICY:
        raise ValueError('Logit-z requires explicit reviewed kind and objective policy')
    if (type(coefficient) not in (int,float) or not math.isfinite(coefficient)
            or coefficient != COEFFICIENTS[kind]):
        raise ValueError('Logit-z coefficient must exactly match the reviewed family')
    from .position_family import position_family_contract
    if position_family_contract(cfg) is None:
        raise ValueError('Logit-z requires the final explicit inherited position/backbone')
    for key in ('logit_z_center', 'logit_z_temperature', 'logit_z_clip',
                'logit_z_detach', 'logit_z_width_scale', 'label_smoothing',
                'logit_z_ignore_index', 'logit_z_log_vocab_subtract'):
        if _has(cfg,key): raise ValueError('Unreviewed logit-z override: '+key)
    return dict(logit_z_kind=kind,logit_z_coefficient=float(coefficient),
                logit_z_objective_policy=POLICY)

def logit_z_signature(cfg):
    c=logit_z_contract(cfg)
    return None if c is None else (c[FIELDS[0]],c[FIELDS[1]],POLICY,CONVENTION)

def validate_logit_z_model(model):
    signature=logit_z_signature(getattr(model,'cfg',{}))
    if signature != getattr(model,'logit_z_signature',None):
        raise ValueError('Constructed/current logit-z objectives differ or were deleted')
    # The signature is immutable metadata, never learned/averaged tensor state.
    for key in FIELDS+('logit_z_signature',):
        if key in getattr(model,'_parameters',{}) or key in getattr(model,'_buffers',{}):
            raise ValueError('Logit-z adds no parameter or buffer state')
    return signature

def validate_logit_z_load(model,checkpoint):
    saved=_get(checkpoint.get('cfg',{}),'model',{})
    if logit_z_contract(getattr(model,'cfg',{})) != logit_z_contract(saved):
        raise ValueError('Checkpoint logit-z objective differs despite compatible weights')
    validate_logit_z_model(model)

def objective_requested(model, enabled, targets):
    if type(enabled) is not bool: raise ValueError('Training objective flag must be boolean')
    signature=validate_logit_z_model(model)
    if enabled and (signature is None or targets is None):
        raise ValueError('Training objective requires explicit contract and targets')
    return signature if enabled else None

def training_logit_z(logits, targets, ce_loss, signature):
    """Return loss/metrics; zero arm returns the original CE object unchanged.

    CE's historical ignore_index=-100 supplies exactly the valid-token mask.
    Empty valid batches fail for the nonzero objective, rather than produce NaN.
    For zero, logZ diagnostics are deliberately null: computing them would add
    arithmetic to the promised historical zero path. No tensor is detached here.
    """
    if (not isinstance(signature,tuple) or len(signature)!=4
            or signature[0] not in COEFFICIENTS
            or signature != (signature[0],COEFFICIENTS[signature[0]],POLICY,CONVENTION)):
        raise ValueError('Invalid constructed logit-z objective signature')
    coefficient=signature[1]
    if coefficient == 0.:
        return ce_loss, dict(logit_z_coefficient=0., logit_z_mean=None,
                            logit_z_squared_mean=None, logit_z_penalty=None)
    import torch
    if logits.dtype != torch.float32 or targets.shape != logits.shape[:-1]:
        raise ValueError('Logit-z requires final FP32 logits and matching targets')
    flat=logits.reshape(-1,logits.shape[-1])
    valid=targets.reshape(-1).ne(-100)
    if not valid.any().item(): raise ValueError('Logit-z requires at least one valid target')
    log_z=torch.logsumexp(flat[valid],dim=-1)
    squared=log_z.square().mean()
    penalty=coefficient*squared
    return ce_loss+penalty, dict(logit_z_coefficient=coefficient,
        logit_z_mean=log_z.mean(),logit_z_squared_mean=squared,logit_z_penalty=penalty)
''')
edit(Path('src/models/gpt.py'),'        self.cfg = cfg\n','        self.cfg = cfg\n        from .logit_z import logit_z_signature\n        self.logit_z_signature = logit_z_signature(cfg)\n')
edit(Path('src/models/gpt.py'),'        return_loss_breakdown=False,\n    ):\n        b, t = idx.size()','        return_loss_breakdown=False,\n        include_training_objective=False,\n    ):\n        from .logit_z import objective_requested\n        objective = objective_requested(self, include_training_objective, targets)\n        b, t = idx.size()')
edit(Path('src/models/gpt.py'),'        aux_loss = None\n        if targets is not None:','        aux_loss = None\n        objective_breakdown = {}\n        if targets is not None:')
edit(Path('src/models/gpt.py'),'            loss = ce_loss\n            if aux_losses:','            loss = ce_loss\n            if objective is not None:\n                from .logit_z import training_logit_z\n                loss, objective_breakdown = training_logit_z(logits, targets, ce_loss, objective)\n            if aux_losses:')
edit(Path('src/models/gpt.py'),'                "total_loss": loss,\n','                "total_loss": loss,\n                **objective_breakdown,\n')
edit(Path('src/train/optimizers.py'),'def build_optimizer(model, training):\n','def build_optimizer(model, training):\n    from ..models.logit_z import validate_logit_z_model\n    validate_logit_z_model(model)\n')
edit(Path('src/utils/checkpoint.py'),'    from ..models.position_family import validate_position_family_load\n','    from ..models.logit_z import validate_logit_z_load\n    validate_logit_z_load(model, checkpoint)\n    from ..models.position_family import validate_position_family_load\n')
# Preserve legacy call signature for all historical models/mocks; named objective
# explicitly opts in ONLY at the training call. Evaluation default remains false.
edit(Path('src/train/train.py'),'        logits, loss, train_loss_breakdown = model(xb, yb, return_loss_breakdown=True)\n','        objective_kwargs = ({"include_training_objective": True}\n                            if getattr(model, "logit_z_signature", None) is not None else {})\n        logits, loss, train_loss_breakdown = model(xb, yb, return_loss_breakdown=True, **objective_kwargs)\n')
edit(Path('src/train/train.py'),'            if cuda_usage is not None:\n','            if "logit_z_coefficient" in train_loss_breakdown:\n                log.info("Training objective: ce %.6f | logit_z_coefficient %.6g | logit_z_squared_mean %s | logit_z_penalty %s | logit_z_mean %s | total %.6f",\n                         train_ce_loss.item(), train_loss_breakdown["logit_z_coefficient"],\n                         *[None if train_loss_breakdown[k] is None else train_loss_breakdown[k].item()\n                           for k in ("logit_z_squared_mean", "logit_z_penalty", "logit_z_mean")], loss.item())\n            if cuda_usage is not None:\n')
edit(Path('src/train/train.py'),'            metrics.append(metric)\n','            if "logit_z_coefficient" in train_loss_breakdown:\n                metric["train_logit_z_coefficient"] = train_loss_breakdown["logit_z_coefficient"]\n                for key in ("logit_z_squared_mean", "logit_z_penalty", "logit_z_mean"):\n                    value = train_loss_breakdown[key]\n                    metric["train_" + key] = None if value is None else float(value.item())\n            metrics.append(metric)\n')
# Draft explicitly documents the zero diagnostic exception; no design history rewritten.
p=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-preparation001/PROTOCOL_DRAFT.md')
text=p.read_text().replace('DESIGN ONLY. Not registered, implemented, tested or launched.','SEPARATE PRIMITIVE PROTOTYPE ONLY. Not integrated, registered or launched; actual tensor/model tests pending.')
text+='\nImplementation clarification: zero coefficient returns the exact historical CE tensor and does not compute logZ diagnostics; its logZ mean, square and penalty fields are null (coefficient zero is recorded). Nonzero arms log these values on the existing training batch. GPT defaults include_training_objective=False independently of train/eval mode; only the configured trainer call opts in. All sampled/full validation remains pure CE. Exact current/saved/constructed kind/coefficient/policy is checked even when loading inference-only weights.\n'
(D/'research/LOGIT_Z_PROTOCOL.md').write_text(text)
print('Separate primitive created; no imports or execution.')
