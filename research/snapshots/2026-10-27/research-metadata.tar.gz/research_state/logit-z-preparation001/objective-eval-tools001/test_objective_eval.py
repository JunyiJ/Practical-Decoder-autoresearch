import ast,copy,importlib.abc,importlib.util,json,sys,unittest
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='torch' or fullname.startswith(('torch.','src.')) or fullname=='src':raise AssertionError('No model/tensor imports in helper tests')
sys.meta_path.insert(0,Block())
s=importlib.util.spec_from_file_location('audit',P/'objective-eval-audit.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
COUNTS=dict(primitive_rows=0,primitive_corruptions=0,evaluation_families=0,evaluation_corruptions=0,capture_ast_checks=0)
def primitive_fixture():
 rows=[]
 for case,(values,labels) in a.CASES.items():
  for kind,coef in a.COEFFICIENTS.items():
   z=np.asarray(values,dtype=np.float32);y=np.asarray(labels,dtype=np.int64);o=a.oracle.objective(z,y,coef)
   metrics={'logit_z_coefficient':coef}
   for key,name in [('logit_z_mean','mean'),('logit_z_squared_mean','squared'),('logit_z_penalty','penalty')]:metrics[key]=None if kind=='none' else float(np.float32(o[name]))
   rows.append(dict(case=case,kind=kind,coefficient=coef,logits=z,targets=y,gradient=o['gradient'].astype(np.float32),ce=float(np.float32(o['ce'])),total=float(np.float32(o['total'])),zero_identity=kind=='none',metrics=metrics))
 return dict(schema='logit_z_mps_primitive_v1',device='mps',dtype='float32',convention=a.oracle.CONVENTION,rows=rows,rejected=['shape','empty'],sentinel_zero_identity=True,cpu_rng_unchanged=True,mps_rng_unchanged=True,tolerances=copy.deepcopy(a.TOL))
def evaluation_fixture(kind):
 rng=np.random.default_rng(333);x=np.arange(22,dtype=np.int64).reshape(2,11);y=(x+1)%65;z=rng.normal(0,1,(2,11,65)).astype(np.float32);loss=float(np.float32(a.token_losses(z,y).mean()));data=np.arange(22,dtype=np.int64)
 calls=[dict(stage=stage,training=i==0,include_training_objective=False,tokens=x.copy(),targets=y.copy(),logits=z.copy(),loss=loss) for i,stage in enumerate(['default_train','default_eval','sampled','sampled'])]
 sums=[]
 for xx,yy in [(np.stack([data[:8],data[8:16]]),np.stack([data[1:9],data[9:17]])),(data[16:21][None],data[17:22][None])]:
  zz=rng.normal(0,1,(*xx.shape,65)).astype(np.float32);sums.append(float(a.token_losses(zz,yy).astype(np.float32).astype(np.float64).sum()));calls.append(dict(stage='coverage',training=False,include_training_objective=False,tokens=xx,targets=None,logits=zz,loss=None))
 p=dict(schema='logit_z_mps_pure_ce_v1',device='mps',derived_checkpoint_sha256='a'*64,objective_kind=kind,coefficient=a.COEFFICIENTS[kind],convention=a.oracle.CONVENTION,tokens=x,targets=y,synthetic_data=data,calls=calls,sampled_ce=loss,sampled_aux=None,veto_calls=0,eval_rng_reset=True,cpu_rng_unchanged=True,mps_rng_unchanged=True,coverage=dict(context=8,eval_batch_size=2,block_tokens=16,target_count=21,window_count=3,mean_ce=sum(sums)/21,block_loss_sums=sums,block_target_counts=[16,5]))
 graph=dict(derived_checkpoint_sha256='a'*64,logit_z_kind=kind,tokens=x,logits=z)
 return p,graph
class Tests(unittest.TestCase):
 def test_primitive_manifest_math_and_corruptions(self):
  p=primitive_fixture();self.assertEqual(a.primitive(p)['cases'],12);COUNTS['primitive_rows']=12
  mutations=[lambda q:q['rows'].pop(),lambda q:q['rows'].append(copy.deepcopy(q['rows'][0])),lambda q:q['tolerances'].update(extreme_atol=.01),lambda q:q.update(cpu_rng_unchanged=False),lambda q:q.update(rejected=['shape']),lambda q:q.update(sentinel_zero_identity=False)]
  for i in range(12):
   mutations.extend([lambda q,i=i:q['rows'][i].update(gradient=q['rows'][i]['gradient']+.1),lambda q,i=i:q['rows'][i].update(total=q['rows'][i]['total']+100),lambda q,i=i:q['rows'][i].update(coefficient=.01),lambda q,i=i:q['rows'][i].update(zero_identity=not q['rows'][i]['zero_identity'])])
  mutations.extend([lambda q:q['rows'][0]['metrics'].update(logit_z_mean=0.),lambda q:q['rows'][1]['metrics'].update(logit_z_penalty=0.),lambda q:q['rows'][0].update(logits=q['rows'][0]['logits'].astype(np.float64)),lambda q:q['rows'][3]['targets'].__setitem__(1,1)])
  for mutate in mutations:
   bad=copy.deepcopy(p);mutate(bad)
   with self.assertRaises(AssertionError):a.primitive(bad)
   COUNTS['primitive_corruptions']+=1
 def test_pure_ce_all_families_linkage_tails_and_corruptions(self):
  for kind in a.COEFFICIENTS:
   p,g=evaluation_fixture(kind);self.assertEqual(a.evaluation(p,g,'a'*64,kind)['synthetic_coverage_targets'],21);COUNTS['evaluation_families']+=1
   mutations=[lambda q:q.update(sampled_ce=q['sampled_ce']+.2),lambda q:q.update(veto_calls=1),lambda q:q.update(sampled_aux=0.),lambda q:q.update(eval_rng_reset=False),lambda q:q.update(derived_checkpoint_sha256='b'*64),lambda q:q.update(coefficient=.01),lambda q:q['coverage'].update(target_count=22),lambda q:q['coverage'].update(block_target_counts=[15,6]),lambda q:q['coverage'].update(mean_ce=q['coverage']['mean_ce']+.1),lambda q:q['coverage'].update(block_loss_sums=[1.,2.]),lambda q:q['calls'].pop(),lambda q:q['synthetic_data'].__setitem__(0,4)]
   for i in range(6):
    mutations.extend([lambda q,i=i:q['calls'][i].update(include_training_objective=True),lambda q,i=i:q['calls'][i]['tokens'].__setitem__((0,0),64),lambda q,i=i:q['calls'][i]['logits'].__setitem__((0,0,0),100)])
   for mutate in mutations:
    bad=copy.deepcopy(p);mutate(bad)
    with self.assertRaises(AssertionError):a.evaluation(bad,g,'a'*64,kind)
    COUNTS['evaluation_corruptions']+=1
   for key,value in [('tokens',g['tokens']+1),('logits',g['logits']+.01),('derived_checkpoint_sha256','b'*64),('logit_z_kind','invalid')]:
    bad=copy.deepcopy(g);bad[key]=value
    with self.assertRaises(AssertionError):a.evaluation(p,bad,'a'*64,kind)
    COUNTS['evaluation_corruptions']+=1
 def test_deferred_capture_ast_and_no_import_side_effects(self):
  for name in ('primitive-capture.py','evaluation-capture.py'):
   t=ast.parse((P/name).read_text());self.assertTrue(all(isinstance(n,(ast.Expr,ast.FunctionDef)) for n in t.body));COUNTS['capture_ast_checks']+=1
   self.assertFalse(any(isinstance(n,ast.Import) and any(i.name=='torch' for i in n.names) for n in t.body));COUNTS['capture_ast_checks']+=1
  text=(P/'evaluation-capture.py').read_text();tree=ast.parse(text)
  for required in ["patch('src.models.logit_z.training_logit_z'",'score_validation(model,data,context=8,batch_size=2,block_tokens=16)',"_evaluate(model,loader,'val',2)","idx.device.type=='mps'",'finally:', 'hook.remove();model.train(training)']:
   self.assertIn(required,text);COUNTS['capture_ast_checks']+=1
  calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='model'];self.assertEqual(len(calls),1);self.assertFalse(calls[0].keywords);COUNTS['capture_ast_checks']+=1
  self.assertNotIn('read_checkpoint',text);self.assertNotIn('evaluate_job',text);self.assertNotIn('torch.load',text);COUNTS['capture_ast_checks']+=3
if __name__=='__main__':
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 if r.wasSuccessful():(P/'test-counts.json').write_text(json.dumps(COUNTS,indent=2)+'\n')
 raise SystemExit(not r.wasSuccessful())
