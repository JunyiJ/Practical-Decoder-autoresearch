"""Deferred MPS-only primitive checks; no import-time tensor/model work."""
def capture():
    import torch
    import torch.nn.functional as F
    from src.models.logit_z import training_logit_z,COEFFICIENTS,POLICY,CONVENTION
    assert torch.backends.mps.is_available()
    cpu_rng=torch.get_rng_state().clone();mps_rng=torch.mps.get_rng_state().clone()
    cases={
        'ordinary':([[0.,1.,-2.,3.],[-3.,4.,2.,-1.],[1.,1.,1.,1.]],[2,-100,1]),
        'extreme':([[10000.,9999.,-10000.,0.],[-10000.,-9999.,-9998.,-10001.],[10000.]*4],[2,-100,1]),
        'shift0':([[.1,1.2,-.4,2.],[-1.,.3,.5,.8]],[0,3]),
        'shift3':([[3.1,4.2,2.6,5.],[2.,3.3,3.5,3.8]],[0,3]),
    }
    rows=[]
    for case,(values,labels) in cases.items():
        for kind,coef in COEFFICIENTS.items():
            z=torch.tensor(values,dtype=torch.float32,device='mps',requires_grad=True)
            y=torch.tensor(labels,dtype=torch.long,device='mps')
            ce=F.cross_entropy(z,y);loss,metrics=training_logit_z(z,y,ce,(kind,coef,POLICY,CONVENTION))
            identity=loss is ce;loss.backward()
            assert z.device.type=='mps' and z.dtype==torch.float32
            assert torch.isfinite(loss).item() and torch.isfinite(z.grad).all().item()
            rows.append(dict(case=case,kind=kind,coefficient=coef,logits=z.detach().cpu(),targets=y.cpu(),
                gradient=z.grad.detach().cpu(),ce=ce.item(),total=loss.item(),zero_identity=identity,
                metrics={k:None if v is None else (v.item() if isinstance(v,torch.Tensor) else v) for k,v in metrics.items()}))
    sentinel=object();same,meta=training_logit_z(object(),object(),sentinel,('none',0.,POLICY,CONVENTION))
    assert same is sentinel and meta['logit_z_penalty'] is None
    rejected=[]
    # MPS does not support float64: CPU already verified dtype refusal. These
    # MPS cases prove shape and no-valid-target refusals without a float64 cast.
    for label,z,y in [('shape',torch.zeros(2,4,device='mps'),torch.zeros(3,dtype=torch.long,device='mps')),
                      ('empty',torch.zeros(2,4,device='mps'),torch.full((2,),-100,dtype=torch.long,device='mps'))]:
        try:training_logit_z(z,y,torch.tensor(0.,device='mps'),('z1e4',.0001,POLICY,CONVENTION))
        except ValueError:rejected.append(label)
        else:raise AssertionError('Invalid MPS objective accepted: '+label)
    assert torch.equal(cpu_rng,torch.get_rng_state()) and torch.equal(mps_rng,torch.mps.get_rng_state())
    return dict(schema='logit_z_mps_primitive_v1',device='mps',dtype='float32',convention=CONVENTION,
        rows=rows,rejected=rejected,sentinel_zero_identity=True,cpu_rng_unchanged=True,mps_rng_unchanged=True,
        tolerances=dict(ordinary_atol=1e-4,ordinary_rtol=2e-5,extreme_atol=2e-3,extreme_loss_rtol=2e-6,extreme_gradient_rtol=2e-5),
        scope='Synthetic primitive correctness, not quality. Extreme tolerances exactly match the previously passed actual CPU primitive gate; full-model tolerances remain unchanged.')
