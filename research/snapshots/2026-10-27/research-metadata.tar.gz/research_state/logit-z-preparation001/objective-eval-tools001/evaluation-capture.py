"""Deferred small synthetic MPS evaluator-veto panel; no corpus or model creation."""
def capture(model,idx,derived_sha):
    import torch
    from unittest.mock import patch
    from src.train.train import _evaluate
    from src.research.coverage_eval import score_validation
    from src.models.logit_z import validate_logit_z_model
    sig=validate_logit_z_model(model);assert sig is not None
    assert idx.device.type=='mps' and tuple(idx.shape)==(2,11)
    assert model.cfg.vocab_size==65 and model.cfg.dropout==0
    cpu_rng=torch.get_rng_state().clone();mps_rng=torch.mps.get_rng_state().clone()
    training=model.training;stage='';calls=[]
    def observe(module,args,kwargs,result):
        x=args[0];y=args[1] if len(args)>1 else kwargs.get('targets')
        assert not kwargs.get('include_training_objective',False)
        logits,loss=result[:2]
        calls.append(dict(stage=stage,training=bool(module.training),include_training_objective=False,
            tokens=x.detach().cpu(),targets=None if y is None else y.detach().cpu(),
            logits=logits.detach().cpu(),loss=None if loss is None else loss.item()))
    hook=model.register_forward_hook(observe,with_kwargs=True)
    target=(idx+1)%65;data=torch.arange(22,dtype=torch.long)%65
    class Loader:
        eval_seed=2026
        def __init__(self):self.generators={'val':torch.Generator().manual_seed(99)}
        def get_batch(self,split):assert split=='val';return idx,target
    loader=Loader()
    veto_calls=[]
    def veto(*args,**kwargs):
        veto_calls.append(True)
        raise AssertionError('Validation invoked training logit penalty')
    try:
        with patch('src.models.logit_z.training_logit_z',side_effect=veto):
            with torch.no_grad():
                for mode in (True,False):
                    stage='default_train' if mode else 'default_eval';model.train(mode);model(idx,target)
            stage='sampled';sampled,aux=_evaluate(model,loader,'val',2)
            stage='coverage';coverage=score_validation(model,data,context=8,batch_size=2,block_tokens=16)
    finally:
        hook.remove();model.train(training)
    assert not veto_calls and aux is None
    assert torch.equal(loader.generators['val'].get_state(),torch.Generator().manual_seed(2026).get_state())
    assert torch.equal(cpu_rng,torch.get_rng_state()) and torch.equal(mps_rng,torch.mps.get_rng_state())
    return dict(schema='logit_z_mps_pure_ce_v1',device='mps',derived_checkpoint_sha256=derived_sha,
        objective_kind=sig[0],coefficient=sig[1],convention=sig[3],tokens=idx.detach().cpu(),targets=target.cpu(),
        synthetic_data=data,calls=calls,sampled_ce=sampled,sampled_aux=aux,coverage=coverage,
        veto_calls=0,eval_rng_reset=True,cpu_rng_unchanged=True,mps_rng_unchanged=True,
        scope='Small synthetic default/train-mode/eval-mode/sampled/coverage-tail checks. No corpus read, holdout, raw/derived checkpoint evaluator rerun, or quality measurement.')
