"""Independent NumPy audit of deferred primitive/evaluator MPS observations."""
import importlib.util
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent.parent/'objective-math-tools001/objective-math-audit.py'
s=importlib.util.spec_from_file_location('logit_objective_oracle',p);oracle=importlib.util.module_from_spec(s);s.loader.exec_module(oracle)
COEFFICIENTS={'none':0.,'z1e4':.0001,'z1e3':.001}
TOL=dict(ordinary_atol=1e-4,ordinary_rtol=2e-5,extreme_atol=2e-3,extreme_loss_rtol=2e-6,extreme_gradient_rtol=2e-5)
CASES={
 'ordinary':([[0.,1.,-2.,3.],[-3.,4.,2.,-1.],[1.,1.,1.,1.]],[2,-100,1]),
 'extreme':([[10000.,9999.,-10000.,0.],[-10000.,-9999.,-9998.,-10001.],[10000.]*4],[2,-100,1]),
 'shift0':([[.1,1.2,-.4,2.],[-1.,.3,.5,.8]],[0,3]),
 'shift3':([[3.1,4.2,2.6,5.],[2.,3.3,3.5,3.8]],[0,3]),
}
def close(a,b,atol=1e-4,rtol=2e-5):
 a=np.asarray(a);b=np.asarray(b)
 assert a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all()
 assert np.allclose(a,b,atol=atol,rtol=rtol),(float(np.max(np.abs(a-b))),atol,rtol)
 return float(np.max(np.abs(a-b)))

def primitive(payload):
 assert payload['schema']=='logit_z_mps_primitive_v1' and payload['device']=='mps' and payload['dtype']=='float32'
 assert payload['convention']==oracle.CONVENTION and payload['tolerances']==TOL
 assert payload['rejected']==['shape','empty']
 assert all(payload[k] is True for k in ('sentinel_zero_identity','cpu_rng_unchanged','mps_rng_unchanged'))
 rows=payload['rows'];assert len(rows)==12
 assert [(r['case'],r['kind']) for r in rows]==[(c,k) for c in CASES for k in COEFFICIENTS]
 errors={};by={}
 for r in rows:
  case,kind=r['case'],r['kind'];coef=COEFFICIENTS[kind];values,labels=CASES[case]
  z=np.asarray(r['logits']);y=np.asarray(r['targets']);g=np.asarray(r['gradient'])
  assert z.dtype==np.float32 and g.dtype==np.float32 and y.dtype==np.int64
  assert np.array_equal(z,np.asarray(values,dtype=np.float32)) and np.array_equal(y,np.asarray(labels,dtype=np.int64))
  assert type(r['coefficient']) is float and r['coefficient']==coef and r['zero_identity'] is (kind=='none')
  o=oracle.objective(z,y,coef);atol=2e-3 if case=='extreme' else 1e-4;lossrtol=2e-6 if case=='extreme' else 2e-5
  errors[case+'_'+kind]=dict(ce=close(r['ce'],o['ce'],atol,lossrtol),total=close(r['total'],o['total'],atol,lossrtol),gradient=close(g,o['gradient'],atol,2e-5))
  assert np.count_nonzero(g[y==-100])==0
  m=r['metrics'];assert set(m)=={'logit_z_coefficient','logit_z_mean','logit_z_squared_mean','logit_z_penalty'}
  assert type(m['logit_z_coefficient']) is float and m['logit_z_coefficient']==coef
  for key,name in [('logit_z_mean','mean'),('logit_z_squared_mean','squared'),('logit_z_penalty','penalty')]:
   if kind=='none':assert m[key] is None
   else:close(m[key],o[name],atol,lossrtol)
  if kind=='none':assert r['total']==r['ce']
  by[case,kind]=r
 for kind in COEFFICIENTS:
  close(by['shift0',kind]['ce'],by['shift3',kind]['ce'])
  if kind!='none':assert by['shift3',kind]['metrics']['logit_z_penalty']>by['shift0',kind]['metrics']['logit_z_penalty']
 for case in CASES:close(by[case,'z1e3']['metrics']['logit_z_penalty'],10*by[case,'z1e4']['metrics']['logit_z_penalty'],atol=2e-3 if case=='extreme' else 1e-4)
 return dict(status='verified',cases=12,masked_cases=6,invalid_cases=2,errors=errors,scope='Synthetic primitive only; extreme limits retain actual CPU gate values, full-model limits unchanged.')

def token_losses(logits,targets):
 z=np.asarray(logits,dtype=np.float64);y=np.asarray(targets,dtype=np.int64)
 assert z.shape[:-1]==y.shape and np.isfinite(z).all() and ((y>=0)&(y<z.shape[-1])).all()
 m=z.max(-1);lz=m+np.log(np.exp(z-m[...,None]).sum(-1))
 return lz-np.take_along_axis(z,y[...,None],-1)[...,0]

def evaluation(payload,objective_graph,derived_sha,kind):
 assert len(derived_sha)==64 and all(c in '0123456789abcdef' for c in derived_sha)
 assert payload['schema']=='logit_z_mps_pure_ce_v1' and payload['device']=='mps'
 assert payload['derived_checkpoint_sha256']==objective_graph['derived_checkpoint_sha256']==derived_sha
 assert payload['objective_kind']==objective_graph['logit_z_kind']==kind
 assert type(payload['coefficient']) is float and payload['coefficient']==COEFFICIENTS[kind]
 assert payload['convention']==oracle.CONVENTION and payload['veto_calls']==0 and payload['sampled_aux'] is None
 assert all(payload[k] is True for k in ('eval_rng_reset','cpu_rng_unchanged','mps_rng_unchanged'))
 x=np.asarray(payload['tokens']);y=np.asarray(payload['targets']);data=np.asarray(payload['synthetic_data'])
 assert x.shape==(2,11) and x.dtype==y.dtype==data.dtype==np.int64 and ((x>=0)&(x<65)).all()
 assert np.array_equal(x,objective_graph['tokens']) and np.array_equal(y,(x+1)%65)
 assert np.array_equal(data,np.arange(22,dtype=np.int64)%65)
 calls=payload['calls'];stages=['default_train','default_eval','sampled','sampled','coverage','coverage']
 assert len(calls)==len(stages) and [c['stage'] for c in calls]==stages
 errors=[];sampled=[];sums=[]
 for i,c in enumerate(calls):
  assert c['include_training_objective'] is False and c['training'] is (i==0)
  z=np.asarray(c['logits']);assert z.dtype==np.float32 and z.shape[-1]==65
  if i<4:
   assert np.array_equal(c['tokens'],x) and np.array_equal(c['targets'],y)
   loss=token_losses(z,y).mean();errors.append(close(c['loss'],loss))
   errors.append(close(z,objective_graph['logits']))
   if i in (2,3):sampled.append(c['loss'])
  else:
   expected_x=np.stack([data[:8],data[8:16]]) if i==4 else data[16:21][None]
   expected_y=np.stack([data[1:9],data[9:17]]) if i==4 else data[17:22][None]
   assert c['targets'] is None and c['loss'] is None and np.array_equal(c['tokens'],expected_x)
   assert z.shape==(*expected_x.shape,65)
   sums.append(float(token_losses(z,expected_y).sum()))
 errors.append(close(payload['sampled_ce'],sum(sampled)/2))
 c=payload['coverage'];assert set(c)=={'context','eval_batch_size','block_tokens','target_count','window_count','mean_ce','block_loss_sums','block_target_counts'}
 assert (c['context'],c['eval_batch_size'],c['block_tokens'],c['target_count'],c['window_count'])==(8,2,16,21,3)
 assert c['block_target_counts']==[16,5]
 errors.append(close(c['block_loss_sums'],sums));errors.append(close(c['mean_ce'],sum(sums)/21))
 return dict(status='verified',forward_calls=6,default_modes=2,sampled_batches=2,synthetic_coverage_targets=21,synthetic_coverage_windows=3,short_tail=5,objective_graph_links=2,max_error=max(errors),scope='Synthetic logits observations independently rescored with FP64 CE; checkpoint binding through same objective graph. Does not rescore corpus/raw/derived files or replace full checkpoint audit.')
