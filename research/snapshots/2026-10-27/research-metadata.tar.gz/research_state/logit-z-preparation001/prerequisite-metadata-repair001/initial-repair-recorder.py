from pathlib import Path
import ast,datetime,hashlib,json,sys
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');Z=B/'research_state/logit-z-preparation001';F=Z/'pilot-tools001';R=Z/'prerequisite-metadata-repair001';R.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(Path(p).resolve()),sha256=sha(p))
original=F/'review-prerequisites001.py';new=F/'review-prerequisites002.py';assert not new.exists() and not (Z/'review.json').exists()
s=original.read_text();needle=" graph_checks.append(dict(width=w,family=f,**graph_review))";assert s.count(needle)==1
replace=" assert graph_review['width']==w and graph_review['objective_kind']==f\n graph_checks.append(dict(graph_review,family=f))"
s=s.replace(needle,replace)
needle2="out=args.output;assert not out.exists();"
assert s.count(needle2)==1
s=s.replace(" artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])", " artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts+[folder.parent/'prerequisite-metadata-repair001/review.json',folder.parent/'prerequisite-audit-first.log',folder/'review-prerequisites001.py'])])")
assert 'prerequisite-metadata-repair001/review.json' in s
ast.parse(s);new.write_text(s)
(R/'original-reviewer.py').write_bytes(original.read_bytes());(R/'first-failed-audit.log').write_bytes((Z/'prerequisite-audit-first.log').read_bytes())
pilot=Z/'mps-pilots001';inventory=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(pilot.rglob('*')) if p.is_file()];(R/'unchanged-pilot-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
# Execute just the corrected assembly AST, using the six existing JSON reviews; no tensor load/model import.
ns={};nodes=ast.parse(replace.strip()).body
for path in sorted(pilot.glob('w*/linked-graph-review.json')):
 g=json.loads(path.read_text());w=int(path.parent.name.split('_')[0][1:]);f=path.parent.name.split('_',1)[1];ns=dict(graph_review=g,w=w,f=f,graph_checks=[]);exec(compile(ast.Module(body=nodes,type_ignores=[]),'assembly','exec'),ns);assert ns['graph_checks']==[{**g,'family':f}]
 for key,bad in [('width',-1),('objective_kind','wrong')]:
  b=dict(g);b[key]=bad;n=dict(graph_review=b,w=w,f=f,graph_checks=[])
  try:exec(compile(ast.Module(body=nodes,type_ignores=[]),'assembly','exec'),n)
  except AssertionError:pass
  else:raise AssertionError('Invalid metadata accepted')
assert len(list(pilot.glob('w*/linked-graph-review.json')))==6
review=dict(status='metadata_assembly_repaired_no_training_or_scoring_rerun',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),failure="dict(width=w,family=f,**graph_review) duplicated the producer's width key. The first independent audit stopped after first-cell checks and before final review output.",repair='Version002 explicitly checks graph width/objective kind, copies the already validated graph mapping, then adds family once. All numerical/model/checkpoint/resource predicates and tolerances are unchanged; original001 immutable.',six_saved_json_assembly_routes_passed=True,corrupt_width_objective_rejections=12,source_sha256='c9319b87f4a07371695ffb29caaf200c7de51075f271613e62d0a9e29b560895',source_commit='37c3150d946c1d4884e88d48021b36801d626465',artifacts=[art(original),art(new),art(R/'original-reviewer.py'),art(R/'first-failed-audit.log'),art(R/'unchanged-pilot-inventory.json')])
(R/'review.json').write_text(json.dumps(review,indent=2)+'\n')
sys.path.insert(0,str(S));from src.research.team.knowledge import KnowledgeBank
bank=KnowledgeBank(B/'research_state/knowledge');kid=bank.add(dict(kind='observation',outcome='failed',created_by='continuing-quality-research',title='Logit-z prerequisite reviewer duplicated width metadata after successful pilots',summary='All six fresh MPS pilots completed with saved graph and full-validation evidence. The independent reviewer stopped on duplicate width keyword while assembling a graph summary; no model or tolerance defect was identified. Original log/reviewer and complete pilot-byte inventory preserved. Version002 explicitly verifies producer width/objective and adds family once; six saved-JSON assembly routes and12 corruption rejections passed. No training/scoring rerun. Full repaired audit still required.',scope=dict(source_commit=review['source_commit'],source_sha256=review['source_sha256']),details=review,artifacts=[art(R/'review.json')],related_ids=['kb_b074183b9557430b742e2cbeac69a507943c6bc4bb4f2c623e470d53c7d47840','kb_f151585b1c3aa0367175f23150d6ccb9d4c19b3a83aed88db44bd6b58df866ea']))
(R/'knowledge.json').write_text(json.dumps(dict(knowledge_id=kid),indent=2)+'\n');snap=Z/'prerequisite-repair-knowledge-snapshot001.md';assert not snap.exists();snap.write_text(bank.export_markdown());snap.chmod(0o444)
for p in R.iterdir():p.chmod(0o444)
new.chmod(0o444);assert 'torch' not in sys.modules;print(json.dumps(dict(knowledge_id=kid,reviewer=art(new),review=art(R/'review.json'))))
