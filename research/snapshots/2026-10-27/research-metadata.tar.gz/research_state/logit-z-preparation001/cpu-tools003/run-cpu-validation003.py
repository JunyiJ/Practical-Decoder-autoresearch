"""Reviewed one-time continuation after monitor failure; no completed case is rerun."""
from pathlib import Path
import os,sys,json,subprocess,shutil,datetime
from bounded_cpu import atomic_json,sha,collected_ids,passed_ids,live_model_commands,cleanup_passed_batch
from recovery import validate_orphan
from segments import passed_prefix,remaining_ids
from process_guard import execute
BASE=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');ROOT=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=BASE/'research_state/logit-z-preparation001';R=P/'cpu-scratch-isolation-repair001';OLD=P/'cpu-watchdog-repair001';SCRATCH=Path('/private/tmp/rsi-logit-z-cpu002')
if Path.cwd()!=ROOT or 'PYTORCH_ENABLE_MPS_FALLBACK' in os.environ:raise ValueError('Use frozen isolated cwd and unset fallback')
active=json.loads((BASE/'research_state/active-campaign.json').read_text())
if active['kind']!='position_quality' or active['status']!='completed_reviewed':raise ValueError('Final predecessor required')
run=Path(active['campaign'])
if json.loads((run/'review.json').read_text())['status']!='verified' or json.loads((run/'state.json').read_text())['status']!='completed':raise ValueError('Final verified predecessor required')
live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
if live:raise ValueError('Competing work '+str(live))
manifest=P/'cpu-execution-manifest.json';frozen=R/'failed-manifest.json'
if sha(manifest)!=sha(frozen):raise ValueError('Original failed manifest required; no automatic retry')
record=json.loads(manifest.read_text())
if record['status']!='failed' or record['pid']!=49786 or record['active_pid'] is not None or len(record['batches'])!=100:raise ValueError('Wrong failure lineage')
if shutil.disk_usage('/private/tmp').free<10*2**30:raise ValueError('Insufficient free space')
from src.research.team.suite import source_digest
integration=json.loads((P/'integration-review.json').read_text());source=source_digest(ROOT);test_hashes=record['test_hashes']
def verify():
    if source_digest(ROOT)!=source or source!=integration['source_sha256'] or source!=record['source_sha256']:raise ValueError('Frozen source changed')
    for x in integration['files']:
        if sha(ROOT/x['path'])!=x['sha256']:raise ValueError('Integration changed')
    if {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'tests').rglob('*.py'))}!=test_hashes:raise ValueError('Tests changed')
verify();ids=collected_ids((P/'full-collection.log').read_text())
if ids!=record['collection']['ids'] or len(ids)!=5689:raise ValueError('Collection changed')
actual=['tests/test_logit_z_geometry.py','tests/test_logit_z_training.py'];files=actual+sorted({n.split('::')[0] for n in ids}-set(actual))
for i,item in enumerate(record['batches'][:99]):
    selected=[n for n in ids if n.startswith(files[i]+'::')];receipt=json.loads(Path(item['cleanup']).read_text())
    if i==84:
        validate_orphan(item,receipt,Path(item['log']).read_text(),selected)
    else:
        result=passed_ids(Path(item['log']).read_text(),item['exit_code'],selected)
        if item['file']!=files[i] or item['expected_ids']!=selected or sha(item['log'])!=item['log_sha256'] or receipt['status']!='passed_scratch_removed' or receipt['verified']!=result or Path(item['scratch']).exists():raise ValueError('Prior successful batch changed')
interrupted=record['batches'][99]
if interrupted['file']!=files[99] or sha(interrupted['log'])!=interrupted['log_sha256']:raise ValueError('Interrupted file changed')
tail=remaining_ids(Path(interrupted['log']).read_text(),interrupted['expected_ids'],interrupted['exit_code'])
from bounded_cpu import inventory
receipt=json.loads((R/'interrupted-scratch-preserved.json').read_text())
if inventory(interrupted['scratch'])!=receipt['inventory']:raise ValueError('Preserved resource-failure scratch changed')
review=json.loads((R/'review.json').read_text())
for x in review['artifacts']:
    if sha(x['path'])!=x['sha256']:raise ValueError('Repair lineage changed')
if SCRATCH.exists():raise ValueError('Unique fresh scratch required; no retry')
budgets={label:cap-sum(x['seconds'] for x in record['batches'] if x['partition']==label) for label,cap in [('actual',900.),('remaining',5400.)]}
if min(budgets.values())<=0:raise ValueError('Original budget exhausted')
record.setdefault('continuation_history',[]).append(record['continuation'])
record['batches']=record['batches'][:99]
record.update(status='running',pid=os.getpid(),active_pid=None,active_scratch_root=str(SCRATCH),continuation_started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),continuation=dict(review=str(R/'review.json'),review_sha256=sha(R/'review.json'),original_failure_manifest=str(frozen),original_failure_manifest_sha256=sha(frozen),orphan_exit_code_unavailable=True,orphan_wall_reservation_seconds=600,budget_remaining_at_start=budgets.copy(),interrupted_batch=interrupted,partial_passed_cases=4,remaining_tail_ids=tail))
SCRATCH.mkdir()
record.pop('finished_at',None);record.pop('error',None)
def save():atomic_json(manifest,record)
def on_pid(pid):record['active_pid']=pid;save()
save();env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.')
wrapper='import torch;torch.set_num_threads(1);import pytest,sys;sys.exit(pytest.main(sys.argv[1:]))'
print(json.dumps(dict(status='continuing_unexecuted_only',completed_cases=sum(len(x['expected_ids']) for x in record['batches'])+4,next_file=files[99],next_case_ids=tail,budget_remaining=budgets)),flush=True)
try:
    for i in range(99,len(files)):
        f=files[i];verify();label='actual' if f in actual else 'remaining'
        if shutil.disk_usage('/private/tmp').free<10*2**30:raise ValueError('Insufficient headroom; preserve evidence')
        if budgets[label]<=0:raise ValueError('Original partition budget exhausted')
        scratch=SCRATCH/f'batch-{i:04d}';scratch.mkdir();log=P/(f'cpu-batch-{i:04d}-tail.log' if i==99 else f'cpu-batch-{i:04d}.log');expected=tail if i==99 else [n for n in ids if n.startswith(f+'::')]
        targets=tail if i==99 else [f]
        command=[sys.executable,'-u','-c',wrapper,*targets,'-vv','-x','--color=no','-p','no:cacheprovider','--basetemp',str(scratch)]
        code,seconds=execute(command,ROOT,env,log,budgets[label],SCRATCH,on_pid);budgets[label]-=seconds
        segment=dict(file=f,partition=label,log=str(log),log_sha256=sha(log),exit_code=code,seconds=seconds,expected_ids=expected,scratch=str(scratch))
        if i==99:
            original=dict(interrupted,expected_ids=interrupted['expected_ids'][:4],cleanup=str(R/'interrupted-scratch-preserved.json'))
            item=dict(interrupted,exit_code=None,seconds=interrupted['seconds']+seconds,process_exit_status='segmented_after_resource_stop',segments=[original,segment],cleanup=str(R/'interrupted-scratch-preserved.json'))
        else:item=segment
        record['batches'].append(item);save()
        passed_ids(log.read_text(),code,expected);verify()
        receipt=P/(f'cpu-batch-{i:04d}-tail-cleanup.json' if i==99 else f'cpu-batch-{i:04d}-cleanup.json');cleanup_passed_batch(SCRATCH,scratch,log,code,expected,receipt)
        segment['cleanup']=str(receipt);save()
    verify();record.update(status='completed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print('All case assertions completed; independent version003 review and explicit orphan-exit limitation required',flush=True)
except BaseException as exc:
    record.update(status='failed',error=repr(exc),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
