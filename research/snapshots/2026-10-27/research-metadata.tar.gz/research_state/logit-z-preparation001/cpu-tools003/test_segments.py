import unittest,sys,ast,json,copy,tempfile,hashlib
from pathlib import Path
from segments import passed_prefix,remaining_ids
import importlib.util
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('record-cpu-review003.py'));audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
P=Path(__file__).resolve().parents[1];R=P/'cpu-scratch-isolation-repair001'
class Segments(unittest.TestCase):
 def test_preserved_prefix_and_no_repeat(self):
  m=json.loads((R/'failed-manifest.json').read_text());item=m['batches'][99];t=Path(item['log']).read_text();ids=item['expected_ids']
  self.assertEqual(passed_prefix(t,ids,125),ids[:4]);self.assertEqual(remaining_ids(t,ids,125),ids[4:])
  for text,expected,code in [(t,ids,0),(t.replace('PASSED','FAILED',1),ids,125),(t+t,ids,125),(t+'Traceback',ids,125),(t+'1 passed in 1.0s',ids,125),(t,list(reversed(ids)),125),(t.replace('PASSED','SKIPPED',1),ids,125),(t.replace('PASSED','ERROR',1),ids,125)]:
   with self.assertRaises(ValueError):passed_prefix(text,expected,code)
  allids=m['collection']['ids'];done=[n for b in m['batches'][:99] for n in b['expected_ids']]+ids[:4];todo=[x for x in allids if x not in set(done)]
  self.assertEqual(len(done),3659);self.assertEqual(len(todo),2030);self.assertEqual(len(done),len(set(done)));self.assertFalse(set(done)&set(todo))
 def test_normal_receipt_and_corruptions(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d).resolve();log=root/'log';receipt=root/'receipt';expected=['tests/a.py::test_a'];log.write_text('tests/a.py::test_a PASSED [100%]\n1 passed in 1.0s\n');sha=audit.sha(log)
   item=dict(expected_ids=expected,scratch=str(root/'batch-0099'),log=str(log),cleanup=str(receipt),log_sha256=sha,exit_code=0)
   r=dict(status='passed_scratch_removed',batch=item['scratch'],log=str(log),log_sha256=sha,exit_code=0,verified=dict(ids=expected,seconds=1.,warnings=0),bytes=0,inventory=[]);receipt.write_text(json.dumps(r))
   self.assertEqual(audit.normal(item,expected,root,99,[])['ids'],expected)
   for k,v in [('status','bad'),('exit_code',125),('log_sha256','bad'),('bytes',1),('verified',{}),('batch','wrong')]:
    b=dict(r);b[k]=v;receipt.write_text(json.dumps(b))
    with self.assertRaises(ValueError):audit.normal(item,expected,root,99,[])
 def test_fresh_scratch_exact_tail_dispatch(self):
  p=Path(__file__).with_name('run-cpu-validation003.py');s=p.read_text();tree=ast.parse(s)
  self.assertIn("SCRATCH=Path('/private/tmp/rsi-logit-z-cpu002')",s);self.assertIn("targets=tail if i==99 else [f]",s);self.assertNotIn('--collect-only',s)
  ranges=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='range'];self.assertEqual(len(ranges),1);self.assertEqual(ast.literal_eval(ranges[0].args[0]),99)
  self.assertIn("code,seconds=execute(command,ROOT,env,log,budgets[label],SCRATCH,on_pid)",s)
  self.assertEqual((Path(__file__).parent/'process_guard.py').read_bytes(),(P/'cpu-tools002/process_guard.py').read_bytes())
  with self.assertRaises(ValueError):audit.verify_records(dict(status='failed',active_pid=None),P,[])
if __name__=='__main__':unittest.main(verbosity=2)
