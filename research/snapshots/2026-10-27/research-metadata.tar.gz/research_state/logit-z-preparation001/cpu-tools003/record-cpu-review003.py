"""Complete unique CPU assertion audit with both preserved monitoring failures explicit."""
import argparse,json,datetime,math
from pathlib import Path
from bounded_cpu import sha,collected_ids,passed_ids,inventory
from recovery import validate_orphan
from segments import passed_prefix
EXPECTED={'tests/test_logit_z_geometry.py':15,'tests/test_logit_z_training.py':12,'tests/test_logit_z_contract.py':280,'tests/test_logit_z_study.py':190,'tests/test_logit_z_predecessor.py':29,'tests/test_logit_z_report_audit.py':36}

def normal(item,expected,root,index,artifacts):
    if item['expected_ids']!=expected or Path(item['scratch'])!=root/f'batch-{index:04d}':raise ValueError('Wrong normal case partition or scratch namespace')
    log=Path(item['log']);receipt_path=Path(item['cleanup']);r=json.loads(receipt_path.read_text())
    if sha(log)!=item['log_sha256'] or Path(item['scratch']).exists():raise ValueError('Changed log or incomplete cleanup')
    result=passed_ids(log.read_text(),item['exit_code'],expected)
    if (r['status']!='passed_scratch_removed' or r['batch']!=item['scratch'] or r['log']!=item['log'] or r['log_sha256']!=item['log_sha256'] or r['exit_code']!=0 or r['verified']!=result or r['bytes']!=sum(x['bytes'] for x in r['inventory'] if x['kind']=='file')):raise ValueError('Cleanup receipt mismatch')
    artifacts.extend([log,receipt_path]);return result

def verify_records(m,folder,artifacts):
    if m['status']!='completed' or m['active_pid'] is not None:raise ValueError('Terminal completion required')
    ids=collected_ids((folder/'full-collection.log').read_text());actual=list(EXPECTED)[:2];files=actual+sorted({n.split('::')[0] for n in ids}-set(actual))
    if len(ids)!=5689 or m['collection']['ids']!=ids or m['collection']['exit_code']!=0 or len(m['batches'])!=len(files):raise ValueError('Exact complete5689 collection required')
    if {f:sum(n.startswith(f+'::') for n in ids) for f in EXPECTED}!=EXPECTED:raise ValueError('Actual/metadata partitions differ')
    oldroot=Path('/private/tmp/rsi-logit-z-cpu001');newroot=Path('/private/tmp/rsi-logit-z-cpu002');done=[];known_seconds=0;warnings=0
    for i,item in enumerate(m['batches']):
        selected=[n for n in ids if n.startswith(files[i]+'::')]
        if item['file']!=files[i] or item['expected_ids']!=selected or item['partition']!=('actual' if i<2 else 'remaining'):raise ValueError('Order or partition mismatch')
        if i==84:
            log=Path(item['log']);receipt=Path(item['cleanup'])
            if sha(log)!=item['log_sha256'] or Path(item['scratch'])!=oldroot/'batch-0084':raise ValueError('Orphan log/root mismatch')
            result=validate_orphan(item,json.loads(receipt.read_text()),log.read_text(),selected);artifacts.extend([log,receipt])
        elif i==99:
            if item['process_exit_status']!='segmented_after_resource_stop' or item['exit_code'] is not None or len(item['segments'])!=2:raise ValueError('Exact resource-stop segmentation required')
            first,last=item['segments'];log=Path(first['log']);receipt=Path(first['cleanup']);r=json.loads(receipt.read_text());prefix=passed_prefix(log.read_text(),selected,first['exit_code'])
            if sha(log)!=first['log_sha256'] or first['expected_ids']!=prefix or first['scratch']!=str(oldroot/'batch-0099'):raise ValueError('Stopped prefix changed')
            if (r['status']!='resource_stopped_scratch_preserved' or r['exit_code']!=125 or r['passed_ids']!=prefix or r['log']!=first['log'] or r['log_sha256']!=first['log_sha256'] or r['batch']!=first['scratch'] or inventory(first['scratch'])!=r['inventory'] or r['bytes']!=sum(x['bytes'] for x in r['inventory'] if x['kind']=='file')):raise ValueError('Stopped evidence changed')
            tail=normal(last,selected[4:],newroot,99,artifacts)
            if not math.isclose(item['seconds'],first['seconds']+last['seconds'],rel_tol=0,abs_tol=1e-9):raise ValueError('Interrupted work must remain charged')
            result=dict(ids=prefix+tail['ids'],seconds=tail['seconds'],warnings=tail['warnings']);artifacts.extend([log,receipt])
        else:result=normal(item,selected,oldroot if i<99 else newroot,i,artifacts)
        done.extend(result['ids']);known_seconds+=result['seconds'];warnings+=result['warnings']
    if len(done)!=5689 or len(set(done))!=5689 or set(done)!=set(ids):raise ValueError('Missing/duplicate assertions')
    for label,cap in [('actual',900),('remaining',5400)]:
        values=[x['seconds'] for x in m['batches'] if x['partition']==label]
        if any(not math.isfinite(x) or x<0 for x in values) or sum(values)>cap:raise ValueError('Original wall budget exceeded')
    return dict(collected=5689,passed=5689,actual_tests=27,remaining_tests=5662,metadata_tests=535,failed=0,batches=len(files),warnings_in_completed_summaries=warnings,total_test_seconds_from_completed_summaries=known_seconds,partial_prefix_case_durations_unavailable=4,partial_prefix_warning_summary_unavailable=True,orphan_process_exit_codes_unavailable=1,preserved_monitoring_failures=2)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--folder',type=Path,required=True);a=ap.parse_args();p=a.folder.resolve();root=Path.cwd()
    from src.research.team.suite import source_digest
    manifest=p/'cpu-execution-manifest.json';m=json.loads(manifest.read_text());integration=p/'integration-review.json';integ=json.loads(integration.read_text());artifacts=[manifest,integration,p/'full-collection.log',Path(__file__)]
    if source_digest(root)!=m['source_sha256'] or integ['source_sha256']!=m['source_sha256'] or {str(q.relative_to(root)):sha(q) for q in sorted((root/'tests').rglob('*.py'))}!=m['test_hashes']:raise ValueError('Source/test changes')
    for x in integ['files']:
        q=root/x['path']
        if sha(q)!=x['sha256']:raise ValueError('Integrated source changed')
        artifacts.append(q)
    for r in [p/'cpu-watchdog-repair001/recovery-review.json',p/'cpu-scratch-isolation-repair001/review.json']:
        artifacts.append(r)
        for x in json.loads(r.read_text())['artifacts']:
            q=Path(x['path'])
            if sha(q)!=x['sha256']:raise ValueError('Failure/repair lineage changed')
            artifacts.append(q)
    if sha(p/'cpu-scratch-isolation-repair001/review.json')!=m['continuation']['review_sha256']:raise ValueError('Continuation lineage changed')
    for name in ['bounded_cpu.py','recovery.py','segments.py','process_guard.py','run-cpu-validation003.py']:artifacts.append(Path(__file__).with_name(name))
    result=verify_records(m,p,artifacts)
    out=p/'cpu-review.json'
    if out.exists():raise ValueError('Preserve existing review')
    review=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=m['source_sha256'],full_tests=result,actual_logit_z_geometry_tests_passed=15,actual_logit_z_training_tests_passed=12,logit_z_metadata_tests_passed=535,checks=['Exact5689 unique passed case assertions across original/continuation logs; no completed case rerun','Frozen source/test hashes; original900/5400sec budgets include orphan600sec reservation and interrupted54.894918sec','All normal scratch inventoried before removal; both monitor-failure batches fully preserved and independently rehashed'],limitations=['Two monitoring failures preserved: transient checkpoint-rename race then retained-evidence scratch accounting','Orphan batch84 OS exit code unavailable;12 assertions and complete passing summary plus observed process exit, never fabricated zero','Batch99 resource-stop125;4 completed assertions preserved, only interrupted/unexecuted2 resumed. Durations/warning summary for4-case prefix unavailable','CPU assertion correctness is not quality or MPS proof; actual serial MPS/prerequisite/resource gates remain required'],artifacts=[dict(path=str(q.resolve()),sha256=sha(q)) for q in dict.fromkeys(artifacts)])
    out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
