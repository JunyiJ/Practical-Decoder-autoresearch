"""Exact successful prefix from a resource-stopped file; no completed case retry."""
import re

def passed_prefix(text,expected,code):
    if code!=125 or re.search(r'Traceback|INTERNALERROR|\b(?:FAILED|ERROR|SKIPPED|XFAIL|XPASS)\b|\d+ passed in',text):raise ValueError('Only preserved resource-stopped incomplete batch allowed')
    statuses=re.findall(r'^(tests/.+?)\s+PASSED\b',text,re.M)
    if len(statuses)!=4 or statuses!=expected[:4] or len(set(statuses))!=4 or len(expected)!=6:raise ValueError('Exact four-case passing prefix required')
    return statuses

def remaining_ids(text,expected,code):
    done=passed_prefix(text,expected,code)
    return [x for x in expected if x not in done]
