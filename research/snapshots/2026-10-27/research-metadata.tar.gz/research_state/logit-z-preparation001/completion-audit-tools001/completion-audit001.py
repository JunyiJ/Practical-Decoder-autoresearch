"""Deferred complete logit-z evidence audit. No training or model evaluation."""
import argparse,copy,datetime,json,math,subprocess,re
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);args=parser.parse_args()
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=args.run.resolve();folder=Path(__file__).resolve().parent
if run.parent!=root/'research_runs' or not run.name.startswith('logit-z-quality-'):
 raise ValueError('A distinct registered logit-z run is required')
active=json.loads((root/'research_state/active-campaign.json').read_text())
if Path(active['campaign']).resolve()!=run or json.loads((run/'state.json').read_text())['status']!='completed':
 raise ValueError('Logit-z study must be completed before CPU checkpoint audit')
import os,sys
sys.path.insert(0,str(folder.parent/'cpu-tools001'))
from bounded_cpu import live_model_commands
processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True)
if live_model_commands(processes,{os.getpid(),os.getppid()}):
 raise ValueError('Competing model work; defer completion checkpoint audit')
if (run/'review.json').exists():raise ValueError('Existing completion review must be preserved')
import torch
from omegaconf import OmegaConf
from src.models.gpt import GPT
from src.models.output_bias import POLICY
from src.models.weight_tying import validate_weight_tying_model,POLICY as TYING_POLICY
from src.models.residual_topology import validate_residual_topology_model,POLICY as TOPOLOGY_POLICY
from src.models.attention_scale import validate_attention_scale_model,POLICY as ATTENTION_SCALE_POLICY
from src.models.gated_activation import validate_gated_activation_model,POLICY as GATE_POLICY
from src.models.residual_gain import validate_residual_gain_model,POLICY as GAIN_POLICY,PARAMETERS as GAIN_PARAMETERS
from src.models.value_residual import validate_value_residual_model,POLICY as VALUE_POLICY
from src.models.position_family import validate_position_family_model,POLICY as POSITION_POLICY
from src.models.logit_z import validate_logit_z_model,POLICY as Z_POLICY,COEFFICIENTS,CONVENTION
from src.research import logit_z_study as study
from src.research.logit_z_audit import audit as independent_report_audit
from src.research.averaging_eval import validate_derivation
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result,disk_mb
from src.research.team.suite import _request
from src.train.weight_averaging import TailWeightAverages
from src.utils.checkpoint import read_checkpoint,load_model_weights

def check_objective_metric(metric,kind):
    coefficient=COEFFICIENTS[kind]
    assert type(metric['train_logit_z_coefficient']) is float and metric['train_logit_z_coefficient']==coefficient
    assert metric['train_aux_loss'] is None and metric['val_aux_loss'] is None and metric['val_loss']==metric['val_ce_loss']
    assert all(type(metric[k]) in (int,float) and math.isfinite(metric[k]) and metric[k]>=0 for k in ('train_ce_loss','train_loss','train_total_loss','val_ce_loss'))
    if kind=='none':
        assert all(metric[k] is None for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert metric['train_loss']==metric['train_total_loss']==metric['train_ce_loss']
    else:
        square,penalty,mean=(metric[k] for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert all(type(x) in (int,float) and math.isfinite(x) for x in (square,penalty,mean))
        assert square>=0 and penalty>=0 and square+1e-4>=mean*mean
        assert math.isclose(penalty,coefficient*square,abs_tol=1e-6,rel_tol=2e-5)
        assert metric['train_loss']==metric['train_total_loss']
        assert math.isclose(metric['train_total_loss'],metric['train_ce_loss']+penalty,abs_tol=1e-6,rel_tol=2e-5)

p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());study.verify_lineage(p)
assert p==json.loads((root/'research_state/logit-z-quality-plan.json').read_text()) and digest(p)==s['plan_sha256']
assert p['objective']==dict(convention=CONVENTION,training_only=True,validation_metric='pure_ce',ignore_index=-100,zero_diagnostics='null_without_extra_arithmetic')
assert p['logit_z_coefficients']==COEFFICIENTS and p['logit_z_policy']==Z_POLICY
import importlib.util
prior_spec=importlib.util.spec_from_file_location('independent_output_prior',folder.parent/'pilot-tools001/prior-audit.py')
prior_audit=importlib.util.module_from_spec(prior_spec);prior_spec.loader.exec_module(prior_audit)
prior_review=prior_audit.verify_prior(Path(p['config']['data']['path']).read_bytes(),p['output_bias_prior'])
assert prior_review['vocabulary_size']==65
assert not any(r['status']=='failed' for r in s['records'])
records=[r for r in s['records'] if r['status']=='completed'];jobs=[list(x) for x in study.local_jobs(p)]
if s['selection']:
 assert s['selection']==json.loads((run/'selection.json').read_text())==study.freeze_selection(p,records[:18])
 jobs+=s['selection']['confirmation']['jobs']
 if s['records'][18:]:
  assert (run/'selection.json').stat().st_mtime<=min((run/'trials'/r['trial_id']/'request.json').stat().st_mtime for r in s['records'][18:])
assert [[r[k] for k in ('family','lr','width','seed')] for r in s['records']]==jobs[:len(s['records'])]
assert len({r['trial_id'] for r in s['records']})==len(s['records']) and disk_mb(run)<4096
assert s['status']=='completed' and len(records)==len(s['records'])==s['selection']['confirmation']['total_distinct_trials']in (36,42) and s['active_seconds']<21600

assert s['selection']['confirmation']==study.confirmation_manifest(p,s['selection']['choices'])
for alias,target in s['selection']['confirmation']['reference_aliases'].items():
 for w in study.WIDTHS:
  for seed in study.CONFIRM_SEEDS:
   aliasjob=dict(family=alias,lr=p['recipe']['learning_rate'],width=w,n_heads=w//32,seed=seed,stage='confirmation',arm='candidate',trial_id='alias_check')
   targetjob={**aliasjob,'family':target,'lr':s['selection']['choices'][target]['lr']}
   directory=run/'unused-alias-check'
   assert _request(study.suite_spec(p,alias,aliasjob['lr']),aliasjob,directory)['config']==_request(study.suite_spec(p,target,targetjob['lr']),targetjob,directory)['config']

torch.set_num_threads(1);checks=[];unique_paths=set();data_length=len(Path(p['config']['data']['path']).read_text())
for r in records:
 assert r['error'] is None and r['duration_seconds']<2400
 d=run/'trials'/r['trial_id'];req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 for name in ('request','result'):assert file_digest(d/f'{name}.json')==r[name+'_sha256']
 assert req==_request(study.suite_spec(p,r['family'],r['lr']),r,d)
 cfg=req['config'];t=cfg['training'];m=cfg['model'];total,start=3000,2000;snapshots=1+(total-start)//10
 assert p['returned_half_life']==200
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
 extra=study.adapter(p,raw,checked,req,d)
 assert all(r.get(k)==v for k,v in {**checked,**extra}.items())
 assert raw['runtime']==dict(cpu_threads=4,requested_device='mps',torch=p['runtime']['packages']['torch'])
 assert raw['completed_steps']==total and raw['eval_iters']==30 and raw['eval_every']==300
 assert json.loads((d/'training_summary.json').read_text())['completed_steps']==total
 metrics=[json.loads(x) for x in (d/'metrics.jsonl').read_text().splitlines()]
 assert metrics==raw['metrics'] and [x['step'] for x in metrics]==list(range(0,total,300))+[total-1]
 assert max(x['rss_mb'] for x in metrics)<4096
 for row in metrics:
  i=row['step'];warmup=p['recipe']['warmup_steps']
  ratio=(.1 if i==total-1 else .1+.9*i/(warmup-1) if warmup and i<warmup-1
         else 1. if i<=start else 1.-.9*(i-start)/(total-start-1))
  assert math.isclose(row['lr_multiplier'],ratio,rel_tol=0,abs_tol=1e-14)
  assert row['base_learning_rate']==r['lr'] and math.isclose(row['scheduled_learning_rate'],r['lr']*ratio,abs_tol=1e-15)
  completed=i+1;expected=0 if completed<start else 1+(completed-start)//10
  assert row['averaging_snapshots']==expected and row['tokens_processed']==completed*1024
  assert row['train_aux_loss'] is None and row['moe_usage'] is None
  check_objective_metric(row,'none' if r['family']==study.REFERENCE else r['family'])
 cp=read_checkpoint(r['checkpoint']);assert file_digest(Path(r['checkpoint']))==r['checkpoint_sha256']
 assert cp['step']==total and cp['parameter_layout_version']==2 and cp['model_math_version']==2
 assert 'averaged_weights' not in cp
 want=copy.deepcopy(cfg);want['model']['vocab_size']=65;assert cp['cfg']==want
 assert t['max_iters']*t['batch_size']*m['block_size']==total*1024 and t['batch_layout']=='paired_blocks512'
 assert t['weight_averaging']==dict(kind='spaced_tail_ema',total_steps=total,start_step=start,interval=10,half_lives=[200])
 schedule=dict(kind='linear_cooldown',total_steps=3000,start_step=2000,min_ratio=.1)
 if p['recipe']['warmup_steps']:schedule.update(kind='warmup_linear_cooldown',warmup_steps=p['recipe']['warmup_steps'],initial_ratio=.1)
 assert t['lr_schedule']==schedule and r['lr'] in study.LRS
 assert r['family']!=study.REFERENCE or r['lr']==p['recipe']['learning_rate']
 contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
  optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=want['model'],data_sha256=p['data_sha256'],
  data_split=dict(train_fraction=.8,val_fraction=.1),eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
  training={k:want['training'][k] for k in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==contract and cp['training_state']['metrics']==metrics
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 gen=torch.Generator().manual_seed(r['seed'])
 for _ in range(total):torch.randint(int(.8*data_length)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
 valgen=torch.Generator().manual_seed(2026);val_length=int(.9*data_length)-int(.8*data_length)
 for _ in range(30):torch.randint(val_length-128,(8,),generator=valgen)
 assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
 model=GPT(OmegaConf.create(want['model']));load_model_weights(model,cp,for_resume=True)
 expected_input=p['recipe']['input_embedding_scale']
 assert model.input_embedding_scale==m['input_embedding_scale']==expected_input
 assert m['input_width_policy']=='mha4_input_scale'
 expected_kind=p['recipe']['readout_norm_kind']
 expected_bias=p['recipe']['output_bias_kind']
 expected_tying=p['recipe']['weight_tying_kind']
 expected_topology=p['recipe']['residual_topology_kind']
 expected_attention_scale=p['recipe']['attention_logit_scale']
 expected_activation=p['recipe']['gated_activation_kind']
 expected_gain=p['recipe']['residual_gain_kind']
 expected_value=p['recipe']['value_residual_kind']
 expected_position=p['recipe']['position_family_kind']
 expected_objective='none' if r['family']==study.REFERENCE else r['family']
 assert m['logit_z_kind']==expected_objective and type(m['logit_z_coefficient']) is float and m['logit_z_coefficient']==COEFFICIENTS[expected_objective] and m['logit_z_objective_policy']==Z_POLICY
 validate_logit_z_model(model)
 assert model.logit_z_signature==(expected_objective,COEFFICIENTS[expected_objective],Z_POLICY,CONVENTION)
 assert m['position_family_kind']==expected_position and m['position_family_width_policy']==POSITION_POLICY
 assert type(m['rope']) is int and m['rope']==1
 validate_position_family_model(model)
 assert model.position_family_signature==(expected_position,POSITION_POLICY,'power2_head_order_exp_minus8',m['n_heads'])
 assert model.position_encoding==expected_position and model.enable_rope is (expected_position=='rope')
 expected_slopes=tuple(2.**(-8.*(head+1)/m['n_heads']) for head in range(m['n_heads'])) if expected_position=='alibi' else ()
 assert all(b.attn.position_family_kind==expected_position and b.attn.position_slopes==expected_slopes for b in model.transformer.h)
 assert not hasattr(model.transformer,'wpe')
 assert m['value_residual_kind']==expected_value and m['value_residual_width_policy']==VALUE_POLICY
 validate_value_residual_model(model)
 assert model.value_residual_signature==(expected_value,VALUE_POLICY)
 for index,block in enumerate(model.transformer.h):
  assert block.attn.value_residual_kind==expected_value
  assert type(block.attn.value_residual_layer) is int and block.attn.value_residual_layer==index
  for owner in (model,block,block.attn):
   assert not hasattr(owner,'first_layer_value') and not hasattr(owner,'value_residual_state')
 assert m['residual_gain_kind']==expected_gain and m['residual_gain_width_policy']==GAIN_POLICY
 validate_residual_gain_model(model)
 assert model.residual_gain_signature==(expected_gain,GAIN_POLICY)
 assert all(b.residual_gain_kind==expected_gain for b in model.transformer.h)
 assert m['gated_activation_kind']==expected_activation and m['gated_activation_width_policy']==GATE_POLICY
 validate_gated_activation_model(model)
 assert model.gated_activation_signature==(expected_activation,GATE_POLICY)
 assert all(b.mlp.gate_activation==expected_activation for b in model.transformer.h)
 assert m['attention_logit_scale']==expected_attention_scale and m['attention_logit_scale_width_policy']==ATTENTION_SCALE_POLICY
 validate_attention_scale_model(model)
 assert model.attention_scale_signature==(expected_attention_scale,ATTENTION_SCALE_POLICY)
 assert all(b.attn.attention_logit_scale==expected_attention_scale for b in model.transformer.h)
 assert m['residual_topology_kind']==expected_topology and m['residual_topology_width_policy']==TOPOLOGY_POLICY
 validate_residual_topology_model(model)
 assert model.residual_topology_signature==(expected_topology,TOPOLOGY_POLICY)
 assert all(b.residual_topology_kind==expected_topology and b.ln1 is not b.ln2 for b in model.transformer.h)
 assert m['weight_tying_kind']==expected_tying and m['weight_tying_width_policy']==TYING_POLICY
 validate_weight_tying_model(model)
 assert model.weight_tying_signature==(expected_tying,TYING_POLICY,64)
 assert m['output_bias_kind']==expected_bias and m['output_bias_width_policy']==POLICY and m['output_bias_prior']==p['output_bias_prior']
 assert model.output_bias_signature==(expected_bias,POLICY,p['output_bias_prior']['prior_sha256'])
 assert m['readout_norm_kind']==expected_kind and m['readout_norm_width_policy']=='mha4_readout_norm' and m['readout_norm_epsilon']==1e-5
 assert model.readout_norm_signature==(expected_kind,1e-5) and model.transformer.ln_f.eps==1e-5
 assert isinstance(model.transformer.ln_f,torch.nn.RMSNorm if expected_kind=='rms' else torch.nn.LayerNorm)
 assert all(torch.isfinite(v).all() for v in cp['model_state'].values())
 named=dict(model.named_parameters());width=r['width'];depth=4
 hidden=21*width//8
 coefficient=p['recipe']['weight_decay']
 assert t['decay_mode']=='independent' and t['weight_decay']==coefficient
 family='mha'
 assert m['attn_type']==family and len(model.transformer.h)==4
 shapes={'transformer.wte.weight':(65,width),'lm_head.weight':(65,width),'transformer.ln_f.weight':(width,),'transformer.ln_f.bias':(width,)}
 if expected_kind!='layer_affine':del shapes['transformer.ln_f.bias']
 if expected_tying=='scaled_tied':del shapes['lm_head.weight']
 assert len(list(model.named_parameters(remove_duplicate=False)))==len(named)
 if expected_bias!='none':shapes['output_bias']=(65,)
 for layer in range(4):
  prefix=f'transformer.h.{layer}.'
  common={'ln1.weight':(width,),'ln2.weight':(width,),
   'mlp.linear_gate.weight':(hidden,width),'mlp.linear_up.weight':(hidden,width),'mlp.linear_down.weight':(width,hidden)}
  attn={'attn.qkv.weight':(3*width,width),'attn.qkv.bias':(3*width,),'attn.out.weight':(width,width),'attn.out.bias':(width,)}
  if expected_position=='rope':
   angles=torch.outer(torch.arange(128,dtype=torch.float32),1./(10000.**(torch.arange(0,32,2,dtype=torch.float32)/32)))
   for key,reference in (('freq_cos',angles.cos()),('freq_sin',angles.sin())):
    actual=cp['model_state'][prefix+key]
    assert actual.dtype==torch.float32 and actual.shape==(128,16) and torch.equal(actual,reference)
  else:
   assert prefix+'freq_cos' not in cp['model_state'] and prefix+'freq_sin' not in cp['model_state']
  assert m['depth_width_policy']=='depth4_unscaled' and m['attention_width_policy']=='mha_head32'
  shapes.update({prefix+k:v for k,v in {**common,**attn}.items()})
  if expected_gain=='learned_tenth':shapes.update({prefix+name:(width,) for name in GAIN_PARAMETERS})
 assert set(named)==set(shapes) and all(tuple(named[k].shape)==v for k,v in shapes.items())
 expected_state=set(shapes) | ({f'transformer.h.{layer}.{key}' for layer in range(4) for key in ('freq_cos','freq_sin')} if expected_position=='rope' else set())
 assert set(cp['model_state'])==expected_state
 expected_count=sum(math.prod(v) for v in shapes.values());assert sum(v.numel() for v in named.values())==expected_count
 assert not any('.mlp.hidden_norm.' in n for n in named)
 seen=[];assert cp['optimizer_state']['version']==1 and cp['optimizer_state']['independent_decay']==coefficient
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   assert len(g['params'])==len(g['parameter_names'])==1
   name=g['parameter_names'][0];seen.append(name);v=named[name];matrix=name.startswith('transformer.h.') and v.ndim==2
   scale=1/math.sqrt(width/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==r['lr']*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'} and g['momentum']==.95 and g['adjust_lr_fn']=='match_rms_adamw'
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total and g['betas']==(.9,.999)
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==v.shape
 assert len(seen)==len(set(seen))==len(named) and set(seen)==set(named)
 state=cp['training_state']['weight_averaging_state'];tracker=TailWeightAverages(model,OmegaConf.create(t));tracker.load_state_dict(state,total)
 assert state['spec']==t['weight_averaging'] and state['completed_steps']==total and state['snapshots']==snapshots
 assert state['parameter_names']==list(named) and set(state['averages'])=={'200'}
 rawpath=Path(r['checkpoint']).resolve();assert rawpath not in unique_paths;unique_paths.add(rawpath)
 derived_checks=[]
 for h in (200,):
  item=r['averaged_outputs'][str(h)];path=Path(item['checkpoint']).resolve();assert path not in unique_paths;unique_paths.add(path)
  job=dict(checkpoint=str(path),checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=str(rawpath),
   parent_sha256=r['checkpoint_sha256'],half_life=h,completed_steps=total)
  derived=validate_derivation(job)
  assert 'training_state' not in derived and 'optimizer_state' not in derived
  assert derived['averaged_weights']['parameter_names']==list(named) and derived['cfg']==cp['cfg']
  assert derived['averaged_weights']['snapshots']==snapshots
  load_model_weights(model,derived);validate_logit_z_model(model);validate_position_family_model(model);validate_value_residual_model(model);validate_residual_gain_model(model);validate_gated_activation_model(model);validate_weight_tying_model(model);validate_residual_topology_model(model);validate_attention_scale_model(model)
  for name,value in derived['model_state'].items():
   reference=state['averages'][str(h)][name] if name in named else cp['model_state'][name]
   assert value.dtype==reference.dtype and value.shape==reference.shape and torch.equal(value,reference) and torch.isfinite(value).all()
  assert file_digest(path)==item['checkpoint_sha256']
  derived_checks.append(dict(half_life=h,path=str(path),sha256=item['checkpoint_sha256']))
 checks.append(dict(trial_id=r['trial_id'],checkpoint_sha256=r['checkpoint_sha256'],request_sha256=r['request_sha256'],
  result_sha256=r['result_sha256'],parameter_count=expected_count,derived_checkpoints=derived_checks))
 print('Verified trajectory',r['trial_id'],flush=True)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_commit=p['git_commit'],source_sha256=p['source_sha256'],plan_sha256=digest(p),distinct_trajectories=len(records),distinct_checkpoints=len(unique_paths),
 checkpoint_audit=checks,independent_training_prior=prior_review,holdout_consumed=False)
report=json.loads((run/'report.json').read_text());assert study.summarize(p,s)==report
independent=independent_report_audit(p,s,report)
assert independent['physical_trajectories']==len(records) and independent['correlated_outputs']==len(unique_paths)
review.update(report_sha256=file_digest(run/'report.json'),selection_sha256=file_digest(run/'selection.json'),quality_decision=report['quality_decision'],active_seconds=s['active_seconds'],disk_mb=disk_mb(run),reference_aliases=report['reference_aliases'],independent_report_review=independent,
 checks=['Every checkpoint/raw request/result hash, config/source/corpus/runtime/full-bank/prerequisite contract',
 'All eight explicit learned gain vectors when present, MHA/FFN/head/norm shapes independently enumerated and exact parameter counts; corpus-bound training-only counts/formula/hashes independently reconstructed; canonical shared-table uniqueness, explicit RoPE/nope/ALiBi positional semantics, independent fixed power2 slopes and analytic RoPE-only frequencies, absence of learned positional tables or added position state; inherited local/local_half/first_blend value semantics and exact layer identities with no persistent first-value activation; inherited unit/static0.1/learned0.1 full-branch semantics with explicit gain H200 shadows and no folding, inherited SiLU/exact-erf GELU/ReLU semantics and inherited fixed attention scale/serial-parallel topology, separate block norms, and inherited tying/bias/norm/input-scale contracts and strict finite CPU loads',
 'Actual optimizer slots/steps/width factors/constant independent decay/zero child decay; reconstructed private train and reset-validation RNG, untouched test RNG',
 'Step/token/warmup/cooldown/H200 counters, derived-parent shadow equality and inference-only contract; full111538-target coverage',
 'Eighteen fresh2501/2502 screens freeze three LRs and eligible objective family using PURE CE; fresh2511/2512/2513 confirmation64/256; exact prospective incumbent aliases checked',
 'Complete report and every primary/raw paired conditional bootstrap/fixed-LR screen/adoption independently reconstructed',
 'Raw and derived current/saved/constructed logit-z signatures, exact kind/coefficient/convention and absence of objective tensor state; saved telemetry separates pure CE, unweighted squared logZ, mean logZ, once-weighted penalty and total. Zero objective retains exact CE with null logZ diagnostics; sampled validation logs remain pure CE. Separate frozen CPU/MPS objective/evaluator-veto proof is required, since final artifacts alone cannot prove every historical forward call.'],
 limitations=['Saved final shadows cannot reconstruct every historical averaging snapshot; separate correctness tests cover recurrence',
 '36/42 trajectories produce72/84 correlated raw/H200 outputs; adaptive validation, no holdout/seed-population inference',
 'Equal finite LR tuning includes LR choice in selected contrasts. All positional/value/gain/activation/attention/topology/table/bias/prior/norm/input controls are inherited only from the final predecessor. The training-only penalty is lambda times mean squared logsumexp of final FP32 logits over the same valid targets, with no centering, log-vocabulary subtraction, clipping, detach or width scaling; the common-shift coordinate convention matters. Pure CE alone ranks all outputs. No added objective parameters or RNG draws; objective gradients change optimization paths. Saved endpoint/telemetry cannot reconstruct every historical logit or prove historical penalty exclusion, attached value paths, ALiBi placement, cache operations or101EMA snapshots; separately frozen actual CPU/MPS prerequisites are necessary. No identified instability, isolated confidence mechanism, paper reproduction, empirical optimal muP, equal compute, extrapolation or inference-speed claim.'])
assert not (run/'review.json').exists()
(run/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('VERIFIED',len(records),'trajectories',len(unique_paths),'checkpoints')
