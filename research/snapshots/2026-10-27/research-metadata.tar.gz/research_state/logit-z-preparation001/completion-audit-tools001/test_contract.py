"""Deferred auditor AST/metadata only: no Torch or model imports."""
import ast, hashlib, importlib.abc, json, math, sys, unittest
from pathlib import Path
class NoModels(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('torch','src'):raise RuntimeError('Model imports prohibited')
sys.meta_path.insert(0,NoModels())
f=Path(__file__).resolve().parent
code=(f/'completion-audit001.py').read_text();tree=ast.parse(code)
COEFFICIENTS=dict(none=0.,z1e4=.0001,z1e3=.001)
class Study:REFERENCE='incumbent_reference'
class TestDeferred(unittest.TestCase):
 def test_wrong_study_guard_without_imports(self):
  guard=next(x for x in tree.body if isinstance(x,ast.If) and "run.parent" in ast.unparse(x.test))
  root=Path('/synthetic')
  for run in (root/'research_runs/position-quality-001',root/'other/logit-z-quality-001'):
   with self.assertRaises(ValueError):exec(compile(ast.Module(body=[guard],type_ignores=[]),'<guard-only>','exec'),dict(root=root,run=run))
 def test_inherited_position_value_gain_and_objective_routes(self):
  names={'expected_position','expected_objective','expected_value','expected_gain'}
  assignments=[x for x in ast.walk(tree) if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id in names]
  self.assertEqual(len(assignments),4)
  count=0
  for family in (*COEFFICIENTS,Study.REFERENCE):
   for position in ('rope','nope','alibi'):
    for value in ('local','local_half','first_blend'):
     for gain in ('unit','static_tenth','learned_tenth'):
      for width in (64,256):
       env=dict(p={'recipe':dict(position_family_kind=position,value_residual_kind=value,residual_gain_kind=gain)},r=dict(family=family,width=width),study=Study)
       exec(compile(ast.Module(body=assignments,type_ignores=[]),'<metadata-only>','exec'),env)
       self.assertEqual((env['expected_position'],env['expected_value'],env['expected_gain']),(position,value,gain))
       self.assertEqual(env['expected_objective'],'none' if family==Study.REFERENCE else family);count+=1
  self.assertEqual(count,216)
 def test_guards_telemetry_and_semantic_load_wiring(self):
  first_torch=next(x.lineno for x in tree.body if isinstance(x,ast.Import) and any(a.name=='torch' for a in x.names))
  self.assertLess(code.index("Competing model work"),code.index('import torch'))
  self.assertLess(code.index("Existing completion review"),code.index('import torch'))
  screen=ast.parse((f.parent/'screening-tools001/audit.py').read_text())
  metric=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='check_objective_metric')
  ref=next(x for x in screen.body if isinstance(x,ast.FunctionDef) and x.name=='check_objective_metric')
  self.assertEqual(ast.dump(metric,include_attributes=False),ast.dump(ref,include_attributes=False))
  self.assertEqual(code.count('validate_logit_z_model(model)'),2)
  self.assertIn('from src.research.logit_z_audit import audit as independent_report_audit',code)
  self.assertIn("model.logit_z_signature==(expected_objective,COEFFICIENTS[expected_objective],Z_POLICY,CONVENTION)",code)
  self.assertIn("set(cp['model_state'])==expected_state",code)
  self.assertIn("check_objective_metric(row,'none' if r['family']==study.REFERENCE else r['family'])",code)
  self.assertNotIn("expected_position='rope' if r['family']",code)
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TestDeferred))
 assert 'torch' not in sys.modules
 raise SystemExit(not result.wasSuccessful())
