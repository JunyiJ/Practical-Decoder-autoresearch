"""Explicit continuation evidence; never infer an unavailable process exit code."""
from pathlib import Path
import json,re,hashlib
from bounded_cpu import sha,passed_ids,inventory
P=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-preparation001')
R=P/'cpu-watchdog-repair001'
def assertion_summary(text,expected):
    statuses=re.findall(r'^(tests/.+?)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)\b',text,re.M)
    ids=[n for n,s in statuses if s=='PASSED'];summary=re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s',text)
    if (any(s!='PASSED' for _,s in statuses) or len(ids)!=len(set(ids)) or set(ids)!=set(expected) or not summary or int(summary[1])!=len(ids) or re.search(r'\b\d+ (?:failed|errors?|skipped|xfailed|xpassed)\b|Traceback|INTERNALERROR',text)):
        raise ValueError('Complete exact orphan assertion summary required')
    return dict(ids=ids,seconds=float(summary[3]),warnings=int(summary[2] or 0))
def validate_orphan(item,receipt,text,expected,check_disk=True):
    lineage=json.loads((R/'recovery-review.json').read_text())
    for a in lineage['artifacts']:
        if sha(a['path'])!=a['sha256']:raise ValueError('Recovery lineage changed')
    observation=json.loads((R/'orphan-observation.json').read_text())
    if (item['exit_code'] is not None or item.get('process_exit_status')!='unavailable_orphaned_after_monitor_failure' or item['file']!='tests/test_position_family_training.py' or item['seconds']!=600 or observation['status']!='worker_exited_observed' or observation['error'] is not None or observation['exit_code'] is not None or observation['pid']!=49096 or observation['charged_wall_seconds']!=600):raise ValueError('Invalid orphan identity/accounting')
    result=assertion_summary(text,expected)
    if (receipt['status']!='passed_assertions_scratch_preserved_after_monitor_failure' or receipt['exit_code'] is not None or receipt['verified']!=result or receipt['log_sha256']!=item['log_sha256'] or receipt['log']!=item['log'] or receipt['batch']!=item['scratch'] or receipt['bytes']!=sum(x['bytes'] for x in receipt['inventory'] if x['kind']=='file')):raise ValueError('Orphan receipt mismatch')
    if check_disk and inventory(item['scratch'])!=receipt['inventory']:raise ValueError('Preserved orphan scratch changed')
    return result
