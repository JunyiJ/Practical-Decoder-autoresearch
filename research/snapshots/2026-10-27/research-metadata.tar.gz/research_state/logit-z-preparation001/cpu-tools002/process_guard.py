"""Serial subprocess guard: monitoring failures terminate/reap the owned process group."""
import os,signal,subprocess,time,shutil
from pathlib import Path
from bounded_cpu import scratch_bytes

def stop(child):
    if child.poll() is not None:return
    try:os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        child.wait()

def execute(command,cwd,env,log,seconds,scratch,on_pid,sample=scratch_bytes,free=lambda:shutil.disk_usage('/private/tmp').free):
    if seconds<=0:raise ValueError('Exhausted existing partition budget')
    started=time.monotonic();child=None;code=None
    with Path(log).open('x') as out:
        try:
            child=subprocess.Popen(command,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
            on_pid(child.pid)
            while child.poll() is None:
                if time.monotonic()-started>seconds:code=124
                elif sample(scratch)>8*2**30 or free()<2*2**30:code=125
                if code is not None:stop(child);break
                time.sleep(.5)
            if code is None:code=child.returncode
        except BaseException:
            if child is not None:stop(child)
            raise
        finally:
            if child is not None and child.poll() is None:stop(child)
            on_pid(None)
    return code,time.monotonic()-started
