"""Stdlib gates and cleanup restricted to this new validation's passed scratch batch."""
from pathlib import Path
import hashlib,json,os,re,shutil,stat


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def atomic_json(path,data):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');os.replace(tmp,path)


def collected_ids(text):
    ids=[x.strip() for x in text.splitlines() if x.startswith('tests/') and '::' in x]
    m=re.search(r'(\d+) tests collected',text)
    if not m or int(m[1])!=len(ids) or len(ids)!=len(set(ids)):
        raise ValueError('Complete unique collected IDs required')
    return ids


def passed_ids(text,code,expected):
    statuses=re.findall(r'^(tests/.+?)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)\b',text,re.M)
    ids=[n for n,s in statuses if s=='PASSED']
    summary=re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s',text)
    if (code!=0 or any(s!='PASSED' for _,s in statuses) or len(ids)!=len(set(ids))
        or set(ids)!=set(expected) or not summary or int(summary[1])!=len(ids)
        or re.search(r'\b\d+ (?:failed|errors?|skipped|xfailed|xpassed)\b',text)):
        raise ValueError('Exact passed batch required before scratch cleanup')
    return dict(ids=ids,seconds=float(summary[3]),warnings=int(summary[2] or 0))


def live_model_commands(text,ignore):
    live=[]
    for line in text.splitlines():
        a=line.strip().split(None,2)
        if len(a)!=3 or not a[0].isdigit() or int(a[0]) in ignore:continue
        if re.search(r'src\.research\.(?:worker|[a-z_]+study)|src\.train\.train|pytest\.main|python.*-m pytest|run-cpu-validation|pilot-driver',a[2]):live.append((int(a[0]),a[2][:180]))
    return live


def inventory(folder):
    folder=Path(folder);items=[]
    for p in sorted(folder.rglob('*')):
        st=p.lstat();item=dict(path=str(p.relative_to(folder)),bytes=st.st_size)
        if stat.S_ISLNK(st.st_mode):item.update(kind='symlink',target=os.readlink(p))
        elif stat.S_ISREG(st.st_mode):item.update(kind='file',sha256=sha(p))
        elif stat.S_ISDIR(st.st_mode):item.update(kind='directory')
        else:raise ValueError('Unexpected scratch object')
        items.append(item)
    return items


def scratch_bytes(folder):
    total=0
    for p in Path(folder).rglob('*'):
        try: st=p.lstat()
        except FileNotFoundError: continue # Concurrent atomic rename/removal; next sample sees destination.
        if stat.S_ISREG(st.st_mode): total+=st.st_size
    return total


def cleanup_passed_batch(scratch_root,batch,log,code,expected,record_path):
    root=Path(scratch_root);batch=Path(batch);log=Path(log);record_path=Path(record_path)
    # Only a direct uniquely named batch under this run's private scratch root.
    if (root.is_symlink() or batch.is_symlink() or not batch.is_dir()
        or root.resolve()!=root.absolute() or batch.parent!=root
        or not re.fullmatch(r'batch-\d{4}',batch.name)
        or record_path.exists() or record_path.is_relative_to(root)):
        raise ValueError('Unsafe scratch cleanup destination')
    verified=passed_ids(log.read_text(),code,expected)
    entries=inventory(batch)
    if any(x['kind']=='symlink' and not (batch/x['path']).resolve().is_relative_to(batch.resolve()) for x in entries):
        raise ValueError('External scratch link: preserve for review')
    evidence=dict(status='passed_scratch_inventoried',batch=str(batch),log=str(log),log_sha256=sha(log),exit_code=code,verified=verified,inventory=entries,bytes=sum(x['bytes'] for x in entries if x['kind']=='file'),scope='Only temporary files created by this successful batch. Research runs, prior validation, and failed scratch are never touched.')
    atomic_json(record_path,evidence) # Durable inventory BEFORE deletion.
    if sha(log)!=evidence['log_sha256'] or inventory(batch)!=entries:
        raise ValueError('Scratch or successful log changed before deletion')
    shutil.rmtree(batch)
    evidence['status']='passed_scratch_removed';atomic_json(record_path,evidence)
    return evidence
