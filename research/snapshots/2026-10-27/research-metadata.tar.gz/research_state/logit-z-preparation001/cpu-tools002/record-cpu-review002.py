"""Independently verify complete CPU coverage and every bounded-scratch receipt."""
import json,datetime,argparse
from pathlib import Path
from bounded_cpu import collected_ids,passed_ids,sha,inventory
from recovery import validate_orphan
EXPECTED={'tests/test_logit_z_geometry.py':15,'tests/test_logit_z_training.py':12,'tests/test_logit_z_contract.py':280,'tests/test_logit_z_study.py':190,'tests/test_logit_z_predecessor.py':29,'tests/test_logit_z_report_audit.py':36}


def verify_records(manifest,collection,logs,receipts):
    if manifest['status']!='completed' or manifest.get('active_pid') is not None:raise ValueError('CPU execution must be terminal successful')
    names=collected_ids(collection)
    if len(names)!=5689 or manifest['collection']['ids']!=names or manifest['collection']['exit_code']!=0:raise ValueError('Full5689-case collection required')
    if {f:sum(n.startswith(f+'::') for n in names) for f in EXPECTED}!=EXPECTED:raise ValueError('New actual and metadata partitions differ')
    executed=[];actual=0;seconds=0;warnings=0;files=[];actual_files=list(EXPECTED)[:2]
    expected_files=actual_files+sorted({n.split('::')[0] for n in names}-set(actual_files))
    for i,item in enumerate(manifest['batches']):
        f=item['file'];files.append(f);selected=[n for n in names if n.startswith(f+'::')]
        partition='actual' if f in actual_files else 'remaining'
        if item['expected_ids']!=selected or item['partition']!=partition:raise ValueError('Batch partition or identifiers changed')
        orphan=(i==84 and item.get('process_exit_status')=='unavailable_orphaned_after_monitor_failure')
        result=validate_orphan(item,receipts[i],logs[i],selected) if orphan else passed_ids(logs[i],item['exit_code'],selected)
        executed+=result['ids'];seconds+=result['seconds'];warnings+=result['warnings']
        if partition=='actual':actual+=len(result['ids'])
        receipt=receipts[i]
        if (receipt['status']!=('passed_assertions_scratch_preserved_after_monitor_failure' if orphan else 'passed_scratch_removed') or receipt['batch']!=item['scratch']
            or receipt['log']!=item['log'] or receipt['log_sha256']!=item['log_sha256']
            or receipt['exit_code']!=(None if orphan else 0) or receipt['verified']!=result
            or receipt['bytes']!=sum(x['bytes'] for x in receipt['inventory'] if x['kind']=='file')):raise ValueError('Successful scratch cleanup receipt changed')
        if Path(item['scratch'])!=Path(manifest['scratch_root'])/f'batch-{i:04d}':raise ValueError('Scratch batch outside expected namespace')
    if files!=expected_files or len(executed)!=len(set(executed)) or set(executed)!=set(names) or actual!=27:raise ValueError('Missing/repeated CPU cases or incorrect actual-first ordering')
    if len(logs)!=len(files) or len(receipts)!=len(files):raise ValueError('Extra or missing evidence')
    if sum(x.get('process_exit_status')=='unavailable_orphaned_after_monitor_failure' for x in manifest['batches'])!=1:raise ValueError('Exactly one documented orphan exit required')
    for label,cap in [('actual',900),('remaining',5400)]:
        if sum(x['seconds'] for x in manifest['batches'] if x['partition']==label)>cap:raise ValueError('Original CPU budget exceeded')
    return dict(orphan_process_exit_codes_unavailable=1,collected=5689,passed=5689,actual_tests=27,remaining_tests=5662,metadata_tests=535,warnings=warnings,total_test_seconds=seconds,batches=len(files),failed=0)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--folder',type=Path,required=True);args=ap.parse_args();folder=args.folder.resolve();root=Path.cwd()
    from src.research.team.suite import source_digest
    manifest_path=folder/'cpu-execution-manifest.json';m=json.loads(manifest_path.read_text());integration_path=folder/'integration-review.json';integration=json.loads(integration_path.read_text())
    if source_digest(root)!=m['source_sha256'] or integration['source_sha256']!=m['source_sha256']:raise ValueError('CPU source changed')
    if {str(p.relative_to(root)):sha(p) for p in sorted((root/'tests').rglob('*.py'))}!=m['test_hashes']:raise ValueError('Test source changed')
    artifacts=[manifest_path,integration_path,folder/'full-collection.log',Path(__file__),Path(__file__).with_name('bounded_cpu.py')]
    for x in integration['files']:
        f=root/x['path']
        if sha(f)!=x['sha256']:raise ValueError('Integrated file mismatch')
        artifacts.append(f)
    logs={};receipts={}
    for i,item in enumerate(m['batches']):
        log=Path(item['log']);receipt=Path(item['cleanup'])
        if sha(log)!=item['log_sha256']:raise ValueError('Changed log')
        if i!=84 and Path(item['scratch']).exists():raise ValueError('Claimed cleanup incomplete')
        if i==84 and not Path(item['scratch']).is_dir():raise ValueError('Orphan scratch must be preserved')
        logs[i]=log.read_text();receipts[i]=json.loads(receipt.read_text());artifacts.extend([log,receipt])
    recovery_review=folder/'cpu-watchdog-repair001/recovery-review.json'
    if m['continuation']['review_sha256']!=sha(recovery_review):raise ValueError('Recovery review changed')
    artifacts.extend([recovery_review,Path(__file__).with_name('recovery.py')])
    artifacts.extend(Path(x['path']) for x in json.loads(recovery_review.read_text())['artifacts'])
    result=verify_records(m,(folder/'full-collection.log').read_text(),logs,receipts)
    review=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=m['source_sha256'],full_tests=result,actual_logit_z_geometry_tests_passed=15,actual_logit_z_training_tests_passed=12,logit_z_metadata_tests_passed=535,checks=['Exact5689 unique cases, actual27 first, all remaining5662, no skipped/repeated cases','All source/test hashes frozen throughout batch validation','All normal batches exactIDs/log verified before durable scratch cleanup; orphan batch84 complete assertions verified with full scratch retained'],process_exit_status_limitation='Batch84 original parent failed during scratch sampling; all12 exact assertions and final summary passed and worker exit observed, but OS process exit code unavailable; never inferred as zero',limitations=['One orphan worker exit code unavailable; monitor failure and all scratch preserved, 600second conservative reservation charged inside original5400second budget','CPU correctness is not model quality or MPS evidence','Successful temporary test checkpoints removed only after assertions passed; logs and full path/size/hash inventory remain','Six serial actual MPS pilots and independent math/checkpoint/resource audit still required'],artifacts=[dict(path=str(p.resolve()),sha256=sha(p)) for p in dict.fromkeys(artifacts)])
    out=folder/'cpu-review.json'
    if out.exists():raise ValueError('Preserve earlier review')
    out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
