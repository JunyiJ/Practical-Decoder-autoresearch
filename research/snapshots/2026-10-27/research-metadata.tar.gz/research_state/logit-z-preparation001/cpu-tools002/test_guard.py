import unittest,tempfile,os,sys,stat
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from bounded_cpu import scratch_bytes
from process_guard import execute
from recovery import assertion_summary
class Guard(unittest.TestCase):
 def test_atomic_rename_race(self):
  class Entry:
   def __init__(self,mode=None):self.mode=mode
   def lstat(self):
    if self.mode is None:raise FileNotFoundError('concurrent atomic rename')
    return SimpleNamespace(st_mode=self.mode,st_size=17)
  with patch.object(Path,'rglob',return_value=iter([Entry(None),Entry(stat.S_IFREG),Entry(stat.S_IFLNK),Entry(stat.S_IFDIR)])):
   self.assertEqual(scratch_bytes('/unused'),17)
  with patch.object(Path,'rglob',side_effect=PermissionError('not transient')):
   self.assertRaises(PermissionError,scratch_bytes,'/unused')
 def run_child(self,source,seconds=4,sample=lambda p:0,free=lambda:20*2**30):
  with tempfile.TemporaryDirectory() as d:
   ids=[]
   try:return execute([sys.executable,'-c',source],d,os.environ,Path(d)/'out',seconds,d,ids.append,sample,free)
   finally:
    self.assertIsNone(ids[-1])
    with self.assertRaises(ProcessLookupError):os.kill(ids[0],0)
 def test_normal_and_nonzero_exit(self):
  self.assertEqual(self.run_child('print("done")')[0],0)
  self.assertEqual(self.run_child('raise SystemExit(3)')[0],3)
 def test_sampler_failure_reaps(self):
  def fail(p):raise PermissionError('test monitor error')
  with self.assertRaises(PermissionError):self.run_child('import time;time.sleep(60)',sample=fail)
 def test_timeout_and_resource_reap(self):
  self.assertEqual(self.run_child('import time;time.sleep(60)',seconds=.1)[0],124)
  self.assertEqual(self.run_child('import time;time.sleep(60)',sample=lambda p:9*2**30)[0],125)
  self.assertEqual(self.run_child('import time;time.sleep(60)',free=lambda:1*2**30)[0],125)
 def test_exact_assertions_no_exit_inference(self):
  t='tests/a.py::test_a PASSED [100%]\n1 passed in 1.23s\n';e=['tests/a.py::test_a']
  self.assertEqual(assertion_summary(t,e)['ids'],e)
  for bad in [t.replace('PASSED','FAILED'),t.replace('1 passed','0 passed'),t+t,t+'Traceback',t+'INTERNALERROR',t.replace('test_a PASSED','test_b PASSED')]:
   with self.assertRaises(ValueError):assertion_summary(bad,e)
if __name__=='__main__':unittest.main(verbosity=2)
