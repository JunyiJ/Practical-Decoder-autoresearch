import ast
from pathlib import Path
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');N=B/'research_state/position-quality-preparation001';Z=B/'research_state/logit-z-preparation001'
A=Z/'screening-tools001';C=Z/'completion-audit-tools001';assert A.exists() and C.exists() and not (A/'test_audit.py').exists() and not (C/'completion-audit001.py').exists()
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
metric='''def check_objective_metric(metric,kind):
    coefficient=COEFFICIENTS[kind]
    assert type(metric['train_logit_z_coefficient']) is float and metric['train_logit_z_coefficient']==coefficient
    assert metric['train_aux_loss'] is None and metric['val_aux_loss'] is None and metric['val_loss']==metric['val_ce_loss']
    assert all(type(metric[k]) in (int,float) and math.isfinite(metric[k]) and metric[k]>=0 for k in ('train_ce_loss','train_loss','train_total_loss','val_ce_loss'))
    if kind=='none':
        assert all(metric[k] is None for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert metric['train_loss']==metric['train_total_loss']==metric['train_ce_loss']
    else:
        square,penalty,mean=(metric[k] for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert all(type(x) in (int,float) and math.isfinite(x) for x in (square,penalty,mean))
        assert square>=0 and penalty>=0 and square+1e-4>=mean*mean
        assert math.isclose(penalty,coefficient*square,abs_tol=1e-6,rel_tol=2e-5)
        assert metric['train_loss']==metric['train_total_loss']
        assert math.isclose(metric['train_total_loss'],metric['train_ce_loss']+penalty,abs_tol=1e-6,rel_tol=2e-5)

'''
s=(N/'screening-tools001/audit.py').read_text()
s=s.replace("['rope','nope','alibi']","['none','z1e4','z1e3']").replace('2481','2501').replace('2482','2502').replace('2491','2511').replace('2492','2512').replace('2493','2513')
s=replace(s,"POSITIONS=dict(rope='rope',nope='nope',alibi='alibi')","COEFFICIENTS=dict(none=0.,z1e4=.0001,z1e3=.001)\nPOLICY='mha4_final_logit_z'\nCONVENTION='final_fp32_logsumexp_squared_valid_target_mean_v1'\nOBJECTIVE=dict(convention=CONVENTION,training_only=True,validation_metric='pure_ce',ignore_index=-100,zero_diagnostics='null_without_extra_arithmetic')")
s=replace(s,"assert p['position_families']==POSITIONS and p['position_family_policy']=='mha4_position_family' and p['prior_pseudocount']==1","assert p['logit_z_coefficients']==COEFFICIENTS and p['logit_z_policy']==POLICY and p['objective']==OBJECTIVE and p['prior_pseudocount']==1\n    assert all(type(p['logit_z_coefficients'][k]) is float for k in FAMILIES)\n    assert p['objective']['training_only'] is True")
s=replace(s,"'residual_gain_kind','value_residual_kind'}","'residual_gain_kind','value_residual_kind','position_family_kind'}")
s=replace(s,"assert recipe['value_residual_kind'] in ('local','local_half','first_blend')","assert recipe['value_residual_kind'] in ('local','local_half','first_blend')\n    assert recipe['position_family_kind'] in ('rope','nope','alibi')")
# Only independent selection block uses the reference family's name.
start=s.index('    best=min(');end=s.index('\ndef check_row',start)
block=s[start:end].replace("'rope'","'none'").replace('rope/nope/alibi','none/z1e4/z1e3').replace('tuned rope for changed position family','tuned none for nonzero objective coefficient')
s=s[:start]+block+s[end:]
s=replace(s,"position_family_kind=POSITIONS[r['family']]","position_family_kind=p['recipe']['position_family_kind'],logit_z_kind=r['family'],logit_z_coefficient=COEFFICIENTS[r['family']],logit_z_objective_policy=POLICY")
s=replace(s,"    assert req==dict(stage='local',config=cfg,cpu_threads=threads,result_path=str(result_path))","    assert req==dict(stage='local',config=cfg,cpu_threads=threads,result_path=str(result_path))\n    assert type(req['config']['model']['logit_z_coefficient']) is float\n    assert [x['step'] for x in raw['metrics']]==list(range(0,3000,300))+[2999]\n    for metric in raw['metrics']:check_objective_metric(metric,r['family'])")
s=s.replace('research_runs/position-quality-001','research_runs/logit-z-quality-001')
s=replace(s,'def check_row(',metric+'def check_row(')
s=replace(s,"'Screen-only hash/request/result/coverage/arithmetic audit;","'Screen-only hash/request/result/coverage/objective-telemetry arithmetic audit; penalty exclusion and same-batch objective correctness rely on separately frozen CPU/MPS prerequisites, not endpoint JSON alone;")
ast.parse(s);(A/'audit.py').write_text(s)
# Synthetic screening schema and independent selection routes.
t=(N/'screening-tools001/test_audit.py').read_text().replace('position_quality_study.py','logit_z_study.py')
t=t.replace('2481','2501').replace('2482','2502').replace('2491','2511').replace('2492','2512').replace('2493','2513')
t=replace(t,"position_families=a.POSITIONS,position_family_policy='mha4_position_family'","logit_z_coefficients=a.COEFFICIENTS,logit_z_policy=a.POLICY,objective=a.OBJECTIVE")
t=replace(t,"residual_gain_kind='unit',value_residual_kind='local'","residual_gain_kind='unit',value_residual_kind='local',position_family_kind='rope'")
t=replace(t,"selected=dict(rope=incumbent if alias else other,nope=.01,alibi=.005)","selected=dict(none=incumbent if alias else other,z1e4=.01,z1e3=.005)")
t=replace(t,"levels=dict(rope=1.3,nope=1.4,alibi=1.4)","levels=dict(none=1.3,z1e4=1.4,z1e3=1.4)")
t=replace(t,"position_family_kind=a.POSITIONS[f]","position_family_kind=p['recipe']['position_family_kind'],logit_z_kind=f,logit_z_coefficient=a.COEFFICIENTS[f],logit_z_objective_policy=a.POLICY")
t=replace(t," for name,obj in [('request',req),('result',raw)]:"," for metric in raw['metrics']:\n  coefficient=a.COEFFICIENTS[f];penalty=coefficient*4.\n  metric.update(train_ce_loss=1.6,train_loss=1.6+penalty,train_total_loss=1.6+penalty,train_aux_loss=None,val_aux_loss=None,val_loss=1.5,val_ce_loss=1.5,train_logit_z_coefficient=coefficient,train_logit_z_squared_mean=4. if coefficient else None,train_logit_z_mean=2. if coefficient else None,train_logit_z_penalty=penalty if coefficient else None)\n for name,obj in [('request',req),('result',raw)]:")
start=t.index('class TestMetadata');pre=t[:start];test=t[start:]
test=test.replace("best=='rope'","best=='none'").replace("panel(p,'alibi'","panel(p,'z1e3'").replace("panel(p,'nope'","panel(p,'z1e4'").replace("r['family']=='nope'","r['family']=='z1e4'").replace("v['best_selected_arm'],'nope'","v['best_selected_arm'],'z1e4'").replace('then_rope','then_none')
test=replace(test,"p['position_families']={'alibi':'alibi'}","p['logit_z_coefficients']={'z1e3':.001}")
test=replace(test,"p['position_family_policy']='wrong'","p['logit_z_policy']='wrong'")
test=replace(test,"'inherited_gain','inherited_value'):","'inherited_gain','inherited_value','inherited_position','objective','coefficient_type'):")
test=replace(test,"elif damage=='inherited_value':p['recipe']['value_residual_kind']='alibi'","elif damage=='inherited_value':p['recipe']['value_residual_kind']='alibi'\n    elif damage=='inherited_position':p['recipe']['position_family_kind']='z1e4'\n    elif damage=='objective':p['objective']={**p['objective'],'validation_metric':'penalized'}\n    elif damage=='coefficient_type':p['logit_z_coefficients']={**p['logit_z_coefficients'],'none':False}")
test=replace(test,"p['recipe']['residual_gain_kind']=gain;p['recipe']['value_residual_kind']=value;","p['recipe']['residual_gain_kind']=gain;p['recipe']['value_residual_kind']=value;p['recipe']['position_family_kind']=('rope','nope','alibi')[a.RATES.index(lr)];")
test=replace(test,"for damage in ('family','lr','seed','metric','hash','steps','epsilon','kind','position','position_policy','inherited_value'):","for damage in ('family','lr','seed','metric','hash','steps','epsilon','kind','position','position_policy','inherited_value','objective_kind','objective_policy','objective_coefficient'):")
test=replace(test,"'inherited_value':'value_residual_kind'}[damage]","'inherited_value':'value_residual_kind','objective_kind':'logit_z_kind','objective_policy':'logit_z_objective_policy','objective_coefficient':'logit_z_coefficient'}[damage]")
test=replace(test,"('epsilon','kind','position','position_policy','inherited_value'):path.write_text(original)","('epsilon','kind','position','position_policy','inherited_value','objective_kind','objective_policy','objective_coefficient'):path.write_text(original)")
t=pre+test
extra=''' def test_objective_metric_corruptions(self):
  for kind in a.FAMILIES:
   coefficient=a.COEFFICIENTS[kind];penalty=coefficient*4.
   m=dict(train_ce_loss=1.6,train_loss=1.6+penalty,train_total_loss=1.6+penalty,train_aux_loss=None,val_aux_loss=None,val_loss=1.5,val_ce_loss=1.5,train_logit_z_coefficient=coefficient,train_logit_z_squared_mean=4. if coefficient else None,train_logit_z_mean=2. if coefficient else None,train_logit_z_penalty=penalty if coefficient else None)
   a.check_objective_metric(m,kind)
   for field,bad in [('train_logit_z_coefficient',False if kind=='none' else .01),('train_aux_loss',0.),('val_aux_loss',0.),('val_loss',1.6),('train_ce_loss',float('nan')),('train_loss',0.),('train_total_loss',0.),('train_logit_z_penalty',1.),('train_logit_z_squared_mean',-1.),('train_logit_z_mean',10.)]:
    with self.subTest(kind=kind,field=field):
     changed={**m,field:bad}
     with self.assertRaises(AssertionError):a.check_objective_metric(changed,kind)
'''
t=replace(t,"if __name__=='__main__':",extra+"if __name__=='__main__':")
ast.parse(t);(A/'test_audit.py').write_text(t)
# Deferred full checkpoint audit: preserve complete inherited geometry and state checks.
c=(N/'completion-audit-tools001/completion-audit001.py').read_text()
c=c.replace('position-quality-','logit-z-quality-').replace('position_quality_study','logit_z_study').replace('position_quality_audit','logit_z_audit').replace('position-quality-plan.json','logit-z-quality-plan.json').replace('Position-family study','Logit-z study').replace('Deferred complete position-family','Deferred complete logit-z').replace('distinct registered position-quality','distinct registered logit-z')
c=c.replace('2481/2482','2501/2502').replace('2491/2492/2493','2511/2512/2513')
c=replace(c,'from src.research import logit_z_study as study',"from src.models.logit_z import validate_logit_z_model,POLICY as Z_POLICY,COEFFICIENTS,CONVENTION\nfrom src.research import logit_z_study as study")
c=replace(c,"p=json.loads((run/'plan.json').read_text());",metric+"p=json.loads((run/'plan.json').read_text());")
c=replace(c,"assert p==json.loads((root/'research_state/logit-z-quality-plan.json').read_text()) and digest(p)==s['plan_sha256']","assert p==json.loads((root/'research_state/logit-z-quality-plan.json').read_text()) and digest(p)==s['plan_sha256']\nassert p['objective']==dict(convention=CONVENTION,training_only=True,validation_metric='pure_ce',ignore_index=-100,zero_diagnostics='null_without_extra_arithmetic')\nassert p['logit_z_coefficients']==COEFFICIENTS and p['logit_z_policy']==Z_POLICY")
c=replace(c,"  assert row['train_ce_loss']==row['train_loss']==row['train_total_loss']","  check_objective_metric(row,'none' if r['family']==study.REFERENCE else r['family'])")
c=replace(c," expected_position='rope' if r['family']==study.REFERENCE else r['family']"," expected_position=p['recipe']['position_family_kind']\n expected_objective='none' if r['family']==study.REFERENCE else r['family']\n assert m['logit_z_kind']==expected_objective and type(m['logit_z_coefficient']) is float and m['logit_z_coefficient']==COEFFICIENTS[expected_objective] and m['logit_z_objective_policy']==Z_POLICY\n validate_logit_z_model(model)\n assert model.logit_z_signature==(expected_objective,COEFFICIENTS[expected_objective],Z_POLICY,CONVENTION)")
c=replace(c,'load_model_weights(model,derived);validate_position_family_model(model);','load_model_weights(model,derived);validate_logit_z_model(model);validate_position_family_model(model);')
c=replace(c," 'Eighteen fresh2501/2502 screens freeze three LRs and eligible positional family;"," 'Eighteen fresh2501/2502 screens freeze three LRs and eligible objective family using PURE CE;")
c=replace(c," 'Complete report and every primary/raw paired conditional bootstrap/fixed-LR screen/adoption independently reconstructed'],"," 'Complete report and every primary/raw paired conditional bootstrap/fixed-LR screen/adoption independently reconstructed',\n 'Raw and derived current/saved/constructed logit-z signatures, exact kind/coefficient/convention and absence of objective tensor state; saved telemetry separates pure CE, unweighted squared logZ, mean logZ, once-weighted penalty and total. Zero objective retains exact CE with null logZ diagnostics; sampled validation logs remain pure CE. Separate frozen CPU/MPS objective/evaluator-veto proof is required, since final artifacts alone cannot prove every historical forward call.'],")
last=" 'Equal finite LR tuning includes LR choice in selected contrasts;"
idx=c.index(last);end=c.index("])\nassert not (run/'review.json')",idx)
c=c[:idx]+" 'Equal finite LR tuning includes LR choice in selected contrasts. All positional/value/gain/activation/attention/topology/table/bias/prior/norm/input controls are inherited only from the final predecessor. The training-only penalty is lambda times mean squared logsumexp of final FP32 logits over the same valid targets, with no centering, log-vocabulary subtraction, clipping, detach or width scaling; the common-shift coordinate convention matters. Pure CE alone ranks all outputs. No added objective parameters or RNG draws; objective gradients change optimization paths. Saved endpoint/telemetry cannot reconstruct every historical logit or prove historical penalty exclusion, attached value paths, ALiBi placement, cache operations or101EMA snapshots; separately frozen actual CPU/MPS prerequisites are necessary. No identified instability, isolated confidence mechanism, paper reproduction, empirical optimal muP, equal compute, extrapolation or inference-speed claim.'"+c[end:]
ast.parse(c);(C/'completion-audit001.py').write_text(c)
print('Prepared screening and deferred completion audit sources; not executed against research.')
