"""Read-only screen audit: JSON/arithmetic/hashes only; no model or tensor loads."""
import argparse
import copy
import datetime
import hashlib
import json
import math
from pathlib import Path
from statistics import mean
import subprocess
import sys

FAMILIES=['none','z1e4','z1e3']
RATES=[.0025,.005,.01]
SCREENS=[2501,2502]
CONFIRM=[2511,2512,2513]
COEFFICIENTS=dict(none=0.,z1e4=.0001,z1e3=.001)
POLICY='mha4_final_logit_z'
CONVENTION='final_fp32_logsumexp_squared_valid_target_mean_v1'
OBJECTIVE=dict(convention=CONVENTION,training_only=True,validation_metric='pure_ce',ignore_index=-100,zero_diagnostics='null_without_extra_arithmetic')
REFERENCE='incumbent_reference'

def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def endpoint(row,raw=False):
    return row['coverage']['128'] if raw else row['averaged_outputs']['200']['coverage']['evaluations']['128']

def reconstruct(p,rows):
    assert p['families']==FAMILIES and p['learning_rates']==RATES
    assert p['seeds']==SCREENS and p['confirmation_seeds']==CONFIRM and p['widths']==[64,256]
    assert p['logit_z_coefficients']==COEFFICIENTS and p['logit_z_policy']==POLICY and p['objective']==OBJECTIVE and p['prior_pseudocount']==1
    assert all(type(p['logit_z_coefficients'][k]) is float for k in FAMILIES)
    assert p['objective']['training_only'] is True
    recipe=p['recipe'];incumbent_lr=recipe['learning_rate']
    assert set(recipe)=={'warmup_steps','learning_rate','weight_decay','input_embedding_scale','readout_norm_kind','readout_norm_epsilon','output_bias_kind','weight_tying_kind','residual_topology_kind','attention_logit_scale','gated_activation_kind','residual_gain_kind','value_residual_kind','position_family_kind'}
    assert recipe['warmup_steps']==0 and incumbent_lr in RATES and recipe['weight_decay']==.00006 and recipe['input_embedding_scale'] in (1.,.5,.25)
    assert recipe['readout_norm_kind'] in ('layer_affine','layer_no_bias','rms') and recipe['readout_norm_epsilon']==1e-5
    assert recipe['output_bias_kind'] in ('none','learned_zero','learned_train_unigram')
    assert recipe['weight_tying_kind'] in ('legacy_untied','matched_untied','scaled_tied')
    assert recipe['residual_topology_kind'] in ('serial','parallel_separate_norms')
    assert recipe['attention_logit_scale'] in (1.,.5,2.)
    assert recipe['gated_activation_kind'] in ('silu','gelu_exact','relu')
    assert recipe['residual_gain_kind'] in ('unit','static_tenth','learned_tenth')
    assert recipe['value_residual_kind'] in ('local','local_half','first_blend')
    assert recipe['position_family_kind'] in ('rope','nope','alibi')
    jobs=[[f,lr,64,s] for lr in RATES for i,s in enumerate(SCREENS) for f in (FAMILIES if i==0 else FAMILIES[::-1])]
    assert p['screen_jobs']==jobs and len(rows)==18
    assert [[r[k] for k in ('family','lr','width','seed')] for r in rows]==jobs
    assert all(r['stage']=='local' and r['status']=='completed' for r in rows)
    choices={}
    for f in FAMILIES:
        grid=[dict(lr=lr,mean_ce=mean(endpoint(r)['mean_ce'] for r in rows if r['family']==f and r['lr']==lr)) for lr in RATES]
        v=min(grid,key=lambda x:(x['mean_ce'],x['lr']))
        choices[f]={**v,'grid':grid,'at_grid_boundary':v['lr'] in (.0025,.01)}
    best=min(FAMILIES,key=lambda f:(choices[f]['mean_ce'],FAMILIES.index(f)))
    def scores(f,lr):return {r['seed']:endpoint(r)['mean_ce'] for r in rows if r['family']==f and r['lr']==lr}
    aa=scores(best,choices[best]['lr']);refs=[(REFERENCE,incumbent_lr)]
    if best!='none':refs.append(('none',choices['none']['lr']))
    contrasts=[]
    for ref,lr in refs:
        bb=scores('none',lr);d={str(s):aa[s]-bb[s] for s in SCREENS}
        contrasts.append(dict(reference=ref,reference_lr=lr,paired_seed_deltas=d,mean_delta=mean(d.values()),supported=mean(d.values())<-.005 and max(d.values())<0))
    eligible=all(v['supported'] for v in contrasts)
    aliases={REFERENCE:'none'} if choices['none']['lr']==incumbent_lr else {}
    confirmation=[]
    for w in (64,256):
        for i,s in enumerate(CONFIRM):
            fs=FAMILIES+([] if aliases else [REFERENCE])
            for f in (fs if i%2==0 else fs[::-1]):confirmation.append([f,incumbent_lr if f==REFERENCE else choices[f]['lr'],w,s])
    return dict(plan_sha256=digest(p),local_evidence_sha256=digest(rows),choices=choices,best_selected_arm=best,local_contrasts=contrasts,candidate_eligible=eligible,winner=best if eligible else 'incumbent_unchanged',confirmation=dict(jobs=confirmation,reference_aliases=aliases,total_distinct_trials=18+len(confirmation),total_model_evaluations=2*(18+len(confirmation))),selected_by='Only width64 H200 means; family LR ties lower LR, arm ties none/z1e4/z1e3. Best arm must gain>.005/every seed against fixed incumbent and tuned none for nonzero objective coefficient. No alternative fallback or larger-width reselection.')

def check_objective_metric(metric,kind):
    coefficient=COEFFICIENTS[kind]
    assert type(metric['train_logit_z_coefficient']) is float and metric['train_logit_z_coefficient']==coefficient
    assert metric['train_aux_loss'] is None and metric['val_aux_loss'] is None and metric['val_loss']==metric['val_ce_loss']
    assert all(type(metric[k]) in (int,float) and math.isfinite(metric[k]) and metric[k]>=0 for k in ('train_ce_loss','train_loss','train_total_loss','val_ce_loss'))
    if kind=='none':
        assert all(metric[k] is None for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert metric['train_loss']==metric['train_total_loss']==metric['train_ce_loss']
    else:
        square,penalty,mean=(metric[k] for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
        assert all(type(x) in (int,float) and math.isfinite(x) for x in (square,penalty,mean))
        assert square>=0 and penalty>=0 and square+1e-4>=mean*mean
        assert math.isclose(penalty,coefficient*square,abs_tol=1e-6,rel_tol=2e-5)
        assert metric['train_loss']==metric['train_total_loss']
        assert math.isclose(metric['train_total_loss'],metric['train_ce_loss']+penalty,abs_tol=1e-6,rel_tol=2e-5)

def check_row(p,r,run):
    assert r['status']=='completed' and r['stage']=='local' and r['width']==64 and r['n_heads']==2 and r['tokens_processed']==3072000
    directory=run/'trials'/r['trial_id'];request_path=directory/'request.json';result_path=directory/'result.json'
    assert sha(request_path)==r['request_sha256'] and sha(result_path)==r['result_sha256']
    req=json.loads(request_path.read_text());raw=json.loads(result_path.read_text())
    cfg=copy.deepcopy(p['config']);m,t=cfg['model'],cfg['training'];threads=t.pop('cpu_threads')
    m.update(dim=64,n_heads=2,vocab_size=1,input_width_policy='mha4_input_scale',input_embedding_scale=p['recipe']['input_embedding_scale'],readout_norm_kind=p['recipe']['readout_norm_kind'],readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,weight_tying_kind=p['recipe']['weight_tying_kind'],residual_topology_kind=p['recipe']['residual_topology_kind'],residual_topology_width_policy='mha4_separate_norm_residual_topology',attention_logit_scale=p['recipe']['attention_logit_scale'],gated_activation_kind=p['recipe']['gated_activation_kind'],residual_gain_kind=p['recipe']['residual_gain_kind'],value_residual_kind=p['recipe']['value_residual_kind'],position_family_kind=p['recipe']['position_family_kind'],logit_z_kind=r['family'],logit_z_coefficient=COEFFICIENTS[r['family']],logit_z_objective_policy=POLICY,position_family_width_policy='mha4_position_family',value_residual_width_policy='mha4_first_value_residual',residual_gain_width_policy='mha4_channel_residual_gain',gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',weight_tying_width_policy='mha4_scaled_table_sharing',output_bias_kind=p['recipe']['output_bias_kind'],output_bias_width_policy='mha4_train_bound_output_bias',output_bias_prior=p['output_bias_prior'])
    t.update(learning_rate=r['lr'],seed=r['seed'],eval_seed=2026,strict_device=True,checkpoint_dir=str(directory/'checkpoints'),checkpoint_every=0,keep_best_checkpoint=False,resume_from=None,max_train_seconds=None,metrics_file=str(directory/'metrics.jsonl'),summary_file=str(directory/'training_summary.json'))
    assert req==dict(stage='local',config=cfg,cpu_threads=threads,result_path=str(result_path))
    assert type(req['config']['model']['logit_z_coefficient']) is float
    assert [x['step'] for x in raw['metrics']]==list(range(0,3000,300))+[2999]
    for metric in raw['metrics']:check_objective_metric(metric,r['family'])
    assert raw['completed_steps']==raw['max_iters']==3000 and raw['stop_reason']=='max_iters' and raw['device']=='mps'
    assert raw['eval_iters']==30 and raw['eval_every']==300
    assert raw['runtime']==dict(cpu_threads=threads,requested_device='mps',torch=p['runtime']['packages']['torch'])
    assert raw['final_checkpoint']==r['checkpoint'] and Path(r['checkpoint']).resolve().is_relative_to(directory.resolve())
    assert sha(r['checkpoint'])==r['checkpoint_sha256']
    assert set(r['averaged_outputs'])=={'200'} and raw['averaged_outputs']==r['averaged_outputs']
    a=r['averaged_outputs']['200'];assert Path(a['checkpoint']).resolve().is_relative_to(directory.resolve())
    assert sha(a['checkpoint'])==a['checkpoint_sha256'] and a['parent_checkpoint']==dict(path=r['checkpoint'],sha256=r['checkpoint_sha256'])
    assert raw['coverage']['evaluations']==r['coverage'] and raw['coverage']['holdout_consumed'] is False
    assert a['coverage']['holdout_consumed'] is False and a['coverage']['checkpoint_sha256']==a['checkpoint_sha256'] and a['coverage']['parent_checkpoint_sha256']==r['checkpoint_sha256']
    for e in (endpoint(r),endpoint(r,True)):
        assert (e['context'],e['eval_batch_size'],e['block_tokens'],e['target_count'],e['window_count'])==(128,8,2048,111538,872)
        assert e['block_target_counts']==[2048]*54+[946] and len(e['block_loss_sums'])==55
        assert all(math.isfinite(x) and x>=0 for x in e['block_loss_sums'])
        assert math.isclose(sum(e['block_loss_sums'])/111538,e['mean_ce'],rel_tol=0,abs_tol=1e-12)
    assert r['metric']==endpoint(r)['mean_ce'] and r['raw_metric']==endpoint(r,True)['mean_ce']
    assert raw['metrics'][-1]['step']==2999 and raw['metrics'][-1]['tokens_processed']==3072000 and raw['metrics'][-1]['lr_multiplier']==.1
    assert raw['weight_averaging']==dict(completed_steps=3000,snapshots=101,spec=t['weight_averaging'])
    assert a['averaged_weights']['completed_steps']==3000 and a['averaged_weights']['snapshots']==101 and a['averaged_weights']['half_life']==200 and a['averaged_weights']['spec']==t['weight_averaging']
    assert a['averaged_weights']['purpose']=='inference_only_not_optimizer_resume'
    return dict(trial_id=r['trial_id'],request_sha256=r['request_sha256'],result_sha256=r['result_sha256'],raw_checkpoint_sha256=r['checkpoint_sha256'],derived_checkpoint_sha256=a['checkpoint_sha256'])

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    run=args.run.resolve();output=args.output.resolve();base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
    assert run==base/'research_runs/logit-z-quality-001' and output.is_relative_to(base/'research_state') and not output.exists()
    p=json.loads((run/'plan.json').read_text());state=json.loads((run/'state.json').read_text());selpath=run/'selection.json';selection=json.loads(selpath.read_text());selsha=sha(selpath)
    assert selpath.stat().st_mode & 0o222==0
    rows=[r for r in state['records'] if r['stage']=='local'];rebuild=reconstruct(p,rows)
    assert selection==rebuild and state['selection']==selection
    source=Path(p['source_root']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==p['git_commit']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
    paths=sorted((source/'src').rglob('*.py'))+[source/'requirements.txt']
    assert digest({str(x.relative_to(source)):sha(x) for x in paths})==p['source_sha256']
    for x in p['artifacts']+[p['knowledge_snapshot']]:assert sha(x['path'])==x['sha256']
    assert sha(p['config']['data']['path'])==p['data_sha256']
    import importlib.util
    spec=importlib.util.spec_from_file_location('independent_output_prior',Path(__file__).resolve().parent.parent/'pilot-tools001/prior-audit.py')
    prior_audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior_audit)
    prior_review=prior_audit.verify_prior(Path(p['config']['data']['path']).read_bytes(),p['output_bias_prior'])
    checks=[check_row(p,r,run) for r in rows]
    latest=json.loads((run/'state.json').read_text())
    assert sha(selpath)==selsha and digest([r for r in latest['records'] if r['stage']=='local'])==digest(rows)
    assert 'torch' not in sys.modules
    review=dict(status='screening_arithmetic_and_artifact_hashes_verified',checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],plan_sha256=digest(p),selection_sha256=selsha,screen_evidence_sha256=digest(rows),distinct_screen_trajectories=18,raw_derived_checkpoint_hashes=36,choices=selection['choices'],winner=selection['winner'],best_selected_arm=selection['best_selected_arm'],local_contrasts=selection['local_contrasts'],confirmation=selection['confirmation'],checkpoint_hash_audit=checks,independent_training_prior=prior_review,holdout_access=False,training_rerun=False,checkpoint_tensors_loaded=False,limitation='Screen-only hash/request/result/coverage/objective-telemetry arithmetic audit; penalty exclusion and same-batch objective correctness rely on separately frozen CPU/MPS prerequisites, not endpoint JSON alone; final tensor/optimizer/RNG/report/bootstrap audit still required after the complete36/42-trajectory panel. No adoption or backbone change from screening.',memory_documentation_correction=str(base/'research_state/embedding-scale-preparation001/memory-guard-clarification001.json'))
    output.mkdir();(output/'audit.py').write_bytes(Path(__file__).read_bytes());(output/'review.json').write_text(json.dumps(review,indent=2)+'\n')
    for f in output.iterdir():f.chmod(0o444)
    print(json.dumps({k:v for k,v in review.items() if k!='checkpoint_hash_audit'},indent=2))

if __name__=='__main__':main()
