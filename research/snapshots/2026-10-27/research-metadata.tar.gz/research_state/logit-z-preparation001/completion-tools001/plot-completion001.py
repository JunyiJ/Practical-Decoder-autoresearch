from pathlib import Path
import json
b=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
def validate(c,v):
 assert v['status']=='verified' and v['distinct_trajectories'] in (36,42)
 assert v['distinct_checkpoints']==2*v['distinct_trajectories']
 assert c['quality_decision']==v['quality_decision']
 assert set(c['selection']['choices'])=={'none','z1e4','z1e3'}
 assert len(c['comparisons'])==12
 aliases=c['selection']['confirmation']['reference_aliases']
 assert aliases==({'incumbent_reference':'none'} if v['distinct_trajectories']==36 else {})
 assert c['selection']['winner']==c['quality_decision']['frozen_screen_winner']
 assert all(c['selection']['choices'][f]['lr'] in (.0025,.005,.01) for f in ('none','z1e4','z1e3'))
 for x in c['comparisons']:
  assert x['width'] in (64,256)
  assert [z['text_block_tokens'] for z in x['sensitivity']]==[2048,4096,8192]
  for z in x['sensitivity']:
   assert set(z['paired_seed_deltas'])=={'2511','2512','2513'}
 return c['quality_decision']
c=json.loads((b/'research_state/logit-z-quality-conclusion.json').read_text());v=json.loads(Path(c['review']).read_text())
validate(c,v)
import hashlib
run=Path(c['review']).parent
assert hashlib.sha256((run/'report.json').read_bytes()).hexdigest()==v['report_sha256']
assert json.loads((run/'state.json').read_text())['status']=='completed'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=b/'research_state/reports/pretraining-learning-guide';out.mkdir(exist_ok=True,parents=True)
fig,(ax,cost)=plt.subplots(1,2,figsize=(15,6.4),gridspec_kw={'width_ratios':[1.6,1]})
rows=[x for x in c['comparisons'] if (x['candidate'],x['reference']) in [('z1e4','none'),('z1e3','none'),('z1e3','z1e4')]]
labels=[]
pretty={'none':'Zero penalty','z1e4':'λ = 1e-4','z1e3':'λ = 1e-3'}
for i,x in enumerate(rows):
 z=x['sensitivity'][1];color='#077f83' if x['width']==64 else '#b06338';lo,hi=z['conditional_text_bootstrap_95pct']
 ax.plot([lo,hi],[i,i],color=color,lw=2)
 for off,seed in zip([-.13,0,.13],[2511,2512,2513]):ax.scatter(z['paired_seed_deltas'][str(seed)],i+off,color=color,s=24,alpha=.75)
 ax.scatter(z['mean_delta'],i,color=color,marker='D',s=52,zorder=4,edgecolor='white')
 labels.append(f"{pretty[x['candidate']]} − {pretty[x['reference']]} · width {x['width']}")
ax.axvline(0,color='#727e85',lw=1);ax.axvline(-.005,color='#a8b2b8',ls=':',lw=1)
ax.set_yticks(range(len(labels)),labels);ax.invert_yaxis();ax.set_xlabel('Paired validation CE difference (negative is better)');ax.set_title('Fresh-seed H200 confirmation')
for index,width in enumerate(('64','256')):
 for off,fam,col in [(-.18,'z1e4','#077f83'),(.18,'z1e3','#b06338')]:
  value=c['cost'][fam][width]['training_time_ratio_vs_none']
  cost.bar(index+off,value,width=.32,color=col,label=pretty[fam] if index==0 else None)
  cost.text(index+off,value+.012,f'{value:.3f}×',ha='center',fontsize=10)
cost.axhline(1,color='#727e85',lw=1);cost.set_xticks([0,1],['Width 64','Width 256']);cost.set_ylabel('Training time / zero-penalty training time');cost.set_ylim(0,max(1.4,max(c['cost'][f][w]['training_time_ratio_vs_none'] for f in ('z1e4','z1e3') for w in ('64','256'))*1.2));cost.set_title('Measured training cost');cost.legend(frameon=False)
for a in (ax,cost):
 a.spines[['top','right']].set_visible(False);a.grid(axis='x' if a is ax else 'y',alpha=.13);a.set_axisbelow(True)
fig.suptitle('Logit-z objective: pure-CE ranking, frozen selection',fontsize=16)
aliases=c['selection']['confirmation']['reference_aliases']
alias_text='Six fixed-reference cells alias selected baseline; not independent repeats.' if aliases else 'Six distinct fresh fixed-reference trajectories; no aliases.'
lr_text='; '.join(f"{pretty[f]} {c['selection']['choices'][f]['lr']:g}" for f in ('none','z1e4','z1e3'))
fig.text(.02,.02,f'Dots: seeds 2511/2512/2513. Diamonds: paired means. Lines: conditional 95% text intervals (4,096-token blocks).\n{v["distinct_trajectories"]} physical trajectories; {v["distinct_checkpoints"]} correlated raw/H200 outputs. {alias_text}\nSelected peak LR: {lr_text}.\nFrozen winner: {c["quality_decision"]["frozen_screen_winner"]}; adoption: {c["quality_decision"]["qualifies_for_incumbent_replacement"]}. Adaptive validation; no holdout or seed-population confidence.',fontsize=9,color='#455963')
fig.tight_layout(rect=(0,.19,1,.94))
for suffix in ('png','svg'):fig.savefig(out/f'logit-z-quality001.{suffix}',dpi=160,bbox_inches='tight')
print(out/'logit-z-quality001.png')
