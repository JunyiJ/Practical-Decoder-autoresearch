from pathlib import Path
import ast,re,json,hashlib
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');N=B/'research_state/position-quality-preparation001/completion-tools001';Z=B/'research_state/logit-z-preparation001/completion-tools001';Z.mkdir(exist_ok=False)
def adapt(s):
 for a,b in [('position-quality','logit-z-quality'),('position_quality_study','logit_z_study'),('position_quality_audit','logit_z_audit'),('POSITION_QUALITY','LOGIT_Z'),('2491','2511'),('2492','2512'),('2493','2513'),('2481','2501'),('2482','2502')]:s=s.replace(a,b)
 for a,b in [('rope','none'),('nope','z1e4'),('alibi','z1e3')]:s=s.replace("'"+a+"'","'"+b+"'")
 return s
s=adapt((N/'record-completion.py').read_text())
s=s.replace("FAMILIES=('none','z1e4','z1e3');", "COEFFICIENTS={'none':0.,'z1e4':.0001,'z1e3':.001};POLICY='mha4_final_logit_z'\nFAMILIES=('none','z1e4','z1e3');")
s=s.replace("position_family_kind=winner,position_family_width_policy=", "logit_z_kind=winner,logit_z_coefficient=COEFFICIENTS[winner],logit_z_objective_policy=POLICY,position_family_kind=r['position_family_kind'],position_family_width_policy=",1)
s=s.replace("    assert all(m.get(k)==v for k,v in expected.items())", "    assert all(m.get(k)==v for k,v in expected.items())\n    assert type(m.get('logit_z_coefficient')) is float and m['logit_z_coefficient']==COEFFICIENTS[winner]")
s=s.replace("position_family_kind=winner,position_family_width_policy=", "logit_z_kind=winner,logit_z_coefficient=COEFFICIENTS[winner],logit_z_objective_policy=POLICY,position_family_kind=p['recipe']['position_family_kind'],position_family_width_policy=")
s=s.replace('training_time_ratio_vs_rope','training_time_ratio_vs_none')
s=s.replace('position-family','logit-z objective').replace('Position-family','Logit-z objective').replace('tuned RoPE','tuned zero-penalty control').replace('tunedRoPE','tuned zero-penalty control')
s=s.replace("No explicit position {delta('z1e4')}; ALiBi {delta('z1e3')}","lambda1e-4 {delta('z1e4')}; lambda1e-3 {delta('z1e3')}")
s=s.replace("A tuned RoPE-only gain is attributed to LR selection, not position family.","A tuned zero-penalty-only gain is attributed to LR selection, not the penalty.")
old=next(x for x in s.splitlines() if x.strip().startswith("'Equal 3000 updates"))
new="        'Equal 3000 updates and3072000 targets at context128. Final-reviewed position, values, gains, gated activation, attention scale, topology, tables, bias/prior, readout normalization, input scale, schedule/H200 and independent decay are inherited unchanged. Training loss is CE plus lambda times the mean squared logsumexp of FINAL FP32 logits on exactly the CE valid targets, with coefficients0/1e-4/1e-3 applied once. No centering, log-vocabulary subtraction, clipping, detach, temperature or width-dependent coefficient. Zero uses the historical exact CE path and leaves logZ diagnostics null. No added learned parameters or initialization draws. Every validation score and ranking is pure CE; training objective metrics are separate. The penalty is sensitive to a common logit shift unlike CE. Nonzero-coefficient contrasts are separate, not an extra adoption gate. No diagnosed local instability, isolated-confidence cause, published-recipe replication or optimal muP claim.',"
s=s.replace(old,new)
s=s.replace('historical position-bias placement, attached-value gradients or cache operations','historical objective calls, pure-CE evaluation exclusion, attached-value gradients or cache operations')
s=s.replace('Position-family with equal LR tuning on the final reviewed backbone','Logit-z objective with equal LR tuning on the final reviewed backbone')
s=s.replace('Position families','Logit-z objectives').replace('Position-family quality results','Logit-z objective quality results').replace('position family at both widths','objective at both widths').replace('Ratio versus tuned RoPE','Ratio versus tuned zero-penalty control')
assert 'position_family_kind=winner' not in s and 'position_quality' not in s
assert "position_family_kind=r['position_family_kind']" in s and "position_family_kind=p['recipe']['position_family_kind']" in s
ast.parse(s);(Z/'record-completion.py').write_text(s)
t=adapt((N/'test_completion_recorder.py').read_text())
t=t.replace("m=dict(position_family_kind=family,", "m=dict(logit_z_kind=family,logit_z_coefficient=rec.COEFFICIENTS[family],logit_z_objective_policy=rec.POLICY,position_family_kind=r['position_family_kind'],")
t=t.replace("p['recipe'].update(residual_topology_kind=topology,weight_tying_kind=table,residual_gain_kind=gain,value_residual_kind=value)","p['recipe'].update(residual_topology_kind=topology,weight_tying_kind=table,residual_gain_kind=gain,value_residual_kind=value,position_family_kind=('rope','nope','alibi')[rec.FAMILIES.index(family)])")
t=t.replace("    def test_exact_selected_gate_and_all_inherited_contracts(self):","    def test_exact_selected_objective_and_all_inherited_contracts(self):")
t=t.replace("                            for key in m:","                            if family=='none':\n                                bad=copy.deepcopy(cfg);bad['model']['logit_z_coefficient']=False\n                                with self.assertRaises(AssertionError):rec.verify_selected_model(p,family,bad)\n                            for key in m:")
t=t.replace('162 selected-model routes','162 selected-model routes (three inherited position modes distributed)')
ast.parse(t);(Z/'test_completion_recorder.py').write_text(t)
p=adapt((N/'plot-completion001.py').read_text()).replace('training_time_ratio_vs_rope','training_time_ratio_vs_none')
p=p.replace("pretty={'none':'RoPE','z1e4':'No explicit position','z1e3':'ALiBi'}", "pretty={'none':'Zero penalty','z1e4':'λ = 1e-4','z1e3':'λ = 1e-3'}")
p=p.replace('Training time / RoPE training time','Training time / zero-penalty training time').replace('Position families: bounded LR tuning, frozen selection','Logit-z objective: pure-CE ranking, frozen selection')
ast.parse(p);(Z/'plot-completion001.py').write_text(p)
t=adapt((N/'test_rendering001.py').read_text());ast.parse(t);(Z/'test_rendering001.py').write_text(t)
# Preserve all historical sections verbatim. Append only a new guard, figure, and banner sentence.
j=(N/'render-completed-guide001.mjs').read_text()
guard="""const logitZ=JSON.parse(fs.readFileSync('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-quality-conclusion.json','utf8'));
const logitZReview=JSON.parse(fs.readFileSync(logitZ.review,'utf8'));
if(logitZReview.status!=='verified'||![36,42].includes(logitZReview.distinct_trajectories)||logitZReview.distinct_checkpoints!==2*logitZReview.distinct_trajectories||JSON.stringify(logitZ.quality_decision)!==JSON.stringify(logitZReview.quality_decision))throw new Error('Final complete logit-z review required');
if(!fs.existsSync('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/reports/pretraining-learning-guide/logit-z-quality001.png'))throw new Error('Final logit-z figure required');
"""
assert j.count("const root=")==1;j=j.replace("const root=",guard+"const root=",1)
fig="body += '<figure><img src=\"logit-z-quality001.png\" alt=\"Logit-z penalty pure-CE differences and measured training cost\"><figcaption>Fresh paired seeds, means and 4,096-token conditional text intervals. Ranking uses pure CE; the training penalty is separate. Only the frozen locally eligible winner can qualify at both widths. Raw/H200 endpoints and prospective aliases are correlated. Historical objective calls and evaluator exclusion additionally rely on frozen CPU/MPS prerequisites.</figcaption></figure>';\n"
assert j.count('const html=')==1;j=j.replace('const html=',fig+'const html=',1)
needle='Earlier preparation status paragraphs are historical.'
assert j.count(needle)==1
j=j.replace(needle,'<strong>Logit-z objective comparison is completed and independently reviewed.</strong> ${logitZ.summary} All ${logitZReview.distinct_checkpoints} raw/H200 checkpoint contracts, objective coefficient and inherited architecture, optimizer/RNG/shadow/coverage, frozen choices and full independent report/bootstrap were verified. Training metrics are distinct from pure-CE validation. '+needle)
# Every preexisting figure line remains byte-identical.
assert all(line in j.splitlines() for line in (N/'render-completed-guide001.mjs').read_text().splitlines() if 'body +=' in line and '<figure>' in line)
(Z/'render-completed-guide001.mjs').write_text(j)
print(json.dumps({'prepared':str(Z),'python_syntax_files':4,'historical_figure_lines_preserved':sum('body +=' in l and '<figure>' in l for l in (N/'render-completed-guide001.mjs').read_text().splitlines())}))
