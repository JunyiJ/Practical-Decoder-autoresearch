import sys
import pytest
from src.models.gpt import GPT
from src.train import train
from src.research.team import suite
from src.research import optimizer_study, logit_z_study, worker

def forbidden(*a, **kw):
    raise AssertionError('Actual model/training/worker execution forbidden in metadata validation')
GPT.__init__ = forbidden
train.run_training = forbidden
suite._launch = forbidden
optimizer_study._launch = forbidden
logit_z_study._launch = forbidden
worker.main = forbidden
import json
from pathlib import Path
passed=set(json.loads(Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/logit-z-preparation001/controller-fixture-repair001/passed-case-ids.json').read_text()))
class Remaining:
    def pytest_collection_modifyitems(self,session,config,items):
        selected=[x for x in items if x.nodeid not in passed]
        removed=[x for x in items if x.nodeid in passed]
        assert len(removed)==154
        config.hook.pytest_deselected(items=removed)
        items[:]=selected
raise SystemExit(pytest.main(['-v','-p','no:cacheprovider','--maxfail=1',
 'tests/test_logit_z_study.py','tests/test_logit_z_predecessor.py','tests/test_logit_z_report_audit.py'],plugins=[Remaining()]))
