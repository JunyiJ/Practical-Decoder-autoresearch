import ast,difflib,hashlib,json,re,shutil,subprocess,sys,tarfile
from pathlib import Path
from datetime import datetime,timezone
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');D=Path('/private/tmp/rsi-logit-z-development001');P=B/'research_state/logit-z-preparation001'
base='7c2c6d5a82c20009f0b31f9b8227558004dd96c5';now=datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,v):
 assert not p.exists(),p
 p.write_text(v if isinstance(v,str) else json.dumps(v,indent=2,allow_nan=False)+'\n');p.chmod(0o444)
prior=json.loads((P/'prototype-review002.json').read_text())
for f in prior['files']:assert sha(D/f['path'])==f['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==base
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='63d397017a5a692ded7847a61c7768871c72ee71'
logs=[P/'controller-metadata-first.log',P/'controller-metadata-remaining002.log'];ids=[]
for log,expected in zip(logs,[154,101]):
 text=log.read_text();cases=re.findall(r'^(tests/\S+) PASSED',text,re.M);assert len(cases)==expected and len(set(cases))==expected;ids+=cases
assert '1 failed, 154 passed, 1 warning in 1.77s' in logs[0].read_text()
assert '101 passed, 154 deselected, 1 warning in 3.73s' in logs[1].read_text()
assert len(ids)==len(set(ids))==255
protocol=D/'research/LOGIT_Z_PROTOCOL.md';s=protocol.read_text()
s=s.replace('SEPARATE PRIMITIVE PROTOTYPE ONLY.', 'SEPARATE PROTOTYPE WITH SYNTHETICALLY CHECKED CONTROLLER.')
s=s.replace('- No implementation, tests, model work, MPS, integration or registration yet. All closed studies and006 permanent stop preserved.', '- Objective implementation and metadata/controller tests are prepared separately. Actual27 model/trainer cases are written but uncollected and unexecuted. No model work, MPS, integration or registration yet. All closed studies and006 permanent stop preserved.')
s+='''\nRevision003 adds logit_z_study, logit_z_predecessor and logit_z_audit. The controller freezes18 pure-CE screen choices before18/24 fresh confirmation cells, with exact zero-objective fixed-reference aliases only. The final-only predecessor reconstructs the entire completed position report, selection and independent bootstrap; objective families never overwrite inherited position/value/gain. The report auditor independently reconstructs all primary/raw means, seed deltas, conditional text intervals, fixed-LR contrasts and adoption. All validation ranking remains pure CE.\n\n255 unique synthetic controller/resolver/report cases passed with GPT construction, training and real worker entry points blocked. First154 passed before a new inheritance fixture incorrectly requested reference LR.01 despite its own incumbent.005; the controller correctly rejected it. The fixture now requests its recorded incumbent LR; only failed/unexecuted101 cases ran afterward, not the154 passed cases. Production controller bytes were unchanged by this fixture repair. Earlier280 primitive metadata cases were not repeated. These535 metadata checks and six earlier scalar methods are not actual model or MPS correctness evidence. All27 actual geometry/primitive/evaluator/trainer cases remain deferred until the position worker exits and its full review/docs complete.\n'''
protocol.write_text(s)
new=['src/research/logit_z_study.py','src/research/logit_z_predecessor.py','src/research/logit_z_audit.py','tests/test_logit_z_study.py','tests/test_logit_z_predecessor.py','tests/test_logit_z_report_audit.py']
files=[f['path'] for f in prior['files']]+new;assert len(files)==15
cap=P/'source-capsule003';cap.mkdir();records=[];patch=''
for name in files:
 f=D/name
 if f.suffix=='.py':ast.parse(f.read_text())
 r=subprocess.run(['git','show',base+':'+name],cwd=S,capture_output=True);old=r.stdout.decode() if r.returncode==0 else '';newtext=f.read_text();assert newtext!=old
 records.append(dict(path=name,sha256=sha(f),base_sha256=hashlib.sha256(old.encode()).hexdigest() if r.returncode==0 else None))
 dest=cap/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
 patch+='diff --git a/'+name+' b/'+name+'\n'
 if r.returncode:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(old.splitlines(True),newtext.splitlines(True),fromfile='/dev/null' if r.returncode else 'a/'+name,tofile='b/'+name))
(cap/'prototype003.patch').write_text(patch)
c=subprocess.run(['git','apply','--check',str(cap/'prototype003.patch')],cwd=S,text=True,capture_output=True);assert c.returncode==0,c.stderr
write(cap/'apply-check.json',dict(exit_code=0,stdout=c.stdout,stderr=c.stderr,applied=False))
with tarfile.open(cap/'prototype003.tar.gz','w:gz') as t:
 for name in files:t.add(D/name,arcname=name)
mapping=hashlib.sha256(json.dumps({r['path']:r['sha256'] for r in records if r['path'].startswith('src/')},sort_keys=True).encode()).hexdigest()
counts={x:sum(i.startswith('tests/test_logit_z_'+x+'.py::') for i in ids) for x in ['study','predecessor','report_audit']};assert counts==dict(study=190,predecessor=29,report_audit=36)
review=dict(status='separate_controller_predecessor_report_metadata_validated_actual_tests_unexecuted',created_at=now,development_root=str(D),base_commit=base,files=records,total_files=15,production_files=8,changed_production_mapping_sha256=mapping,mapping_is_not_full_engine_digest=True,original_five_production_and_actual_tests_unchanged=True,metadata_tests=dict(prior_primitive=280,new_unique=255,total_unique=535,new_by_file=counts,logs=[art(x) for x in logs],first_pass=154,remaining_after_fixture_repair=101,passed_cases_not_repeated=True,warnings='One Hydra preimport pytest rewrite warning per invocation',fixture_repair=art(P/'controller-fixture-repair001/review.json')),actual_cases_written_ast_only=27,actual_model_tests_executed=False,actual_tests_collected=False,source_integrated=False,research_registered=False,patch=art(cap/'prototype003.patch'),archive=art(cap/'prototype003.tar.gz'),manual_review=[
'Finite18screens2501/2502 and18/24fresh2511/2512/2513 confirmations at64/256;36/42physical72/84correlated raw/H200 outputs. Three objective coefficients times3LRs, exact zero-objective/reference aliases only. No extension/pruning/fallback/larger-width reselection.',
'All model inheritance including position comes ONLY from the final complete independently reconstructed position adoption/retention decision. Exact review/state/plan/source/report/selection contracts; independent entire conditional bootstrap reconstruction before recipe resolution. No actual live predecessor resolution occurred.',
'Objective policy/coefficient/convention are frozen; same target mask and final FP32 logit coordinate convention. Explicit training-only objective and pure-CE validation contract metadata. All ranking still uses full-validation H200 CE, not training total, sampled losses or penalty size.',
'Independent report auditor directly rebuilds screen LR/winner/eligibility,36/42manifest/aliases, all12primary/raw comparisons with three bootstrap block sizes,9fixedLR contrasts and final frozen-winner adoption. Nonuniform synthetic text blocks and mutually consistent forged state/report corruption rejection tested.',
'Inherited position/value/gain are distinct from none/z1e4/z1e3 objective families.27 extra position/value/gain inheritance combinations exercise all three objective kinds and reference with exact incumbent LR.',
'First generator AST rejected wrongly indented position import before imports/tests; only temporary controller written, generator/partial file preserved. Correct exact indented block and explicit inherited return key before execution.',
'First synthetic fixture failure correctly rejected a reference LR inconsistent with its plan. Test-only correction;154 successful cases deselected,101 failed/unexecuted cases then passed. No production/evidence/threshold change or model/scoring work.'
],pending=['Current position full terminal checkpoint/optimizer/RNG/report/bootstrap audit and docs first','Manual complete-source review then integrate only15reviewedfiles; actual27/full bounded CPU with prospectively reviewed count and budget','Six serial MPS objective/fullgraph/cache/pure-CE evaluator/optimizerRNGH200 checks and resource50percentmargin; clean publication/fullbank/fresh seeds/new preregistration','CPU/pilot/prerequisite/screening/completion/registration/recording helpers still unprepared'])
write(P/'prototype-review003.json',review)
for src,name in [('/private/tmp/build-logit-z-controller001.py','controller-generator002.py'),('/private/tmp/run-logit-z-metadata001.py','metadata-runner001.py'),('/private/tmp/run-logit-z-metadata-remaining002.py','remaining-metadata-runner002.py'),(__file__,'record-prototype003.py')]:shutil.copyfile(src,cap/name)
sys.path.insert(0,str(S));from src.research.team.knowledge import KnowledgeBank
bank=KnowledgeBank(B/'research_state/knowledge');kid=bank.add(dict(kind='implementation',title='Logit-Z revision003: pure-CE controller, final-only position resolver and independent report auditor',summary='Separate15file prototype;255 new unique synthetic cases pass after a preserved test-only reference-LR correction;535 total metadata cases. All27 actual model/trainer cases remain uncollected/unexecuted. Live position source unchanged.',created_by='codex',outcome='untried',scope=dict(study='logit-z-quality-prospective',source=base),details=review,artifacts=[art(P/'prototype-review003.json'),art(cap/'prototype003.tar.gz'),art(cap/'prototype003.patch'),art(P/'controller-fixture-repair001/review.json')],related_ids=[json.loads((P/'prototype-knowledge002.json').read_text())['knowledge_id']]))
write(P/'prototype-knowledge003.json',dict(knowledge_id=kid,created_at=now,review=art(P/'prototype-review003.json')));write(P/'full-knowledge-snapshot004.md',bank.export_markdown())
before=P/'prototype-metadata-before003';before.mkdir()
for name in ('quality-evolution-progress.json','research-monitor.json'):
 f=B/'research_state'/name;data=json.loads(f.read_text());write(before/name,data)
 assert data['next_preparation']['study']=='logit-z-quality'
 data.setdefault('metadata_history',[]).append(dict(at=now,kind='logit_z_controller_metadata_preparation',prior_next_preparation=data['next_preparation'].copy()))
 data['next_preparation'].update(status=review['status'],review=str(P/'prototype-review003.json'),knowledge_id=kid,metadata_tests_passed=535,actual_model_tests_written=27,actual_model_tests_executed=False,pytest_collection_executed=False,source_integrated=False,research_registered=False,pending=review['pending'])
 data['last_preparation_at']=now;tmp=f.with_suffix('.tmp-logit-controller003');tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');tmp.replace(f)
for directory in [cap,P/'controller-generator-repair001',P/'controller-fixture-repair001']:
 for f in directory.rglob('*'):
  if f.is_file():f.chmod(0o444)
for log in logs:log.chmod(0o444)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
print(json.dumps(dict(knowledge=kid,review=str(P/'prototype-review003.json'),mapping=mapping,metadata=535,actual_executed=False,snapshot=art(P/'full-knowledge-snapshot004.md'))))
