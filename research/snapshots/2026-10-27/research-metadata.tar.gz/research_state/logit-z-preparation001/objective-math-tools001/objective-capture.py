"""Deferred capture on an already-loaded MPS model after its pilot worker exits."""
def install(model):
 t={};hooks=[]
 def norm_hook(module,inputs,output):
  inputs[0].retain_grad();output.retain_grad();t.update(norm_input=inputs[0],hidden=output)
 def lookup_hook(module,inputs,output):output.retain_grad();t['lookup']=output
 hooks.extend([model.transformer.ln_f.register_forward_hook(norm_hook),model.transformer.wte.register_forward_hook(lookup_hook)])
 return t,hooks

def export(model,t,idx,target,logits,loss,breakdown,derived_sha):
 import math
 import torch
 assert logits.device.type=='mps' and logits.dtype==torch.float32 and logits.grad is not None
 assert model.logit_z_signature is not None and breakdown['aux_loss'] is None
 kind,coef,policy,convention=model.logit_z_signature
 assert policy=='mha4_final_logit_z'
 tying=model.cfg.weight_tying_kind;norm=model.transformer.ln_f;table=model.transformer.wte.weight
 q=table if tying=='scaled_tied' else model.lm_head.weight
 cpu=lambda x:None if x is None else x.detach().cpu()
 grad=lambda x:None if x is None else cpu(x.grad)
 p=dict(width=model.cfg.dim,tying_kind=tying,norm_kind=model.cfg.readout_norm_kind,norm_epsilon=norm.eps,
  output_bias_kind=model.cfg.output_bias_kind,input_embedding_scale=model.input_embedding_scale,
  logit_z_kind=kind,logit_z_coefficient=coef,convention=convention,include_training_objective=True,ignore_index=-100,
  valid_targets=int(target.ne(-100).sum().item()),derived_checkpoint_sha256=derived_sha,atol=1e-4,rtol=2e-5,
  tokens=cpu(idx),targets=cpu(target),logits=cpu(logits),logits_gradient=grad(logits),
  norm_input=cpu(t['norm_input']),norm_input_gradient=grad(t['norm_input']),hidden=cpu(t['hidden']),hidden_gradient=grad(t['hidden']),
  norm_weight=cpu(norm.weight),norm_weight_gradient=grad(norm.weight),norm_bias=cpu(getattr(norm,'bias',None)),norm_bias_gradient=grad(getattr(norm,'bias',None)),
  readout=cpu(q),embedding=cpu(table),table_gradient=grad(table),readout_gradient=None if tying=='scaled_tied' else grad(q),
  lookup_output_gradient=grad(t['lookup']),bias=torch.zeros(65) if model.output_bias is None else cpu(model.output_bias),bias_gradient=grad(model.output_bias),
  readout_coefficient=(1 if tying=='legacy_untied' else 1/math.sqrt(192))/(model.cfg.dim/64),ce=float(breakdown['ce_loss'].item()),total=float(loss.item()))
 for key in ('logit_z_mean','logit_z_squared_mean','logit_z_penalty'):p[key]=None if breakdown[key] is None else float(breakdown[key].item())
 return p

def forward(model,idx,target):
 """Caller installs all hooks, calls this once, then loss.backward and export."""
 logits,loss,breakdown=model(idx,target,include_training_objective=True,return_loss_breakdown=True)
 logits.retain_grad()
 return logits,loss,breakdown
