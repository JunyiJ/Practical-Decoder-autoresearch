import ast,copy,importlib.util,json,math,unittest
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('audit',P/'objective-math-audit.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
COUNTS=dict(combinations=0,directional_checks=0,objective_coordinates=0,corruptions=0,bindings=0)

def fixture(width,tying,norm,kind):
 rng=np.random.default_rng(113);idx=np.array([[1,2,1],[4,5,2]]);y=np.array([[2,-100,3],[1,2,4]]);scale=.5
 e=rng.normal(0,.15,(65,width));q=e.copy() if tying=='scaled_tied' else rng.normal(0,.12,(65,width));gamma=rng.normal(1,.1,width);beta=rng.normal(0,.03,width) if norm=='layer_affine' else None;bias=rng.normal(0,.05,65)
 coeff=(1 if tying=='legacy_untied' else 1/math.sqrt(192))/(width/64)
 def evaluate(e,q,gamma,beta,bias):
  x=e[idx]*scale;c=x if norm=='rms' else x-np.mean(x,-1,keepdims=True);h=c/np.sqrt(np.mean(c*c,-1,keepdims=True)+1e-5)*gamma+(0 if beta is None else beta)
  readout=e if tying=='scaled_tied' else q;z=np.einsum('btd,vd->btv',h,readout)*coeff+bias
  return a.objective(z,y,a.COEFFICIENTS[kind])['total']
 x=e[idx]*scale;h=a.normalize(x,gamma,beta,norm)[0];z=np.einsum('btd,vd->btv',h,q)*coeff+bias;o=a.objective(z,y,a.COEFFICIENTS[kind]);g=o['gradient'];hg=np.einsum('btv,vd->btd',g,q)*coeff;gx,gg,gb=a.norm_vjp(x,gamma,beta,norm,hg)
 lookup=np.zeros_like(e);np.add.at(lookup,idx.reshape(-1),(gx*scale).reshape(-1,width));projection=np.einsum('btv,btd->vd',g,h)*coeff
 p=dict(width=width,tying_kind=tying,norm_kind=norm,norm_epsilon=1e-5,output_bias_kind='learned_zero',input_embedding_scale=scale,logit_z_kind=kind,logit_z_coefficient=a.COEFFICIENTS[kind],convention=a.CONVENTION,include_training_objective=True,ignore_index=-100,valid_targets=5,derived_checkpoint_sha256='a'*64,atol=1e-4,rtol=2e-5,tokens=idx,targets=y,logits=z,logits_gradient=g,norm_input=x,norm_input_gradient=gx,hidden=h,hidden_gradient=hg,norm_weight=gamma,norm_weight_gradient=gg,norm_bias=beta,norm_bias_gradient=gb,readout=q,embedding=e,table_gradient=lookup+projection if tying=='scaled_tied' else lookup,readout_gradient=None if tying=='scaled_tied' else projection,lookup_output_gradient=gx*scale,bias=bias,bias_gradient=g.sum((0,1)),readout_coefficient=coeff,ce=o['ce'],total=o['total'])
 for key,name in [('logit_z_mean','mean'),('logit_z_squared_mean','squared'),('logit_z_penalty','penalty')]:p[key]=None if kind=='none' else o[name]
 state={'transformer.wte.weight':e.copy(),'transformer.ln_f.weight':gamma.copy(),'output_bias':bias.copy()}
 if tying!='scaled_tied':state['lm_head.weight']=q.copy()
 if beta is not None:state['transformer.ln_f.bias']=beta.copy()
 branch=dict(width=width,derived_checkpoint_sha256='a'*64,blocks=[dict(input=x,input_gradient=gx),{}, {},dict(output=x,output_gradient=gx)])
 return p,state,branch,evaluate,[e,q,gamma,beta,bias],[p['table_gradient'],None if tying=='scaled_tied' else projection,gg,gb,g.sum((0,1))]

class Tests(unittest.TestCase):
 def test_mask_extremes_common_shift_and_objective_coordinates(self):
  z=np.array([[.3,-.5,1.7],[3.,-2.,.1],[-1.,.2,.6]]);y=np.array([2,-100,1])
  for coef in a.COEFFICIENTS.values():
   o=a.objective(z,y,coef)
   for ij in np.ndindex(z.shape):
    lo=z.copy();hi=z.copy();lo[ij]-=1e-5;hi[ij]+=1e-5
    fd=(a.objective(hi,y,coef)['total']-a.objective(lo,y,coef)['total'])/2e-5
    self.assertAlmostEqual(fd,o['gradient'][ij],places=8);COUNTS['objective_coordinates']+=1
   self.assertTrue(np.array_equal(o['gradient'][1],np.zeros(3)))
   shifted=a.objective(z+7,y,coef);self.assertAlmostEqual(o['ce'],shifted['ce'],places=12)
   self.assertGreater(shifted['squared'],o['squared'])
   ext=a.objective(np.array([[1e4,9999.,-1e4],[-1e4,-9999.,-9998.],[0.,0.,0.]]),y,coef)
   self.assertTrue(np.isfinite(ext['total']) and np.isfinite(ext['gradient']).all())
  with self.assertRaises(AssertionError):a.objective(z,np.full(3,-100),.001)
  with self.assertRaises(AssertionError):a.objective(z,np.array([2,6,1]),.001)
 def test_complete_readout_norm_table_directions(self):
  rng=np.random.default_rng(216)
  for width in (64,256):
   for tying in ('legacy_untied','matched_untied','scaled_tied'):
    for norm in ('layer_affine','layer_no_bias','rms'):
     for kind in a.COEFFICIENTS:
      p,state,branch,evaluate,values,grads=fixture(width,tying,norm,kind);a.verify(p);a.bind_checkpoint(p,state,'a'*64,width,kind,norm,tying,'learned_zero',.5);a.link_graph(p,branch);COUNTS['combinations']+=1
      for i,(value,grad) in enumerate(zip(values,grads)):
       if grad is None:continue
       direction=rng.normal(size=value.shape);direction/=np.linalg.norm(direction)
       lo=list(values);hi=list(values);lo[i]=value-direction*1e-5;hi[i]=value+direction*1e-5
       fd=(evaluate(*hi)-evaluate(*lo))/2e-5
       self.assertAlmostEqual(fd,float(np.sum(grad*direction)),places=7);COUNTS['directional_checks']+=1
 def test_corruption_checkpoint_graph_and_capture_wiring(self):
  for tying in ('legacy_untied','scaled_tied'):
   p,state,branch,*_=fixture(64,tying,'layer_affine','z1e3')
   for key in ('total','ce','logit_z_mean','logit_z_squared_mean','logit_z_penalty','logits_gradient','norm_input_gradient','hidden_gradient','table_gradient','bias_gradient','norm_weight_gradient','norm_bias_gradient'):
    bad=copy.deepcopy(p);bad[key]=np.asarray(bad[key])+1
    with self.assertRaises(AssertionError):a.verify(bad)
    COUNTS['corruptions']+=1
   for key,value in [('logit_z_coefficient',.0001),('convention','changed'),('include_training_objective',False),('valid_targets',6),('ignore_index',0),('readout_coefficient',3.)]:
    bad=copy.deepcopy(p);bad[key]=value
    with self.assertRaises(AssertionError):a.verify(bad)
    COUNTS['corruptions']+=1
   for key in state:
    bad=copy.deepcopy(state);bad[key].flat[0]+=1
    with self.assertRaises(AssertionError):a.bind_checkpoint(p,bad,'a'*64,64,'z1e3','layer_affine',tying,'learned_zero',.5)
    COUNTS['bindings']+=1
   for i,key in [(0,'input'),(0,'input_gradient'),(3,'output'),(3,'output_gradient')]:
    bad=copy.deepcopy(branch);bad['blocks'][i][key]=bad['blocks'][i][key]+1
    with self.assertRaises(AssertionError):a.link_graph(p,bad)
    COUNTS['corruptions']+=1
  tree=ast.parse((P/'objective-capture.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='forward');calls=[n for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='model'];self.assertEqual(len(calls),1)
  self.assertEqual({x.arg:ast.literal_eval(x.value) for x in calls[0].keywords},{'include_training_objective':True,'return_loss_breakdown':True})
  self.assertIn('logits.retain_grad()',ast.unparse(f));self.assertIn("logits.device.type == 'mps'",ast.unparse(tree))
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);r=unittest.TextTestRunner(verbosity=2).run(suite)
 if r.wasSuccessful():(P/'test-counts.json').write_text(json.dumps(COUNTS,indent=2)+'\n')
 raise SystemExit(not r.wasSuccessful())
