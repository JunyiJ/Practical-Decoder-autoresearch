"""Independent NumPy final-logit objective, readout and final-normalization VJP.

No model imports. Bind checkpoint weights and link the SAME realized objective
backward graph to separately audited attention/branch payloads before claiming
complete gradient coverage. Pure-CE evaluators require separate actual gates.
"""
import math
import numpy as np
COEFFICIENTS={'none':0.,'z1e4':.0001,'z1e3':.001}
CONVENTION='final_fp32_logsumexp_squared_valid_target_mean_v1'

def objective(z,y,coefficient):
 z=np.asarray(z,dtype=np.float64);y=np.asarray(y)
 assert z.ndim>=2 and z.shape[:-1]==y.shape and np.isfinite(z).all()
 assert np.issubdtype(y.dtype,np.integer) and coefficient in COEFFICIENTS.values()
 flat=z.reshape(-1,z.shape[-1]);target=y.reshape(-1);valid=target!=-100
 assert valid.any() and np.all((target[valid]>=0)&(target[valid]<flat.shape[-1]))
 q=flat[valid];a=q.max(-1,keepdims=True);e=np.exp(q-a);s=e.sum(-1,keepdims=True);prob=e/s;logz=a[:,0]+np.log(s[:,0])
 ce=float(np.mean(logz-q[np.arange(len(q)),target[valid]]));squared=float(np.mean(logz*logz))
 g=prob.copy();g[np.arange(len(q)),target[valid]]-=1;g+=2*coefficient*logz[:,None]*prob;g/=len(q)
 full=np.zeros_like(flat);full[valid]=g
 return dict(ce=ce,total=ce+coefficient*squared,mean=float(logz.mean()),squared=squared,penalty=coefficient*squared,gradient=full.reshape(z.shape),valid_targets=int(valid.sum()))

def normalize(x,gamma,beta,kind,eps=1e-5):
 x=np.asarray(x,dtype=np.float64);gamma=np.asarray(gamma,dtype=np.float64)
 assert kind in ('layer_affine','layer_no_bias','rms') and eps==1e-5
 centered=x if kind=='rms' else x-x.mean(-1,keepdims=True)
 inv=1/np.sqrt(np.mean(centered*centered,-1,keepdims=True)+eps)
 return centered*inv*gamma+(0 if beta is None else beta),centered,inv

def norm_vjp(x,gamma,beta,kind,upstream):
 _,c,inv=normalize(x,gamma,beta,kind);u=upstream*gamma
 gx=inv*(u-c*inv**2*np.mean(u*c,-1,keepdims=True))
 if kind!='rms':gx-=inv*np.mean(u,-1,keepdims=True)
 return gx,np.sum(upstream*c*inv,axis=(0,1)),None if beta is None else np.sum(upstream,axis=(0,1))

def verify(p):
 assert p['atol']==1e-4 and p['rtol']==2e-5 and p['convention']==CONVENTION
 kind=p['logit_z_kind'];assert kind in COEFFICIENTS and type(p['logit_z_coefficient']) is float and p['logit_z_coefficient']==COEFFICIENTS[kind]
 assert p['include_training_objective'] is True and p['ignore_index']==-100
 w=p['width'];assert w in (64,256);tying=p['tying_kind'];assert tying in ('legacy_untied','matched_untied','scaled_tied')
 coeff=(1 if tying=='legacy_untied' else 1/math.sqrt(192))/(w/64);assert p['readout_coefficient']==coeff
 assert p['input_embedding_scale'] in (1.,.5,.25) and p['norm_epsilon']==1e-5
 norm=p['norm_kind'];assert norm in ('layer_affine','layer_no_bias','rms')
 assert (p['norm_bias'] is not None)==(norm=='layer_affine')
 errors={}
 def arr(k):
  a=np.asarray(p[k],dtype=np.float64);assert np.isfinite(a).all(),k;return a
 def close(k,a,b):
  a=np.asarray(a);b=np.asarray(b);assert a.shape==b.shape,k
  np.testing.assert_allclose(a,b,atol=1e-4,rtol=2e-5,err_msg=k);errors[k]=float(np.max(np.abs(a-b)))
 x=arr('norm_input');h=arr('hidden');q=arr('readout');embedding=arr('embedding');gamma=arr('norm_weight');beta=None if p['norm_bias'] is None else arr('norm_bias');z=arr('logits');idx=np.asarray(p['tokens']);y=np.asarray(p['targets'])
 assert x.shape==h.shape and x.ndim==3 and x.shape[-1]==w and idx.shape==y.shape==x.shape[:2]
 assert q.shape==embedding.shape==(65,w) and gamma.shape==(w,) and z.shape==(*idx.shape,65)
 assert np.issubdtype(idx.dtype,np.integer) and idx.min()>=0 and idx.max()<65
 assert p['output_bias_kind'] in ('none','learned_zero','learned_train_unigram')
 bias=arr('bias');assert bias.shape==(65,)
 if p['output_bias_kind']=='none':assert np.array_equal(bias,np.zeros(65)) and p['bias_gradient'] is None
 close('normalization',h,normalize(x,gamma,beta,norm)[0]);close('logits',z,np.einsum('btd,vd->btv',h,q)*coeff+bias)
 o=objective(z,y,p['logit_z_coefficient']);assert p['valid_targets']==o['valid_targets']
 for k in ('ce','total'):close(k,p[k],o[k])
 for key,expected in [('logit_z_mean','mean'),('logit_z_squared_mean','squared'),('logit_z_penalty','penalty')]:
  if kind=='none':assert p[key] is None
  else:close(key,p[key],o[expected])
 if kind=='none':assert p['ce']==p['total']
 g=o['gradient'];close('logits_gradient',arr('logits_gradient'),g)
 hg=np.einsum('btv,vd->btd',g,q)*coeff;projection=np.einsum('btv,btd->vd',g,h)*coeff
 close('hidden_gradient',arr('hidden_gradient'),hg)
 gx,gg,gb=norm_vjp(x,gamma,beta,norm,hg)
 close('norm_input_gradient',arr('norm_input_gradient'),gx);close('norm_weight_gradient',arr('norm_weight_gradient'),gg)
 if beta is None:assert p['norm_bias_gradient'] is None
 else:close('norm_bias_gradient',arr('norm_bias_gradient'),gb)
 lookup=np.zeros_like(embedding);lg=arr('lookup_output_gradient');assert lg.shape==x.shape;np.add.at(lookup,idx.reshape(-1),lg.reshape(-1,w))
 close('table_gradient',arr('table_gradient'),lookup+projection if tying=='scaled_tied' else lookup)
 if tying=='scaled_tied':assert np.array_equal(q,embedding) and p['readout_gradient'] is None
 else:close('readout_gradient',arr('readout_gradient'),projection)
 if p['output_bias_kind']!='none':close('bias_gradient',arr('bias_gradient'),g.sum((0,1)))
 return dict(status='verified',errors=errors,valid_targets=o['valid_targets'],scope='Saved realized objective/readout/final-normalization VJP; CP binding, branch/attention links and pure-CE evaluator gates separately required')

def bind_checkpoint(p,state,derived_sha,width,objective_kind,norm_kind,tying_kind,bias_kind,input_scale):
 assert p['derived_checkpoint_sha256']==derived_sha and len(derived_sha)==64 and all(c in '0123456789abcdef' for c in derived_sha)
 assert (p['width'],p['logit_z_kind'],p['norm_kind'],p['tying_kind'],p['output_bias_kind'],p['input_embedding_scale'])==(width,objective_kind,norm_kind,tying_kind,bias_kind,input_scale)
 fields={'embedding':'transformer.wte.weight','norm_weight':'transformer.ln_f.weight','readout':'transformer.wte.weight' if tying_kind=='scaled_tied' else 'lm_head.weight'}
 if norm_kind=='layer_affine':fields['norm_bias']='transformer.ln_f.bias'
 else:assert p['norm_bias'] is None and 'transformer.ln_f.bias' not in state
 if bias_kind!='none':fields['bias']='output_bias'
 else:assert 'output_bias' not in state and np.array_equal(p['bias'],np.zeros(65))
 if tying_kind=='scaled_tied':assert 'lm_head.weight' not in state
 for a,b in fields.items():assert np.array_equal(np.asarray(p[a]),np.asarray(state[b])),a
 return dict(status='bound',unique_checkpoint_tensors=len(set(fields.values())),checkpoint_fields=fields)

def link_graph(p,branch):
 assert branch['derived_checkpoint_sha256']==p['derived_checkpoint_sha256'] and branch['width']==p['width'] and len(branch['blocks'])==4
 a,b=branch['blocks'][0],branch['blocks'][-1]
 pairs=[(p['norm_input'],b['output']),(p['norm_input_gradient'],b['output_gradient']),
        (np.asarray(p['embedding'])[p['tokens']]*p['input_embedding_scale'],a['input']),
        (p['lookup_output_gradient'],np.asarray(a['input_gradient'])*p['input_embedding_scale'])]
 for x,y in pairs:np.testing.assert_allclose(x,y,atol=1e-4,rtol=2e-5)
 return dict(status='linked',objective_to_branch_edges=4)
