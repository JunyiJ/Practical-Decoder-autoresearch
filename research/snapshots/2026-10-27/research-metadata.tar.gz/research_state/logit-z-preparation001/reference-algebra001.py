"""Independent stdlib algebra only: does not execute proposed tensor implementation."""
import math,random,unittest,json
from pathlib import Path
COUNT=0

def ref(rows,targets,coefficient):
    valid=[(r,t) for r,t in zip(rows,targets) if t!=-100]
    if not valid:raise ValueError('empty mask')
    ces=[];zs=[];grad=[]
    for r,t in valid:
        m=max(r);ex=[math.exp(v-m) for v in r];z=m+math.log(sum(ex));p=[v/sum(ex) for v in ex]
        ces.append(z-r[t]);zs.append(z)
        grad.append([(q-(j==t)+2*coefficient*z*q)/len(valid) for j,q in enumerate(p)])
    ce=sum(ces)/len(valid);sq=sum(z*z for z in zs)/len(valid)
    return ce+coefficient*sq,ce,sq,sum(zs)/len(valid),grad
class Algebra(unittest.TestCase):
    def test_gradient(self):
        global COUNT
        rng=random.Random(2501)
        for coef in (0.,.0001,.001):
            for shift in (-5.,0.,5.):
                rows=[[rng.uniform(-3,3)+shift for _ in range(7)] for _ in range(3)];ts=[1,4,2]
                g=ref(rows,ts,coef)[-1]
                for i in range(3):
                    for j in range(7):
                        e=1e-5;rows[i][j]+=e;a=ref(rows,ts,coef)[0];rows[i][j]-=2*e;b=ref(rows,ts,coef)[0];rows[i][j]+=e
                        self.assertAlmostEqual((a-b)/(2*e),g[i][j],delta=2e-9);COUNT+=1
    def test_common_shift(self):
        rows=[[1.,-2.,.5],[4.,-.3,2.]];ts=[0,2]
        for c in (.0001,.001):
            a=ref(rows,ts,c);delta=11.;b=ref([[x+delta for x in r] for r in rows],ts,c)
            self.assertAlmostEqual(a[1],b[1],places=13)
            self.assertAlmostEqual(b[0]-a[0],c*(2*delta*a[3]+delta*delta),places=12)
    def test_extremes(self):
        for c in (0.,.0001,.001):
            for row in ([10000.,9999.,-10000.],[-10000.,-10001.,-9999.],[0.,0.,0.]):
                vals=ref([row],[1],c)
                self.assertTrue(all(math.isfinite(x) for x in vals[:4]))
                self.assertTrue(all(math.isfinite(x) for x in vals[-1][0]))
    def test_mask_and_denominator(self):
        rows=[[.1,.4],[-1.,3.],[2.,-5.]];ts=[1,-100,0]
        for c in (.0001,.001):
            self.assertEqual(ref(rows,ts,c),ref([rows[0],rows[2]],[1,0],c))
            rows[1]=[1e10,-1e10];self.assertEqual(ref(rows,ts,c),ref([rows[0],rows[2]],[1,0],c))
        with self.assertRaises(ValueError):ref(rows,[-100]*3,.001)
    def test_coefficient_once(self):
        rows=[[1.,-1.],[3.,4.]];ts=[0,1]
        a=ref(rows,ts,0.);b=ref(rows,ts,.0001);c=ref(rows,ts,.001)
        self.assertAlmostEqual((c[0]-a[0])/(b[0]-a[0]),10.,places=10)
        self.assertAlmostEqual(c[0],c[1]+.001*c[2],places=14)
    def test_sum_penalty_gradient(self):
        row=[1.,-1.,3.];c=.001;out=ref([row],[0],c)
        self.assertAlmostEqual(sum(out[-1][0]),2*c*out[3],places=14)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Algebra))
    print(json.dumps({'methods':result.testsRun,'directional_scalar_coordinates':COUNT,'passed':result.wasSuccessful(),'scope':'independent reference algebra; production tensor function NOT executed'}))
    raise SystemExit(not result.wasSuccessful())
