import ast,copy,json,unittest
from pathlib import Path
from prerequisites import verify_linked_prerequisites
F=Path(__file__).resolve().parent

def fixture(pos='rope',value='local',gain='unit'):
 p=dict(source_sha256='a'*64,recipe=dict(position_family_kind=pos,value_residual_kind=value,residual_gain_kind=gain))
 f=dict(collected=5689,passed=5689,failed=0,actual_tests=27,remaining_tests=5662,metadata_tests=535,preserved_monitoring_failures=2,orphan_process_exit_codes_unavailable=1,partial_prefix_case_durations_unavailable=4,partial_prefix_warning_summary_unavailable=True,total_test_seconds_from_completed_summaries=4000.)
 t=dict(status='cpu_verified',publication_status='verified',source_sha256='a'*64,full_tests=f,actual_logit_z_geometry_tests_passed=15,actual_logit_z_training_tests_passed=12,logit_z_metadata_tests_passed=535,limitations=['Preserved failures and unavailable exit/timing'],artifacts=[dict(path='/evidence/'+x) for x in ('cpu-watchdog-repair001/recovery-review.json','cpu-scratch-isolation-repair001/review.json','cpu-tools003/record-cpu-review003.py','tested-original-protocol.md')])
 freq=8 if pos=='rope' else 0;rows=[]
 for w in (64,256):
  for k in ('none','z1e4','z1e3'):
   rows.append(dict(status='verified',width=w,family=k,objective_kind=k,position_kind=pos,value_kind=value,gain_kind=gain,objective=dict(status='verified'),objective_binding=dict(status='bound',unique_checkpoint_tensors=4),objective_links=dict(status='linked',objective_to_branch_edges=4),branch=dict(status='verified'),branch_binding=dict(status='bound',weights=28 if gain=='learned_tenth' else 20),attention=dict(status='verified',first_value_gradient_roles=4 if value=='first_blend' else 1),attention_binding=dict(status='bound',weights=16,rope_buffers=freq),attention_links=dict(status='linked',edges=16),cache=dict(status='verified',forward_calls=24,cache_prefixes=96,reset_events=1,absolute_offset=117,attention_input_links=4,qkv_checkpoint_tensors=8,rope_checkpoint_buffers=freq,position_kind=pos),evaluation=dict(status='verified',forward_calls=6,default_modes=2,sampled_batches=2,synthetic_coverage_targets=21,synthetic_coverage_windows=3,short_tail=5,objective_graph_links=2)))
 return dict(tests=t,independent_linked_objective_graph=rows,independent_objective_primitive=dict(status='verified',cases=12,masked_cases=6,invalid_cases=2),averaging_reuse=dict(trainer_changed=True)),p

class Tests(unittest.TestCase):
 def test_27_inherited_routes_and_all_required_graph_fields(self):
  count=0
  for pos in ('rope','nope','alibi'):
   for value in ('local','local_half','first_blend'):
    for gain in ('unit','static_tenth','learned_tenth'):
     v,p=fixture(pos,value,gain);self.assertTrue(verify_linked_prerequisites(v,p))
     for group in ('objective','objective_binding','objective_links','branch','branch_binding','attention','attention_binding','attention_links','cache','evaluation'):
      for key,val in v['independent_linked_objective_graph'][0][group].items():
       bad=copy.deepcopy(v);bad['independent_linked_objective_graph'][0][group][key]='corrupt'
       with self.assertRaises((AssertionError,TypeError)):verify_linked_prerequisites(bad,p)
       count+=1
     for key in ('objective_kind','position_kind','value_kind','gain_kind','status'):
      bad=copy.deepcopy(v);bad['independent_linked_objective_graph'][0][key]='corrupt'
      with self.assertRaises(AssertionError):verify_linked_prerequisites(bad,p)
      count+=1
  print('graph field corruptions',count)
 def test_cpu_failure_lineage_and_counts_must_remain_explicit(self):
  v,p=fixture()
  for key,val in v['tests']['full_tests'].items():
   bad=copy.deepcopy(v);bad['tests']['full_tests'][key]=False if isinstance(val,bool) else -1
   with self.assertRaises(AssertionError,msg=key):verify_linked_prerequisites(bad,p)
  for i in range(4):
   bad=copy.deepcopy(v);bad['tests']['artifacts'].pop(i)
   with self.assertRaises(AssertionError):verify_linked_prerequisites(bad,p)
  for key in ('actual_logit_z_geometry_tests_passed','actual_logit_z_training_tests_passed','logit_z_metadata_tests_passed','status','publication_status','source_sha256','limitations'):
   bad=copy.deepcopy(v);bad['tests'][key]=None
   with self.assertRaises(AssertionError):verify_linked_prerequisites(bad,p)
 def test_cell_primitive_and_trainer_lineage_vetoes(self):
  v,p=fixture()
  for mode in ('missing','duplicate','primitive','mask','invalid','trainer'):
   bad=copy.deepcopy(v)
   if mode=='missing':bad['independent_linked_objective_graph'].pop()
   elif mode=='duplicate':bad['independent_linked_objective_graph'][1]=copy.deepcopy(bad['independent_linked_objective_graph'][0])
   elif mode=='trainer':bad['averaging_reuse']['trainer_changed']=False
   else:bad['independent_objective_primitive'][{'primitive':'cases','mask':'masked_cases','invalid':'invalid_cases'}[mode]]=0
   with self.assertRaises(AssertionError):verify_linked_prerequisites(bad,p)
 def test_registration_manifest_and_preimport_guards(self):
  tree=ast.parse((F/'freeze-logit-z-quality001.py').read_text());ns={'Path':Path,'re':__import__('re')}
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='reviewed_files');exec(compile(ast.Module(body=[fn],type_ignores=[]),'manifest','exec'),ns)
  record={'files':[dict(path=f'src/file{i}.py' if i<14 else 'research/LOGIT_Z_PROTOCOL.md',sha256='a'*64,base_sha256=None) for i in range(15)]};self.assertEqual(len(ns['reviewed_files'](record)),15)
  for mode in ('count','duplicate','sha','absolute','traversal','fields'):
   b=copy.deepcopy(record)
   if mode=='count':b['files'].pop()
   elif mode=='duplicate':b['files'][1]=copy.deepcopy(b['files'][0])
   elif mode=='sha':b['files'][0]['sha256']='no'
   elif mode=='absolute':b['files'][0]['path']='/src/a.py'
   elif mode=='traversal':b['files'][0]['path']='../a.py'
   else:b['files'][0].pop('base_sha256')
   with self.assertRaises(AssertionError):ns['reviewed_files'](b)
  for file in ('freeze-logit-z-quality001.py','launch-logit-z-quality001.py'):
   tr=ast.parse((F/file).read_text());guard=next(n for n in tr.body if isinstance(n,ast.If) and 'live_model_commands' in ast.unparse(n.test));ns={'live_model_commands':lambda *a:['worker'],'subprocess':type('P',(),{'check_output':staticmethod(lambda *a,**k:'worker')}),'os':__import__('os')}
   with self.assertRaisesRegex(ValueError,'Competing'):exec(compile(ast.Module(body=[guard],type_ignores=[]),'live-guard','exec'),ns)
   imp=next(n for n in tr.body if isinstance(n,ast.ImportFrom) and n.module=='src.research');self.assertLess(guard.lineno,imp.lineno)
  launch=(F/'launch-logit-z-quality001.py').read_text();self.assertLess(launch.index('json.dumps(m,allow_nan=False)'),launch.index('subprocess.Popen'))
if __name__=='__main__':unittest.main(verbosity=2)
