"""Pure metadata prerequisites. Files and payloads are separately rehashed by the freezer."""
from pathlib import Path
COEFFICIENTS={'none':0.,'z1e4':.0001,'z1e3':.001}
def verify_linked_prerequisites(v,p):
 t=v['tests'];f=t['full_tests'];r=p['recipe']
 assert t['status']=='cpu_verified' and t['publication_status']=='verified'
 assert f['collected']==f['passed']==5689 and f['failed']==0
 assert (f['actual_tests'],f['remaining_tests'],f['metadata_tests'])==(27,5662,535)
 assert (t['actual_logit_z_geometry_tests_passed'],t['actual_logit_z_training_tests_passed'],t['logit_z_metadata_tests_passed'])==(15,12,535)
 assert f['preserved_monitoring_failures']==2 and f['orphan_process_exit_codes_unavailable']==1
 assert f['partial_prefix_case_durations_unavailable']==4 and f['partial_prefix_warning_summary_unavailable'] is True
 assert f['total_test_seconds_from_completed_summaries']>0
 paths={Path(a['path']).as_posix() for a in t['artifacts']}
 for suffix in ('cpu-watchdog-repair001/recovery-review.json','cpu-scratch-isolation-repair001/review.json','cpu-tools003/record-cpu-review003.py','tested-original-protocol.md'):
  assert any(x.endswith('/'+suffix) for x in paths),suffix
 assert t['limitations'] and t['source_sha256']==p['source_sha256']
 rows=v['independent_linked_objective_graph'];cells={(w,k) for w in (64,256) for k in COEFFICIENTS}
 assert len(rows)==6 and {(x['width'],x['family']) for x in rows}==cells
 for x in rows:
  assert x['status']=='verified' and x['objective_kind']==x['family']
  assert x['position_kind']==r['position_family_kind'] and x['value_kind']==r['value_residual_kind'] and x['gain_kind']==r['residual_gain_kind']
  for name in ('objective','branch','attention','cache','evaluation'):assert x[name]['status']=='verified'
  assert x['objective_binding']['status']=='bound' and x['objective_binding']['unique_checkpoint_tensors']>0
  assert x['objective_links']==dict(status='linked',objective_to_branch_edges=4)
  assert x['branch_binding']==dict(status='bound',weights=28 if r['residual_gain_kind']=='learned_tenth' else 20)
  freq=8 if r['position_family_kind']=='rope' else 0
  assert x['attention_binding']==dict(status='bound',weights=16,rope_buffers=freq)
  assert x['attention_links']==dict(status='linked',edges=16)
  assert x['attention']['first_value_gradient_roles']==(4 if r['value_residual_kind']=='first_blend' else 1)
  c=x['cache'];assert (c['forward_calls'],c['cache_prefixes'],c['reset_events'],c['absolute_offset'],c['attention_input_links'],c['qkv_checkpoint_tensors'],c['rope_checkpoint_buffers'])==(24,96,1,117,4,8,freq)
  assert c['position_kind']==r['position_family_kind']
  e=x['evaluation'];assert (e['forward_calls'],e['default_modes'],e['sampled_batches'],e['synthetic_coverage_targets'],e['synthetic_coverage_windows'],e['short_tail'],e['objective_graph_links'])==(6,2,2,21,3,5,2)
 primitive=v['independent_objective_primitive'];assert primitive['status']=='verified'
 assert (primitive['cases'],primitive['masked_cases'],primitive['invalid_cases'])==(12,6,2)
 assert v['averaging_reuse']['trainer_changed'] is True
 return True
