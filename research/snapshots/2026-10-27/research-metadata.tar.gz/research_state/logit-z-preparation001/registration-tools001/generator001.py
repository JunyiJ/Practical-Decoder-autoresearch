from pathlib import Path
import ast,re
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');N=B/'research_state/position-quality-preparation001/registration-tools001';Z=B/'research_state/logit-z-preparation001/registration-tools001';Z.mkdir(exist_ok=False)
s=(N/'freeze-position-quality001.py').read_text()
for a,b in [('position-quality','logit-z-quality'),('position_quality_study','logit_z_study'),('POSITION_QUALITY','LOGIT_Z'),('value-residual-quality','position-quality'),('value-residual completion','position completion'),('position-family','logit-z objective'),('5127','5689'),('actual_position_family_training','actual_logit_z_training'),('actual_position_family_geometry','actual_logit_z_geometry'),('position_quality_metadata','logit_z_metadata'),('==13','==15'),('==496','==535'),('len(files)==16','len(files)==15'),("result)==15","result)==14"),('cpu-tools001','cpu-tools003')]:s=s.replace(a,b)
# Replace the old separate CE-table/branch summaries with the actual new linked penalized graph contract.
a=s.index("assert len(v['independent_branch_math'])");b=s.index('# Verify every required artifact',a)
s=s[:a]+"verify_linked_prerequisites(v,p)\n\n"+s[b:]
a=s.index("artifacts += [prep/'pilot-tools001'");b=s.index("artifacts += [prior/f",a)
s=s[:a]+"""artifacts += [prep/'pilot-tools001'/n for n in ('pilot-driver001.py','review-prerequisites001.py','preflight.py','prior-audit.py','pilot-geometry.py','resource-gate.py','preparation-review001.json','manual-wiring-review001.json')]
artifacts += [prep/'graph-tools001'/n for n in ('graph-capture.py','graph-audit.py','load-helpers.py','helper-manifest.json','review.json')]
artifacts += [prep/'objective-math-tools001/review.json',prep/'objective-eval-tools001/review.json',prep/'resource-tools001/review.json']
artifacts += [prep/'cpu-tools003'/n for n in ('record-cpu-review003.py','run-cpu-validation003.py','bounded_cpu.py','process_guard.py','recovery.py','segments.py')]
artifacts += [prep/'cpu-watchdog-repair001/recovery-review.json',prep/'cpu-scratch-isolation-repair001/review.json',prep/'cpu-recovery-knowledge-snapshot002.md']
# All transitive CPU failure/repair, source and actual MPS evidence must be plan-bound.
artifacts += [Path(a['path']) for a in v['artifacts']]
artifacts=list(dict.fromkeys(artifacts))
"""+s[b:]
# Import the pure metadata checker before any irreversible registration writes.
s=s.replace("review=prep/'review.json';", "sys.path.insert(0,str(folder))\nfrom prerequisites import verify_linked_prerequisites\nreview=prep/'review.json';")
s=s.replace("folder/'freeze-position-quality001.py'", "folder/'freeze-logit-z-quality001.py'").replace("folder/'launch-position-quality001.py'", "folder/'launch-logit-z-quality001.py'")
s=s.replace("folder/'review.json',", "folder/'review.json',folder/'prerequisites.py',")
# Rewrite human-facing registration claims around the final objective rather than positional intervention.
a=s.index(" title='Position families");b=s.index(" scope=dict(source_commit",a)
s=s[:a]+""" title='Logit-z objective passed unique CPU assertions and serial MPS prerequisites',
 summary=f"All {tests['passed']} unique source-matched CPU assertions, including27 actual geometry/evaluator/trainer cases, and six serial MPS40-update pilots passed. Two CPU monitoring failures remain preserved: orphan batch84 has unavailable OS exit code, and batch99 preserves four completed assertions with unavailable prefix durations/warning summary. No completed case rerun; original wall budgets include the600-second orphan reservation and interrupted work. Independent checkpoint-bound penalized objective/readout/final-norm graph linked through branches and attention, masked/extreme/zero primitive cases, pure-CE evaluator vetoes, inherited position/value/gain/cache/prior/optimizer/RNG/H200/fullcoverage verified. Resource forecasts require50percent margins within unchanged caps. Correctness pilots excluded from quality evidence.",
"""+s[b:]
a=s.index(" title='Preregistered");b=s.index(" output_bias_prior=p",a)
s=s[:a]+""" title='Preregistered logit-z quality001: zero versus1e-4 versus1e-3',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='A fixed squared final-logit normalizer penalty may improve pure-CE validation. No local instability, quality gain or optimal transfer is assumed.',
 selection='Eighteen width64 screens2501/2502 choose one LR per objective family, ties lowerLR; bestfamily ties none/z1e4/z1e3. Zero LR-only requires>.005mean/everyseed versusfixedincumbent; nonzero also versus tunedzero. Failedbest retains incumbent, nofallback. Freeze before18selected fresh2511/2512/2513 at64/256 plus0/6 exactfixedreferences. Onlyeligiblefrozenwinner adopts after>.005mean/everyseed/allthreeconditionaltextuppernegative bothwidths against requiredrefs.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='All position/value/gain/activation/attention/topology/table/bias/prior/norm/input/LR/decay/warmup inherit FINAL reviewed position decision. Training-only CE+lambda*mean(logsumexp(finalFP32logits)^2), same valid-target mask and denominator, coefficients0/1e-4/1e-3 applied once. No centering/logVsubtraction/clip/detach/temperature/widthcoefficient/newparameters. Zero exact historical CE path with null logZ diagnostics. ALL validation/ranking PURECE; training objective metrics separate. Explicit training flag independent of model train/eval mode. Common3000updates3072000targets/cooldown2000/H200101. EqualLRgrid.0025/.005/.01;36/42physical72/84correlated. Nonzero-coefficient contrast separate, not extra adoption gate. Noextension/reselection/rerun/holdout; allolderstudiesclosed/006permanentstop/primaryuntouched.',
"""+s[b:]
ast.parse(s);(Z/'freeze-logit-z-quality001.py').write_text(s)
s=(N/'launch-position-quality001.py').read_text()
for a,b in [('position-quality','logit-z-quality'),('position_quality','logit_z'),('POSITION_QUALITY','LOGIT_Z'),('value-residual-quality','position-quality'),('value_residual_quality_completion','position_quality_completion'),('value-residual completion','position completion'),('position-family','logit-z objective'),('cpu-tools001','cpu-tools003')]:s=s.replace(a,b)
a=s.index("scope='RoPE/");b=s.index("',next_action=",a)
s=s[:a]+"scope='Training-only finalFP32 squared-logsumexp penalty0/1e-4/1e-3; all validation pureCE; final-reviewed inherited position/value/gain/architecture; equal LR tuning36/42fresh trajectories72/84correlated outputs, exact aliases, holdout closed."+s[b:]
ast.parse(s);(Z/'launch-logit-z-quality001.py').write_text(s)
print(Z)
