"""Serial short implementation checks, excluded from research selection."""
import copy, gc, json, math, time
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.train.train import run_training, evaluate_checkpoint
from src.research.coverage_eval import evaluate_job
from src.research.protocol import file_digest
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint, load_model_weights
root=Path.cwd(); out=root/'research_state/context-interaction-validation'
torch.set_num_threads(4)
base=json.loads((root/'research_state/stage1-conclusion.json').read_text())['control']
rows=[]
for width in [64,256]:
 for attn in ['mha','gqa']:
  cfg=copy.deepcopy(base); d=out/f'{attn}-w{width}-c512';d.mkdir(exist_ok=False)
  cfg['model'].update(dim=width,n_heads=width//32,attn_type=attn,n_layers=4,
    block_size=512,depth_width_policy='depth4_unscaled' if attn=='mha' else 'depth4_gqa_unscaled',
    attention_width_policy='mha_head32' if attn=='mha' else 'gqa_half_head32',
    ffn='swiglu',ffn_bias=False,ffn_width_policy='swiglu_21_8')
  cfg['training'].update(max_iters=20,eval_every=10,eval_iters=2,batch_size=2,
    batch_layout='paired_blocks512',learning_rate=.005,seed=9091,strict_device=True,
    checkpoint_dir=str(d/'checkpoints'),metrics_file=str(d/'metrics.jsonl'),summary_file=str(d/'summary.json'))
  c=OmegaConf.create(cfg); start=time.monotonic(); result=run_training(c)
  check=evaluate_checkpoint(c,result['final_checkpoint'],split='val',eval_iters=2)
  assert result['completed_steps']==20 and check['checkpoint_step']==20 and math.isfinite(check['loss'])
  assert abs(check['loss']-result['final_metric']['val_loss'])<1e-6
  path=Path(result['final_checkpoint']); sha=file_digest(path)
  coverage=evaluate_job(dict(checkpoint=str(path),checkpoint_sha256=sha,completed_steps=20,
    data_sha256=file_digest(Path(cfg['data']['path'])),contexts=[128,512]))
  assert all(x['target_count']==111538 for x in coverage['evaluations'].values())
  saved=read_checkpoint(path); model=GPT(OmegaConf.create(saved['cfg']['model']))
  load_model_weights(model,saved)
  assert all(tuple(b.attn.qkv.weight.shape)==((3 if attn=='mha' else 2)*width,width) for b in model.transformer.h)
  rows.append(dict(width=width,attention=attn,context=512,depth=4,
    parameters=sum(p.numel() for p in model.parameters()),checkpoint_sha256=sha,
    checkpoint_bytes=path.stat().st_size,training=result,checkpoint_evaluation=check,
    coverage=coverage,wall_seconds=time.monotonic()-start))
  (out/'mps-correctness.json').write_text(json.dumps(dict(purpose='Short correctness and feasibility checks only; not quality evidence or full-run timing',results=rows),indent=2)+'\n')
  print(json.dumps(dict(width=width,attention=attn,steps=20,training_seconds=result['training_time_sec'],wall_seconds=rows[-1]['wall_seconds'])),flush=True)
  del model,saved;gc.collect();torch.mps.empty_cache()
