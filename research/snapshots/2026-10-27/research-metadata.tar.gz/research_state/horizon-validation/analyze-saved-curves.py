"""Read completed horizon logs only; no model training, scoring or selection."""
import ast,datetime,hashlib,json,statistics,subprocess
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.knowledge import KnowledgeBank
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');run=base/'research_runs/horizon-quality-001';folder=base/'research_state/horizon-validation';commit='280ea428792d4dd31780123d14846d5302d43227'
report=json.loads((run/'report.json').read_text());review=json.loads((run/'review.json').read_text());con=json.loads((base/'research_state/horizon-conclusion.json').read_text());assert review['status']=='verified' and review['distinct_checkpoints']==48
assert file_digest(run/'report.json')==review['report_sha256']
functions={}
for rel,fn in [('src/train/train.py','_evaluate'),('src/data/loaders.py','_get_batch')]:
 text=subprocess.check_output(['git','show',commit+':'+rel],cwd=source,text=True);tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==fn);body=ast.get_source_segment(text,node)
 functions[rel]=dict(function=fn,sha256=hashlib.sha256(body.encode()).hexdigest(),source=body)
assert "manual_seed(loader.eval_seed + (split == 'test'))" in functions['src/train/train.py']['source']
assert "if split == 'train'" in functions['src/data/loaders.py']['source']
panels=[];artifacts=[run/'report.json',run/'review.json']
for width in [64,256]:
 for family in ['control3000','long6000_stretched','long6000_fixedtail']:
  rows=[r for r in report['records'] if r['stage']=='confirmation' and r['width']==width and r['family']==family];assert sorted(r['seed'] for r in rows)==[2171,2172,2173]
  curves={};deltas={};finals=[];before=[]
  for r in rows:
   d=run/'trials'/r['trial_id'];raw=json.loads((d/'result.json').read_text());assert file_digest(d/'result.json')==r['result_sha256']
   req=json.loads((d/'request.json').read_text());assert file_digest(d/'request.json')==r['request_sha256']
   cfg=req['config'];assert cfg['model']['block_size']==128 and cfg['training']['batch_size']==8 and cfg['training']['eval_iters']==30 and cfg['training']['eval_seed']==2026
   metrics=[json.loads(x) for x in (d/'metrics.jsonl').read_text().splitlines()];assert metrics==raw['metrics']
   end=metrics[-1];previous=metrics[-2];assert end['step']-previous['step']==299 and end['lr_multiplier']==.1
   curves[str(r['seed'])]={str(x['step']+1):dict(sampled_online_validation_ce=x['val_loss'],lr_multiplier=x['lr_multiplier']) for x in metrics}
   deltas[str(r['seed'])]=end['val_loss']-previous['val_loss'];finals.append(end['val_loss']);before.append(previous['val_loss'])
   artifacts.extend([d/'request.json',d/'result.json',d/'metrics.jsonl'])
  panels.append(dict(width=width,family=family,curves=curves,last299_update_paired_deltas=deltas,mean_delta=statistics.mean(deltas.values()),every_seed_improves=max(deltas.values())<0,every_seed_worsens=min(deltas.values())>0,mean_before=statistics.mean(before),mean_final=statistics.mean(finals),completed_update_start=previous['step']+1,completed_update_end=end['step']+1))
limits=['Post-completion descriptive analysis of saved logs, not a preregistered new hypothesis test or revised selection.',
 'The sampled panel resets evaluation seed2026 each call and has30720 scored targets; text overlap/repeats are possible. It differs from the final111538-target fullvalidation primary metric.',
 'These logs score online weights; H200 primary endpoints are separate correlated outputs and are not measured at every log point.',
 'Online training losses are single changing minibatches; no fixed-panel training/validation gap or identified overfitting cause is established.',
 'Update count, cooldown multiplier, cumulative decay and averaging history change together. No isolated cause, extrapolation, optimal stopping time or new grid choice follows.',
 'All findings remain adaptive validation. No training/scoring rerun, holdout use, early-checkpoint selection or incumbent change.']
large={x['family']:x for x in panels if x['width']==256}
summary='Saved online validation logs reverse late behavior at width256: over the final299updates, control3000 improves everyseed (mean '+f"{large['control3000']['mean_delta']:+.6f}"+'), while both6000recipes worsen everyseed (stretched '+f"{large['long6000_stretched']['mean_delta']:+.6f}"+', fixedtail '+f"{large['long6000_fixedtail']['mean_delta']:+.6f}"+'). These fixed-sampled-panel diagnostics help characterize the observed width reversal, but do not identify its cause or change the final H200 selection.'
result=dict(status='verified_existing_log_diagnostic',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),historical_source_commit=commit,summary=summary,panels=panels,historical_evaluation_functions=functions,scope=dict(physical_training_runs_inspected=18,additional_training_runs=0,additional_model_evaluations=0,holdout_consumed=False,sampled_panel_tokens=30720,primary_full_validation_targets=111538),limitations=limits,artifacts=[dict(path=str(p),sha256=file_digest(p)) for p in artifacts])
p=folder/'late-curve-diagnostic.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');p.chmod(0o444)
bank=KnowledgeBank(base/'research_state/knowledge');kid=bank.add(dict(kind='evaluation',outcome='mixed',created_by='continuing-quality-research',title='Saved horizon logs show late online-validation regression at larger width',summary=summary,scope=result['scope'],details=result,artifacts=[dict(path=str(p),sha256=file_digest(p))],related_ids=[con['result_id'],'kb_515dd8687f458de37efcb88b39abd1d726c5fb712f55a531178928c064954479']))
(folder/'late-curve-knowledge.json').write_text(json.dumps(dict(knowledge_id=kid,review=str(p)),indent=2)+'\n')
lines=['## Saved-log diagnostic after the horizon result','',summary,'','All rows compare the final299updates on the same sampled online-validation panel within a trajectory. They do not replace full-validation H200 scores or select an earlier checkpoint.','','| Recipe | Width | Completed updates | Sampled CE before | Sampled CE final | Mean change | Every seed improves | Every seed worsens |','|---|---:|---|---:|---:|---:|---|---|']
for x in panels:lines.append(f'| {x["family"]} | {x["width"]} | {x["completed_update_start"]} to {x["completed_update_end"]} | {x["mean_before"]:.6f} | {x["mean_final"]:.6f} | {x["mean_delta"]:+.6f} | {x["every_seed_improves"]} | {x["every_seed_worsens"]} |')
lines+=['','The validation seed is reset before each logging evaluation:30batches ×8examples ×128targets =30,720scored targets, with possible overlap. Online training losses are changing single minibatches, so this does not measure a fixed train/validation gap or establish overfitting as the cause. Schedule, update count and cumulative decay are confounded. All earlier choices stay frozen. No model work or holdout access.','',f'Evidence: `research_state/horizon-validation/late-curve-diagnostic.json`; knowledge `{kid}`.']
Path('/private/tmp/horizon-curves-guide-addition.md').write_text('\n'.join(lines)+'\n')
print(kid);print(summary)
for x in panels:print(x['family'],x['width'],x['mean_delta'],x['every_seed_improves'],x['every_seed_worsens'])
