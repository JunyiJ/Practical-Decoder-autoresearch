import datetime,json,math,statistics
from pathlib import Path
import numpy as np
from src.research import horizon_study as study
from src.research.coverage_eval import paired_blocks
from src.research.protocol import digest,file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/horizon-quality-001';folder=root/'research_state/horizon-validation'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());audit=json.loads((folder/'partial-audit.json').read_text())
rows=[r for r in s['records'] if r['status']=='completed' and r['stage']=='confirmation' and r['width']==64]
assert len(rows)==9 and set(r['seed'] for r in rows)=={2171,2172,2173}
assert audit['status']=='partial_verified' and audit['distinct_trajectories']>=15
checked={r['trial_id']:r for r in audit['checkpoint_audit']}
for r in rows:assert checked[r['trial_id']]['checkpoint_sha256']==r['checkpoint_sha256']
assert s['selection']==json.loads((run/'selection.json').read_text())==study.freeze_selection(p,s['records'][:6])
comparisons=[]
for a,b in [('long6000_stretched','control3000'),('long6000_fixedtail','control3000'),('long6000_fixedtail','long6000_stretched')]:
 item=dict(candidate=a,reference=b,width=64)
 for raw,key in [(False,'primary'),(True,'raw')]:
  panels={f:{r['seed']:study.endpoint(p,r,raw) for r in rows if r['family']==f} for f in (a,b)}
  calculated=[paired_blocks(panels[a],panels[b],n) for n in (2048,4096,8192)]
  differences=np.array([np.array(panels[a][seed]['block_loss_sums'])-panels[b][seed]['block_loss_sums'] for seed in (2171,2172,2173)]).mean(0)
  counts=np.array(panels[a][2171]['block_target_counts'])
  ds={str(seed):panels[a][seed]['mean_ce']-panels[b][seed]['mean_ce'] for seed in (2171,2172,2173)}
  for n,v in zip((2048,4096,8192),calculated):
   factor=n//2048;sums=np.array([differences[i:i+factor].sum() for i in range(0,len(differences),factor)])
   ns=np.array([counts[i:i+factor].sum() for i in range(0,len(counts),factor)])
   ids=np.random.default_rng(20261024).integers(len(ns),size=(2000,len(ns)))
   boot=sums[ids].sum(1)/ns[ids].sum(1)
   assert np.allclose(np.quantile(boot,[.025,.975]),v['conditional_text_bootstrap_95pct'],rtol=0,atol=1e-12)
   assert v['paired_seed_deltas']==ds and math.isclose(v['mean_delta'],statistics.mean(ds.values()),abs_tol=1e-12)
  item[key]=calculated
 v=item['primary'];item['passes_width64_rule']=v[0]['mean_delta']<-.005 and max(v[0]['paired_seed_deltas'].values())<0 and all(x['conditional_text_bootstrap_95pct'][1]<0 for x in v)
 comparisons.append(item)
means={f:dict(primary=statistics.mean(study.endpoint(p,r)['mean_ce'] for r in rows if r['family']==f),raw=statistics.mean(study.endpoint(p,r,True)['mean_ce'] for r in rows if r['family']==f)) for f in study.CELLS}
review=dict(status='partial_width64_verified',checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],plan_sha256=digest(p),selection_sha256=file_digest(run/'selection.json'),physical_confirmation_trajectories=9,correlated_confirmation_endpoints=18,checkpoint_audit=audit,means=means,comparisons=comparisons,frozen_winner=s['selection']['winner'],adoption=False,holdout_consumed=False,limitations=['Only width64 fresh confirmation is complete; width256 remains required before any adoption','Longer recipes double tokens/updates and change cumulative decay; no equal-compute or isolated cooldown effect claim','Conditional text bootstrap is not seed-population uncertainty or independent holdout evidence'])
out=folder/'width64-confirmation-review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');out.chmod(0o444)
frozen=next(c for c in comparisons if c['candidate']==s['selection']['winner'] and c['reference']=='control3000')
summary=f"Fresh width64 horizon confirmation on seeds2171/2172/2173: primary H200 means {means}. Frozen {s['selection']['winner']} minuscontrol mean {frozen['primary'][0]['mean_delta']:.9f}, paired {frozen['primary'][0]['paired_seed_deltas']}, 4096conditionaltextinterval {frozen['primary'][1]['conditional_text_bootstrap_95pct']}; passeswidth64={frozen['passes_width64_rule']}. All9confirmation trajectories/18endpoints audited and everyprimary/raw bootstrap independently reconstructed. Width256 stillpending; noadoption."
k=KnowledgeBank(root/'research_state/knowledge').add(dict(kind='evaluation',outcome='supported',created_by='continuing-quality-research',title='Horizon width64 fresh confirmation reviewed; larger-width adoption gate pending',summary=summary,scope=dict(stage='partial_confirmation',width=64,holdout_consumed=False,adoption=False),artifacts=[dict(path=str(out),sha256=file_digest(out))],related_ids=['kb_6d794f60b317b94482293fde0603549eea39abfaffb09335b7c1895d691caf25'],details=review))
(folder/'width64-knowledge.json').write_text(json.dumps(dict(knowledge_id=k,review=str(out)),indent=2)+'\n')
for name in ['research-monitor.json','quality-evolution-progress.json']:
 f=root/'research_state'/name;v=json.loads(f.read_text());v.update(horizon_width64_review=str(out),horizon_width64_result_id=k,horizon_width64_notified=False);f.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(dict(knowledge_id=k,means=means,comparisons=[dict(candidate=c['candidate'],reference=c['reference'],mean_delta=c['primary'][0]['mean_delta'],paired=c['primary'][0]['paired_seed_deltas'],interval4096=c['primary'][1]['conditional_text_bootstrap_95pct'],passes_width64_rule=c['passes_width64_rule']) for c in comparisons]),indent=2))
