"""Plot final reviewed horizon evidence; no training or scoring."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');con=json.loads((root/'research_state/horizon-conclusion.json').read_text());review=json.loads(Path(con['review']).read_text())
assert review['status']=='verified' and review['distinct_trajectories']==24 and review['distinct_checkpoints']==48
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,3,figsize=(14,4.8),gridspec_kw={'width_ratios':[1.15,1.15,1]})
families=['long6000_stretched','long6000_fixedtail'];labels=['6k stretched','6k fixed tail'];values=[]
for ax,w in zip(axes[:2],[64,256]):
 for i,f in enumerate(families):
  c=next(x for x in con['comparisons'] if x['width']==w and x['candidate']==f and x['reference']=='control3000');v=c['sensitivity'][1]
  ds=[v['paired_seed_deltas'][str(s)] for s in [2171,2172,2173]];lo,hi=v['conditional_text_bootstrap_95pct'];values.extend(ds+[lo,hi])
  color='#087d87' if f==con['selection']['winner'] else '#748799'
  ax.scatter(ds,np.array([i]*3)+[-.11,0,.11],s=32,color=color,zorder=3)
  ax.plot([lo,hi],[i,i],color=color,linewidth=2,alpha=.75);ax.scatter(v['mean_delta'],i,marker='D',color=color,s=68,edgecolor='white',zorder=4)
 ax.axvline(0,color='#555',linewidth=.8);ax.axvline(-.005,color='#888',linewidth=.8,linestyle=':');ax.set_yticks([0,1],labels);ax.set_ylim(1.55,-.55);ax.set_title(f'Width {w} · H200 quality');ax.set_xlabel('CE difference versus fresh 3k control');ax.grid(axis='x',alpha=.15)
lo=min(values+[0]);hi=max(values+[0]);margin=max(.003,(hi-lo)*.08)
for ax in axes[:2]:
 ax.set_xlim(lo-margin,hi+margin)
 ax.locator_params(axis='x',nbins=4)
ax=axes[2];y=np.arange(2)
for offset,w,color in [(-.17,'64','#087d87'),(.17,'256','#c18c31')]:
 vals=[con['cost'][f][w]['training_time_ratio_vs_control'] for f in families]
 ax.barh(y+offset,vals,height=.29,label=f'Width {w}',color=color)
 for i,val in enumerate(vals):ax.text(val+.025,i+offset,f'{val:.2f}×',va='center',fontsize=10)
ax.set_yticks(y,labels);ax.invert_yaxis();ax.axvline(1,color='#555',linewidth=.8);ax.set_xlim(0,max(con['cost'][f][w]['training_time_ratio_vs_control'] for f in families for w in ['64','256'])*1.25);ax.set_xlabel('Measured training time / fresh 3k control');ax.set_title('Added training cost');ax.legend(frameon=False,fontsize=9);ax.grid(axis='x',alpha=.15)
fig.suptitle('Longer training — fresh paired confirmation and measured cost',fontsize=15)
fig.text(.025,.035,'Quality: dots = paired seeds; diamonds = means; lines = 4096-token conditional text intervals. Dotted line = mean-gain threshold.\nOnly the frozen local winner can be adopted. 6k recipes use twice the training tokens/updates; adaptive validation, no holdout.',fontsize=9,color='#555')
fig.tight_layout(rect=[0,.14,1,.93]);out=root/'research_state/reports/pretraining-learning-guide/horizon-quality001.png';fig.savefig(out,dpi=180);print(out)
