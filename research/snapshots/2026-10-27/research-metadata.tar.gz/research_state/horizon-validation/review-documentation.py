"""Check published numerical tables and all local HTML links against audited evidence."""
import datetime,hashlib,json,re,statistics
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse,unquote
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');run=base/'research_runs/horizon-quality-001';folder=base/'research_state/horizon-validation';out=base/'research_state/reports/pretraining-learning-guide'
r=json.loads((run/'report.json').read_text());v=json.loads((run/'review.json').read_text());con=json.loads((base/'research_state/horizon-conclusion.json').read_text());best=json.loads((base/'research_state/best-observed-config.json').read_text())
assert v['status']=='verified' and v['distinct_checkpoints']==48 and not v['quality_decision']['qualifies_for_incumbent_replacement']
assert best['result_id']=='kb_297e2dca399a3a438b7205016233e75d94f8a28b702ed6d8012ea24f9d227135' and any(x['result_id']==con['result_id'] for x in best['subsequent_algorithm_studies'])
md=(source/'research/HORIZON_QUALITY_RESULTS.md').read_text();guide=(source/'research/LEARNING_GUIDE.md').read_text();html=(out/'index.html').read_text()
rows=[x for x in r['records'] if x['stage']=='confirmation'];cells={'control3000':(3000,2000),'long6000_stretched':(6000,4000),'long6000_fixedtail':(6000,5000)}
for f,(steps,start) in cells.items():
 vals=[]
 for raw in [False,True]:
  for w in [64,256]:
   panel=[x for x in rows if x['family']==f and x['width']==w];assert sorted(x['seed'] for x in panel)==[2171,2172,2173]
   vals.append(statistics.mean(x['raw_metric'] if raw else x['metric'] for x in panel))
 line=f'| {f} | {steps} | {start} | {steps*1024} | '+' | '.join(f'{x:.6f}' for x in vals)+' |';assert line in md and line in guide
 for w in [64,256]:
  panel=[x for x in rows if x['family']==f and x['width']==w];control=[x for x in rows if x['family']=='control3000' and x['width']==w]
  time=statistics.mean(x['training_time_sec'] for x in panel);wall=statistics.mean(x['duration_seconds'] for x in panel);rss=statistics.mean(x['rss_mb'] for x in panel);ratio=time/statistics.mean(x['training_time_sec'] for x in control)
  assert f'| {f} | {w} | {time:.2f} | {wall:.2f} | {ratio:.3f} | {rss:.2f} |' in md
for c in r['comparisons']:
 for key,label in [('sensitivity','H200'),('raw_sensitivity','Raw')]:
  z=c[key][1];lo,hi=z['conditional_text_bootstrap_95pct'];ds=' / '.join(f'{z["paired_seed_deltas"][str(k)]:+.6f}' for k in [2171,2172,2173]);passed=str(c['quality_improvement']) if label=='H200' else 'Diagnostic only'
  assert f'| {label} | {c["width"]} | {c["candidate"]} minus {c["reference"]} | {z["mean_delta"]:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] | {passed} |' in md
assert con['summary'] in md and con['summary'] in guide and con['summary'] in html
class Links(HTMLParser):
 def __init__(self):super().__init__();self.urls=[]
 def handle_starttag(self,tag,attrs):
  for k,val in attrs:
   if k in ('href','src'):self.urls.append(val)
parser=Links();parser.feed(html);checked=[]
for url in parser.urls:
 v=urlparse(url)
 if v.scheme in ('http','https','data') or not v.path:continue
 path=Path(unquote(v.path)) if v.scheme=='file' else out/unquote(v.path)
 assert path.exists(),str(path);checked.append(str(path))
files=[source/'research/HORIZON_QUALITY_RESULTS.md',source/'research/LEARNING_GUIDE.md',source/'research/ARCHITECTURE_STAGE2.md',out/'index.html',out/'horizon-quality001.png']
review=dict(status='verified',checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),numerical_tables='All12endpoint means,12primary/raw contrasts with36paired seed differences and12intervals, and6cost rows match audited report at printed precision.',local_links_checked=len(checked),broken_links=[],visual_review='All three panels inspected. Crowded horizontal tick labels reduced and final image re-inspected; paired means/intervals and measured cost remain legible.',files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},historical_evidence_source='280ea428792d4dd31780123d14846d5302d43227',incumbent_retained=True)
p=folder/'documentation-review.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review,indent=2))
