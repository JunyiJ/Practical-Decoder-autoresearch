"""Record completed partitioned project tests; refuses incomplete/failing logs."""
import datetime,json,re
from pathlib import Path
from src.research.protocol import file_digest
from src.research.team.suite import source_digest
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=base/'research_state/horizon-validation'
actual=base/'research_state/horizon-actual-tests-first.log';remaining=base/'research_state/horizon-full-tests-first.log'
def passed(path,n):
 text=path.read_text();m=re.search(r'(\d+) passed in ([\d.]+)s',text)
 assert m and int(m[1])==n and not re.search(r'\b(?:FAILED|ERROR|failed|error)\b',text)
 return float(m[2])
a,b=passed(actual,6),passed(remaining,980)
review=json.loads((folder/'integrated-source-review.json').read_text());assert review['source_sha256']==source_digest(source)
for item in review['artifacts']:assert file_digest(Path(item['path']))==item['sha256']
files=[actual,remaining,folder/'integrated-source-review.json',folder/'record-cpu-review.py',source/'src/research/horizon_study.py',source/'tests/test_horizon_study.py',source/'tests/test_horizon_training.py',source/'research/HORIZON_QUALITY_PROTOCOL.md']
result=dict(status='cpu_verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=source_digest(source),base_commit=review['base_commit'],
 trainer_integration=dict(passed=6,failed=0,seconds=a,scope='ActualCPU3horizonrecipes x2widths: exactmodel/optimizer/RNG/average savedstatecontinuation, changedhorizonresume rejection, privateRNG reconstruction and derivedcounters'),
 full_tests=dict(passed=986,failed=0,partition='6 actual CPU horizon tests in separate development with identical source/test hashes plus980 remaining integrated project tests; no duplicate case count',remaining_tests=980,remaining_seconds=b,total_seconds=a+b),
 limitations=['Synthetic CPU correctness, not quality or MPS performance','Actual serial MPS/resource gates stillrequired'],artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in files])
out=folder/'cpu-review.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['full_tests']))
