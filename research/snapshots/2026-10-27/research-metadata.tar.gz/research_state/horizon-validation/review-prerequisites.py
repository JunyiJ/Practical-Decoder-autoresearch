"""Review saved horizon prerequisites and resource forecasts; never train or score."""
import argparse,datetime,json,math,subprocess
from pathlib import Path
import torch
from omegaconf import OmegaConf
from src.research import horizon_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import digest,file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.utils.checkpoint import read_checkpoint,load_model_weights

parser=argparse.ArgumentParser();parser.add_argument('--pilots',type=Path,required=True);args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=base/'research_state/horizon-validation'
p=study.make_plan(source,base/'research_runs/averaging-quality-001/review.json');assert p['returned_half_life']==200
cpu_path=folder/'cpu-review.json';cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
assert cpu['status']=='cpu_verified' and cpu['full_tests']['passed']==986 and cpu['full_tests']['failed']==0
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==6
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.CELLS}
artifacts=[cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver.py',folder/'completion-audit.py',source/'research/HORIZON_QUALITY_PROTOCOL.md',Path(p['predecessor_review']['path'])]
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
old=base/'research_state/averaging-mps-coupled-001/review.json';assert file_digest(old)==pilot['coupled_arithmetic_review_sha256'];artifacts.append(old)
for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 assert (source/rel).read_bytes()==subprocess.check_output(['git','show','0f15366dc43b5e2a2805ca08bb1eeac25f6b1e14:'+rel],cwd=source)
for rel in ['averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
checks=[];torch.set_num_threads(1)
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=(30,20) if f=='control3000' else (60,40 if f=='long6000_stretched' else 50)
 job=dict(family=f,lr=.005,width=w,n_heads=w//32,seed=9306,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,.005),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total and cp['training_state']['weight_averaging_state']['snapshots']==1+(total-start)//10
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
 expected_count=132*w+4*(4*w*w+6*w+3*w*(21*w//8))
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 for i in range(4):
  weights=cp['model_state'];prefix=f'transformer.h.{i}.'
  assert weights[prefix+'attn.qkv.weight'].shape==(3*w,w)
  assert weights[prefix+'mlp.linear_gate.weight'].shape==(21*w//8,w)
  assert weights[prefix+'mlp.linear_up.weight'].shape==(21*w//8,w)
  assert weights[prefix+'mlp.linear_down.weight'].shape==(w,21*w//8)
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==.00006
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved)
 gen=torch.Generator().manual_seed(9306);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 assert 0<row['training_seconds']<=row['wall_seconds']<180 and row['sampled_peak_rss_mb']<4096
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.append(d/'review.json');checks.append(row)
# Fresh24jobs: five trajectories per family at width64, three per family at256.
seconds=0;storage=0;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=5 if w==64 else 3;target=study.CELLS[f][0]
 estimate=1.5*(row['training_seconds']*target/row['steps']+row['wall_seconds']-row['training_seconds'])
 assert estimate<2400;seconds+=count*estimate
 size=row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2;storage+=count*size*1.5
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate))
assert seconds<21600 and storage/1024**2<4096
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=list((base/'research_runs').glob('*/plan.json'))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=dict(hours=seconds/3600,trial_proxies=proxies,total_mb_with_margin=storage/1024**2,
 method='Scale each measured30/60-update pilot training by100, retain measured two-output overhead and add50% margin. Final raw+derived bytes plus25MiBmetadata per trajectory and50%margin. Forecast, not measured production cost.'),
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['986 project tests:6actual CPU horizon trainer/resume cases plus980 remainingtests','Six actual serial MPS shortened3recipe/2width jobs;12 full validation panels, finite strictCPU raw/derived loads, exact derivation','Unchanged train/averaging/checkpoint/evaluator implementation bound to previous directMPSnoninterference/float64recurrence/sharedgradientcontinuation checks; independentMPSreproducibility not assumed','Explicit horizon/schedule/averaging resume contracts; final private data RNG and untouched holdout RNG','Fixed four-layer MHA architecture and Muon muP factors; extra tokens/updates/compute/cumulativedecay explicit','Final predecessor adoptedH200 resolved before newregistration; finite24trajectories48correlatedoutputs, nooldstudyextension'],
 limitations=['Short synthetic pilots excluded from quality findings','Resource forecasts are estimates; independent watchdog and hard caps stillapply','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness depends on separately tested frozenimplementation','No optimalLR/muP/horizon transfer or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=folder/'review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
