"""Record reviewed closure after audited documentation is pushed; goal continues."""
import datetime,json,subprocess
from pathlib import Path
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');run=root/'research_runs/horizon-quality-001';folder=root/'research_state/horizon-validation'
s=json.loads((run/'state.json').read_text());v=json.loads((run/'review.json').read_text());con=json.loads((root/'research_state/horizon-conclusion.json').read_text());docs=json.loads((folder/'documentation-review.json').read_text())
assert s['status']=='completed' and v['status']=='verified' and v['distinct_checkpoints']==48 and docs['status']=='verified'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert commit.startswith('081b658')
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=source,text=True).split()[0]==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
now=datetime.datetime.now(datetime.timezone.utc).isoformat();path=root/'research_state/active-campaign.json';a=json.loads(path.read_text());assert a['campaign']==str(run)
a.update(status='completed_reviewed',pid=None,review=str(run/'review.json'),result_id=con['result_id'],documentation_commit=commit,completed_reviewed_at=now,next_action='Continue QK RMS preparation on retained3000-update/start2000/H200 incumbent: finish4actualCPUtraining tests, integrate reviewedsource, runremaining1112tests, serialMPS/resourceaudit, cleancommitpush and newfinitepreregistration. Alloldstudiesclosed;006permanentstop.')
path.write_text(json.dumps(a,indent=2)+'\n')
for name in ['research-monitor.json','quality-evolution-progress.json']:
 path=root/'research_state'/name;x=json.loads(path.read_text());x.update(status='preparing_next_round',horizon_status='completed_reviewed',horizon_completed_trials=24,horizon_checkpoint_count=48,horizon_result_id=con['result_id'],horizon_review=str(run/'review.json'),horizon_documentation_commit=commit,horizon_completion_notified=True,last_checked_at=now,next_action=a['next_action'],next_stage='qknorm_quality',next_resolved_horizon=dict(family='control3000',total_steps=3000,cooldown_start=2000,half_life=200),actual_cpu_tests='Running four QK normalization family/width training and resume checks; no research training active.')
 path.write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(dict(status=a['status'],result_id=con['result_id'],documentation_commit=commit)))
