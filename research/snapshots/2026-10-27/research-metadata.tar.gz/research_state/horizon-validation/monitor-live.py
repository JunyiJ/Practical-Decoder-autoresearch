"""Observe the active horizon process and recent metrics without controlling it."""
import datetime,json,subprocess
from pathlib import Path
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
active=json.loads((root/'research_state/active-campaign.json').read_text());run=Path(active['campaign'])
assert run==root/'research_runs/horizon-quality-001'
state=json.loads((run/'state.json').read_text());now=datetime.datetime.now(datetime.timezone.utc)
processes=[]
for line in subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True).splitlines():
 parts=line.split(None,3)
 if len(parts)==4 and parts[0].isdigit() and parts[1].isdigit():processes.append(dict(pid=int(parts[0]),ppid=int(parts[1]),elapsed=parts[2],command=parts[3]))
controller=next((p for p in processes if p['pid']==active['pid'] and '-m src.research.horizon_study ' in p['command'] and str(run/'plan.json') in p['command']),None)
workers=[p for p in processes if p['ppid']==active['pid'] and '--request '+str(run/'trials')+'/' in p['command']]
records=state['records'];completed=sum(r['status']=='completed' for r in records);pending=[r for r in records if r['status']!='completed'];observation='unknown';details=[]
for r in pending:
 metric=run/'trials'/r['trial_id']/'metrics.jsonl';item=dict(trial_id=r['trial_id'],status=r['status'])
 if metric.exists():
  lines=metric.read_text().splitlines()
  try:last=json.loads(lines[-1])
  except (IndexError,json.JSONDecodeError):item['metric_note']='Current append incomplete; re-observe, do not restart.'
  else:item.update(last_step=last['step'],metric_age_seconds=round(now.timestamp()-metric.stat().st_mtime,2))
 details.append(item)
if state['status']=='running':
 if controller and len(workers)==1:observation='worker_live'
 elif controller and not workers:observation='controller_live_between_workers_or_finalizing'
 elif not controller:observation='running_marker_without_controller_requires_diagnosis'
 else:observation='multiple_workers_requires_diagnosis'
elif state['status']=='completed':
 observation='completed_ready_for_review' if not controller and not workers and (run/'report.json').exists() else 'completed_state_finalizing'
else:observation='terminal_state_requires_review'
snapshot=dict(checked_at=now.isoformat(),campaign=str(run),status=state['status'],observation=observation,completed=completed,total=24,controller_pid=controller['pid'] if controller else None,controller_elapsed=controller['elapsed'] if controller else None,workers=[{k:p[k] for k in ('pid','ppid','elapsed')} for p in workers],pending=details,report_exists=(run/'report.json').exists(),actions_taken='read-only process/evidence observation; monitor metadata only; no process control or training')
# Refuse to overwrite a concurrently changed active pointer.
assert json.loads((root/'research_state/active-campaign.json').read_text())==active
for filename in ('research-monitor.json','quality-evolution-progress.json'):
 path=root/'research_state'/filename;metadata=json.loads(path.read_text())
 metadata.update(last_checked_at=now.isoformat(),horizon_record_count=completed,horizon_last_health=f"{completed}/{snapshot['total']} completed; {observation}; "+', '.join(x['trial_id'] for x in details),last_verified_processes=dict(checked_at=now.isoformat(),controller_pid=snapshot['controller_pid'],worker_pid=workers[0]['pid'] if len(workers)==1 else None,note=observation),horizon_live_observation=snapshot)
 temporary=path.with_name(path.name+'.monitor-tmp');temporary.write_text(json.dumps(metadata,indent=2)+'\n');temporary.replace(path)
with (root/'research_state/horizon-validation/live-observations.jsonl').open('a') as stream:stream.write(json.dumps(snapshot)+'\n')
print(json.dumps(snapshot))
