"""Freeze a unique horizon study after completed predecessor and all actual gates."""
import datetime,json,os,re,subprocess
from pathlib import Path
from src.research import horizon_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();run=base/'research_runs/horizon-quality-001';folder=base/'research_state/horizon-validation'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text());prior=base/'research_runs/averaging-quality-001'
assert active['campaign']==str(prior) and active['status']=='completed_reviewed' and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
lines=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in lines if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]==p['git_commit']
review=folder/'review.json';v=json.loads(review.read_text())
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit'] and v['returned_half_life']==200
assert v['tests']['full_tests']['passed']==986 and v['tests']['full_tests']['failed']==0
assert len(v['pilot_audit'])==6 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.CELLS}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (base/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/HORIZON_QUALITY_PROTOCOL.md';con=json.loads((base/'research_state/averaging-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='Explicit horizon/cooldown contracts with fixed adopted H200 returned weights',
 summary='The new finite controller reuses unchanged model, trainer, optimizer, sampler and averaging code.986 project tests and six actual serial MPS shortened horizon pilots passed;12 full validation outputs, raw/derived contracts, RNG and resource budgets verified. Final averaging review fixes H200 before registration. Correctness pilots are excluded from quality evidence.',
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id'],'kb_64fd3492bf2cf722a9a1d74d0470945989ad747b0d2d7c9005b35ba3e388a4f8']))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',title='Preregistered horizon-quality-001: fresh3000/6000-update cooldown comparison',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='Additional updates may improve quality or may overfit; stretched and fixed-duration cooldown may interact with H200 averaging. No quantitative quality prediction. Raw endpoints remain diagnostics.',
 selection='Six width64screens2161/2162; locally eligible longer recipe requires mean gain>.005 and bothseeds. Freeze winner before18freshconfirmations at64/256 on2171/2172/2173; onlywinner can adopt ifmean gain>.005,everyseed and all3textupper<0 bothwidths.',
 limits={k:p[k] for k in ['max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb']},
 lineage='Final averaging adoption fixes returned policy.24freshtrajectories48correlatedoutputs. Extra tokens/updates/compute/cumulativeperstepdecay explicit; nooldtrialcontinuation/gridextension/posthocselection.006permanentstop preserved.'),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in [protocol,review,prior/'review.json']],related_ids=[implementation,con['result_id'],'kb_515dd8687f458de37efcb88b39abd1d726c5fb712f55a531178928c064954479']))
snapshot=base/'research_state/horizon-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
artifacts=[protocol,review,folder/'review-prerequisites.py',folder/'freeze-horizon.py',folder/'launch-horizon.py',base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/averaging-conclusion.json',base/'research_state/averaging-completed-knowledge-snapshot.md',base/'research_state/schedule-validation/late-curve-diagnostic.json']+[prior/f for f in ['plan.json','report.json','review.json','selection.json']]
p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary kimi/KDA untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in [run/'plan.json',base/'research_state/horizon-plan.json']:path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],physical_training_trajectories=24,model_evaluations=48,returned_half_life=200,horizon_cells=p['horizon_cells'],completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
