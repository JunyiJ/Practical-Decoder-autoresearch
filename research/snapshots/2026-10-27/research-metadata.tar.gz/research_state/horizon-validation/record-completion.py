"""Publish horizon findings only after final verified evidence; no model execution."""
import copy,datetime,json,statistics
from pathlib import Path
from src.research import horizon_study as study
from src.research.protocol import digest,file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/horizon-quality-001';folder=root/'research_state/horizon-validation'
p=json.loads((run/'plan.json').read_text());s=json.loads((run/'state.json').read_text());r=json.loads((run/'report.json').read_text());v=json.loads((run/'review.json').read_text())
assert s['status']=='completed' and v['status']=='verified' and v['distinct_trajectories']==24 and v['distinct_checkpoints']==48
assert digest(p)==r['plan_sha256']==v['plan_sha256'] and v['report_sha256']==file_digest(run/'report.json') and v['selection_sha256']==file_digest(run/'selection.json')
study.verify_lineage(p);assert study.summarize(p,s)==r and r['quality_decision']==v['quality_decision']
assert p['returned_half_life']==200 and len(r['records'])==24
rows=[x for x in r['records'] if x['stage']=='confirmation'];winner=r['selection']['winner'];adopt=v['quality_decision']['qualifies_for_incumbent_replacement']
means={};cost={}
for f in study.CELLS:
 means[f]={};cost[f]={}
 for w in [64,256]:
  panel=[x for x in rows if x['width']==w and x['family']==f];assert sorted(x['seed'] for x in panel)==[2171,2172,2173]
  means[f][str(w)]={key:statistics.mean(study.endpoint(p,x,raw)['mean_ce'] for x in panel) for key,raw in [('H200',False),('raw',True)]}
  cost[f][str(w)]=dict(mean_training_seconds=statistics.mean(x['training_time_sec'] for x in panel),mean_trajectory_wall_seconds=statistics.mean(x['duration_seconds'] for x in panel),mean_sampled_rss_mb=statistics.mean(x['rss_mb'] for x in panel))
for f in study.CELLS:
 for w in ['64','256']:
  cost[f][w]['training_time_ratio_vs_control']=cost[f][w]['mean_training_seconds']/cost['control3000'][w]['mean_training_seconds']
chosen=[c for c in r['comparisons'] if c['candidate']==winner and c['reference']=='control3000']
summary=f'The horizon study completed 24 training trajectories and 48 correlated raw/H200 outputs, all independently reviewed. Frozen candidate: {winner}. '
if chosen:summary+='H200 mean validation CE changes at widths 64/256 versus fresh 3,000-update controls: '+ '/'.join(f"{next(c for c in chosen if c['width']==w)['sensitivity'][0]['mean_delta']:+.6f}" for w in [64,256])+'. '
summary+=('It passes the complete preregistered screening and confirmation rule at both widths and becomes the observed quality incumbent.' if adopt else 'It does not pass the complete frozen adoption rule; retain the prior 3,000-update H200 incumbent.')
limits=['Adaptive validation on fresh development seeds; conditional text bootstrap is not seed-population uncertainty, holdout, or adjusted significance.',
 'Twenty-four training trajectories produce 48 correlated raw/H200 outputs; raw and averaged endpoints of one trajectory are not independent training runs.',
 'The 6,000-update recipes consume 6,144,000 targets versus 3,072,000 for 3,000 updates; extra tokens, updates, compute and cumulative independent decay are explicit. This is not an equal-compute comparison.',
 'Control/stretched/fixed-tail base learning-rate sums are 12.75/25.5/27.75 and nominal decay retention differs with update count. Cooldown shape, LR integral, averaging duration and training budget are not isolated causal effects.',
 'H200 snapshot counts are 101/201/101. Every derived tensor matches its final raw-parent shadow; final checkpoints do not independently reconstruct every historical online snapshot.',
 'Inherited direct MPS recurrence checks remain valid for unchanged averaging source; earlier independent MPS trajectory agreement failures are preserved. No exact independent MPS reproducibility or identified kernel cause claim.',
 'Only the frozen screening winner can replace the incumbent after fresh confirmation at both widths. Other recipes remain reported diagnostics; no posthoc promotion or grid extension.',
 'Derived averaged weights are inference-only; online optimizer continuation requires the original raw parent. No inference-speed or peak-memory claim.',
 'A fixed peak learning rate of 0.005 at the tested horizons does not establish optimal horizon, LR, width scaling or universal model quality.']
artifacts=[run/x for x in ['plan.json','selection.json','report.json','review.json']]+[folder/x for x in ['completion-audit.py','review.json','screen-audit.json','width64-confirmation-review.json']]
conpath=root/'research_state/horizon-conclusion.json';assert not conpath.exists();bestpath=root/'research_state/best-observed-config.json';old=json.loads(bestpath.read_text());archive=root/'research_state/best-observed-before-horizon-quality001.json'
assert old['result_id']=='kb_297e2dca399a3a438b7205016233e75d94f8a28b702ed6d8012ea24f9d227135'
if adopt:assert not archive.exists() and len(chosen)==2
bank=KnowledgeBank(root/'research_state/knowledge');kid=bank.add(dict(kind='result',outcome='supported' if adopt else 'mixed',created_by='continuing-quality-research',title='Longer training horizons and cooldown shape with fixed H200 returned weights',summary=summary,
 scope=dict(source_commit=p['git_commit'],screen_seeds=[2161,2162],confirmation_seeds=[2171,2172,2173],widths=[64,256],physical_trajectories=24,correlated_outputs=48,validation_targets=111538,holdout_consumed=False),
 details=dict(means=means,cost=cost,comparisons=r['comparisons'],selection=r['selection'],quality_decision=v['quality_decision'],active_seconds=v['active_seconds'],disk_mb=v['disk_mb'],limitations=limits),
 artifacts=[dict(path=str(a),sha256=file_digest(a)) for a in artifacts],related_ids=[p['preregistration_id'],p['implementation_id'],old['result_id'],'kb_6d794f60b317b94482293fde0603549eea39abfaffb09335b7c1895d691caf25','kb_f67e283b925cf1abf2e6b6855503823d65c63184c7cab6b2ffbd9c5cb3486773']))
con=dict(result_id=kid,summary=summary,means=means,cost=cost,comparisons=r['comparisons'],selection=r['selection'],quality_decision=v['quality_decision'],limitations=limits,review=str(run/'review.json'),historical_incumbent_unchanged=not adopt)
conpath.write_text(json.dumps(con,indent=2)+'\n');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
if adopt:
 archive.write_bytes(bestpath.read_bytes());archive.chmod(0o444)
 config=copy.deepcopy(study.suite_spec(p,winner,.005)['candidate']['config']);averaging=config['training'].pop('weight_averaging');steps,start=study.CELLS[winner]
 b=dict(label=f'Most promising observed returned weights: four-layer MHA {winner}, H200',baseline_commit=p['git_commit'],baseline_config=config,
  config_overrides=[dict(path='training.weight_averaging',value_json=json.dumps(averaging))],reference_overrides={},result_id=kid,source_campaign=str(run),source_iteration=None,evidence_path=str(run/'report.json'),
  source_contract=dict(source_sha256=p['source_sha256'],data_sha256=p['data_sha256']),previous_best=dict(path=str(archive),sha256=file_digest(archive),result_id=old['result_id']),constant_reference=copy.deepcopy(old['constant_reference']),
  prior_3000_update_reference=dict(path=str(archive),description='Prior3000-update H200 quality incumbent; fresh same-round control is the comparison basis. Historical measurements not pooled.'),
  returned_weights=dict(kind='spaced_tail_ema',half_life=200,purpose='inference_only_not_optimizer_resume',raw_training_parent_required=True,start_step=start,interval=10,snapshots=1+(steps-start)//10),
  selection=dict(path=str(run/'selection.json'),family=winner,rule='Frozen local winner only; mean gain>.005,everyseednegative,allconditionaltextupper<0 at64/256'),quality_decision=v['quality_decision'],
  local_outcome='supported',transfer_outcome='supported_at_tested_widths',metrics=[dict(target=f'width-{c["width"]}',metric='full_validation_context128_ce_delta',candidate_mean=means[winner][str(c['width'])]['H200'],baseline_mean=means['control3000'][str(c['width'])]['H200'],**c['sensitivity'][0]) for c in chosen],
  comparators=means,measured_training_cost=cost,training_steps=steps,training_targets=steps*1024,widths=[64,256],seeds=[2171,2172,2173],holdout_consumed=False,stage1_control_retained_as_reference=True,ranking_scope=limits[0],limitations=limits,last_reviewed_at=now,learning_ids=[])
else:
 b=old;b.setdefault('subsequent_algorithm_studies',[]).append(dict(campaign=str(run),result_id=kid,review=str(run/'review.json'),summary=summary,means=means,quality_decision=v['quality_decision']));b['last_reviewed_at']=now
bestpath.write_text(json.dumps(b,indent=2)+'\n');snapshot=root/'research_state/horizon-completed-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
lines=['# Training horizon and cooldown quality results','',summary,'',f'Historical source `{p["git_commit"]}`. Result `{kid}`. All 24 raw and 24 derived checkpoint hashes, requests, results, saved configurations, optimizer and RNG states, schedules, averaging counts, model shapes, full validation coverage, frozen selection, and report calculations were verified before documentation. The paired conditional bootstrap was reconstructed independently. No training or scoring was rerun, and the holdout remained closed.','',f'Controller active time: {v["active_seconds"]:.2f} seconds ({v["active_seconds"]/3600:.2f} hours); output before review {v["disk_mb"]:.2f} MiB. [Frozen protocol](HORIZON_QUALITY_PROTOCOL.md).','','## Fresh confirmation scores','','Means use fresh seeds 2171, 2172 and 2173. Each endpoint scores all 111,538 validation targets once, at context length 128 and batch size 8. H200 is the primary metric; raw endpoints are correlated diagnostics.','','| Recipe | Updates | Cooldown start | Targets | H200 CE64 | H200 CE256 | Raw CE64 | Raw CE256 |','|---|---:|---:|---:|---:|---:|---:|---:|']
for f,(steps,start) in study.CELLS.items():lines.append(f'| {f} | {steps} | {start} | {steps*1024} | {means[f]["64"]["H200"]:.6f} | {means[f]["256"]["H200"]:.6f} | {means[f]["64"]["raw"]:.6f} | {means[f]["256"]["raw"]:.6f} |')
lines+=['','## Paired confirmation contrasts','','Positive means worse. Intervals condition on the three trained seed pairs and resample contiguous text blocks; they are not population confidence across training seeds. All three block sizes are audited.','','| Endpoint | Width | Candidate minus reference | Mean CE delta | Paired seeds 2171 / 2172 / 2173 | 4,096-token conditional 95% interval | Primary quality rule |','|---|---:|---|---:|---|---|---|']
for c in r['comparisons']:
 for key,label in [('sensitivity','H200'),('raw_sensitivity','Raw')]:
  z=c[key][1];lo,hi=z['conditional_text_bootstrap_95pct'];ds=' / '.join(f'{z["paired_seed_deltas"][str(k)]:+.6f}' for k in [2171,2172,2173]);passed=str(c['quality_improvement']) if label=='H200' else 'Diagnostic only'
  lines.append(f'| {label} | {c["width"]} | {c["candidate"]} minus {c["reference"]} | {z["mean_delta"]:+.6f} | {ds} | [{lo:+.6f}, {hi:+.6f}] | {passed} |')
lines+=['','## Measured costs','','Costs include the shared training trajectory; wall time also includes raw/H200 scoring and export. Longer recipes have twice the training tokens and updates.','','| Recipe | Width | Mean training seconds | Mean trajectory wall seconds | Training ratio versus control | Mean sampled RSS (MiB) |','|---|---:|---:|---:|---:|---:|']
for f in study.CELLS:
 for w,x in cost[f].items():lines.append(f'| {f} | {w} | {x["mean_training_seconds"]:.2f} | {x["mean_trajectory_wall_seconds"]:.2f} | {x["training_time_ratio_vs_control"]:.3f} | {x["mean_sampled_rss_mb"]:.2f} |')
lines+=['','## Frozen selection and decision','',f'Six width-64 screening trajectories on seeds 2161 and 2162 froze **{winner}** before any fresh confirmation. All three recipes then completed all six width/seed cells. '+('The frozen winner passes the adoption rule at both widths and replaces the observed incumbent; the original 3,000-update recipe remains archived as a reference.' if adopt else 'The frozen winner fails full adoption; the original 3,000-update H200 incumbent remains. No alternative is promoted from confirmation.'),'','The backbone has four MHA layers with head dimension 32, bias-free SwiGLU with hidden width 21d/8, RMSNorm blocks, final LayerNorm, RoPE and unscaled residuals. Training uses Muon/AdamW with muP base width 64, peak learning rate 0.005, cooldown to 10% of peak, independent decay 0.00006 per update, clipping at 1, zero dropout, context length 128 and batch size 8 with paired_blocks512 sampling. H200 initializes at cooldown start and updates every 10 steps. Control/stretched/fixed-tail recipes have 101/201/101 snapshots.','','## Continuation','','A separate finite QK RMS normalization and equal bounded LR-tuning round is prepared. It resolves its horizon from this final adoption, and must pass the full CPU test suite, serial MPS correctness and resource checks, clean committed source and new preregistration before launch. Completed studies remain closed; human-stopped campaign 006 remains stopped.','','## Limits','']+['- '+x for x in limits]
Path('/private/tmp/HORIZON_QUALITY_RESULTS.md').write_text('\n'.join(lines)+'\n')
start=lines.index('| Recipe | Updates | Cooldown start | Targets | H200 CE64 | H200 CE256 | Raw CE64 | Raw CE256 |');end=lines.index('## Paired confirmation contrasts')
Path('/private/tmp/horizon-guide-addition.md').write_text('## Completed horizon and cooldown quality round\n\n'+summary+'\n\n'+'\n'.join(lines[start:end])+'\n[Complete horizon results and costs](HORIZON_QUALITY_RESULTS.md). More training tokens and compute; adaptive validation, with the holdout closed.\n')
print(kid);print(summary)
