"""Six bounded serial MPS horizon correctness pilots; never research quality evidence."""
import argparse,json,math,os,re,subprocess,time
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-pilots',action='store_true');parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-review',type=Path,required=True);args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):raise ValueError('Unset fallback')
    base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();prior=base/'research_runs/averaging-quality-001'
    active=json.loads((base/'research_state/active-campaign.json').read_text())
    if Path(active['campaign'])!=prior or active['status']!='completed_reviewed':raise ValueError('Completed reviewed predecessor required')
    if json.loads((prior/'state.json').read_text())['status']!='completed':raise ValueError('Predecessor still active')
    processes=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
    live=[x for x in processes if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
    if live:raise ValueError('Competing model work: '+str(live))
    import torch
    from omegaconf import OmegaConf
    from src.models.gpt import GPT
    from src.utils.checkpoint import read_checkpoint,load_model_weights
    from src.train.lr_schedule import multiplier
    from src.research import horizon_study as study
    from src.research.averaging_eval import validate_derivation
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest,_request,_launch
    from src.research.runner import atomic_json,session_lock,validate_result,disk_mb
    torch.set_num_threads(1)
    sha=source_digest(source);cpu=json.loads(args.cpu_review.read_text())
    if cpu['status']!='cpu_verified' or cpu['source_sha256']!=sha or cpu['full_tests']['passed']!=986 or cpu['full_tests']['failed']!=0:
        raise ValueError('Complete matching986-test CPU gate required')
    for a in cpu['artifacts']:
        if file_digest(Path(a['path']))!=a['sha256']:raise ValueError('CPU evidence changed')
    if subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise ValueError('Dirty source')
    p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
    coupled=base/'research_state/averaging-mps-coupled-001/review.json';assert json.loads(coupled.read_text())['status']=='verified'
    # Bind unchanged arithmetic implementation instead of asserting equality of independent MPS trajectories.
    for rel in ['src/train/train.py','src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
        old=subprocess.check_output(['git','show','0f15366dc43b5e2a2805ca08bb1eeac25f6b1e14:'+rel],cwd=source)
        assert old==(source/rel).read_bytes(),rel
    out=args.output.resolve();assert out.is_relative_to(base/'research_state');out.mkdir(exist_ok=False)
    atomic_json(out/'intent.json',dict(source_commit=p['git_commit'],source_sha256=sha,cpu_review_sha256=file_digest(args.cpu_review),
        prior_review=p['predecessor_review'],coupled_arithmetic_review_sha256=file_digest(coupled),seed=9306,
        purpose='Synthetic shortened horizon train/reload/raw+H200 full validation; excluded from research',
        hard_limits=dict(jobs=6,job_seconds=180,round_seconds=1800,disk_mb=1024),holdout_consumed=False))
    began=time.monotonic();rows=[]
    def finite(x):
        if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
        elif isinstance(x,dict):
            for v in x.values():finite(v)
        elif isinstance(x,(list,tuple)):
            for v in x:finite(v)
        elif isinstance(x,float):assert math.isfinite(x)
    with session_lock(out) as fd:
        try:
            for w in (64,256):
                for f in study.CELLS:
                    assert source_digest(source)==sha
                    d=out/f'w{w}_{f}';d.mkdir();job=dict(family=f,lr=.005,width=w,n_heads=w//32,seed=9306,stage='local',arm='candidate',trial_id=d.name)
                    req=_request(study.suite_spec(p,f,.005),job,d);t=req['config']['training']
                    total,start=(30,20) if f=='control3000' else (60,40 if f=='long6000_stretched' else 50)
                    t.update(max_iters=total,eval_every=10,eval_iters=2)
                    t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
                    atomic_json(d/'request.json',req);started=time.monotonic()
                    allowance=min(180,1800-(started-began));assert allowance>0
                    status,error=_launch(d/'request.json',out,allowance,1024,fd,root=source,bootstrap=study.BOOTSTRAP)
                    if status!='completed':raise RuntimeError((status,error))
                    raw=json.loads((d/'result.json').read_text());checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
                    extra=study.adapter(p,raw,checked,req,d);cp=read_checkpoint(checked['checkpoint']);finite(cp)
                    assert cp['step']==total and raw['completed_steps']==total
                    cfg=OmegaConf.create(cp['cfg'])
                    with torch.random.fork_rng(devices=[]):
                        model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
                    names=dict(model.named_parameters());state=cp['model_state']
                    assert cfg.model.dim==w and cfg.model.n_layers==4 and cfg.model.n_heads==w//32 and cfg.model.attn_type=='mha'
                    assert sum(v.numel() for v in model.parameters())==sum(state[n].numel() for n in names)
                    avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
                    gen=torch.Generator().manual_seed(9306);text=Path(req['config']['data']['path']).read_text()
                    for _ in range(total):torch.randint(int(.8*len(text))-512,(2,),generator=gen)
                    assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
                    assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
                    for m in raw['metrics']:assert m['lr_multiplier']==multiplier(t['lr_schedule'],m['step'])
                    assert raw['metrics'][-1]['tokens_processed']==1024*total and abs(raw['metrics'][-1]['lr_multiplier']-.1)<1e-12
                    item=extra['averaged_outputs']['200'];derived=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
                    assert 'optimizer_state' not in derived and 'training_state' not in derived
                    load_model_weights(model,derived);finite(derived)
                    assert extra['coverage']['128']['target_count']==item['coverage']['evaluations']['128']['target_count']==111538
                    rss=max(x['rss_mb'] for x in raw['metrics']);assert rss<4096
                    row=dict(width=w,family=f,steps=total,cooldown_start=start,snapshots=avg['snapshots'],status='verified',
                        training_seconds=raw['training_time_sec'],wall_seconds=time.monotonic()-started,sampled_peak_rss_mb=rss,
                        parameter_count=sum(v.numel() for v in model.parameters()),raw_checkpoint_bytes=Path(checked['checkpoint']).stat().st_size,
                        derived_checkpoint_bytes=Path(item['checkpoint']).stat().st_size,checkpoint_sha256=checked['checkpoint_sha256'],
                        derived_checkpoint_sha256=item['checkpoint_sha256'],request_sha256=file_digest(d/'request.json'),result_sha256=file_digest(d/'result.json'),
                        private_train_rng_sha256=__import__('hashlib').sha256(cp['training_state']['loader_rng']['train'].numpy().tobytes()).hexdigest())
                    atomic_json(d/'review.json',row);rows.append(row);print(row,flush=True)
        except Exception as e:
            atomic_json(out/'failure.json',dict(error=repr(e),completed_jobs=len(rows),no_automatic_retry=True));raise
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,rows=rows,excluded_from_research=True,
        holdout_consumed=False,disk_mb=disk_mb(out),coupled_arithmetic_review_sha256=file_digest(coupled)))

if __name__=='__main__':main()
