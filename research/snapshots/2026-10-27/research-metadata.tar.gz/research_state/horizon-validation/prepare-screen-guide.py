from pathlib import Path
p=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/horizon-validation')
s=(p/'render-launch-guide.mjs').read_text()
needle='No longer-horizon quality finding is available yet.'
assert needle in s
s=s.replace(needle,'The six width64 screening trajectories have passed independent checkpoint review. The stretched 6,000-update candidate is frozen for confirmation; no incumbent change is made from screening. See the screening table below. Longer training uses more tokens, updates, compute and cumulative decay.')
needle='const html=`'
assert needle in s
insert="""const screen=JSON.parse(fs.readFileSync(evidenceRoot+'/research_state/horizon-validation/screen-audit.json','utf8'));
if(screen.status!=='partial_verified'||screen.distinct_trajectories!==6||screen.distinct_checkpoints!==12||!screen.screen_only||screen.adoption)throw new Error('Verified six-trajectory screening audit required');
body += '<h2>Horizon screening — confirmation pending</h2><p>These are measured width64 development-screening results on seeds2161/2162. They select a candidate, not a new incumbent. Each physical trajectory supplies a raw and correlated H200 endpoint; the table uses the preregistered H200 endpoint. All recipes continue on fresh confirmation seeds at widths64/256.</p><table><thead><tr><th>Recipe</th><th>Mean CE</th><th>Mean minus control</th><th>Seed2161 delta</th><th>Seed2162 delta</th></tr></thead><tbody>';
for(const family of ['control3000','long6000_stretched','long6000_fixedtail']){const x=screen.screen_selection.scores[family];body += `<tr><td>${family}</td><td>${x.mean_ce.toFixed(6)}</td><td>${x.mean_delta.toFixed(6)}</td><td>${x.paired_seed_deltas['2161'].toFixed(6)}</td><td>${x.paired_seed_deltas['2162'].toFixed(6)}</td></tr>`;}
body += '</tbody></table><p>The frozen candidate is the stretched 6,000-update recipe. Its average screening improvement is0.044254nats/token, with both seeds improving. This is not equal compute, a holdout result, a convergence claim, or evidence of the optimal training horizon. <a href="file://'+evidenceRoot+'/research_state/horizon-validation/screen-audit.json">Read the screening checkpoint audit and frozen choice</a>.</p>';
"""
s=s.replace(needle,insert+needle)
out=p/'render-screen-guide.mjs';assert not out.exists();out.write_text(s)
