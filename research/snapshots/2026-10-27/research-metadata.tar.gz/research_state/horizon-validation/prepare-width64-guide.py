from pathlib import Path
folder=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state/horizon-validation')
s=(folder/'render-screen-guide.mjs').read_text()
s=s.replace('The six width-64 screening trajectories have passed independent checkpoint review. The stretched 6,000-update candidate is frozen for confirmation; no incumbent change is made from screening. See the screening table below.', 'The six screening and nine width-64 confirmation trajectories have passed independent checkpoint review. The stretched 6,000-update candidate improves all three fresh width-64 seeds. Width-256 confirmation remains required before adoption. See both tables below.')
s=s.replace('Horizon screening — confirmation pending','Horizon screening — historical frozen choice')
needle='const html=`'
insert="""const partial=JSON.parse(fs.readFileSync(evidenceRoot+'/research_state/horizon-validation/width64-confirmation-review.json','utf8'));
if(partial.status!=='partial_width64_verified'||partial.physical_confirmation_trajectories!==9||partial.adoption)throw new Error('Audited width64 confirmation required');
body += '<h2>Fresh width-64 confirmation — width 256 pending</h2><p>Seeds 2171, 2172 and 2173 are separate from screening. The table uses final H200 full-validation CE. Raw endpoints remain separate diagnostics in the audit. No larger-width result is used to revise the frozen candidate.</p><table><thead><tr><th>Recipe</th><th>Mean CE</th><th>Mean minus control</th></tr></thead><tbody>';
for(const f of ['control3000','long6000_stretched','long6000_fixedtail']){const x=partial.means[f].primary;body += `<tr><td>${f}</td><td>${x.toFixed(6)}</td><td>${(x-partial.means.control3000.primary).toFixed(6)}</td></tr>`;}
const chosen=partial.comparisons.find(x=>x.candidate===partial.frozen_winner&&x.reference==='control3000');
body += `</tbody></table><p>The stretched candidate improves all three seeds, with mean delta ${chosen.primary[0].mean_delta.toFixed(6)}. Its 4,096-token conditional text interval is [${chosen.primary[1].conditional_text_bootstrap_95pct.map(x=>x.toFixed(6)).join(', ')}]; all three registered block-size upper bounds are negative. These are conditional text intervals, not seed-population confidence or holdout results. The incumbent remains unchanged until width-256 confirmation and the final audit pass. <a href="file://${evidenceRoot}/research_state/horizon-validation/width64-confirmation-review.json">Read the checkpoint and independently reconstructed comparison audit</a>.</p>`;
"""
assert needle in s
s=s.replace(needle,insert+needle)
out=folder/'render-width64-guide.mjs';assert not out.exists();out.write_text(s)
