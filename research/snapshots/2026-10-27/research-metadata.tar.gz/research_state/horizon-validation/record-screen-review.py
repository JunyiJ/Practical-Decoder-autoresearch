import datetime,json,shutil,statistics
from pathlib import Path
from src.research.protocol import digest,file_digest
from src.research.team.knowledge import KnowledgeBank
root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=root/'research_runs/horizon-quality-001';folder=root/'research_state/horizon-validation'
a=json.loads((folder/'partial-audit.json').read_text());assert a['distinct_trajectories']==6 and a['distinct_checkpoints']==12 and a['status']=='partial_verified'
s=json.loads((run/'selection.json').read_text());state=json.loads((run/'state.json').read_text());rows=state['records'][:6]
assert all(r['stage']=='local' and r['status']=='completed' for r in rows) and digest(rows)==s['local_evidence_sha256']
assert [r['trial_id'] for r in rows]==[r['trial_id'] for r in a['checkpoint_audit']]
refs={r['seed']:r for r in rows if r['family']=='control3000'}
def ce(r):return r['averaged_outputs']['200']['coverage']['evaluations']['128']['mean_ce']
for f,score in s['scores'].items():
 panel=[r for r in rows if r['family']==f];ds={str(r['seed']):ce(r)-ce(refs[r['seed']]) for r in panel}
 assert score['paired_seed_deltas']==ds and score['mean_delta']==statistics.mean(ds.values()) and score['mean_ce']==statistics.mean(map(ce,panel))
 assert score['eligible']==(f!='control3000' and statistics.mean(ds.values())<-.005 and max(ds.values())<0)
assert s['winner']==min((f for f in s['scores'] if s['scores'][f]['eligible']),key=lambda f:(s['scores'][f]['mean_ce'],f))
out=folder/'screen-audit.json';assert not out.exists()
a.update(screen_selection=s,screen_only=True,adoption=False,limitations=['Six width64 screening trajectories only; confirmation still running. More tokens, updates, compute and cumulative decay; no equal-compute or optimal-horizon claim.'])
out.write_text(json.dumps(a,indent=2)+'\n');out.chmod(0o444)
summary='Six audited width64 horizon screens: H200 CE control3000=1.525327256, long6000 stretched cooldown=1.481072913, fixed-tail=1.488656997. Stretched improves both seeds by -.041536374/-.046972312, mean -.044254343; fixed-tail mean -.036670258, both improve. Frozen stretched candidate advances; all three arms continue fresh64/256 confirmation. No adoption from screening.'
k=KnowledgeBank(root/'research_state/knowledge').add(dict(kind='evaluation',outcome='supported',created_by='continuing-quality-research',title='Horizon screening selects stretched 6000-update recipe for confirmation',summary=summary,scope=dict(stage='screening_only',physical_trajectories=6,correlated_outputs=12,holdout_consumed=False,adoption=False),artifacts=[dict(path=str(out),sha256=file_digest(out)),dict(path=str(run/'selection.json'),sha256=file_digest(run/'selection.json'))],related_ids=['kb_7fb494ea2ba64745dec7fcefed50b90c42f4016ff7f193a368f79775977eb9f5'],details=dict(selection=s)))
(folder/'screen-knowledge.json').write_text(json.dumps(dict(knowledge_id=k,review=str(out)),indent=2)+'\n')
for name in ['research-monitor.json','quality-evolution-progress.json']:
 p=root/'research_state'/name;v=json.loads(p.read_text());v.update(horizon_screen_review=str(out),horizon_screen_result_id=k,horizon_screen_notified=True,horizon_frozen_winner=s['winner']);p.write_text(json.dumps(v,indent=2)+'\n')
print(k)
