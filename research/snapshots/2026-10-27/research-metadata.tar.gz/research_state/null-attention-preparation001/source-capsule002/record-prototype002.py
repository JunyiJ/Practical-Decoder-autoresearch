import ast,datetime,difflib,hashlib,importlib.util,json,shutil,subprocess,tarfile
from pathlib import Path
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');D=Path('/private/tmp/rsi-null-attention-development001');P=B/'research_state/null-attention-preparation001';C=P/'source-capsule002'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();commit='37c3150d946c1d4884e88d48021b36801d626465'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p
 p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2,allow_nan=False)+'\n');p.chmod(0o444)
assert not C.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==commit
for root in (B,S):assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
a=json.loads((B/'research_state/active-campaign.json').read_text());assert a['status']=='running' and a['kind']=='logit_z' and a['source_commit']==commit
prior=json.loads((P/'prototype-review001.json').read_text())
for x in prior['files']:assert sha(D/x['path'])==x['sha256']
files=[x['path'] for x in prior['files']]+['tests/test_null_attention_geometry.py','tests/test_null_attention_training.py']
counts={}
for name in files:
 if not name.endswith('.py'):continue
 tree=ast.parse((D/name).read_text())
 if name in files[-2:]:
  n=0
  for f in tree.body:
   if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
    count=1
    for dec in f.decorator_list:
     if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.func.attr=='parametrize':count*=len(ast.literal_eval(dec.args[1]))
    n+=count
  counts[name]=n
assert list(counts.values())==[16,12]
patch=''
for f in files:
 old=(S/f).read_text() if (S/f).exists() else ''
 patch+=''.join(difflib.unified_diff(old.splitlines(True),(D/f).read_text().splitlines(True),fromfile='a/'+f if old else '/dev/null',tofile='b/'+f))
C.mkdir();write(C/'prototype002.patch',patch)
check=subprocess.run(['git','apply','--check',str(C/'prototype002.patch')],cwd=S,text=True,capture_output=True);write(C/'unapplied-check.log',check.stdout+check.stderr);assert check.returncode==0
for f in files:
 p=C/'files'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/f,p);p.chmod(0o444)
with tarfile.open(C/'prototype002.tar.gz','w:gz') as tar:
 for f in files:tar.add(C/'files'/f,arcname=f,recursive=False)
(C/'prototype002.tar.gz').chmod(0o444)
shutil.copyfile('/private/tmp/write-null-actual-tests001.py',C/'write-null-actual-tests001.py');(C/'write-null-actual-tests001.py').chmod(0o444)
pre=C/'pre-execution-review-drafts001';pre.mkdir()
shutil.copyfile('/private/tmp/null-actual-test-pre-review001/test_null_attention_geometry.py',pre/'test_null_attention_geometry.py');(pre/'test_null_attention_geometry.py').chmod(0o444)
review=dict(status='separate_actual_tests_written_ast_review_only',created_at=now,base_commit=commit,development=str(D),source_integrated=False,research_registered=False,files=[dict(path=f,sha256=sha(D/f),base_sha256=sha(S/f) if (S/f).exists() else None) for f in files],changed_production_mapping_sha256=prior['changed_production_mapping_sha256'],mapping_is_not_full_engine_digest=True,previous_seven_files_unchanged=True,previous_117_metadata_tests_not_repeated=True,python_files_ast_parsed=8,actual_tests=dict(ast_counted=28,files=counts,pytest_collected=False,imported=False,executed=False),manual_review=['Independent exp/sum complete model reference includes null zero in stabilization maximum; prefix mass counts actual visibility. Production normalization is not the oracle.','All parameter gradients including nonzero projection/output bias, shared tables, learned gains and inherited nonzero logit objective; independent analytic parameter counts, same initialization/RNG/optimizer groups, exact standard historical graph.','Three inherited objective/position/value/gain/activation routes distributed across widths64/256, both topologies and three table policies; not the complete Cartesian inheritance product.','Primitive masked/extreme +/-10000/common shift/zero-score control and independent score/value VJPs; nonzero cache origins4/120. Output bias remains after zero-valued attention.','Attached first-layer V gradient independently equals sum of four roles under penalized objective for all three null families.','Full/token/uneven/reset/interleaved cache, nonzero uncached120 origin, causal future-token invariance and independently reconstructed real K/V only; no null cache slot.','Eight-update actual trainer/resume1/4/6, optimizer slot/rate/decay, train/resetval/untouchedtest RNG, passiveH200 and derived shadow/loading/pureCE evaluator veto tests are written but unexecuted.','Standard historical trajectory comparison retains inherited objective; null kind/policy/current/saved/constructed/deletion/all-four-layer guards.','Pre-execution review corrected copied historical forward to opt into inherited nonzero objective, unpacked direct MHA tuple and supplied RoPE frequencies, cleared oracle gradients, and added analytical counts. Original generated geometry draft preserved; no actual test failure or successful test rerun.'],artifacts=[art(C/'prototype002.patch'),art(C/'prototype002.tar.gz'),art(C/'unapplied-check.log'),art(P/'prototype-review001.json'),art(pre/'test_null_attention_geometry.py')],pending=['Controller/final-only logit predecessor/independent report auditor remain unimplemented.','All28 actual cases uncollected/unexecuted; no fullCPU count or wall budget assigned.','Pilot/prerequisite/resource/completion/registration/reporting packages still required.','All inheritance awaits FINAL current logit review; no integration/model work before that boundary.'],active_source_unchanged=True,primary_human_untouched=True,execution_failures_this_preparation=[])
write(P/'prototype-review002.json',review)
spec=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);bank=m.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Separate null-attention deferred full-graph and trainer tests',summary='Nine-file prototype now includes 28 AST-counted actual CPU cases written and manually reviewed only. No imports, collection, model execution or MPS. Five production files and prior117 metadata checks unchanged; no rerun. Complete independent null/prefix graph, cache, optimizer/RNG/resume/H200/pureCE assertions await final predecessor audit and actual gates.',outcome='untried',created_by='continuing-quality-research',related_ids=['kb_373e4183ce34e91002fa2927716da72f6cf9265ebf8effd4fcd9b14e6b3ad691'],artifacts=[art(P/'prototype-review002.json')]+review['artifacts'],details=review))
write(P/'prototype-knowledge002.json',dict(id=kid,created_at=now));write(P/'full-knowledge-snapshot003.md',bank.export_markdown())
before=P/'prototype-metadata-before002';before.mkdir()
for name in ['quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;original=p.read_bytes();(before/name).write_bytes(original);(before/name).chmod(0o444);x=json.loads(original)
 x.setdefault('metadata_history',[]).append(dict(recorded_at=now,reason='Separate null actual test preparation only; source/training unchanged',previous_next_preparation=x.get('next_preparation'),before=art(before/name)))
 x['next_preparation']=dict(stage='null_attention',status='separate_actual_tests_written_ast_review_only',path=str(P),development=str(D),review=str(P/'prototype-review002.json'),knowledge_id=kid,changed_production_mapping_sha256=prior['changed_production_mapping_sha256'],metadata_unique_passed=117,actual_cases_ast_counted=28,actual_cases_collected=False,model_tests_executed=False,source_integrated=False,research_registered=False,inheritance_pending_final_logit_z=True)
 tmp=p.with_suffix('.tmp-null-prototype002');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
shutil.copyfile(__file__,C/'record-prototype002.py');(C/'record-prototype002.py').chmod(0o444)
for root in (B,S):assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
print(json.dumps(dict(status='prototype002_recorded',knowledge_id=kid,snapshot=art(P/'full-knowledge-snapshot003.md'),actual_ast_count=28,actual_executed=False)))
