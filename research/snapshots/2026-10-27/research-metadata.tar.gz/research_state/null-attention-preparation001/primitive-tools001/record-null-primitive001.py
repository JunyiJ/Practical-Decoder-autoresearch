from pathlib import Path
import ast,json,hashlib,datetime,shutil,subprocess,importlib.util
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';C=P/'primitive-tools001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2)+'\n');p.chmod(0o444)
i=json.loads((P/'integration-review.json').read_text())
for row in i['files']:assert sha(S/row['path'])==row['sha256']
paths=sorted((S/'src').rglob('*.py'))+[S/'requirements.txt'];assert not any(p.is_symlink() for p in paths)
source=hashlib.sha256(json.dumps({str(p.relative_to(S)):sha(p) for p in paths},sort_keys=True,allow_nan=False).encode()).hexdigest();assert source==i['source_sha256']
assert subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='63d397017a5a692ded7847a61c7768871c72ee71'
m=json.loads((P/'cpu-execution-manifest.json').read_text());assert m['status']=='running'
ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True);pids={int(x.split()[0]):x for x in ps.splitlines()[1:] if x.strip()}
assert m['pid'] in pids and m['active_pid'] in pids and int(pids[m['active_pid']].split()[1])==m['pid']
actual=[x for x in ps.splitlines() if ' -u -c import torch;torch.set_num_threads(1);import pytest' in x];assert len(actual)==1
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
obs=dict(at=now,status=m['status'],driver_pid=m['pid'],worker_pid=m['active_pid'],processes=[pids[m['pid']],pids[m['active_pid']]],closed_batches=len(m['batches']),completed_ids=sum(len(b['expected_ids']) for b in m['batches']),free_gib=shutil.disk_usage('/private/tmp').free/2**30,all15_integration_hashes_unchanged=True,source_sha256=source,primary_clean=True,full_regression_passed=False,actual_subset_passed=28)
write(P/'primitive-preparation-live-observation001.json',obs)
log=(C/'tests-first.log').read_text();assert log.count(' ... ok')==3 and 'Ran 3 tests in 0.646s' in log and log.rstrip().endswith('OK')
for name in ('primitive-capture.py','primitive-audit.py','test_primitive.py'):ast.parse((C/name).read_text())
# Prospectively bind tolerances to the already-passed actual CPU tests.
cpu=(S/'tests/test_null_attention_geometry.py').read_text()
for fragment in ['probability.double(),expected,atol=1e-6,rtol=2e-5','ds.double(),expected_ds,atol=2e-6,rtol=3e-4','dv.double(),expected_dv,atol=2e-6,rtol=2e-5','p.double(),expected,atol=1e-7,rtol=1e-6']:assert fragment in cpu
shutil.copyfile('/private/tmp/record-null-primitive001.py',C/'record-null-primitive001.py')
review=dict(status='prepared_numpy_ast_verified_actual_mps_unexecuted',at=now,source_sha256=source,unique_methods_passed=3,first_execution_passed=True,seconds=.646,synthetic_payload_rows=45,finite_difference_coordinates=36,corruption_rejections=62,actual_capture_executed=False,checks=['Independent per-query FP64 exp/sum versus vectorized reference; three normalization kinds, origins0/4/120,ordinary/+3/+10000/-10000/zero scores.','Score/value VJP finite differences, exact masked zeros, actual visible-count prefix factor, fixed zero null joint stabilization, common-real-shift behavior.','Deterministic original FP32 inputs/values/upstream, 12 invalid-input refusals, historical-standard exact equality plus opaque visibility sentinel; CPU/MPS RNG checks deferred.','Frozen probability1e-6/2e-5, score gradient2e-6/3e-4, value gradient2e-6/2e-5 and zero-score1e-7/1e-6 match passed CPU assertions; weighted output1e-4/2e-5 matches existing full-model MPS tolerance.','Capture function AST/manual-reviewed only; no Torch imports/production primitive/model/MPS/corpus scoring executed.'],failures=[],limitations=['Synthetic primitive package is not actual MPS, checkpoint/full-model/training/quality evidence.','FullCPU5973, six actual serial MPS pilots with complete graph/cache/objective/optimizer/RNG/H200/resource audit, clean publication and unique preregistration still required.','Float64 refusal CPU-only; unsupported MPS float64 not claimed exercised.'],cpu_tolerance_source=art(S/'tests/test_null_attention_geometry.py'),artifacts=[art(p) for p in sorted(C.iterdir()) if p.is_file()])
write(C/'review.json',review)
sp=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);bank=mod.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Null-attention primitive MPS capture and independent gradient audit prepared',summary='Three NumPy/AST methods passed first try:45 synthetic rows,36 gradient finite-difference coordinates and62 corruption rejections. Prospective MPS tolerances match passed CPU primitive checks. Actual capture and MPS remain unexecuted.',outcome='supported',created_by='continuing-quality-research',related_ids=['kb_73b48a2d7ebe0d8bc90da6ecd217c137b4d79544116d3aa1507ff870327c2867','kb_8c8ebfebab5fa0492a45bf2f71906674f1cab4e91bb309745495dab0a9275c3c','kb_99dc3be84bdb5ceb62d6fd62afbe743726c4b1f34e6f207084924fae9a17fc5d'],artifacts=[art(C/'review.json'),art(P/'primitive-preparation-live-observation001.json')]+review['artifacts'],details=review))
write(C/'knowledge.json',dict(id=kid));write(P/'primitive-knowledge-snapshot001.md',bank.export_markdown())
before=P/'primitive-state-before001';before.mkdir()
for name in ['quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;write(before/name,p.read_text());x=json.loads(p.read_text());x.setdefault('metadata_history',[]).append(dict(at=now,reason='Null primitive MPS evidence capture prepared while serial CPU continues',before=art(before/name)))
 n=x['next_preparation'];n.update(primitive_tools=str(C),primitive_tools_review=str(C/'review.json'),primitive_tools_knowledge_id=kid,primitive_tools_prepared=True,actual_primitive_capture_executed=False,full_regression_passed=False)
 n['pending']=['Finish serial5973 CPU/exact new recorder without repeated passing cases','Prepare linkedgraph/pilot/reviewer/resource helpers; actual6serialMPS only afterfullCPU/cleanpublication/no livework','Prepare screening/finalaudit/registration/completionreport helpers;fresh fullbank/seeds/uniqueprereg']
 x['latest_null_cpu_observation']=obs
 tmp=p.with_suffix('.tmp-null-primitive');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
for p in C.iterdir():
 if p.is_file():p.chmod(0o444)
print(json.dumps(dict(knowledge_id=kid,observation=obs,review=str(C/'review.json'))))
