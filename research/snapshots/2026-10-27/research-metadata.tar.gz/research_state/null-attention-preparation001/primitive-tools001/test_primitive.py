import ast,copy,importlib.util,sys,unittest
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('audit',P/'primitive-audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def vector(z,v,g,m,k):
 score=np.where(m,z.astype(float),-np.inf)
 if k=='null_zero':score=np.concatenate([score,np.zeros((*score.shape[:-1],1))],axis=-1)
 e=np.exp(score-score.max(-1,keepdims=True));q=e/e.sum(-1,keepdims=True)
 if k=='null_zero':q=q[...,:-1]
 if k=='prefix_control':q=q*(m.sum(-1,keepdims=True)/(m.sum(-1,keepdims=True)+1))
 y=q@v.astype(float);dp=g.astype(float)@v.astype(float).swapaxes(-1,-2)
 center=np.sum(dp*q,axis=-1,keepdims=True)
 if k=='prefix_control':center=center/(m.sum(-1,keepdims=True)/(m.sum(-1,keepdims=True)+1))
 return q,y,q*(dp-center),q.swapaxes(-1,-2)@g.astype(float)
def payload():
 rows=[]
 for s,l in ((0,3),(4,2),(120,3)):
  for c in a.CASES:
   z,v,g,m=a.inputs(s,l,c)
   for k in a.KINDS:
    p,y,ds,dv=vector(z,v,g,m,k)
    rows.append(dict(start=s,length=l,case=c,kind=k,scores=z.copy(),values=v.copy(),upstream=g.copy(),visible=m.copy(),probabilities=p.astype('float32'),outputs=y.astype('float32'),score_gradient=ds.astype('float32'),value_gradient=dv.astype('float32'),standard_exact=True if k=='standard' else None))
 return dict(schema='null_attention_primitive_v1',device='mps',dtype='float32',convention=a.CONVENTION,rows=rows,refusals=[k+':'+x for k in a.KINDS[1:] for x in ('float16','mask_dtype','mask_shape','no_visible','score_rank')]+["kind:'unknown'",'kind:False'],cpu_rng_unchanged=True,mps_rng_unchanged=True,float64_refusal='CPU-only; MPS unsupported dtype not exercised')
class Tests(unittest.TestCase):
 def test_all_rows_and_coordinate_vjp(self):
  self.assertEqual(a.verify(payload())['rows'],45)
  z=np.array([[[[-.7,.2,.8],[.4,-.3,.1]]]],dtype=float);v=np.array([[[[.2,-.4],[.7,.5],[-.1,.3]]]]);g=np.array([[[[.6,-.2],[-.3,.8]]]]);m=np.array([[True,True,False],[True,True,True]])
  checks=0
  for k in a.KINDS:
   p,y,ds,dv=a.reference(z,v,g,m,k)
   for base,grad,which in ((z,ds,'z'),(v,dv,'v')):
    for ix in np.ndindex(base.shape):
     plus=base.copy();minus=base.copy();plus[ix]+=1e-5;minus[ix]-=1e-5
     if which=='z':yp=vector(plus,v,g,m,k)[1];ym=vector(minus,v,g,m,k)[1]
     else:yp=vector(z,plus,g,m,k)[1];ym=vector(z,minus,g,m,k)[1]
     self.assertAlmostEqual(float(((yp-ym)*g).sum()/2e-5),float(grad[ix]),places=8);checks+=1
  self.assertEqual(checks,36)
 def test_corruption_rejections(self):
  p=payload();mutations=[]
  for name,value in [('schema','x'),('device','cpu'),('dtype','float16'),('convention','x'),('cpu_rng_unchanged',False),('mps_rng_unchanged',False),('float64_refusal','tested')]:mutations.append(lambda q,n=name,v=value:q.__setitem__(n,v))
  mutations.extend([lambda q:q['rows'].pop(),lambda q:q['rows'].reverse(),lambda q:q['refusals'].pop()])
  for ri in (0,1,2,42,43,44):
   for field in ('scores','values','upstream','probabilities','outputs','score_gradient','value_gradient'):
    def mutate(q,i=ri,f=field):q['rows'][i][f].flat[0]+=.1
    mutations.append(mutate)
   mutations.append(lambda q,i=ri:q['rows'][i].__setitem__('standard_exact',False))
  mutations.append(lambda q:q['rows'][0]['visible'].__setitem__((0,0),False))
  mutations.append(lambda q:q['rows'][0].__setitem__('start',1))
  mutations.append(lambda q:q['rows'][0]['probabilities'].__setitem__((0,0,0,2),.1))
  mutations.append(lambda q:q['rows'][0]['score_gradient'].__setitem__((0,0,0,2),.1))
  for mutate in mutations:
   q=copy.deepcopy(p);mutate(q)
   with self.assertRaises(AssertionError):a.verify(q)
  self.assertEqual(len(mutations),62)
 def test_shift_zero_counts_and_deferred_capture(self):
  p=payload();a.verify(p)
  for s,l in ((0,3),(4,2),(120,3)):
   for k in a.KINDS:
    rows={r['case']:r for r in p['rows'] if r['start']==s and r['kind']==k}
    x=rows['ordinary']['probabilities'];y=rows['shift3']['probabilities']
    if k=='null_zero':self.assertTrue(np.all(y.sum(-1)>x.sum(-1)))
    else:self.assertTrue(np.allclose(x,y,atol=1e-7,rtol=2e-6))
    if k!='standard':self.assertTrue(np.allclose(rows['zero']['probabilities'].sum(-1),np.arange(s+1,s+l+1)/(np.arange(s+1,s+l+1)+1),atol=1e-7,rtol=1e-6))
  t=ast.parse((P/'primitive-capture.py').read_text())
  self.assertFalse(any(isinstance(n,ast.Import) and any(x.name=='torch' for x in n.names) for n in t.body))
  f=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='capture')
  self.assertTrue(any(isinstance(n,ast.ImportFrom) and n.module=='src.models.null_attention' for n in ast.walk(f)))
  text=(P/'primitive-capture.py').read_text()
  for x in ['torch.mps.get_rng_state()','masked_fill(~mask',"('ordinary','shift3','positive_extreme','negative_extreme','zero')",'normalize_attention(masked,object(),kind)','torch.autograd.grad'] :self.assertIn(x,text)
  self.assertNotIn('torch',sys.modules)
if __name__=='__main__':unittest.main(verbosity=2)
