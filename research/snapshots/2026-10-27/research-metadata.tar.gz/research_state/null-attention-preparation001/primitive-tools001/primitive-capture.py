"""Deferred actual MPS primitive evidence; caller supplies bounded watchdog."""
import numpy as np
KINDS=('standard','prefix_control','null_zero')
def capture():
 import torch
 from src.models.null_attention import normalize_attention,CONVENTION
 assert torch.backends.mps.is_available()
 device=torch.device('mps');cpu=torch.get_rng_state().clone();mps=torch.mps.get_rng_state().clone()
 rows=[]
 for start,length in ((0,3),(4,2),(120,3)):
  keys=start+length
  mask=torch.arange(keys,device=device)[None,:]<=torch.arange(start,start+length,device=device)[:,None]
  for case in ('ordinary','shift3','positive_extreme','negative_extreme','zero'):
   # NumPy creates deterministic FP32 inputs, without backend-dependent linspace.
   z=np.linspace(-2.,3.,4*length*keys,dtype=np.float32).reshape(2,2,length,keys)
   if case=='zero':z.fill(0)
   else:z+=np.float32(dict(ordinary=0,shift3=3,positive_extreme=10000,negative_extreme=-10000)[case])
   vv=np.linspace(-1.,2.,4*keys*5,dtype=np.float32).reshape(2,2,keys,5)
   gg=np.linspace(-.3,.7,4*length*5,dtype=np.float32).reshape(2,2,length,5)
   for kind in KINDS:
    raw=torch.tensor(z,device=device,requires_grad=True);values=torch.tensor(vv,device=device,requires_grad=True)
    masked=raw.masked_fill(~mask,float('-inf'));p=normalize_attention(masked,mask,kind);out=p@values
    ds,dv=torch.autograd.grad((out*torch.tensor(gg,device=device)).sum(),(raw,values))
    exact=None
    if kind=='standard':
     exact=bool(torch.equal(p,torch.softmax(masked,-1)))
     assert exact and torch.equal(normalize_attention(masked,object(),kind),p)
    def a(t):return t.detach().cpu().numpy().copy()
    rows.append(dict(kind=kind,case=case,start=start,length=length,scores=z.copy(),values=vv.copy(),upstream=gg.copy(),visible=a(mask),probabilities=a(p),outputs=a(out),score_gradient=a(ds),value_gradient=a(dv),standard_exact=exact))
 refusals=[];s=torch.zeros(1,1,2,3,device=device);v=torch.ones(2,3,dtype=torch.bool,device=device)
 for kind in KINDS[1:]:
  for label,bad,visible in [('float16',s.half(),v),('mask_dtype',s,v.float()),('mask_shape',s,v[:1]),('no_visible',s,torch.zeros_like(v)),('score_rank',s[0],v)]:
   try:normalize_attention(bad,visible,kind)
   except ValueError:refusals.append(kind+':'+label)
   else:raise AssertionError('invalid primitive accepted '+label)
 for kind in ('unknown',False):
  try:normalize_attention(s,v,kind)
  except ValueError:refusals.append('kind:'+repr(kind))
  else:raise AssertionError('invalid kind accepted')
 assert torch.equal(cpu,torch.get_rng_state()) and torch.equal(mps,torch.mps.get_rng_state())
 return dict(schema='null_attention_primitive_v1',device='mps',dtype='float32',convention=CONVENTION,rows=rows,refusals=refusals,cpu_rng_unchanged=True,mps_rng_unchanged=True,float64_refusal='CPU-only; MPS unsupported dtype not exercised')
