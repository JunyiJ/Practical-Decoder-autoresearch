"""Independent NumPy FP64 primitive oracle; never imports model or Torch."""
import numpy as np
KINDS=('standard','prefix_control','null_zero')
CASES=('ordinary','shift3','positive_extreme','negative_extreme','zero')
CONVENTION='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'
def inputs(start,length,case):
 k=start+length;z=np.linspace(-2,3,4*length*k,dtype=np.float32).reshape(2,2,length,k)
 if case=='zero':z.fill(0)
 else:z+=np.float32(dict(ordinary=0,shift3=3,positive_extreme=10000,negative_extreme=-10000)[case])
 return z,np.linspace(-1,2,4*k*5,dtype=np.float32).reshape(2,2,k,5),np.linspace(-.3,.7,4*length*5,dtype=np.float32).reshape(2,2,length,5),np.arange(k)[None,:]<=np.arange(start,start+length)[:,None]
def reference(z,v,g,mask,kind):
 z=np.asarray(z,dtype=np.float64);v=np.asarray(v,dtype=np.float64);g=np.asarray(g,dtype=np.float64)
 p=np.zeros_like(z);y=np.zeros_like(g);ds=np.zeros_like(z);dv=np.zeros_like(v)
 for b in range(z.shape[0]):
  for h in range(z.shape[1]):
   for i in range(z.shape[2]):
    ids=np.flatnonzero(mask[i]);scores=z[b,h,i,ids]
    joint=np.append(scores,0.) if kind=='null_zero' else scores
    weights=np.exp(joint-joint.max());weights/=weights.sum();q=weights[:len(ids)]
    if kind=='prefix_control':q=q*(len(ids)/(len(ids)+1))
    p[b,h,i,ids]=q;y[b,h,i]=q@v[b,h,ids]
    # Differentiate the scalar weighted-value objective independently per key.
    products=v[b,h,ids]@g[b,h,i]
    center=float(q@products)
    if kind=='prefix_control':center/=len(ids)/(len(ids)+1)
    ds[b,h,i,ids]=q*(products-center)
    for j,weight in zip(ids,q):dv[b,h,j]+=weight*g[b,h,i]
 return p,y,ds,dv

def verify(payload):
 assert payload['schema']=='null_attention_primitive_v1' and payload['device']=='mps' and payload['dtype']=='float32'
 assert payload['convention']==CONVENTION
 assert payload['cpu_rng_unchanged'] is True and payload['mps_rng_unchanged'] is True
 assert payload['float64_refusal']=='CPU-only; MPS unsupported dtype not exercised'
 expected=[(s,l,c,k) for s,l in ((0,3),(4,2),(120,3)) for c in CASES for k in KINDS]
 assert len(payload['rows'])==len(expected)==45
 errors={k:0. for k in ('probabilities','outputs','score_gradient','value_gradient')}
 for row,key in zip(payload['rows'],expected):
  s,l,c,k=key;assert (row['start'],row['length'],row['case'],row['kind'])==key
  z,v,g,mask=inputs(s,l,c)
  for name,ref in [('scores',z),('values',v),('upstream',g),('visible',mask)]:
   a=np.asarray(row[name]);assert a.dtype==ref.dtype and a.shape==ref.shape and np.array_equal(a,ref),name
  refs=reference(z,v,g,mask,k)
  for name,ref,atol,rtol in zip(errors,refs,(1e-6,1e-4,2e-6,2e-6),(2e-5,2e-5,3e-4,2e-5)):
   a=np.asarray(row[name]);assert a.dtype==np.float32 and a.shape==ref.shape and np.isfinite(a).all(),name
   assert np.allclose(a,ref,atol=atol,rtol=rtol),(name,float(np.max(np.abs(a-ref))))
   errors[name]=max(errors[name],float(np.max(np.abs(a-ref))))
  assert np.count_nonzero(row['probabilities'][...,~mask])==0
  assert np.count_nonzero(row['score_gradient'][...,~mask])==0
  assert row['standard_exact'] is (True if k=='standard' else None)
  if c=='zero':
   target=mask/(mask.sum(-1,keepdims=True)+(0 if k=='standard' else 1))
   assert np.allclose(row['probabilities'],target,atol=1e-7,rtol=1e-6)
 refusals=[k+':'+x for k in KINDS[1:] for x in ('float16','mask_dtype','mask_shape','no_visible','score_rank')]+["kind:'unknown'",'kind:False']
 assert payload['refusals']==refusals
 return dict(status='verified',rows=45,refusals=12,maximum_errors=errors,probability_tolerance=[1e-6,2e-5],score_gradient_tolerance=[2e-6,3e-4],value_gradient_tolerance=[2e-6,2e-5],output_tolerance=[1e-4,2e-5],scope='Synthetic primitive evidence, not model quality or whole trajectory proof')
