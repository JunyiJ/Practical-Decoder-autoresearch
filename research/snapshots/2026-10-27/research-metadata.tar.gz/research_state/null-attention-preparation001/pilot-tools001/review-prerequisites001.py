"""Audit saved null-attention pilot evidence and forecast bounded resources; no training/scoring."""
import argparse,datetime,json,math,subprocess,re,sys,os
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--pilots',type=Path,required=True)
parser.add_argument('--cpu-review',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd();folder=Path(__file__).resolve().parent
prior=base/'research_runs/logit-z-quality-001'
active=json.loads((base/'research_state/active-campaign.json').read_text())
if Path(active['campaign'])!=prior or active['status']!='completed_reviewed' or json.loads((prior/'state.json').read_text())['status']!='completed':
 raise ValueError('Completed reviewed logit-z predecessor required before CPU checkpoint audit')
sys.path.insert(0,str(folder.parent/'cpu-tools001'))
from bounded_cpu import live_model_commands
live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
if live:raise ValueError('Competing model work: '+str(live))
if args.output.exists() or not args.output.resolve().is_relative_to(base/'research_state'):
 raise ValueError('New review output inside research_state required')
sys.path.insert(0,str(folder))
from preflight import check as publication_preflight
preflight_review=publication_preflight(source,args.cpu_review)
import torch
from omegaconf import OmegaConf
from src.research import null_attention_study as study
from src.research.averaging_eval import validate_derivation
from src.research.protocol import file_digest
from src.research.runner import validate_result
from src.research.team.suite import source_digest,_request
from src.models.gpt import GPT
from src.models.output_bias import POLICY
from src.models.weight_tying import validate_weight_tying_model,POLICY as TYING_POLICY
from src.models.residual_topology import validate_residual_topology_model,POLICY as RESIDUAL_POLICY
from src.models.attention_scale import validate_attention_scale_model,POLICY as SCALE_POLICY
from src.models.gated_activation import validate_gated_activation_model,POLICY as GATE_POLICY
from src.models.residual_gain import validate_residual_gain_model,POLICY as GAIN_POLICY,PARAMETERS as GAIN_PARAMETERS
from src.models.value_residual import validate_value_residual_model,POLICY as VALUE_POLICY
from src.models.position_family import validate_position_family_model,POLICY as POSITION_POLICY,SLOPE_FORMULA
from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION
from src.models.null_attention import validate_null_attention_model, POLICY as NULL_POLICY, CONVENTION as NULL_CONVENTION, STATE_NAMES as NULL_STATE
from src.utils.checkpoint import read_checkpoint,load_model_weights

p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
import importlib.util
prior_spec=importlib.util.spec_from_file_location('independent_output_prior',folder/'prior-audit.py')
prior_audit=importlib.util.module_from_spec(prior_spec);prior_spec.loader.exec_module(prior_audit)
prior_review=prior_audit.verify_prior(Path(p['config']['data']['path']).read_bytes(),p['output_bias_prior'])
assert prior_review['vocabulary_size']==65
assert study.BOOTSTRAP.startswith('from src.research.memory_guard import start_memory_guard\nstart_memory_guard()\n')
attention='mha';lr=.01;short_warmup=0;assert p['recipe']['warmup_steps']==0
cpu_path=args.cpu_review;cpu=json.loads(cpu_path.read_text());pilot_path=args.pilots/'pilots.json';pilot=json.loads(pilot_path.read_text())
tests=cpu['full_tests'];assert cpu['status']=='cpu_verified' and tests['passed']==tests['collected']==5973 and tests['failed']==0
assert cpu['actual_null_attention_training_tests_passed']==12 and cpu['actual_null_attention_geometry_tests_passed']==16 and cpu['null_attention_metadata_tests_passed']==256
assert cpu['source_sha256']==pilot['source_sha256']==source_digest(source)==p['source_sha256']
assert pilot['status']=='verified' and pilot['source_commit']==p['git_commit'] and len(pilot['rows'])==6
assert pilot['excluded_from_research'] is True and pilot['holdout_consumed'] is False
intent=json.loads((args.pilots/'intent.json').read_text())
assert {k:v for k,v in intent['publication_preflight'].items() if k!='published_tip'}=={k:v for k,v in preflight_review.items() if k!='published_tip'}
assert intent['publication_preflight']['published_tip']==intent['published_tip']
assert intent['source_commit']==p['git_commit'] and intent['source_sha256']==p['source_sha256']
subprocess.run(['git','merge-base','--is-ancestor',p['git_commit'],intent['published_tip']],cwd=source,check=True)
assert pilot['disk_mb']<1024
assert intent['cpu_review_sha256']==file_digest(cpu_path) and intent['pilot_driver_sha256']==file_digest(folder/'pilot-driver001.py')
assert intent['predecessor_review']==p['predecessor_review'] and intent['resolved_recipe']==p['recipe']
for path,digest in intent['helper_sha256'].items():assert file_digest(Path(path))==digest
assert intent['seed']==9517 and intent['holdout_consumed'] is False
assert intent['hard_limits']==dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024)
assert {(x['width'],x['family']) for x in pilot['rows']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
graph_folder=folder.parent/'graph-tools001'
graph_spec=importlib.util.spec_from_file_location('null_graph_loader',graph_folder/'load-helpers.py');loader=importlib.util.module_from_spec(graph_spec);graph_spec.loader.exec_module(loader);helpers=loader.load()
artifacts=[folder/'preflight.py',cpu_path,pilot_path,args.pilots/'intent.json',folder/'pilot-driver001.py',folder/'resource-gate.py',folder/'preparation-review001.json',folder/'test_guard_contracts.py',folder/'test_metric_contracts.py',folder.parent/'cpu-tools001/bounded_cpu.py',source/'research/NULL_ATTENTION_PROTOCOL.md',Path(p['predecessor_review']['path']),folder/'pilot-geometry.py',folder/'prior-audit.py',Path(__file__).resolve(),graph_folder/'helper-manifest.json',graph_folder/'load-helpers.py',graph_folder/'review.json',base/'research_state/logit-z-preparation001/objective-math-tools001/review.json',base/'research_state/logit-z-preparation001/objective-eval-tools001/review.json',folder.parent/'attention-math-tools001/review.json',folder.parent/'cache-tools001/review.json',folder.parent/'primitive-tools001/review.json',folder.parent/'resource-tools001/review.json']
artifacts.extend(Path(v['path']) for v in json.loads((graph_folder/'helper-manifest.json').read_text())['helpers'].values())
expected_helpers=[folder/'preflight.py',folder/'resource-gate.py',folder.parent/'cpu-tools001/bounded_cpu.py',graph_folder/'load-helpers.py',graph_folder/'helper-manifest.json']+[Path(v['path']) for v in json.loads((graph_folder/'helper-manifest.json').read_text())['helpers'].values()]
assert intent['helper_sha256']=={str(a.resolve()):file_digest(a) for a in expected_helpers}
for a in cpu['artifacts']:
 assert file_digest(Path(a['path']))==a['sha256'];artifacts.append(Path(a['path']))
# Preserve earlier failed MPS agreement evidence; only unchanged general averaging
# arithmetic is inherited, not a claim about independent trajectory reproducibility.
for rel in ['src/train/weight_averaging.py','src/research/averaging_eval.py','src/utils/checkpoint.py']:
 current=(source/rel).read_bytes()
 if rel=='src/utils/checkpoint.py':
  null_guard=b'    from ..models.null_attention import validate_null_attention_load\n    validate_null_attention_load(model, checkpoint)\n'
  assert current.count(null_guard)==1;current=current.replace(null_guard,b'',1)
  z_guard=b'    from ..models.logit_z import validate_logit_z_load\n    validate_logit_z_load(model, checkpoint)\n'
  assert current.count(z_guard)==1;current=current.replace(z_guard,b'',1)
  position_guard=b'    from ..models.position_family import validate_position_family_load\n    validate_position_family_load(model, checkpoint)\n'
  assert current.count(position_guard)==1;current=current.replace(position_guard,b'',1)
  value_guard=b'    from ..models.value_residual import validate_value_residual_load\n    validate_value_residual_load(model, checkpoint)\n'
  assert current.count(value_guard)==1;current=current.replace(value_guard,b'',1)
  gain_guard=b'    from ..models.residual_gain import validate_residual_gain_load\n    validate_residual_gain_load(model, checkpoint)\n'
  assert current.count(gain_guard)==1;current=current.replace(gain_guard,b'',1)
  gated_guard=b'    from ..models.gated_activation import validate_gated_activation_load\n    validate_gated_activation_load(model, checkpoint)\n'
  assert current.count(gated_guard)==1;current=current.replace(gated_guard,b'',1)
  attention_guard=b'    from ..models.attention_scale import validate_attention_scale_load\n    validate_attention_scale_load(model, checkpoint)\n'
  assert current.count(attention_guard)==1;current=current.replace(attention_guard,b'',1)
  residual_guard=b'    from ..models.residual_topology import validate_residual_topology_load\n    validate_residual_topology_load(model, checkpoint)\n'
  assert current.count(residual_guard)==1;current=current.replace(residual_guard,b'',1)
  tying_guard=b'    from ..models.weight_tying import validate_weight_tying_load\n    validate_weight_tying_load(model, checkpoint)\n'
  assert current.count(tying_guard)==1;current=current.replace(tying_guard,b'',1)
  bias_guard=b'    from ..models.output_bias import validate_output_bias_load\n    validate_output_bias_load(model, checkpoint)\n'
  assert current.count(bias_guard)==1;current=current.replace(bias_guard,b'',1)
  guard=b'    from ..models.embedding_scale import validate_input_scale_load\n    validate_input_scale_load(model, checkpoint)\n'
  assert current.count(guard)==1
  current=current.replace(guard,b'',1)
  readout_guard=b'    from ..models.readout_norm import validate_readout_norm_load\n    validate_readout_norm_load(model, checkpoint)\n'
  assert current.count(readout_guard)==1
  current=current.replace(readout_guard,b'',1)
 assert current==subprocess.check_output(['git','show','280ea428792d4dd31780123d14846d5302d43227:'+rel],cwd=source)
for rel in ['logit-z-preparation001/cpu-watchdog-repair001/recovery-review.json','logit-z-preparation001/cpu-scratch-isolation-repair001/review.json','logit-z-preparation001/cpu-review.json','logit-z-preparation001/prerequisite-metadata-repair001/review.json','logit-z-preparation001/prerequisite-audit-first.log','logit-z-preparation001/pilot-tools001/review-prerequisites001.py','position-quality-preparation001/mps-pilots001/failure.json','position-quality-preparation001/pilot-rope-oracle-repair001/review.json','position-quality-preparation001/pilot-continuation-completion-review002.json','position-quality-preparation001/metadata-bank-path-repair001/review.json','value-residual-preparation001/mps-pilots001/failure.json','value-residual-preparation001/pilot-device-repair001/review.json','value-residual-preparation001/pilot-continuation-completion-review002.json','value-residual-preparation001/registration-schema-repair001/review.json','averaging-pilots-001/failure.json','averaging-mps-diagnostic-001/review.json','averaging-mps-coupled-001/review.json','averaging-validation/review.json']:
 artifacts.append(base/'research_state'/rel)
artifacts.extend([source/'src/train/train.py',source/'src/models/null_attention.py',source/'src/attention/mha.py',source/'src/models/logit_z.py',source/'src/models/embedding_scale.py',source/'src/models/readout_norm.py',source/'src/models/output_bias.py',source/'src/models/weight_tying.py',source/'src/models/residual_topology.py',source/'src/models/attention_scale.py',source/'src/models/gated_activation.py',source/'src/models/residual_gain.py',source/'src/models/value_residual.py',source/'src/models/position_family.py',source/'src/research/memory_guard.py'])
checks=[];checkpoint_paths=set();graph_checks=[];torch.set_num_threads(1)
table_kind=p['recipe']['weight_tying_kind'];topology=p['recipe']['residual_topology_kind'];gain_kind=p['recipe']['residual_gain_kind'];value_kind=p['recipe']['value_residual_kind'];position_kind=p['recipe']['position_family_kind'];objective_kind=p['recipe']['logit_z_kind']
def finite(x):
 if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,(list,tuple)):
  for v in x:finite(v)
 elif isinstance(x,float):assert math.isfinite(x)
for row in pilot['rows']:
 w,f=row['width'],row['family'];bias_kind=p['recipe']['output_bias_kind'];d=args.pilots/f'w{w}_{f}';req=json.loads((d/'request.json').read_text());raw=json.loads((d/'result.json').read_text())
 total,start=40,20
 job=dict(family=f,lr=lr,width=w,n_heads=w//32,seed=9517,stage='local',arm='candidate',trial_id=d.name)
 want=_request(study.suite_spec(p,f,lr),job,d);t=want['config']['training'];t.update(max_iters=total,eval_every=10,eval_iters=2)
 t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
 if short_warmup:t['lr_schedule']['warmup_steps']=short_warmup
 assert row['attention_family']==attention and row['peak_learning_rate']==lr and row['warmup_steps']==t['lr_schedule'].get('warmup_steps',0)
 assert row['input_embedding_scale']==p['recipe']['input_embedding_scale'] and row['input_width_policy']=='mha4_input_scale'
 norm=p['recipe']['readout_norm_kind']
 assert row['output_bias_kind']==bias_kind and row['output_bias_width_policy']==POLICY and row['output_bias_prior_sha256']==p['output_bias_prior']['prior_sha256']
 assert row['readout_norm_kind']==norm and row['readout_norm_width_policy']=='mha4_readout_norm' and row['readout_norm_epsilon']==1e-5
 assert req==want
 for name in ('request','result'):
  a=d/f'{name}.json';assert file_digest(a)==row[name+'_sha256'];artifacts.append(a)
 assert raw['runtime']==dict(torch=p['runtime']['packages']['torch'],cpu_threads=req['cpu_threads'],requested_device='mps')
 checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d);extra=study.adapter(p,raw,checked,req,d)
 assert checked['checkpoint_sha256']==row['checkpoint_sha256']
 cp=read_checkpoint(checked['checkpoint']);finite(cp);assert cp['step']==total
 desired=json.loads(json.dumps(req['config']));desired['model']['vocab_size']=65;assert cp['cfg']==desired
 expected_contract=dict(weight_averaging=t['weight_averaging'],lr_schedule=t['lr_schedule'],batch_layout='paired_blocks512',
     optimizer_contract=dict(optimizer='muon',decay_mode='independent'),model=desired['model'],
     data_sha256=file_digest(Path(desired['data']['path'])),data_split=dict(train_fraction=.8,val_fraction=.1),
     eval_seed=2026,torch_version=p['runtime']['packages']['torch'],device='mps',
     training={key:t[key] for key in ('batch_size','learning_rate','weight_decay','grad_clip','seed','eval_iters')})
 assert cp['training_state']['contract']==expected_contract
 avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
 cfg=OmegaConf.create(cp['cfg']);model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True);names=dict(model.named_parameters())
 # Independently enumerate all named parameter shapes, without deriving them
 # from the model implementation. Strict load separately checks saved buffers.
 import importlib.util
 geometry_spec=importlib.util.spec_from_file_location('output_bias_independent_geometry',folder/'pilot-geometry.py')
 geometry=importlib.util.module_from_spec(geometry_spec);geometry_spec.loader.exec_module(geometry)
 shapes=geometry.parameter_shapes(w,attention,norm,bias_kind,table_kind,gain_kind)
 for i in range(4):
  pre=f'transformer.h.{i}.'
  for suffix in ('freq_cos','freq_sin'):
   assert (pre+suffix in cp['model_state'])==(position_kind=='rope')
   if position_kind=='rope':
    assert cp['model_state'][pre+suffix].shape==(128,16)
    theta=torch.outer(torch.arange(128,dtype=torch.float32),1.0/(10000.**(torch.arange(0,32,2,dtype=torch.float32)/32)))
    expected=theta.cos() if suffix=='freq_cos' else theta.sin()
    torch.testing.assert_close(cp['model_state'][pre+suffix],expected,atol=1e-6,rtol=0)
 assert cfg.model.input_embedding_scale==model.input_embedding_scale==p['recipe']['input_embedding_scale']
 assert cfg.model.input_width_policy=='mha4_input_scale'
 assert cfg.model.readout_norm_kind==norm and cfg.model.readout_norm_width_policy=='mha4_readout_norm' and cfg.model.readout_norm_epsilon==1e-5
 assert model.readout_norm_signature==(norm,1e-5) and model.transformer.ln_f.eps==1e-5
 assert isinstance(model.transformer.ln_f,torch.nn.RMSNorm if norm=='rms' else torch.nn.LayerNorm)
 cfg.model.readout_norm_kind='rms' if norm!='rms' else 'layer_no_bias'
 try: load_model_weights(model,cp)
 except ValueError: pass
 else: raise AssertionError('Wrong final normalization checkpoint accepted')
 cfg.model.readout_norm_kind=norm
 cfg.model.input_embedding_scale=.5 if p['recipe']['input_embedding_scale']==1. else 1.
 try: load_model_weights(model,cp)
 except ValueError: pass
 else: raise AssertionError('Wrong input-scale checkpoint accepted')
 cfg.model.input_embedding_scale=p['recipe']['input_embedding_scale']
 assert cfg.model.output_bias_kind==bias_kind and cfg.model.output_bias_width_policy==POLICY
 assert desired['model']['output_bias_prior']==p['output_bias_prior']
 assert model.output_bias_signature==(bias_kind,POLICY,p['output_bias_prior']['prior_sha256'])
 cfg.model.output_bias_kind='learned_zero' if bias_kind!='learned_zero' else 'learned_train_unigram'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed output-bias semantics accepted')
 cfg.model.output_bias_kind=bias_kind
 validate_weight_tying_model(model)
 assert model.weight_tying_signature==(table_kind,TYING_POLICY,64)
 assert cfg.model.weight_tying_kind==row['weight_tying_kind']==table_kind
 assert cfg.model.weight_tying_width_policy==row['weight_tying_width_policy']==TYING_POLICY
 assert ('lm_head.weight' in names)==(table_kind!='scaled_tied')
 assert len(list(model.named_parameters(remove_duplicate=False)))==len(names)
 cfg.model.weight_tying_kind='matched_untied' if table_kind!='matched_untied' else 'scaled_tied'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed table-sharing semantics accepted')
 cfg.model.weight_tying_kind=table_kind
 validate_residual_topology_model(model)
 assert model.residual_topology_signature==(topology,RESIDUAL_POLICY)
 assert row['residual_topology_kind']==topology and row['residual_topology_width_policy']==RESIDUAL_POLICY
 assert all(b.ln1 is not b.ln2 and b.residual_topology_kind==topology for b in model.transformer.h)
 cfg.model.residual_topology_kind='serial' if topology!='serial' else 'parallel_separate_norms'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped residual topology accepted')
 cfg.model.residual_topology_kind=topology
 validate_attention_scale_model(model)
 assert model.attention_scale_signature==(p['recipe']['attention_logit_scale'],SCALE_POLICY)
 assert row['attention_logit_scale']==p['recipe']['attention_logit_scale'] and row['attention_logit_scale_width_policy']==SCALE_POLICY
 assert all(b.attn.attention_logit_scale==p['recipe']['attention_logit_scale'] for b in model.transformer.h)
 cfg.model.attention_logit_scale=.5 if p['recipe']['attention_logit_scale']!=.5 else 2.
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped attention scale accepted')
 cfg.model.attention_logit_scale=p['recipe']['attention_logit_scale']
 validate_gated_activation_model(model)
 assert model.gated_activation_signature==(p['recipe']['gated_activation_kind'],GATE_POLICY)
 assert cfg.model.gated_activation_kind==row['gated_activation_kind']==p['recipe']['gated_activation_kind']
 assert cfg.model.gated_activation_width_policy==row['gated_activation_width_policy']==GATE_POLICY
 assert all(b.mlp.gate_activation==p['recipe']['gated_activation_kind'] for b in model.transformer.h)
 cfg.model.gated_activation_kind='relu' if p['recipe']['gated_activation_kind']!='relu' else 'silu'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped gated activation accepted')
 cfg.model.gated_activation_kind=p['recipe']['gated_activation_kind']
 validate_residual_gain_model(model)
 assert model.residual_gain_signature==(gain_kind,GAIN_POLICY)
 assert cfg.model.residual_gain_kind==row['residual_gain_kind']==gain_kind
 assert cfg.model.residual_gain_width_policy==row['residual_gain_width_policy']==GAIN_POLICY
 assert all(b.residual_gain_kind==gain_kind for b in model.transformer.h)
 gain_names={f'transformer.h.{i}.{n}' for i in range(4) for n in GAIN_PARAMETERS}
 present={n for n in names if n.endswith(tuple('.'+g for g in GAIN_PARAMETERS))}
 assert present==(gain_names if gain_kind=='learned_tenth' else set())
 assert all(names[n].shape==(w,) for n in present)
 cfg.model.residual_gain_kind='unit' if gain_kind!='unit' else 'static_tenth'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed residual gain checkpoint semantics accepted')
 cfg.model.residual_gain_kind=gain_kind
 validate_value_residual_model(model)
 assert model.value_residual_signature==(value_kind,VALUE_POLICY)
 assert cfg.model.value_residual_kind==row['value_residual_kind']==value_kind
 assert cfg.model.value_residual_width_policy==row['value_residual_width_policy']==VALUE_POLICY
 assert all(b.attn.value_residual_kind==value_kind and b.attn.value_residual_layer==i for i,b in enumerate(model.transformer.h))
 cfg.model.value_residual_kind='local' if value_kind!='local' else 'first_blend'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed value-reuse checkpoint semantics accepted')
 cfg.model.value_residual_kind=value_kind
 validate_position_family_model(model)
 assert model.position_family_signature==(position_kind,POSITION_POLICY,SLOPE_FORMULA,w//32)
 assert cfg.model.position_family_kind==row['position_family_kind']==position_kind
 assert cfg.model.position_family_width_policy==row['position_family_width_policy']==POSITION_POLICY
 slopes=tuple(2.**(-8.*(h+1)/(w//32)) for h in range(w//32)) if position_kind=='alibi' else ()
 assert row['position_slopes']==list(slopes) and row['position_frequency_buffers']==(8 if position_kind=='rope' else 0)
 assert all(b.attn.position_family_kind==position_kind and b.attn.position_slopes==slopes for b in model.transformer.h)
 cfg.model.position_family_kind='nope' if position_kind!='nope' else 'alibi'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped position family accepted')
 cfg.model.position_family_kind=position_kind
 del cfg.model.position_family_width_policy
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Deleted position family policy accepted')
 cfg.model.position_family_width_policy=POSITION_POLICY
 if position_kind=='alibi':
  original_slopes=model.transformer.h[0].attn.position_slopes
  model.transformer.h[0].attn.position_slopes=tuple(x*2 for x in original_slopes)
  try:load_model_weights(model,cp)
  except ValueError:pass
  else:raise AssertionError('Changed constructed slopes accepted')
  model.transformer.h[0].attn.position_slopes=original_slopes
 validate_position_family_model(model)
 validate_logit_z_model(model)
 assert model.logit_z_signature==(objective_kind,COEFFICIENTS[objective_kind],Z_POLICY,CONVENTION)
 assert row['logit_z_kind']==objective_kind and type(row['logit_z_coefficient']) is float and row['logit_z_coefficient']==COEFFICIENTS[objective_kind]
 assert row['logit_z_objective_policy']==Z_POLICY and row['logit_z_convention']==CONVENTION and row['validation_objective']=='pure_cross_entropy'
 assert not any('logit_z' in n for n in cp['model_state'])
 other_kind='z1e4' if objective_kind!='z1e4' else 'z1e3'
 cfg.model.logit_z_kind=other_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[other_kind]
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed valid same-shaped objective family accepted')
 cfg.model.logit_z_kind=objective_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]
 cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]+.01
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed same-shaped objective coefficient accepted')
 cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]
 del cfg.model.logit_z_objective_policy
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Deleted objective policy accepted')
 cfg.model.logit_z_objective_policy=Z_POLICY
 validate_logit_z_model(model)
 validate_null_attention_model(model)
 assert model.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION)
 assert cfg.model.null_attention_kind==f and cfg.model.null_attention_policy==NULL_POLICY
 assert all(b.attn.null_attention_kind==f and b.attn.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION) for b in model.transformer.h)
 assert not any(any(part in NULL_STATE+('null_attention_kind','null_attention_policy','null_attention_signature') for part in n.split('.')) for n in cp['model_state'])
 cfg.model.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed valid same-shaped null family accepted')
 cfg.model.null_attention_kind=f
 del cfg.model.null_attention_policy
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Deleted null normalization policy accepted')
 cfg.model.null_attention_policy=NULL_POLICY
 for block in model.transformer.h:
  original_null=block.attn.null_attention_kind
  block.attn.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
  try:load_model_weights(model,cp)
  except ValueError:pass
  else:raise AssertionError('Changed constructed null normalization accepted')
  block.attn.null_attention_kind=original_null
 validate_null_attention_model(model)
 assert row['null_attention_kind']==f and row['null_attention_policy']==NULL_POLICY and row['null_attention_convention']==NULL_CONVENTION
 assert set(shapes)==set(names)
 assert all(tuple(names[n].shape)==shape for n,shape in shapes.items())
 expected_count=sum(math.prod(shape) for shape in shapes.values())
 assert sum(v.numel() for v in model.parameters())==expected_count==row['parameter_count']
 assert model.position_encoding==position_kind and model.enable_rope==(position_kind=='rope')
 assert cp['cfg']['model']['attn_type']==attention
 assert t['batch_size']==8 and cfg.model.block_size==128 and t['batch_layout']=='paired_blocks512' and t['weight_decay']==p['recipe']['weight_decay']
 assert raw['metrics'][-1]['tokens_processed']==total*1024 and len(raw['coverage']['evaluations']['128']['block_target_counts'])==55
 for metric in raw['metrics']:
  assert type(metric['train_logit_z_coefficient']) is float and metric['train_logit_z_coefficient']==COEFFICIENTS[objective_kind]
  assert metric['train_aux_loss'] is None and metric['val_aux_loss'] is None and metric['val_loss']==metric['val_ce_loss']
  if objective_kind=='none':
   assert all(metric[k] is None for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
   assert metric['train_loss']==metric['train_total_loss']==metric['train_ce_loss']
  else:
   square,penalty,mean=(metric[k] for k in ('train_logit_z_squared_mean','train_logit_z_penalty','train_logit_z_mean'))
   assert all(type(x) in (int,float) and math.isfinite(x) for x in (square,penalty,mean))
   assert square>=0 and penalty>=0 and square+1e-4>=mean*mean
   assert math.isclose(penalty,COEFFICIENTS[objective_kind]*square,abs_tol=1e-6,rel_tol=2e-5)
   assert metric['train_loss']==metric['train_total_loss']
   assert math.isclose(metric['train_total_loss'],metric['train_ce_loss']+penalty,abs_tol=1e-6,rel_tol=2e-5)
  step=metric['step'];warmup=row['warmup_steps']
  expected_ratio=(.1 if step==39 else .1+.9*step/(warmup-1) if warmup and step<warmup-1
                  else 1. if step<=20 else 1-.9*(step-20)/19)
  assert math.isclose(metric['lr_multiplier'],expected_ratio,rel_tol=0,abs_tol=1e-15)
  assert metric['base_learning_rate']==lr
  assert math.isclose(metric['scheduled_learning_rate'],lr*expected_ratio,rel_tol=0,abs_tol=1e-15)
 seen=set()
 assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']
 for opt in cp['optimizer_state']['optimizers']:
  for g in opt['param_groups']:
   name,=g['parameter_names'];assert name not in seen;seen.add(name)
   matrix=name.startswith('transformer.h.') and names[name].ndim==2;scale=1/math.sqrt(w/64) if matrix else 1.
   assert g['width_lr_scale']==scale and g['lr']==lr*scale*.1 and g['weight_decay']==0
   slot=opt['state'][g['params'][0]]
   if matrix:assert set(slot)=={'momentum_buffer'}
   else:assert set(slot)=={'step','exp_avg','exp_avg_sq'} and slot['step'].item()==total
   for key,value in slot.items():
    assert torch.isfinite(value).all()
    if key!='step':assert value.shape==names[name].shape
 assert seen==set(names)
 item=extra['averaged_outputs']['200'];saved=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
 assert 'optimizer_state' not in saved and 'training_state' not in saved
 assert item['checkpoint_sha256']==row['derived_checkpoint_sha256'] and item['coverage']['evaluations']['128']['target_count']==111538
 load_model_weights(model,saved);finite(saved);validate_logit_z_model(model);validate_null_attention_model(model)
 assert {n for n in saved['model_state'] if n.endswith(tuple('.'+g for g in GAIN_PARAMETERS))}==present
 for name in present:
  assert name in avg['parameter_names']
  assert torch.equal(saved['model_state'][name],avg['averages']['200'][name])
 for name,value in saved['model_state'].items():assert torch.equal(value,avg['averages']['200'][name] if name in names else cp['model_state'][name])
 gen=torch.Generator().manual_seed(9517);n=len(Path(req['config']['data']['path']).read_text())
 for _ in range(total):torch.randint(int(.8*n)-512,(2,),generator=gen)
 assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
 assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
 valgen=torch.Generator().manual_seed(2026);val_length=int(.9*n)-int(.8*n)
 for _ in range(t['eval_iters']):torch.randint(val_length-128,(8,),generator=valgen)
 assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
 assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
 graph_path=d/'linked-graph-check.pt';assert file_digest(graph_path)==row['linked_graph_sha256'];artifacts.append(graph_path)
 graph=torch.load(graph_path,map_location='cpu',weights_only=True);finite(graph)
 assert torch.equal(graph['objective']['tokens'],torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9517)))
 def numpy_tree(value):
  if isinstance(value,torch.Tensor):return value.numpy()
  if isinstance(value,dict):return {k:numpy_tree(v) for k,v in value.items()}
  if isinstance(value,(list,tuple)):return [numpy_tree(v) for v in value]
  return value
 graph_review=helpers['graph_audit'].verify(numpy_tree(graph),numpy_tree(saved['model_state']),item['checkpoint_sha256'],w,f,p['recipe'],helpers)
 graph_review_path=d/'linked-graph-review.json';assert file_digest(graph_review_path)==row['linked_graph_review_sha256'];artifacts.append(graph_review_path)
 assert graph_review==json.loads(graph_review_path.read_text())
 cache_result=graph_review['cache']
 assert cache_result['max_logit_error']==row['cached_full_max_abs_error']
 assert cache_result['forward_calls']==row['cache_forward_calls']==24 and cache_result['cache_prefixes']==row['cache_prefixes']==96
 assert cache_result['reset_events']==row['cache_reset_events']==1 and cache_result['absolute_offset']==row['cache_absolute_offset']==117
 assert cache_result['rope_checkpoint_buffers']==(8 if position_kind=='rope' else 0)
 assert row['primitive_sha256']==file_digest(args.pilots/'primitive-check.pt')
 assert row['primitive_review_sha256']==file_digest(args.pilots/'primitive-review.json')
 assert graph_review['width']==w and graph_review['null_kind']==f and graph_review['objective_kind']==objective_kind
 assert cache_result['null_kind']==f and cache_result['attention_output_links']==row['cache_attention_output_links']==4
 assert cache_result['independently_reconstructed_attention_outputs']==row['cache_attention_outputs']==108
 assert cache_result['attention_checkpoint_tensors']==16 and cache_result['output_projection_checkpoint_tensors']==8
 assert row['null_primitive_sha256']==file_digest(args.pilots/'null-primitive-check.pt')
 assert row['null_primitive_review_sha256']==file_digest(args.pilots/'null-primitive-review.json')
 graph_checks.append(dict(graph_review,family=f))
 for checkpoint_path in (Path(checked['checkpoint']).resolve(),Path(item['checkpoint']).resolve()):
  assert checkpoint_path not in checkpoint_paths;checkpoint_paths.add(checkpoint_path)
 expected_cache_bytes=4*2*2*128*w*4
 assert row['actual_cache_bytes']==expected_cache_bytes and row['cache_batch_size']==2
 assert 0<row['training_seconds']<=row['wall_seconds']<240 and row['sampled_peak_rss_mb']<4096 and row['current_driver_mb']<6144
 assert row['driver_allocation_is_not_peak'] is True
 assert row['raw_checkpoint_bytes']==Path(checked['checkpoint']).stat().st_size and row['derived_checkpoint_bytes']==Path(item['checkpoint']).stat().st_size
 artifacts.extend([d/'review.json',Path(checked['checkpoint']),Path(item['checkpoint'])]);checks.append(row)
# A single round-level primitive panel, captured and budgeted inside the first pilot job.
primitive_path=args.pilots/'primitive-check.pt';primitive=torch.load(primitive_path,map_location='cpu',weights_only=True);finite(primitive)
primitive_review=helpers['evaluation_audit'].primitive(numpy_tree(primitive))
assert primitive_review==json.loads((args.pilots/'primitive-review.json').read_text())
artifacts.extend([primitive_path,args.pilots/'primitive-review.json'])
null_primitive_path=args.pilots/'null-primitive-check.pt';null_primitive=torch.load(null_primitive_path,map_location='cpu',weights_only=True);finite(null_primitive)
null_primitive_review=helpers['null_primitive_audit'].verify(numpy_tree(null_primitive))
assert null_primitive_review==json.loads((args.pilots/'null-primitive-review.json').read_text())
artifacts.extend([null_primitive_path,args.pilots/'null-primitive-review.json'])
# Independently reconstruct the worst-case42-run bound, then compare the separately
# synthetic-tested resource function; never treat these forecasts as measurements.
seconds=0.;storage=0.;proxies=[]
for row in checks:
 w,f=row['width'],row['family'];count=(12 if f=='standard' else 9) if w==64 else (6 if f=='standard' else 3)
 estimate=1.5*(row['training_seconds']*75+row['wall_seconds']-row['training_seconds'])
 size=(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)*1.5
 seconds+=count*estimate;storage+=count*size
 proxies.append(dict(width=w,family=f,trajectories=count,seconds_per_trajectory_with_margin=estimate,artifact_mb_per_trajectory_with_margin=size/1024**2,within_trial_limit=estimate<2400))
assert sum(x['trajectories'] for x in proxies)==42
import importlib.util
spec=importlib.util.spec_from_file_location('output_bias_resource_gate',folder/'resource-gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
resource=gate.forecast(checks,p['recipe']['input_embedding_scale'])
assert resource['trial_proxies']==proxies and resource['hours']==seconds/3600 and resource['total_mb_with_margin']==storage/1024**2
if resource['status']!='feasible':
 rejection=args.output.with_name(args.output.stem+'-resource-infeasible.json');assert not rejection.exists()
 rejection.write_text(json.dumps(dict(status='infeasible_no_launch',source_commit=p['git_commit'],source_sha256=p['source_sha256'],resource_proxy=resource,pilot_path=str(pilot_path),pilot_sha256=file_digest(pilot_path),action='Preserve all pilots; no automatic retry or cap extension; review another algorithm or a distinct implementation change.'),indent=2)+'\n')
 raise ValueError('Null-attention resource forecast exceeds frozen limits; no research launch')
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(v,k=''):
 out=set()
 if 'seed' in k:
  if type(v) is int:out.add(v)
  elif isinstance(v,list):out.update(x for x in v if type(x) is int)
 if isinstance(v,dict):
  for a,b in v.items():out|=seeds(b,a)
 elif isinstance(v,list):
  for b in v:out|=seeds(b,k)
 return out
plans=sorted(set((base/'research_runs').glob('*/plan.json'))|set((base/'research_state').glob('*plan*.json')))
for a in plans:assert not new&seeds(json.loads(a.read_text())),str(a)
review=dict(status='verified',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=p['git_commit'],source_sha256=p['source_sha256'],
 returned_half_life=200,recipe=p['recipe'],predecessor_review=p['predecessor_review'],tests=cpu,pilot_audit=checks,
 resource_proxy=resource,independent_training_prior=prior_review,independent_linked_objective_graph=graph_checks,independent_objective_primitive=primitive_review,independent_null_attention_primitive=null_primitive_review,averaging_reuse=dict(unchanged_algorithms=['src/train/weight_averaging.py','src/research/averaging_eval.py'],checkpoint_guard_stripped_identity=True,trainer_changed=True,trainer_validation='Full CPU plus actual objective/optimizer/RNG/H200 resume tests; no whole-trainer historical byte-identity claim'),
 fresh_seed_check=dict(seeds=sorted(new),historical_plan_count=len(plans)),
 checks=['Full5973 CPU cases:16 actual geometry/evaluator,12 trainer/resume and256 metadata cases included',
 'Six fresh serial MPS standard/prefix_control/null_zero width64/25640-update jobs; twelve pure-CE full111538-target raw/H200 panels; no historical training/scoring rerun',
 'Independent parameter geometry, prior counts/formula, exact optimizer roles/slots/steps/width factors and independent decay; sampler train/reset-validation/untouched-test RNG; exact three H200 shadows and inference-only derivation',
 'One checkpoint-bound penalized objective/readout/final-norm/lookup graph per cell, linked through four complete branches and sixteen attention edges; objective/position/value/gain inherited independently of null-attention family',
 'Independent stable masked logsumexp penalty and all gradients, coefficient once, zero identity, primitive extreme/common-shift checks at prospectively frozen CPU-equivalent tolerances; explicit training-only flag',
 'Once-round45 null primitive rows verify probability/value/score gradients, zero-score control, extreme logits and common-real-score shifts at frozen CPU-equivalent tolerances',
 'Six separate synthetic pure-CE forwards per derived model, vetoing penalty invocation, with21-target full/short-tail coverage and links to the same graph; CPU tests separately cover raw/derived evaluator entrypoints',
 'Cached/full/token/uneven/reset/interleaved and absolute117offset:96 real KV prefixes and108 independently reconstructed attention outputs with visible-prefix counts, fixedzero null and4 input/output links; corrected declared FP32 frequency oracle, no tolerance relaxation',
 'Final independently audited logit-z decision resolves the whole inherited recipe; fresh seed scan and unchanged resource caps/50percent margins'],
 limitations=['Short real-training-corpus correctness pilots excluded from quality findings','Resource forecasts are estimates; watchdog and hard caps stillapply','Current driver allocation is not peak memory','Final checkpoints cannot reconstruct all online snapshots; recurrence correctness relies on separately tested frozen implementation','No optimalLR/muP transfer, seed-population inference or independentMPSbitwisereproducibility claim'],
 artifacts=[dict(path=str(a.resolve()),sha256=file_digest(a)) for a in dict.fromkeys(artifacts)])
out=args.output;assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review['resource_proxy'],indent=2))
