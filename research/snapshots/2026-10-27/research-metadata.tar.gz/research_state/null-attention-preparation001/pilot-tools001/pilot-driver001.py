"""Six fresh serial null-attention MPS correctness pilots; final logit-z review and full CPU publication gate required."""
import argparse,json,math,os,re,subprocess,time,threading,sys,importlib.util,shutil
from pathlib import Path


def post_worker_watchdog(output, jobdir, remaining, completed_jobs):
    """Bound native MPS checks after the separately bounded worker has exited."""
    if not math.isfinite(remaining) or remaining<=0:
        raise TimeoutError('Pilot budget exhausted before post-worker correctness checks')
    def expired():
        from src.research.runner import atomic_json
        try:
            atomic_json(Path(output)/'failure.json',dict(error='Post-worker correctness wall-time limit reached',
                phase='post_worker_correctness',job=str(jobdir),completed_jobs=completed_jobs,no_automatic_retry=True))
        finally:
            os._exit(88)
    timer=threading.Timer(remaining,expired);timer.daemon=True;timer.start()
    return timer


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-pilots',action='store_true');parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-review',type=Path,required=True);args=parser.parse_args()
    if not args.run_pilots:parser.error('Explicit --run-pilots required')
    if os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK'):raise ValueError('Unset fallback')
    base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve();prior=base/'research_runs/logit-z-quality-001'
    active=json.loads((base/'research_state/active-campaign.json').read_text())
    if Path(active['campaign'])!=prior or active['status']!='completed_reviewed':raise ValueError('Completed reviewed logit-z predecessor required')
    if json.loads((prior/'state.json').read_text())['status']!='completed':raise ValueError('Predecessor still active')
    sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'cpu-tools001'))
    from bounded_cpu import live_model_commands
    live=live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{os.getpid(),os.getppid()})
    if live:raise ValueError('Competing model work: '+str(live))
    if shutil.disk_usage(base).free<10*1024**3:raise ValueError('At least10GiB free disk required')
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    from preflight import check as publication_preflight
    preflight_review=publication_preflight(source,args.cpu_review)
    import torch
    from omegaconf import OmegaConf
    from src.models.gpt import GPT
    from src.attention.cache import KVCache
    from src.utils.checkpoint import read_checkpoint,load_model_weights
    from src.train.lr_schedule import multiplier
    from src.research import null_attention_study as study
    from src.models.residual_topology import validate_residual_topology_model, POLICY as RESIDUAL_POLICY
    from src.models.attention_scale import validate_attention_scale_model, POLICY as SCALE_POLICY
    from src.models.gated_activation import validate_gated_activation_model, POLICY as GATE_POLICY
    from src.models.residual_gain import validate_residual_gain_model, POLICY as GAIN_POLICY, PARAMETERS as GAIN_PARAMETERS
    from src.models.value_residual import validate_value_residual_model, POLICY as VALUE_POLICY
    from src.models.position_family import validate_position_family_model, POLICY as POSITION_POLICY, SLOPE_FORMULA
    from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION
    from src.models.null_attention import validate_null_attention_model, POLICY as NULL_POLICY, CONVENTION as NULL_CONVENTION, STATE_NAMES as NULL_STATE
    from src.models.embedding_scale import input_scale_contract
    from src.models.readout_norm import readout_norm_contract
    from src.models.weight_tying import validate_weight_tying_model, POLICY as TYING_POLICY
    from src.models.output_bias import output_bias_contract,build_training_prior,POLICY
    from src.research.averaging_eval import validate_derivation
    from src.research.protocol import file_digest
    from src.research.team.suite import source_digest,_request,_launch
    from src.research.runner import atomic_json,session_lock,validate_result,disk_mb
    torch.set_num_threads(1)
    assert source_digest(source)==preflight_review['source_sha256']
    sha=source_digest(source);driver_sha=file_digest(Path(__file__).resolve());cpu=json.loads(args.cpu_review.read_text());tests=cpu['full_tests']
    if (cpu['status']!='cpu_verified' or cpu['source_sha256']!=sha or tests['passed']!=tests['collected']
            or tests['collected']!=5973 or tests['failed']!=0 or cpu['actual_null_attention_training_tests_passed']!=12
            or cpu['actual_null_attention_geometry_tests_passed']!=16 or cpu['null_attention_metadata_tests_passed']!=256):
        raise ValueError('Complete matching full CPU suite, twenty-eight actual null-attention geometry/evaluator/trainer/resume cases and256 metadata tests required')
    for a in cpu['artifacts']:
        if file_digest(Path(a['path']))!=a['sha256']:raise ValueError('CPU evidence changed')
    if subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise ValueError('Dirty source')
    p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
    published_tip=subprocess.check_output(['git','rev-parse','origin/main'],cwd=source,text=True).strip()
    subprocess.run(['git','merge-base','--is-ancestor',p['git_commit'],published_tip],cwd=source,check=True)
    assert study.BOOTSTRAP.startswith('from src.research.memory_guard import start_memory_guard\nstart_memory_guard()\n')
    inherited_bias=p['recipe']['output_bias_kind'];table_kind=p['recipe']['weight_tying_kind'];topology=p['recipe']['residual_topology_kind'];gain_kind=p['recipe']['residual_gain_kind'];value_kind=p['recipe']['value_residual_kind'];position_kind=p['recipe']['position_family_kind'];objective_kind=p['recipe']['logit_z_kind']
    graph_folder=Path(__file__).resolve().parent.parent/'graph-tools001'
    spec=importlib.util.spec_from_file_location('null_graph_loader',graph_folder/'load-helpers.py');loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader);helpers=loader.load()
    attention='mha';lr=.01;short_warmup=0;assert p['recipe']['warmup_steps']==0
    helper_paths=[Path(__file__).with_name('preflight.py'),Path(__file__).with_name('resource-gate.py'),Path(__file__).resolve().parent.parent/'cpu-tools001/bounded_cpu.py',graph_folder/'load-helpers.py',graph_folder/'helper-manifest.json']
    helper_paths += [Path(v['path']) for v in json.loads((graph_folder/'helper-manifest.json').read_text())['helpers'].values()]
    helper_hashes={str(path.resolve()):file_digest(path) for path in helper_paths}
    out=args.output.resolve();assert out.is_relative_to(base/'research_state');out.mkdir(exist_ok=False)
    atomic_json(out/'intent.json',dict(publication_preflight=preflight_review,source_commit=p['git_commit'],source_sha256=sha,cpu_review_sha256=file_digest(args.cpu_review),pilot_driver_sha256=driver_sha,
        predecessor_review=p['predecessor_review'],resolved_recipe=p['recipe'],seed=9517,helper_sha256=helper_hashes,published_tip=published_tip,
        purpose='Six fresh null-attention upper-grid-LR jobs; inherited objective graph, null probabilities/visible-prefix cache outputs, pure-CE validation and optimizer/H200; excluded from research',
        hard_limits=dict(jobs=6,job_seconds=240,round_seconds=1800,disk_mb=1024),holdout_consumed=False))
    began=time.monotonic();rows=[]
    def finite(x):
        if isinstance(x,torch.Tensor):assert torch.isfinite(x).all()
        elif isinstance(x,dict):
            for v in x.values():finite(v)
        elif isinstance(x,(list,tuple)):
            for v in x:finite(v)
        elif isinstance(x,float):assert math.isfinite(x)
    post_timer=None
    with session_lock(out) as fd:
        try:
            for w in (64,256):
                for f in study.FAMILIES:
                    assert source_digest(source)==sha and file_digest(Path(__file__).resolve())==driver_sha
                    assert all(file_digest(Path(path))==digest for path,digest in helper_hashes.items())
                    d=out/f'w{w}_{f}';d.mkdir();job=dict(family=f,lr=lr,width=w,n_heads=w//32,seed=9517,stage='local',arm='candidate',trial_id=d.name)
                    req=_request(study.suite_spec(p,f,lr),job,d);t=req['config']['training']
                    total,start=40,20
                    t.update(max_iters=total,eval_every=10,eval_iters=2)
                    t['lr_schedule'].update(total_steps=total,start_step=start);t['weight_averaging'].update(total_steps=total,start_step=start)
                    if short_warmup:t['lr_schedule']['warmup_steps']=short_warmup
                    atomic_json(d/'request.json',req);started=time.monotonic()
                    allowance=min(240,1800-(started-began));assert allowance>0
                    status,error=_launch(d/'request.json',out,allowance,1024,fd,root=source,bootstrap=study.BOOTSTRAP)
                    if status!='completed':raise RuntimeError((status,error))
                    post_timer=post_worker_watchdog(out,d,min(240-(time.monotonic()-started),1800-(time.monotonic()-began)),len(rows))
                    raw=json.loads((d/'result.json').read_text());checked=validate_result(raw,req,dict(device='mps',training={**t,'block_size':128}),d)
                    extra=study.adapter(p,raw,checked,req,d);cp=read_checkpoint(checked['checkpoint']);finite(cp)
                    assert cp['step']==total and raw['completed_steps']==total
                    wanted=json.loads(json.dumps(req['config']));wanted['model']['vocab_size']=65;assert cp['cfg']==wanted
                    cfg=OmegaConf.create(cp['cfg'])
                    with torch.random.fork_rng(devices=[]):
                        model=GPT(cfg.model);load_model_weights(model,cp,for_resume=True)
                    names=dict(model.named_parameters());state=cp['model_state']
                    assert cp['cfg']['model']['attn_type']==attention and len(model.transformer.h)==4
                    expected_norm=p['recipe']['readout_norm_kind']
                    expected_count=132*w+4*(4*w*w+6*w+3*w*(21*w//8))-(0 if expected_norm=='layer_affine' else w)+(0 if inherited_bias=='none' else 65)-(65*w if table_kind=='scaled_tied' else 0)
                    expected_count += 8*w if gain_kind=='learned_tenth' else 0
                    assert model.position_encoding==position_kind and model.enable_rope==(position_kind=='rope')
                    assert input_scale_contract(cfg.model)==dict(input_width_policy='mha4_input_scale',input_embedding_scale=p['recipe']['input_embedding_scale'])
                    assert model.input_embedding_scale==p['recipe']['input_embedding_scale']
                    assert readout_norm_contract(cfg.model)==dict(readout_norm_kind=expected_norm,readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5)
                    assert model.readout_norm_signature==(expected_norm,1e-5)
                    assert ('transformer.ln_f.bias' in names)==(expected_norm=='layer_affine')
                    assert ('output_bias' in names)==(inherited_bias!='none')
                    validate_weight_tying_model(model)
                    assert model.weight_tying_signature==(table_kind,TYING_POLICY,64)
                    assert ('lm_head.weight' in names)==(table_kind!='scaled_tied')
                    bound=output_bias_contract(cfg.model)
                    assert bound==dict(output_bias_kind=inherited_bias,output_bias_width_policy=POLICY,output_bias_prior=p['output_bias_prior'])
                    assert build_training_prior(Path(req['config']['data']['path']).read_bytes(),.8,.1)==p['output_bias_prior']
                    original_kind=cfg.model.output_bias_kind
                    cfg.model.output_bias_kind='learned_zero' if inherited_bias!='learned_zero' else 'learned_train_unigram'
                    try: load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong output-bias semantic checkpoint accepted')
                    cfg.model.output_bias_kind=original_kind
                    original_tying=cfg.model.weight_tying_kind
                    cfg.model.weight_tying_kind='matched_untied' if table_kind!='matched_untied' else 'scaled_tied'
                    try: load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong sharing checkpoint accepted')
                    cfg.model.weight_tying_kind=original_tying
                    validate_residual_topology_model(model)
                    assert model.residual_topology_signature==(topology,RESIDUAL_POLICY)
                    assert all(block.ln1 is not block.ln2 for block in model.transformer.h)
                    cfg.model.residual_topology_kind='serial' if topology!='serial' else 'parallel_separate_norms'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped residual topology accepted')
                    cfg.model.residual_topology_kind=topology
                    validate_attention_scale_model(model)
                    assert model.attention_scale_signature==(p['recipe']['attention_logit_scale'],SCALE_POLICY)
                    cfg.model.attention_logit_scale=.5 if p['recipe']['attention_logit_scale']!=.5 else 2.
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped attention scale accepted')
                    cfg.model.attention_logit_scale=p['recipe']['attention_logit_scale']
                    validate_gated_activation_model(model)
                    assert model.gated_activation_signature==(p['recipe']['gated_activation_kind'],GATE_POLICY)
                    assert all(b.mlp.gate_activation==p['recipe']['gated_activation_kind'] for b in model.transformer.h)
                    cfg.model.gated_activation_kind='relu' if p['recipe']['gated_activation_kind']!='relu' else 'silu'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped gated activation accepted')
                    cfg.model.gated_activation_kind=p['recipe']['gated_activation_kind']
                    validate_residual_gain_model(model)
                    assert model.residual_gain_signature==(gain_kind,GAIN_POLICY)
                    assert all(b.residual_gain_kind==gain_kind for b in model.transformer.h)
                    gain_names={f'transformer.h.{i}.{n}' for i in range(4) for n in GAIN_PARAMETERS}
                    present={n for n in names if n.endswith(tuple('.'+g for g in GAIN_PARAMETERS))}
                    assert present==(gain_names if gain_kind=='learned_tenth' else set())
                    assert all(names[n].shape==(w,) for n in present)
                    cfg.model.residual_gain_kind='unit' if gain_kind!='unit' else 'static_tenth'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong residual gain semantic checkpoint accepted')
                    cfg.model.residual_gain_kind=gain_kind
                    validate_value_residual_model(model)
                    assert model.value_residual_signature==(value_kind,VALUE_POLICY)
                    assert all(b.attn.value_residual_kind==value_kind and b.attn.value_residual_layer==i for i,b in enumerate(model.transformer.h))
                    cfg.model.value_residual_kind='local' if value_kind!='local' else 'first_blend'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong value-reuse semantic checkpoint accepted')
                    cfg.model.value_residual_kind=value_kind
                    validate_position_family_model(model)
                    assert model.position_family_signature==(position_kind,POSITION_POLICY,SLOPE_FORMULA,w//32)
                    expected_slopes=tuple(2.**(-8.*(h+1)/(w//32)) for h in range(w//32)) if position_kind=='alibi' else ()
                    assert all(b.attn.position_family_kind==position_kind and b.attn.position_slopes==expected_slopes for b in model.transformer.h)
                    for i in range(4):
                        for suffix in ('freq_cos','freq_sin'):
                            key=f'transformer.h.{i}.{suffix}'
                            assert (key in state)==(position_kind=='rope')
                            if position_kind=='rope':assert state[key].shape==(128,16)
                    cfg.model.position_family_kind='nope' if position_kind!='nope' else 'alibi'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Wrong same-shaped position family accepted')
                    cfg.model.position_family_kind=position_kind
                    del cfg.model.position_family_width_policy
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Deleted position policy accepted')
                    cfg.model.position_family_width_policy=POSITION_POLICY
                    if position_kind=='alibi':
                        original_slopes=model.transformer.h[0].attn.position_slopes
                        model.transformer.h[0].attn.position_slopes=tuple(x*2 for x in original_slopes)
                        try:load_model_weights(model,cp)
                        except ValueError:pass
                        else:raise AssertionError('Changed constructed ALiBi slopes accepted')
                        model.transformer.h[0].attn.position_slopes=original_slopes
                    validate_position_family_model(model)
                    validate_logit_z_model(model)
                    assert model.logit_z_signature==(objective_kind,COEFFICIENTS[objective_kind],Z_POLICY,CONVENTION)
                    assert not any('logit_z' in n for n in model.state_dict())
                    other_kind='z1e4' if objective_kind!='z1e4' else 'z1e3'
                    cfg.model.logit_z_kind=other_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[other_kind]
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Changed valid same-shaped objective family accepted')
                    cfg.model.logit_z_kind=objective_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]
                    cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]+.01
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Changed logit-z coefficient accepted')
                    cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]
                    del cfg.model.logit_z_objective_policy
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Deleted logit-z policy accepted')
                    cfg.model.logit_z_objective_policy=Z_POLICY
                    validate_logit_z_model(model)
                    validate_null_attention_model(model)
                    assert model.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION)
                    assert cfg.model.null_attention_kind==f and cfg.model.null_attention_policy==NULL_POLICY
                    assert all(b.attn.null_attention_kind==f and b.attn.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION) for b in model.transformer.h)
                    assert not any(any(part in NULL_STATE+('null_attention_kind','null_attention_policy','null_attention_signature') for part in n.split('.')) for n in cp['model_state'])
                    cfg.model.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Changed valid same-shaped null family accepted')
                    cfg.model.null_attention_kind=f
                    del cfg.model.null_attention_policy
                    try:load_model_weights(model,cp)
                    except ValueError:pass
                    else:raise AssertionError('Deleted null normalization policy accepted')
                    cfg.model.null_attention_policy=NULL_POLICY
                    for block in model.transformer.h:
                     original_null=block.attn.null_attention_kind
                     block.attn.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
                     try:load_model_weights(model,cp)
                     except ValueError:pass
                     else:raise AssertionError('Changed constructed null normalization accepted')
                     block.attn.null_attention_kind=original_null
                    validate_null_attention_model(model)
                    original_scale=cfg.model.input_embedding_scale
                    cfg.model.input_embedding_scale=.5 if original_scale==1. else 1.
                    try:
                        load_model_weights(model,cp)
                    except ValueError: pass
                    else: raise AssertionError('Wrong input-scale checkpoint accepted')
                    cfg.model.input_embedding_scale=original_scale
                    assert sum(v.numel() for v in model.parameters())==expected_count
                    assert not any('.mlp.hidden_norm.' in n for n in names)
                    avg=cp['training_state']['weight_averaging_state'];assert avg['snapshots']==1+(total-start)//10 and set(avg['averages'])=={'200'}
                    gen=torch.Generator().manual_seed(9517);text=Path(req['config']['data']['path']).read_text()
                    for _ in range(total):torch.randint(int(.8*len(text))-512,(2,),generator=gen)
                    assert torch.equal(cp['training_state']['loader_rng']['train'],gen.get_state())
                    assert set(cp['training_state']['loader_rng'])=={'train','val','test'}
                    valgen=torch.Generator().manual_seed(2026);val_length=int(.9*len(text))-int(.8*len(text))
                    for _ in range(t['eval_iters']):torch.randint(val_length-128,(8,),generator=valgen)
                    assert torch.equal(cp['training_state']['loader_rng']['val'],valgen.get_state())
                    assert torch.equal(cp['training_state']['loader_rng']['test'],torch.Generator().manual_seed(2027).get_state())
                    for m in raw['metrics']:assert m['lr_multiplier']==multiplier(t['lr_schedule'],m['step'])
                    assert raw['metrics'][-1]['tokens_processed']==1024*total and abs(raw['metrics'][-1]['lr_multiplier']-.1)<1e-12
                    assert cp['optimizer_state']['independent_decay']==p['recipe']['weight_decay']==t['weight_decay']
                    seen=set()
                    for opt in cp['optimizer_state']['optimizers']:
                        for g in opt['param_groups']:
                            assert g['weight_decay']==0.
                            name,=g['parameter_names'];assert name not in seen;seen.add(name);slot=opt['state'][g['params'][0]]
                            matrix=name.startswith('transformer.h.') and names[name].ndim==2
                            assert g['width_lr_scale']==(1/math.sqrt(w/64) if matrix else 1.)
                            assert g['lr']==lr*g['width_lr_scale']*.1
                            if matrix:
                                assert set(slot)=={'momentum_buffer'} and torch.count_nonzero(slot['momentum_buffer'])>0
                            else:
                                assert slot['step'].item()==total and set(slot)=={'step','exp_avg','exp_avg_sq'}
                                assert torch.count_nonzero(slot['exp_avg_sq'])>0
                            for key,value in slot.items():
                                assert torch.isfinite(value).all()
                                if key!='step':assert value.shape==names[name].shape
                    assert seen==set(names)
                    item=extra['averaged_outputs']['200'];derived=validate_derivation(dict(checkpoint=item['checkpoint'],checkpoint_sha256=item['checkpoint_sha256'],parent_checkpoint=checked['checkpoint'],parent_sha256=checked['checkpoint_sha256'],half_life=200,completed_steps=total))
                    assert 'optimizer_state' not in derived and 'training_state' not in derived
                    for name in present:
                        assert name in avg['parameter_names']
                        assert torch.equal(derived['model_state'][name],avg['averages']['200'][name])
                    assert {n for n in derived['model_state'] if n.endswith(tuple('.'+g for g in GAIN_PARAMETERS))}==present
                    load_model_weights(model,derived);finite(derived);validate_logit_z_model(model);validate_null_attention_model(model)
                    assert extra['coverage']['128']['target_count']==item['coverage']['evaluations']['128']['target_count']==111538
                    # Exactly one penalized graph plus separate synthetic pure-CE/cache checks.
                    # Every check, including the once-per-round primitive panel, is inside this job's watchdog.
                    model=model.to('mps').eval();idx=torch.randint(65,(2,11),generator=torch.Generator().manual_seed(9517)).to('mps')
                    def numpy_tree(value):
                        if isinstance(value,torch.Tensor):return value.detach().cpu().numpy()
                        if isinstance(value,dict):return {k:numpy_tree(v) for k,v in value.items()}
                        if isinstance(value,(list,tuple)):return [numpy_tree(v) for v in value]
                        return value
                    if not rows:
                        primitive=helpers['primitive_capture'].capture()
                        torch.save(primitive,out/'primitive-check.pt')
                        primitive_review=helpers['evaluation_audit'].primitive(numpy_tree(primitive))
                        atomic_json(out/'primitive-review.json',primitive_review)
                        del primitive
                        null_primitive=helpers['null_primitive_capture'].capture()
                        # Capture intentionally returns NumPy arrays. Serialize tensor-only
                        # payloads so the independent reviewer can use weights_only=True.
                        def tensor_tree(value):
                            import numpy as np
                            if isinstance(value,np.ndarray):return torch.from_numpy(value.copy())
                            if isinstance(value,dict):return {k:tensor_tree(v) for k,v in value.items()}
                            if isinstance(value,(list,tuple)):return [tensor_tree(v) for v in value]
                            return value
                        null_primitive=tensor_tree(null_primitive)
                        torch.save(null_primitive,out/'null-primitive-check.pt')
                        null_primitive_review=helpers['null_primitive_audit'].verify(numpy_tree(null_primitive))
                        atomic_json(out/'null-primitive-review.json',null_primitive_review)
                        del null_primitive
                    graph=helpers['graph_capture'].capture(model,cfg,idx,item['checkpoint_sha256'],helpers)
                    torch.save(graph,d/'linked-graph-check.pt')
                    graph_review=helpers['graph_audit'].verify(numpy_tree(graph),numpy_tree(derived['model_state']),item['checkpoint_sha256'],w,f,p['recipe'],helpers)
                    atomic_json(d/'linked-graph-review.json',graph_review)
                    cache_bytes=graph['cache']['cache_bytes'];error=graph_review['cache']['max_logit_error']
                    driver_mb=torch.mps.driver_allocated_memory()/1024**2;assert driver_mb<6144
                    del graph,graph_review,idx,model,names
                    torch.mps.synchronize();torch.mps.empty_cache()
                    rss=max(x['rss_mb'] for x in raw['metrics']);assert rss<4096
                    row=dict(width=w,family=f,position_family_kind=position_kind,position_family_width_policy=POSITION_POLICY,position_slopes=list(expected_slopes),position_frequency_buffers=8 if position_kind=='rope' else 0,value_residual_kind=value_kind,value_residual_width_policy=VALUE_POLICY,residual_gain_kind=gain_kind,residual_gain_width_policy=GAIN_POLICY,gated_activation_kind=p['recipe']['gated_activation_kind'],gated_activation_width_policy=GATE_POLICY,output_bias_kind=inherited_bias,output_bias_width_policy=POLICY,output_bias_prior_sha256=p['output_bias_prior']['prior_sha256'],weight_tying_kind=table_kind,weight_tying_width_policy=TYING_POLICY,residual_topology_kind=topology,residual_topology_width_policy=RESIDUAL_POLICY,attention_logit_scale=p['recipe']['attention_logit_scale'],attention_logit_scale_width_policy=SCALE_POLICY,null_attention_kind=f,null_attention_policy=NULL_POLICY,null_attention_convention=NULL_CONVENTION,logit_z_kind=objective_kind,logit_z_coefficient=COEFFICIENTS[objective_kind],logit_z_objective_policy=Z_POLICY,logit_z_convention=CONVENTION,validation_objective='pure_cross_entropy',linked_graph_sha256=file_digest(d/'linked-graph-check.pt'),linked_graph_review_sha256=file_digest(d/'linked-graph-review.json'),primitive_sha256=file_digest(out/'primitive-check.pt'),primitive_review_sha256=file_digest(out/'primitive-review.json'),null_primitive_sha256=file_digest(out/'null-primitive-check.pt'),null_primitive_review_sha256=file_digest(out/'null-primitive-review.json'),readout_norm_kind=expected_norm,readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,input_embedding_scale=p['recipe']['input_embedding_scale'],input_width_policy='mha4_input_scale',attention_family=attention,peak_learning_rate=lr,warmup_steps=t['lr_schedule'].get('warmup_steps',0),steps=total,cooldown_start=start,snapshots=avg['snapshots'],status='verified',
                        training_seconds=raw['training_time_sec'],wall_seconds=time.monotonic()-started,sampled_peak_rss_mb=rss,
                        cached_full_max_abs_error=error,cache_absolute_offset=117,cache_forward_calls=24,cache_prefixes=96,cache_reset_events=1,cache_attention_outputs=108,cache_attention_output_links=4,current_driver_mb=driver_mb,driver_allocation_is_not_peak=True,
                        actual_cache_bytes=cache_bytes,cache_batch_size=2,
                        parameter_count=expected_count,raw_checkpoint_bytes=Path(checked['checkpoint']).stat().st_size,
                        derived_checkpoint_bytes=Path(item['checkpoint']).stat().st_size,checkpoint_sha256=checked['checkpoint_sha256'],
                        derived_checkpoint_sha256=item['checkpoint_sha256'],request_sha256=file_digest(d/'request.json'),result_sha256=file_digest(d/'result.json'))
                    assert row['wall_seconds']<240 and time.monotonic()-began<1800 and disk_mb(out)<1024
                    atomic_json(d/'review.json',row);rows.append(row);post_timer.cancel();post_timer=None;print(row,flush=True)
        except Exception as e:
            if post_timer is not None:post_timer.cancel()
            atomic_json(out/'failure.json',dict(error=repr(e),completed_jobs=len(rows),no_automatic_retry=True));raise
    atomic_json(out/'pilots.json',dict(status='verified',source_commit=p['git_commit'],source_sha256=sha,rows=rows,excluded_from_research=True,
        holdout_consumed=False,disk_mb=disk_mb(out)))

if __name__=='__main__':main()
