"""Read-only CPU/publication gate, deliberately before Torch/model imports."""
import hashlib,json,subprocess
from pathlib import Path

def sha(path):
    path=Path(path)
    if path.is_symlink() or any(p.is_symlink() for p in path.parents):raise ValueError('Symlink evidence')
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_digest(root):
    root=Path(root).resolve();paths=sorted((root/'src').rglob('*.py'))+[root/'requirements.txt']
    if not (root/'src').is_dir():raise ValueError('Missing source tree')
    return hashlib.sha256(json.dumps({str(p.relative_to(root)):sha(p) for p in paths},sort_keys=True,allow_nan=False).encode()).hexdigest()

def check(source,cpu_path,check_output=subprocess.check_output):
    source=Path(source).resolve();cpu_path=Path(cpu_path).resolve();cpu=json.loads(cpu_path.read_text());tests=cpu['full_tests']
    if cpu_path.name!='cpu-publication-review.json' or not cpu.get('publication_status') or not cpu.get('publication_reviewed_at'):
        raise ValueError('CPU publication review required; preserve original tested protocol first')
    if (cpu['status']!='cpu_verified' or cpu['source_sha256']!=source_digest(source)
        or tests['passed']!=5973 or tests['collected']!=5973 or tests['failed']!=0
        or tests['actual_tests']!=27 or tests['remaining_tests']!=5945 or tests['metadata_tests']!=256
        or cpu['actual_null_attention_geometry_tests_passed']!=15 or cpu['actual_null_attention_training_tests_passed']!=12
        or cpu['null_attention_metadata_tests_passed']!=256):raise ValueError('Complete matching null-attention CPU suite required')
    paths=[]
    for item in cpu['artifacts']:
        p=Path(item['path']);assert p.is_absolute() and sha(p)==item['sha256'];paths.append(p)
    if len(paths)!=len(set(paths)) or not any(p.name=='tested-original-protocol.md' for p in paths):
        raise ValueError('Unique CPU artifacts and preserved tested protocol required')
    if check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise ValueError('Dirty source')
    head=check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    tip=check_output(['git','rev-parse','origin/main'],cwd=source,text=True).strip()
    base=check_output(['git','merge-base',head,tip],cwd=source,text=True).strip()
    if base!=head:raise ValueError('Clean tested source must be published ancestor of origin/main')
    return dict(source_sha256=cpu['source_sha256'],source_commit=head,published_tip=tip,cpu_review_sha256=sha(cpu_path))
