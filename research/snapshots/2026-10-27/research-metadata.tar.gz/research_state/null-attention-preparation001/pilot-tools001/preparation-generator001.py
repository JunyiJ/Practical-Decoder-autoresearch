from pathlib import Path
import ast,json,hashlib
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';Z=B/'research_state/logit-z-preparation001/pilot-tools001';F=P/'pilot-tools001'
def change(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
def common(s):
 for a,b in [('research_runs/position-quality-001','research_runs/logit-z-quality-001'),('Completed reviewed position-family','Completed reviewed logit-z'),('logit_z_study as study','null_attention_study as study'),('actual_logit_z_','actual_null_attention_'),('logit_z_metadata_tests_passed','null_attention_metadata_tests_passed'),('5689','5973'),('5662','5945'),('535','256'),('9491','9517')]:s=s.replace(a,b)
 s=s.replace("geometry_tests_passed']!=15","geometry_tests_passed']!=16").replace("geometry_tests_passed']==15","geometry_tests_passed']==16")
 s=s.replace('twenty-seven actual logit-z','twenty-eight actual null-attention')
 s=s.replace("COEFFICIENTS[f]","COEFFICIENTS[objective_kind]")
 s=s.replace("logit_z_signature==(f,","logit_z_signature==(objective_kind,")
 s=s.replace("if f!='z1e4'","if objective_kind!='z1e4'")
 s=s.replace("cfg.model.logit_z_kind=f;","cfg.model.logit_z_kind=objective_kind;")
 return s
null_guard='''validate_null_attention_model(model)
assert model.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION)
assert cfg.model.null_attention_kind==f and cfg.model.null_attention_policy==NULL_POLICY
assert all(b.attn.null_attention_kind==f and b.attn.null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION) for b in model.transformer.h)
assert not any(any(part in NULL_STATE+('null_attention_kind','null_attention_policy','null_attention_signature') for part in n.split('.')) for n in cp['model_state'])
cfg.model.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
try:load_model_weights(model,cp)
except ValueError:pass
else:raise AssertionError('Changed valid same-shaped null family accepted')
cfg.model.null_attention_kind=f
del cfg.model.null_attention_policy
try:load_model_weights(model,cp)
except ValueError:pass
else:raise AssertionError('Deleted null normalization policy accepted')
cfg.model.null_attention_policy=NULL_POLICY
for block in model.transformer.h:
 original_null=block.attn.null_attention_kind
 block.attn.null_attention_kind='null_zero' if f!='null_zero' else 'prefix_control'
 try:load_model_weights(model,cp)
 except ValueError:pass
 else:raise AssertionError('Changed constructed null normalization accepted')
 block.attn.null_attention_kind=original_null
validate_null_attention_model(model)
'''
imp='from src.models.null_attention import validate_null_attention_model, POLICY as NULL_POLICY, CONVENTION as NULL_CONVENTION, STATE_NAMES as NULL_STATE'
def indent(s,n):return ''.join(' '*n+l+'\n' for l in s.rstrip().splitlines())
s=common((Z/'pilot-driver001.py').read_text())
s=change(s,'Six serial logit-z objective MPS correctness pilots; final value-residual review and full CPU suite required.','Six fresh serial null-attention MPS correctness pilots; final logit-z review and full CPU publication gate required.')
s=change(s,'    from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION','    from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION\n    '+imp)
s=change(s,"position_kind=p['recipe']['position_family_kind']","position_kind=p['recipe']['position_family_kind'];objective_kind=p['recipe']['logit_z_kind']")
s=change(s,"logit_graph_loader","null_graph_loader")
s=change(s,"Six fresh logit-z upper-grid-LR jobs; explicit penalized graph, pure-CE validation, primitive/cache/optimizer/H200 checks; excluded from research","Six fresh null-attention upper-grid-LR jobs; inherited objective graph, null probabilities/visible-prefix cache outputs, pure-CE validation and optimizer/H200; excluded from research")
s=change(s,'                    original_scale=cfg.model.input_embedding_scale',indent(null_guard,20)+'                    original_scale=cfg.model.input_embedding_scale')
s=change(s,'load_model_weights(model,derived);finite(derived);validate_logit_z_model(model)','load_model_weights(model,derived);finite(derived);validate_logit_z_model(model);validate_null_attention_model(model)')
s=change(s,"                        del primitive\n", "                        del primitive\n                        null_primitive=helpers['null_primitive_capture'].capture()\n                        torch.save(null_primitive,out/'null-primitive-check.pt')\n                        null_primitive_review=helpers['null_primitive_audit'].verify(numpy_tree(null_primitive))\n                        atomic_json(out/'null-primitive-review.json',null_primitive_review)\n                        del null_primitive\n")
s=change(s,"logit_z_kind=f,logit_z_coefficient=COEFFICIENTS[objective_kind]","null_attention_kind=f,null_attention_policy=NULL_POLICY,null_attention_convention=NULL_CONVENTION,logit_z_kind=objective_kind,logit_z_coefficient=COEFFICIENTS[objective_kind]")
s=change(s,"primitive_review_sha256=file_digest(out/'primitive-review.json'),","primitive_review_sha256=file_digest(out/'primitive-review.json'),null_primitive_sha256=file_digest(out/'null-primitive-check.pt'),null_primitive_review_sha256=file_digest(out/'null-primitive-review.json'),")
s=change(s,"cache_reset_events=1,current_driver_mb","cache_reset_events=1,cache_attention_outputs=108,cache_attention_output_links=4,current_driver_mb")
(F/'pilot-driver001.py').write_text(s)
s=common((Z/'review-prerequisites002.py').read_text())
s=change(s,'Audit saved logit-z objective pilot evidence','Audit saved null-attention pilot evidence')
s=change(s,'from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION','from src.models.logit_z import validate_logit_z_model, POLICY as Z_POLICY, COEFFICIENTS, CONVENTION\n'+imp)
s=change(s,"position_kind=p['recipe']['position_family_kind']","position_kind=p['recipe']['position_family_kind'];objective_kind=p['recipe']['logit_z_kind']")
s=s.replace('logit_graph_loader','null_graph_loader').replace("source/'research/LOGIT_Z_PROTOCOL.md'","source/'research/NULL_ATTENTION_PROTOCOL.md'")
s=change(s,"folder.parent/'objective-math-tools001/review.json',folder.parent/'objective-eval-tools001/review.json'","base/'research_state/logit-z-preparation001/objective-math-tools001/review.json',base/'research_state/logit-z-preparation001/objective-eval-tools001/review.json',folder.parent/'attention-math-tools001/review.json',folder.parent/'cache-tools001/review.json',folder.parent/'primitive-tools001/review.json'")
s=change(s,"  z_guard=b'", "  null_guard=b'    from ..models.null_attention import validate_null_attention_load\\n    validate_null_attention_load(model, checkpoint)\\n'\n  assert current.count(null_guard)==1;current=current.replace(null_guard,b'',1)\n  z_guard=b'")
# Explicit historical failures are preserved; none is attributed to fresh null CPU/pilots.
s=change(s,"for rel in ['position-quality-preparation001/mps-pilots001/failure.json'", "for rel in ['logit-z-preparation001/cpu-watchdog-repair001/review.json','logit-z-preparation001/cpu-scratch-isolation-repair001/review.json','logit-z-preparation001/cpu-review.json','logit-z-preparation001/prerequisite-metadata-repair001/review.json','logit-z-preparation001/prerequisite-audit-first.log','logit-z-preparation001/pilot-tools001/review-prerequisites001.py','position-quality-preparation001/mps-pilots001/failure.json'")
s=change(s,"source/'src/train/train.py',source/'src/models/logit_z.py'","source/'src/train/train.py',source/'src/models/null_attention.py',source/'src/attention/mha.py',source/'src/models/logit_z.py'")
s=change(s," assert row['logit_z_kind']==f", " assert row['logit_z_kind']==objective_kind")
s=change(s," assert set(shapes)==set(names)",indent(null_guard,1)+" assert row['null_attention_kind']==f and row['null_attention_policy']==NULL_POLICY and row['null_attention_convention']==NULL_CONVENTION\n assert set(shapes)==set(names)")
s=change(s,"  if f=='none':","  if objective_kind=='none':")
s=change(s,"load_model_weights(model,saved);finite(saved);validate_logit_z_model(model)","load_model_weights(model,saved);finite(saved);validate_logit_z_model(model);validate_null_attention_model(model)")
s=change(s," assert graph_review['width']==w and graph_review['objective_kind']==f", " assert graph_review['width']==w and graph_review['null_kind']==f and graph_review['objective_kind']==objective_kind\n assert cache_result['null_kind']==f and cache_result['attention_output_links']==row['cache_attention_output_links']==4\n assert cache_result['independently_reconstructed_attention_outputs']==row['cache_attention_outputs']==108\n assert cache_result['attention_checkpoint_tensors']==16 and cache_result['output_projection_checkpoint_tensors']==8\n assert row['null_primitive_sha256']==file_digest(args.pilots/'null-primitive-check.pt')\n assert row['null_primitive_review_sha256']==file_digest(args.pilots/'null-primitive-review.json')")
s=change(s,"artifacts.extend([primitive_path,args.pilots/'primitive-review.json'])", "artifacts.extend([primitive_path,args.pilots/'primitive-review.json'])\nnull_primitive_path=args.pilots/'null-primitive-check.pt';null_primitive=torch.load(null_primitive_path,map_location='cpu',weights_only=True);finite(null_primitive)\nnull_primitive_review=helpers['null_primitive_audit'].verify(numpy_tree(null_primitive))\nassert null_primitive_review==json.loads((args.pilots/'null-primitive-review.json').read_text())\nartifacts.extend([null_primitive_path,args.pilots/'null-primitive-review.json'])")
s=s.replace("count=(12 if f=='none' else 9) if w==64 else (6 if f=='none' else 3)","count=(12 if f=='standard' else 9) if w==64 else (6 if f=='standard' else 3)")
s=s.replace('Logit-z resource forecast','Null-attention resource forecast')
s=change(s,"independent_objective_primitive=primitive_review,","independent_objective_primitive=primitive_review,independent_null_attention_primitive=null_primitive_review,")
s=s.replace('Full5973 CPU cases:15 actual geometry/evaluator,12 trainer/resume and256 metadata cases included','Full5973 CPU cases:16 actual geometry/evaluator,12 trainer/resume and256 metadata cases included')
s=s.replace('MPS none/z1e4/z1e3','MPS standard/prefix_control/null_zero')
s=s.replace('position/value/gain inherited independently of objective family','objective/position/value/gain inherited independently of null-attention family')
s=s.replace('Final independently audited position decision','Final independently audited logit-z decision')
s=s.replace('Cached/full/token/uneven/reset/interleaved and absolute117offset checks; checkpoint QKV/RoPE or unrotated cache reconstruction; corrected declared FP32 frequency oracle, no tolerance relaxation','Cached/full/token/uneven/reset/interleaved and absolute117offset:96 real KV prefixes and108 independently reconstructed attention outputs with visible-prefix counts, fixedzero null and4 input/output links; corrected declared FP32 frequency oracle, no tolerance relaxation')
s=change(s," 'Six separate synthetic pure-CE forwards", " 'Once-round45 null primitive rows verify probability/value/score gradients, zero-score control, extreme logits and common-real-score shifts at frozen CPU-equivalent tolerances',\n 'Six separate synthetic pure-CE forwards")
s=change(s,"dict.fromkeys(artifacts+[folder.parent/'prerequisite-metadata-repair001/review.json',folder.parent/'prerequisite-audit-first.log',folder/'review-prerequisites001.py'])","dict.fromkeys(artifacts)")
(F/'review-prerequisites001.py').write_text(s)
s=(Z/'preflight.py').read_text().replace('logit-z','null-attention').replace('5689','5973').replace('5662','5945').replace('535','256').replace('actual_tests=27','actual_tests=28').replace('actual_logit_z','actual_null_attention').replace('logit_z_metadata','null_attention_metadata').replace("geometry_tests_passed')!=15","geometry_tests_passed')!=16")
(F/'preflight.py').write_text(s)
for name,origin in [('resource-gate.py',P/'resource-tools001/resource-gate.py'),('pilot-geometry.py',Z/'pilot-geometry.py'),('prior-audit.py',Z/'prior-audit.py')]:
 (F/name).write_bytes(origin.read_bytes())
# Adapt metadata tests to the new consumer; no actual driver/reviewer invocation.
s=(Z/'test_guard_contracts.py').read_text()
for a,b in [('logit-pilot-metadata','null-pilot-metadata'),('5689','5973'),('5688','5972'),('5662','5945'),('5661','5944'),('535','256'),('534','255'),('actual_tests=27','actual_tests=28'),("('actual_tests',26)","('actual_tests',27)"),('actual_logit_z','actual_null_attention'),('logit_z_metadata','null_attention_metadata'),('geometry_tests_passed=15','geometry_tests_passed=16'),("geometry_tests_passed',14","geometry_tests_passed',15"),('Completed reviewed position-family','Completed reviewed logit-z'),('logit_z_study as study','null_attention_study as study'),('9491','9517'),('logit_z_signature==(f,COEFFICIENTS[f],Z_POLICY,CONVENTION)','logit_z_signature==(objective_kind,COEFFICIENTS[objective_kind],Z_POLICY,CONVENTION)'),("count=(12 if f=='none' else 9) if w==64 else (6 if f=='none' else 3)","count=(12 if f=='standard' else 9) if w==64 else (6 if f=='standard' else 3)")]:s=s.replace(a,b)
s=change(s,"  self.assertIn('trainer_changed=True',s)","  self.assertIn('trainer_changed=True',s)\n  self.assertIn(\"graph_checks.append(dict(graph_review,family=f))\",s)\n  self.assertNotIn('dict(width=w,family=f,**graph_review)',s)\n  self.assertIn(\"cache_result['independently_reconstructed_attention_outputs']==row['cache_attention_outputs']==108\",s)")
s=change(s,"   self.assertIn(\"helpers['evaluation_audit'].primitive\",s)","   self.assertIn(\"helpers['evaluation_audit'].primitive\",s)\n   self.assertIn(\"helpers['null_primitive_audit'].verify\",s)\n   self.assertIn(\"null_attention_signature==(f,NULL_POLICY,NULL_CONVENTION)\",s)\n   self.assertIn(\"del cfg.model.null_attention_policy\",s)\n   self.assertIn(\"Changed constructed null normalization accepted\",s)\n   self.assertNotIn('logit_z_kind=f',s)")
s=change(s,"  self.assertNotIn('_launch',ast.unparse(primitive))","  self.assertNotIn('_launch',ast.unparse(primitive))\n  self.assertEqual(sum(isinstance(n,ast.Call) and ast.unparse(n.func)==\"helpers['null_primitive_capture'].capture\" for n in ast.walk(main)),1)\n  self.assertIn(\"helpers['null_primitive_capture'].capture()\",ast.unparse(primitive))")
s=change(s,"  self.assertLess(order.index(\"torch.save(graph\"),order.index(\"helpers['graph_audit'].verify\"))","  self.assertLess(order.index(\"torch.save(graph\"),order.index(\"helpers['graph_audit'].verify\"))\n  self.assertLess(order.index(\"torch.save(null_primitive\"),order.index(\"helpers['null_primitive_audit'].verify\"))")
(F/'test_guard_contracts.py').write_text(s)
s=(Z/'test_metric_contracts.py').read_text().replace("'f':f","'objective_kind':f")
s=s.replace("cfg.model.logit_z_kind=f;cfg.model.logit_z_coefficient=COEFFICIENTS[f]","cfg.model.logit_z_kind=objective_kind;cfg.model.logit_z_coefficient=COEFFICIENTS[objective_kind]")
(F/'test_metric_contracts.py').write_text(s)
for p in F.glob('*.py'):ast.parse(p.read_text())
print('Parsed',len(list(F.glob('*.py'))),'files; no actual pilot/reviewer invocation')
