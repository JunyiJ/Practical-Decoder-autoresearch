"""New AST-only null semantics, inherited schema and safe-serialization checks."""
import ast,copy,sys,types,unittest
from pathlib import Path
F=Path(__file__).resolve().parent
KINDS=('standard','prefix_control','null_zero')
POLICY='mha4_fixed_null_attention';CONVENTION='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'
class Config(dict):
 def __getattr__(self,k):return self[k]
 def __setattr__(self,k,v):self[k]=v
 def __delattr__(self,k):del self[k]
class Tests(unittest.TestCase):
 def test_same_shape_and_each_constructed_layer_veto_restore(self):
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   tree=ast.parse((F/name).read_text());body=next(n.body for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='f') if name.startswith('pilot') else next(n.body for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='row')
   start=next(i for i,n in enumerate(body) if isinstance(n,ast.Expr) and ast.unparse(n)=='validate_null_attention_model(model)')
   end=next(i for i,n in enumerate(body[start+1:],start+1) if isinstance(n,ast.Expr) and ast.unparse(n)=='validate_null_attention_model(model)')
   code=compile(ast.Module(body=body[start:end+1],type_ignores=[]),'null-guards','exec')
   for f in KINDS:
    cfg=types.SimpleNamespace(model=Config(null_attention_kind=f,null_attention_policy=POLICY))
    blocks=[types.SimpleNamespace(attn=types.SimpleNamespace(null_attention_kind=f,null_attention_signature=(f,POLICY,CONVENTION))) for _ in range(4)]
    model=types.SimpleNamespace(null_attention_signature=(f,POLICY,CONVENTION),transformer=types.SimpleNamespace(h=blocks));calls=[]
    def load(m,cp):
     calls.append(1)
     if cfg.model.get('null_attention_kind')!=f or cfg.model.get('null_attention_policy')!=POLICY or any(b.attn.null_attention_kind!=f for b in blocks):raise ValueError('synthetic semantic mismatch')
    env=dict(f=f,cfg=cfg,model=model,cp={'model_state':{'transformer.h.0.attn.qkv.weight':None}},NULL_POLICY=POLICY,NULL_CONVENTION=CONVENTION,NULL_STATE=('null_key','null_value','null_logit','null_attention_state'),validate_null_attention_model=lambda m:None,load_model_weights=load)
    exec(code,env);self.assertEqual(len(calls),6);self.assertEqual(cfg.model,dict(null_attention_kind=f,null_attention_policy=POLICY));self.assertTrue(all(b.attn.null_attention_kind==f for b in blocks))
    bad=dict(env,load_model_weights=lambda m,c:None)
    with self.assertRaises(AssertionError):exec(code,bad)
 def test_numpy_capture_payload_converted_before_safe_load(self):
  tree=ast.parse((F/'pilot-driver001.py').read_text());fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='tensor_tree')
  class Array:
   def __init__(self,v):self.v=v
   def copy(self):return Array(self.v)
  module=types.ModuleType('numpy');module.ndarray=Array
  prior=sys.modules.get('numpy');sys.modules['numpy']=module
  calls=[]
  def convert(a):calls.append(a);return ('synthetic_cpu_tensor',a.v)
  env={'torch':types.SimpleNamespace(from_numpy=convert)}
  try:
   exec(compile(ast.Module(body=[fn],type_ignores=[]),'tensor-only-serializer','exec'),env)
   a=Array(3);result=env['tensor_tree']({'rows':[{'scores':a,'visible':Array(True),'kind':'null_zero'}],'ok':True})
   self.assertEqual(result,{'rows':[{'scores':('synthetic_cpu_tensor',3),'visible':('synthetic_cpu_tensor',True),'kind':'null_zero'}],'ok':True});self.assertIsNot(calls[0],a)
  finally:
   if prior is None:sys.modules.pop('numpy',None)
   else:sys.modules['numpy']=prior
  text=ast.unparse(tree);self.assertLess(text.index('null_primitive = tensor_tree(null_primitive)'),text.index("torch.save(null_primitive"))
  reviewer=(F/'review-prerequisites001.py').read_text();self.assertIn('torch.load(null_primitive_path,map_location=\'cpu\',weights_only=True)',reviewer)
 def test_graph_summary_keeps_independent_null_and_objective(self):
  tree=ast.parse((F/'review-prerequisites001.py').read_text());loop=next(n for n in tree.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='row')
  predicate=next(n for n in loop.body if isinstance(n,ast.Assert) and "graph_review['width']" in ast.unparse(n))
  code=compile(ast.Module(body=[predicate],type_ignores=[]),'graph-summary-schema','exec')
  for w in (64,256):
   for kind in KINDS:
    for objective in ('none','z1e4','z1e3'):
     g=dict(width=w,null_kind=kind,objective_kind=objective);env=dict(w=w,f=kind,objective_kind=objective,graph_review=g);exec(code,env)
     for key,value in [('width',w*2),('null_kind','wrong'),('objective_kind','wrong')]:
      bad=dict(g);bad[key]=value
      with self.assertRaises(AssertionError):exec(code,dict(env,graph_review=bad))
     self.assertEqual(dict(g,family=kind)['width'],w)
if __name__=='__main__':unittest.main(verbosity=2)
