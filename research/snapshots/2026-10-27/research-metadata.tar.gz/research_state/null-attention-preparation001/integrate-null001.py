from pathlib import Path
import json,hashlib,ast,subprocess,shutil,datetime,importlib.util
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');D=Path('/private/tmp/rsi-null-attention-development001');P=B/'research_state/null-attention-preparation001';T=P/'cpu-tools001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2,allow_nan=False)+'\n');p.chmod(0o444)
now=datetime.datetime.now(datetime.timezone.utc).isoformat();base='2f69633da1a2c560952b1738db2c47a0927e9133'
for root in (B,S):assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==base
active=json.loads((B/'research_state/active-campaign.json').read_text());assert active['kind']=='logit_z' and active['status']=='completed_reviewed'
run=Path(active['campaign']);r=json.loads((run/'review.json').read_text());assert r['status']=='verified' and r['distinct_trajectories']==36
assert json.loads((run/'state.json').read_text())['status']=='completed'
import sys
sys.path.insert(0,str(T));from bounded_cpu import live_model_commands
assert not live_model_commands(subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),{__import__('os').getpid(),__import__('os').getppid()})
prior=json.loads((P/'prototype-review003.json').read_text());files=[]
for x in prior['files']:
 f=x['path'];src=D/f;dst=S/f
 if f.endswith('.py'):ast.parse(src.read_text());assert sha(src)==x['sha256']
 else:assert f=='research/NULL_ATTENTION_PROTOCOL.md' and sha(P/'pre-integration-original-protocol.md')==x['sha256']
 assert (sha(dst) if dst.exists() else None)==x['base_sha256'],f
 files.append(dict(path=f,sha256=sha(src),base_sha256=x['base_sha256']))
manual=dict(status='manual_source_and_scaling_reviewed_before_actual_cpu',at=now,files=files,production_matches_capsule003=True,protocol_change='Status prose only; original preserved. All14 Python files unchanged.',checks=['Fixed zero score appended after content/position/causal masking; joint softmax includes null in numerical stabilization. Prefix count uses actual real visibility, no null cache slot.','Legacy standard exact softmax path; no learned parameters/init calls/buffers. Inherited Muon/AdamW grouping, width factors, independent decay and H200 unchanged by source inspection; actual tests still required.','Strict inherited objective/position/value/gain and constructed/current/saved/deletion guards. Null family changes normalization only; same-shaped checkpoint swaps rejected.','All16 geometry/primitive/evaluator and12 trainer tests reviewed: independent exp/sum and all-parameter graph, prefix/null score/value VJP, cache prefix/offset/future causality, standard historical identity, objective/evaluator separation, resume1/4/6 and passive H200/private RNG. Assertions unexecuted at this record.','Finite18+18/24 controller, final-only logit resolver and independent report audit reviewed against prior implementation; no alternate promotion, threshold/grid/holdout change.','No generic old policy relaxation. Research and pilot limits unchanged.'],predecessor=art(run/'review.json'),resolved_predecessor=art(P/'resolved-final-predecessor001.json'),limitations=['No empirical null benefit or actual CPU/MPS pass claimed. Independent null-aware MPS full graph/cache math remains required.'])
write(P/'manual-source-review001.json',manual)
assert 'Ran 2 tests' in (T/'recorder-first.log').read_text() and '\nOK' in (T/'recorder-first.log').read_text()
assert 'Ran 2 tests' in (T/'driver-first.log').read_text() and '\nOK' in (T/'driver-first.log').read_text()
for name in ('bounded_cpu.py','process_guard.py'):assert sha(T/name)==sha(B/'research_state/logit-z-preparation001/cpu-tools003'/name)
for p in T.glob('*.py'):ast.parse(p.read_text())
write(T/'review.json',dict(status='prepared_fresh_serial_cpu_driver_and_recorder',at=now,metadata_methods_passed=4,recorder_corruptions=16,predecessor_guard_rejections=2,guarded_dispatch='AST execution with stubbed child API only; no actual model subprocess yet',corrected_helpers_byteidentical=True,reuse_manifest=art(T/'reuse-manifest.json'),budget=art(T/'prospective-cpu-wall-budget001.json'),expected_total=5973,expected_actual=28,expected_remaining=5945,expected_metadata=256,actual_collection_not_executed=True,artifacts=[art(p) for p in sorted(T.iterdir()) if p.is_file()]))
for x in files:
 f=x['path'];dst=S/f;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/f,dst);assert sha(dst)==x['sha256']
paths=sorted((S/'src').rglob('*.py'))+[S/'requirements.txt'];mapping={str(p.relative_to(S)):sha(p) for p in paths};digest=hashlib.sha256(json.dumps(mapping,sort_keys=True,allow_nan=False).encode()).hexdigest()
review=dict(status='integrated_after_final_predecessor_review',at=now,source_sha256=digest,base_commit=base,files=files,manual_review=str(P/'manual-source-review001.json'),predecessor_review=str(run/'review.json'),predecessor_review_sha256=sha(run/'review.json'),actual_model_tests_executed=False)
write(P/'integration-review.json',review)
spec=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);bank=m.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Null-attention source reviewed and integrated with repaired fresh CPU monitoring',summary='15 reviewed files integrated after final logit audit/docs. Corrected race-safe lstat and owned-process cleanup reused byte-identically, fresh scratch excludes old failed roots. Four metadata test methods passed; expected5973 cases including28 actual await collection/execution. Prospective CPU900/6000-second caps; research/pilot caps unchanged.',outcome='untried',created_by='continuing-quality-research',related_ids=['kb_0ed6e0302ec45c8d396fa7584f3b97638cced38c7f86aaad41fe31de5a2ba352','kb_78ee39c6d3c927c76877e8f4559b47919fe4e794295b07fb200db9f4728de1c6'],artifacts=[art(P/'manual-source-review001.json'),art(P/'integration-review.json'),art(T/'review.json')],details=dict(integration=review,cpu_tools=json.loads((T/'review.json').read_text()))))
write(P/'integration-knowledge001.json',dict(id=kid));write(P/'full-knowledge-snapshot005.md',bank.export_markdown())
before=P/'integration-state-before001';before.mkdir()
for name in ('quality-evolution-progress.json','research-monitor.json'):
 p=B/'research_state'/name;old=p.read_text();write(before/name,old);x=json.loads(old)
 x.setdefault('metadata_history',[]).append(dict(at=now,reason='Null source integrated after final logit closure; CPU gate prepared, not yet executed',before=art(before/name),previous_next_preparation=x.get('next_preparation')))
 x['next_stage']='validate_null_attention_actual28_then_full_bounded_cpu';x['next_preparation']=dict(stage='null_attention',status='integrated_cpu_prepared',path=str(P),development=str(D),review=str(P/'integration-review.json'),source_integrated=True,source_sha256=digest,metadata_unique_passed=256,actual_cases_ast_counted=28,actual_cases_collected=False,model_tests_executed=False,full_regression_passed=False,research_registered=False,inheritance_pending_final_logit_z=False,knowledge_id=kid,cpu_driver=str(T/'run-cpu-validation001.py'),cpu_recorder=str(T/'record-cpu-review001.py'))
 tmp=p.with_suffix('.tmp-null-integration');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
for p in T.iterdir():
 if p.is_file():p.chmod(0o444)
shutil.copyfile(__file__,P/'integrate-null001.py');(P/'integrate-null001.py').chmod(0o444)
print(json.dumps(dict(status='integrated',source_sha256=digest,knowledge_id=kid,files=len(files))))
