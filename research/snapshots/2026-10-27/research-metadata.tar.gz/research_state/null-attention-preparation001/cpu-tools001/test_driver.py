import ast,unittest
from pathlib import Path
class Driver(unittest.TestCase):
 def test_fresh_guarded_dispatch(self):
  tree=ast.parse(Path(__file__).with_name('run-cpu-validation001.py').read_text())
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='execute')
  calls=[]
  def guard(*a):calls.append(a);a[-1](123);a[-1](None);return 0,1.
  class Sys:executable='python'
  ns=dict(guarded_execute=guard,sys=Sys,wrapper='wrapper',ROOT='root',env={},record={},save=lambda:None)
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'<isolated>','exec'),ns)
  self.assertEqual(ns['execute'](['one'], 'log',12,'fresh/batch'),(0,1.))
  self.assertEqual(calls[0][:6],(['python','-u','-c','wrapper','one'],'root',{},'log',12,'fresh/batch'))
  self.assertIsNone(ns['record']['active_pid'])
 def test_predecessor_guards(self):
  t=ast.parse(Path(__file__).with_name('run-cpu-validation001.py').read_text())
  n=next(n for n in t.body if isinstance(n,ast.If) and 'completed_reviewed' in ast.unparse(n.test))
  for active in (dict(kind='logit_z',status='running'),dict(kind='position_quality',status='completed_reviewed')):
   with self.assertRaises(ValueError):exec(compile(ast.Module(body=[n],type_ignores=[]),'<guard>','exec'),{'active':active})
  exec(compile(ast.Module(body=[n],type_ignores=[]),'<guard>','exec'),{'active':dict(kind='logit_z',status='completed_reviewed')})
if __name__=='__main__':unittest.main(verbosity=2)
