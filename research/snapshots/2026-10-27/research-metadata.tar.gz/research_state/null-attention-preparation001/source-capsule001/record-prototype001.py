import ast,datetime,difflib,hashlib,importlib.util,json,shutil,subprocess,tarfile
from pathlib import Path
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');D=Path('/private/tmp/rsi-null-attention-development001');P=B/'research_state/null-attention-preparation001';C=P/'source-capsule001'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();commit='37c3150d946c1d4884e88d48021b36801d626465'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p
 p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2,allow_nan=False)+'\n');p.chmod(0o444)
assert not C.exists() and not (P/'prototype-review001.json').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
a=json.loads((B/'research_state/active-campaign.json').read_text());assert a['status']=='running' and a['kind']=='logit_z' and a['source_commit']==commit
files=['src/models/null_attention.py','src/attention/mha.py','src/models/gpt.py','src/train/optimizers.py','src/utils/checkpoint.py','tests/test_null_attention_contract.py','research/NULL_ATTENTION_PROTOCOL.md']
log=(P/'metadata-first.log').read_text();assert 'Ran 117 tests in 0.075s' in log and log.rstrip().endswith('OK') and 'FAIL' not in log and 'ERROR' not in log
for f in files:
 if f.endswith('.py'):ast.parse((D/f).read_text())
patch=''
for f in files:
 old=(S/f).read_text() if (S/f).exists() else ''
 patch+=''.join(difflib.unified_diff(old.splitlines(True),(D/f).read_text().splitlines(True),fromfile='a/'+f if old else '/dev/null',tofile='b/'+f))
C.mkdir();write(C/'prototype001.patch',patch)
check=subprocess.run(['git','apply','--check',str(C/'prototype001.patch')],cwd=S,text=True,capture_output=True);write(C/'unapplied-check.log',check.stdout+check.stderr);assert check.returncode==0
for f in files:
 p=C/'files'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/f,p);p.chmod(0o444)
with tarfile.open(C/'prototype001.tar.gz','w:gz') as t:
 for f in files:t.add(C/'files'/f,arcname=f,recursive=False)
(C/'prototype001.tar.gz').chmod(0o444)
for name in ['build-null-prototype001.py','write-null-tests001.py']:
 shutil.copyfile(Path('/private/tmp')/name,C/name);(C/name).chmod(0o444)
(P/'metadata-first.log').chmod(0o444)
mapping={f:sha(D/f) for f in files if f.startswith('src/')};digest=hashlib.sha256(json.dumps(mapping,sort_keys=True,allow_nan=False).encode()).hexdigest()
review=dict(status='separate_primitive_prototype_metadata_scalar_only',created_at=now,base_commit=commit,development=str(D),source_integrated=False,research_registered=False,files=[dict(path=f,sha256=sha(D/f),base_sha256=sha(S/f) if (S/f).exists() else None) for f in files],changed_production_mapping_sha256=digest,mapping_is_not_full_engine_digest=True,python_files_ast_parsed=6,metadata_scalar_ast_tests=dict(unique_passed=117,seconds=.075,inheritance_routes=81,invalid_config_cases=20,contract_methods=11,independent_scalar_methods=5,independent_scalar_vjp_coordinates=24,tensor_imports_blocked=True,production_tensor_primitive_executed=False),manual_source_review=['Five production files: new narrow contract/primitive plus fusedMHA/GPT/optimizer/checkpoint wiring; no generic legacy relaxation.','Inherited explicit logit objective must be present; null family never overwrites objective, position, value or gain. Final-only predecessor resolver remains unimplemented; screening cannot resolve the next recipe.','Standard arithmetic remains exact torch.softmax on masked scores; no prefix count/null tensor operation in that branch. Metadata signatures add no learned state or init draw by inspection; actual model proof pending.','Prefix count uses bool real causal visibility mask after cached-prefix slicing, not chunk size. Null zero column appended after inherited scale, position bias and causal mask; softmax jointly stabilizes all columns.','No cached null KV/parameter/buffer or attached value change; all four layer signatures/current/saved/deletion/forbidden state guards.','Scalar reference VJP is independent algebra, not execution of production tensor implementation; all actual geometry/cache/trainer/optimizer/MPS checks still required.'],artifacts=[art(C/'prototype001.patch'),art(C/'prototype001.tar.gz'),art(C/'unapplied-check.log'),art(P/'metadata-first.log')],pending=['Actual geometry/full-model gradient/cache/initialization/optimizer tests not yet written or executed.','Actual CPU trainer/resume/H200/privateRNG/pureCE evaluator tests not yet written or executed.','Finite controller/final-only logit predecessor/independent report auditor not implemented.','Pilot/prerequisite/resource/full completion/registration/reporting helpers not implemented.','No full CPU count or wall budget assigned. All actual gates follow current final audit and reviewed integration/clean publication.'],active_source_unchanged=True,primary_human_untouched=True,failures_or_repairs_this_preparation=[])
write(P/'prototype-review001.json',review)
spec=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);bank=m.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Separate null-attention primitive prototype: metadata/scalar checks only',summary='Seven-file unintegrated prototype adds fixed-null/prefix-control normalization with strict inherited objective/backbone contracts. 117 metadata/scalar/AST tests passed first try; no tensor/model/training/MPS execution or quality claim. Standard arithmetic unchanged by inspection. All final inheritance and actual prerequisites remain pending.',outcome='untried',created_by='continuing-quality-research',related_ids=['kb_3b2957dbc4d5a55ce619ac57907de8b0274bb19c7dcb6c025898a25b05c555fa'],artifacts=[art(P/'prototype-review001.json')]+review['artifacts'],details=review))
write(P/'prototype-knowledge001.json',dict(id=kid,created_at=now));write(P/'full-knowledge-snapshot002.md',bank.export_markdown())
before=P/'prototype-metadata-before001';before.mkdir()
for name in ['quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;original=p.read_bytes();(before/name).write_bytes(original);(before/name).chmod(0o444);x=json.loads(original)
 x.setdefault('metadata_history',[]).append(dict(recorded_at=now,reason='Separate null primitive preparation; active logit source/training untouched',previous_next_preparation=x.get('next_preparation'),before=art(before/name)))
 x['next_preparation']=dict(stage='null_attention',status='separate_primitive_prototype_metadata_only',path=str(P),development=str(D),review=str(P/'prototype-review001.json'),knowledge_id=kid,changed_production_mapping_sha256=digest,model_tests_executed=False,source_integrated=False,research_registered=False,inheritance_pending_final_logit_z=True)
 tmp=p.with_suffix('.tmp-null-prototype');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
shutil.copyfile(__file__,C/'record-prototype001.py');(C/'record-prototype001.py').chmod(0o444)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
print(json.dumps(dict(status='prototype_recorded',knowledge_id=kid,source_mapping=digest,snapshot=art(P/'full-knowledge-snapshot002.md'))))
