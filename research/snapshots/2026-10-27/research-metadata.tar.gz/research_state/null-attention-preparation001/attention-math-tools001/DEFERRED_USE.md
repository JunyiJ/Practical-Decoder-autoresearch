# Null attention pilot math: prepared, not actual MPS evidence

The NumPy oracle checks four captured attention forward/backward graphs, including inherited first-value reuse. Install attention capture together with objective and block hooks on the SAME explicit training-objective forward/backward; bind all16 weights,8 RoPE buffers or0 NoPE/ALiBi buffers, and16 graph links to the independently verified derived checkpoint. Pass null_kind explicitly to bind_checkpoint; objective/position/value/gain remain inherited and do not derive from null family.

Standard ordinary softmax, prefix n/(n+1) softmax and fixed-zero-null joint softmax use distinct score VJPs. Prefix uses ordinary-softmax centering before its attenuation; null uses unnormalized real probability mass with the null contribution zero. Null is appended after content/position scaling. FP32 RoPE frequency reconstruction is byte-equivalent AST to the repaired position oracle; tolerances remain1e-4/2e-5 and frequency1e-6.

Three NumPy methods passed2376 directional comparisons across108 null/position/value/width/origin routes with distributed scales, plus zero-content all-scale ALiBi ordering and checkpoint/graph corruption checks. This validates the independent oracle, not actual MPS execution, a complete transformer, quality, speed or all historical steps. Capture is syntax/manual reviewed ONLY and has not run.

Still required: null-aware primitive/extreme/mask/common-shift MPS panel, cached attention weighted-output reconstruction with actual prefix counts, full driver/reviewer and resource gates after CPU completion. Old cache K/V-only oracle cannot by itself establish null normalization. Do not copy ordinary-softmax VJP or count cached chunk length as prefix visibility. No research registration yet.
