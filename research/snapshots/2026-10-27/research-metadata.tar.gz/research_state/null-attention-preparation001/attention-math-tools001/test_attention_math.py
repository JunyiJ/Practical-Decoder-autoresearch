import copy,importlib.util,unittest
from pathlib import Path
import numpy as np
sp=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('attention-math-audit.py'));a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
KINDS=('standard','prefix_control','null_zero')
def frequencies(start,t):
 f=np.float32(1)/np.power(np.float32(10000),np.arange(0,32,2,dtype=np.float32)/np.float32(32))
 z=np.arange(start,start+t,dtype=np.float32)[:,None]*f[None,:];return np.cos(z).astype(np.float64),np.sin(z).astype(np.float64)
def fixture(null='null_zero',value='first_blend',width=64,position='rope',start=0,scale=.5):
 rng=np.random.default_rng(79);rows=[];co,si=frequencies(start,3)
 for i in range(4):
  rows.append(dict(index=i,input=rng.normal(size=(1,3,width)),output_gradient=rng.normal(size=(1,3,width)),qkv_weight=rng.normal(size=(3*width,width))*.1/np.sqrt(width),qkv_bias=rng.normal(size=3*width)*.02,out_weight=rng.normal(size=(width,width))*.3/np.sqrt(width),out_bias=rng.normal(size=width)*.03,cos=co.copy() if position=='rope' else None,sin=si.copy() if position=='rope' else None))
 return dict(null_kind=null,null_policy='mha4_fixed_null_attention',null_convention='final_masked_scores_fixed_zero_null_visible_real_prefix_v1',position_kind=position,start_pos=start,slopes=tuple(2**(-8*(j+1)/(width//32)) for j in range(width//32)) if position=='alibi' else (),value_kind=value,width=width,scale=scale,atol=1e-4,rtol=2e-5,derived_checkpoint_sha256='a'*64,blocks=rows)
def evaluated(p):
 p=copy.deepcopy(p)
 for row,want in zip(p['blocks'],a.expected_graph(p)):row.update({k:v for k,v in want.items() if k not in ('reuse_gradient','mixed_value')})
 return p
def loss(p):return sum(float((v['output']*r['output_gradient']).sum()) for v,r in zip(a.expected_graph(p),p['blocks']))
def state(p):
 s={};co,si=frequencies(0,128)
 for i,row in enumerate(p['blocks']):
  for key,name in [('qkv_weight','attn.qkv.weight'),('qkv_bias','attn.qkv.bias'),('out_weight','attn.out.weight'),('out_bias','attn.out.bias')]:s[f'transformer.h.{i}.{name}']=row[key].copy()
  if p['position_kind']=='rope':s[f'transformer.h.{i}.freq_cos']=co.copy();s[f'transformer.h.{i}.freq_sin']=si.copy()
 return s
class Tests(unittest.TestCase):
 def test_null_position_value_full_vjp(self):
  n=0;routes=0
  for null in KINDS:
   for pos in ('rope','nope','alibi'):
    for value in ('local','local_half','first_blend'):
     for width in (64,256):
      for start in (0,120):
       scale=(.5,1.,2.)[KINDS.index(null)];p=fixture(null,value,width,pos,start,scale);want=a.expected_graph(p);rng=np.random.default_rng(15);routes+=1
       for i in range(4):
        for key in ('input','qkv_weight','qkv_bias','out_weight','out_bias'):
         x=p['blocks'][i][key];d=rng.normal(size=x.shape);d/=np.linalg.norm(d);eps=1e-5
         p['blocks'][i][key]=x+eps*d;plus=loss(p);p['blocks'][i][key]=x-eps*d;minus=loss(p);p['blocks'][i][key]=x
         np.testing.assert_allclose((plus-minus)/(2*eps),(want[i][key+'_gradient']*d).sum(),atol=2e-8,rtol=2e-6);n+=1
       for key in ('qkv_weight','qkv_bias'):
        x=p['blocks'][0][key];d=np.zeros_like(x);d[2*width:]=rng.normal(size=d[2*width:].shape);d/=np.linalg.norm(d);eps=1e-5
        p['blocks'][0][key]=x+eps*d;plus=loss(p);p['blocks'][0][key]=x-eps*d;minus=loss(p);p['blocks'][0][key]=x
        np.testing.assert_allclose((plus-minus)/(2*eps),(want[0][key+'_gradient']*d).sum(),atol=2e-8,rtol=2e-6);n+=1
       if value=='first_blend':
        assert all(np.linalg.norm(v['reuse_gradient'])>0 for v in want[1:])
        row=p['blocks'][0];own=a.forward_vjp(*[row[k] for k in ('input','qkv_weight','qkv_bias','out_weight','out_bias','cos','sin')],scale,row['output_gradient'],value,0,position_kind=pos,start_pos=start,null_kind=null)
        total=sum(v['reuse_gradient'] for v in want[1:]).transpose(0,2,1,3).reshape(1,3,width)
        np.testing.assert_allclose(want[0]['qkv_output_gradient'][...,2*width:]-own['qkv_output_gradient'][...,2*width:],total,atol=1e-14)
       a.verify(evaluated(p))
  assert routes==108 and n==2376
 def test_zero_content_mass_and_alibi_scale_order(self):
  for width in (64,256):
   t=3;x=np.eye(t,width)[None];w=np.zeros((3*width,width));w[2*width:]=np.eye(width);v=x.reshape(1,t,width//32,32).transpose(0,2,1,3)
   for pos in ('nope','alibi'):
    for null in KINDS:
     expected=np.zeros_like(x)
     for h in range(width//32):
      for i in range(t):
       scores=-2**(-8*(h+1)/(width//32))*(i-np.arange(i+1)) if pos=='alibi' else np.zeros(i+1)
       e=np.exp(scores);p=e/(e.sum()+(1 if null=='null_zero' else 0))
       if null=='prefix_control':p*= (i+1)/(i+2)
       expected[0,i,h*32:(h+1)*32]=p@v[0,h,:i+1]
     for scale in (.5,1.,2.):
      out=a.forward_vjp(x,w,np.zeros(3*width),np.eye(width),np.zeros(width),None,None,scale,np.ones_like(x),'local',0,position_kind=pos,start_pos=120,null_kind=null)
      np.testing.assert_allclose(out['output'],expected,atol=1e-15,rtol=1e-15)
 def test_checkpoint_graph_and_null_corruptions(self):
  for null in KINDS:
   for pos in ('rope','nope','alibi'):
    p=evaluated(fixture(null,position=pos,start=120));s=state(p)
    def bind(q,cp=s):return a.bind_checkpoint(q,cp,'a'*64,.5,64,'first_blend',pos,null)
    assert bind(p)['weights']==16
    for field,bad in [('null_kind','wrong'),('null_kind',KINDS[(KINDS.index(null)+1)%3]),('null_policy','wrong'),('null_convention','wrong')]:
     q=copy.deepcopy(p);q[field]=bad
     with self.assertRaises(AssertionError):bind(q)
    for name in ('null_key','null_value','null_logit','null_attention_state','null_attention_kind','null_attention_policy','null_attention_signature'):
     cp=copy.deepcopy(s);cp['transformer.h.0.attn.'+name]=np.zeros(1)
     with self.assertRaises(AssertionError):bind(p,cp)
    for i in range(4):
     for key in ('qkv_weight','qkv_bias','out_weight','out_bias'):
      q=copy.deepcopy(p);q['blocks'][i][key].flat[0]+=1
      with self.assertRaises(AssertionError):bind(q)
    branch=dict(width=64,derived_checkpoint_sha256='a'*64,blocks=[])
    pairs=[('input','ln1_output'),('input_gradient','ln1_gradient'),('output','attention'),('output_gradient','attention_gradient')]
    for i,row in enumerate(p['blocks']):branch['blocks'].append(dict(index=i,**{rhs:row[lhs].copy() for lhs,rhs in pairs}))
    assert a.link_graph(p,branch)['edges']==16
    for i in range(4):
     for _,rhs in pairs:
      q=copy.deepcopy(branch);q['blocks'][i][rhs].flat[0]+=1
      with self.assertRaises(AssertionError):a.link_graph(p,q)
    q=copy.deepcopy(p);row=q['blocks'][0]
    own=a.forward_vjp(*[row[k] for k in ('input','qkv_weight','qkv_bias','out_weight','out_bias','cos','sin')],.5,row['output_gradient'],'first_blend',0,position_kind=pos,start_pos=120,null_kind=null)
    for key in ('input_gradient','qkv_weight_gradient','qkv_bias_gradient','qkv_output_gradient'):row[key]=own[key]
    with self.assertRaises(AssertionError):a.verify(q)
if __name__=='__main__':unittest.main(verbosity=2)
