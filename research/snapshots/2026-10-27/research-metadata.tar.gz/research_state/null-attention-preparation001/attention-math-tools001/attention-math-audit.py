"""Independent NumPy masked MHA forward/VJP for a saved realized graph.

No model imports, tensors, training or corpus scoring. The caller must bind
weights and RoPE buffers to the derived checkpoint and link this graph to the
captured block graph. Pilot evidence is correctness evidence, never quality. Upper-layer reuse gradients
are summed into the first QKV value slice before its input/parameter VJP.
"""
import numpy as np

def positional_contract(p):
    assert p['position_kind'] in ('rope','nope','alibi')
    assert type(p['start_pos']) is int and 0<=p['start_pos']<128
    h=p['width']//32;assert h in (2,8)
    expected=tuple(2.**(-8.*(j+1)/h) for j in range(h)) if p['position_kind']=='alibi' else ()
    assert tuple(p['slopes'])==expected
    return p['position_kind'],p['start_pos']


def rotate(x,cos,sin,inverse=False):
    cos=cos[None,None,:,:];sin=sin[None,None,:,:]*(-1 if inverse else 1)
    a=x[...,0::2];b=x[...,1::2]
    y=np.empty_like(x);y[...,0::2]=a*cos-b*sin;y[...,1::2]=a*sin+b*cos
    return y

def forward_vjp(x,wq,bq,wo,bo,cos,sin,scale,g,kind,index,first_value=None,first_extra_gradient=None,position_kind="rope",start_pos=0,null_kind="standard"):
    b,t,d=x.shape;h=d//32
    assert d in (64,256) and scale in (1.,.5,2.) and t>0
    assert wq.shape==(3*d,d) and bq.shape==(3*d,) and wo.shape==(d,d) and bo.shape==(d,)
    assert position_kind in ('rope','nope','alibi') and type(start_pos) is int and 0<=start_pos and start_pos+t<=128
    assert g.shape==x.shape
    if position_kind=='rope':assert cos.shape==sin.shape==(t,16)
    else:assert cos is None and sin is None
    qkv=x@wq.T+bq
    q,k,v=[z.reshape(b,t,h,32).transpose(0,2,1,3) for z in np.split(qkv,3,axis=-1)]
    assert kind in ('local','local_half','first_blend') and type(index) is int and 0<=index<4
    raw_value=v.copy()
    if index==0:
        assert first_value is None
    elif kind=='local_half': v=.5*v
    elif kind=='first_blend':
        assert first_value is not None and first_value.shape==v.shape
        v=.5*v+.5*first_value
    qr=rotate(q,cos,sin) if position_kind=="rope" else q;kr=rotate(k,cos,sin) if position_kind=="rope" else k
    logits=(qr@kr.swapaxes(-1,-2))/np.sqrt(32)*scale
    if position_kind=='alibi':
        slopes=np.array([2.**(-8.*(j+1)/h) for j in range(h)])
        positions=np.arange(start_pos,start_pos+t)
        logits=logits-slopes[None,:,None,None]*(positions[:,None]-positions[None,:])
    mask=np.arange(t)[None,:]<=np.arange(t)[:,None]
    logits=np.where(mask,logits,-np.inf)
    assert null_kind in ('standard','prefix_control','null_zero')
    maximum=np.max(logits,axis=-1,keepdims=True)
    if null_kind=='null_zero':maximum=np.maximum(maximum,0.)
    exp=np.exp(logits-maximum);denominator=exp.sum(axis=-1,keepdims=True)
    if null_kind=='null_zero':denominator=denominator+np.exp(-maximum)
    p=exp/denominator
    factor=mask.sum(-1,keepdims=True).astype(np.float64);factor=factor/(factor+1.)
    if null_kind=='prefix_control':p=p*factor
    heads=p@v;y=heads.transpose(0,2,1,3).reshape(b,t,d)
    out=y@wo.T+bo
    dy=(g@wo).reshape(b,t,h,32).transpose(0,2,1,3)
    dp=dy@v.swapaxes(-1,-2);dv=p.swapaxes(-1,-2)@dy
    center=(dp*p).sum(axis=-1,keepdims=True)
    if null_kind=='prefix_control':center=center/factor
    dl=p*(dp-center);dl=np.where(mask,dl,0.)
    dq=(dl@kr)*(scale/np.sqrt(32));dk=(dl.swapaxes(-1,-2)@qr)*(scale/np.sqrt(32))
    if position_kind=='rope':dq=rotate(dq,cos,sin,True);dk=rotate(dk,cos,sin,True)
    reuse_gradient=.5*dv if index>0 and kind=='first_blend' else np.zeros_like(dv)
    dvlocal=.5*dv if index>0 and kind!='local' else dv
    if first_extra_gradient is not None:
        assert index==0 and first_extra_gradient.shape==dv.shape
        dvlocal=dvlocal+first_extra_gradient
    dv=dvlocal
    dqkv=np.concatenate([z.transpose(0,2,1,3).reshape(b,t,d) for z in (dq,dk,dv)],axis=-1)
    return dict(output=out,raw_value=raw_value,mixed_value=v,reuse_gradient=reuse_gradient,qkv_output=qkv,qkv_output_gradient=dqkv,input_gradient=dqkv@wq,
        qkv_weight_gradient=np.einsum('bti,btj->ij',dqkv,x),qkv_bias_gradient=dqkv.sum((0,1)),
        out_weight_gradient=np.einsum('bti,btj->ij',g,y),out_bias_gradient=g.sum((0,1)))

def expected_graph(p):
    assert p['null_kind'] in ('standard','prefix_control','null_zero')
    assert p['null_policy']=='mha4_fixed_null_attention'
    assert p['null_convention']=='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'
    assert p['value_kind'] in ('local','local_half','first_blend')
    position_kind,start_pos=positional_contract(p)
    assert len(p['blocks'])==4
    rows=[];first=None
    for i,row in enumerate(p['blocks']):
        assert row['index']==i
        def arr(k):
            a=np.asarray(row[k],dtype=np.float64);assert np.isfinite(a).all(),k;return a
        x=arr('input');assert x.shape[-1]==p['width']
        if position_kind!='rope':assert row['cos'] is None and row['sin'] is None
        args=[x,arr('qkv_weight'),arr('qkv_bias'),arr('out_weight'),arr('out_bias'),arr('cos') if position_kind=='rope' else None,arr('sin') if position_kind=='rope' else None,p['scale'],arr('output_gradient'),p['value_kind'],i]
        value=forward_vjp(*args,first_value=first if i else None,position_kind=position_kind,start_pos=start_pos,null_kind=p['null_kind'])
        if i==0: first=value['raw_value'];first_args=args
        else: assert value['raw_value'].shape==first.shape
        rows.append(value)
    extra=sum((x['reuse_gradient'] for x in rows[1:]),np.zeros_like(first))
    rows[0]=forward_vjp(*first_args,first_extra_gradient=extra,position_kind=position_kind,start_pos=start_pos,null_kind=p['null_kind'])
    return rows

def verify(p):
    assert p['atol']==1e-4 and p['rtol']==2e-5
    assert p['width'] in (64,256) and p['scale'] in (1.,.5,2.)
    expected=expected_graph(p);errors={}
    for i,(row,want) in enumerate(zip(p['blocks'],expected)):
        for key,value in want.items():
            if key in ('reuse_gradient','mixed_value'): continue
            actual=np.asarray(row[key],dtype=np.float64);assert np.isfinite(actual).all() and actual.shape==value.shape
            np.testing.assert_allclose(actual,value,atol=1e-4,rtol=2e-5,err_msg=f'{i}:{key}')
            errors[f'{i}:{key}']=float(np.max(np.abs(actual-value)))
        t=np.asarray(row['input']).shape[1]
        if p['position_kind']=='rope':
            exponent=np.arange(0,32,2,dtype=np.float32)/np.float32(32)
            frequency=np.float32(1)/np.power(np.float32(10000),exponent)
            angles=np.arange(p['start_pos'],p['start_pos']+t,dtype=np.float32)[:,None]*frequency[None,:]
            np.testing.assert_allclose(row['cos'],np.cos(angles),atol=1e-6,rtol=1e-6)
            np.testing.assert_allclose(row['sin'],np.sin(angles),atol=1e-6,rtol=1e-6)
    return dict(status='verified',null_kind=p['null_kind'],position_kind=p['position_kind'],errors=errors,first_value_gradient_roles=4 if p['value_kind']=='first_blend' else 1,
        scope='Checkpoint-bound fixed-null or visible-prefix normalization; inherited masked attention with attached first-layer raw-value reuse; summed four first-value gradient roles and full QKV/output input/parameter VJP on one saved graph, not a trajectory reconstruction')

def bind_checkpoint(p,state,expected_sha,scale,width,value_kind,position_kind,null_kind):
    assert null_kind in ("standard","prefix_control","null_zero") and p["null_kind"]==null_kind
    assert p["null_policy"]=="mha4_fixed_null_attention"
    assert p["null_convention"]=="final_masked_scores_fixed_zero_null_visible_real_prefix_v1"
    assert not any(any(part in ("null_key","null_value","null_logit","null_attention_state","null_attention_kind","null_attention_policy","null_attention_signature") for part in name.split(".")) for name in state)
    positional_contract(p);assert p["position_kind"]==position_kind
    assert value_kind in ('local','local_half','first_blend') and p['value_kind']==value_kind
    assert p['derived_checkpoint_sha256']==expected_sha and p['scale']==scale and p['width']==width
    assert len(p['blocks'])==4
    for i,row in enumerate(p['blocks']):
        assert row['index']==i
        for key,name in [('qkv_weight','attn.qkv.weight'),('qkv_bias','attn.qkv.bias'),('out_weight','attn.out.weight'),('out_bias','attn.out.bias')]:
            assert np.array_equal(np.asarray(row[key]),np.asarray(state[f'transformer.h.{i}.{name}'])),(i,key)
        t=np.asarray(row['input']).shape[1]
        for key,name in [('cos','freq_cos'),('sin','freq_sin')]:
            state_key=f'transformer.h.{i}.{name}'
            if position_kind=='rope':
                assert np.array_equal(np.asarray(row[key]),np.asarray(state[state_key])[p['start_pos']:p['start_pos']+t]),(i,key)
            else:assert row[key] is None and state_key not in state
        assert not any(k.startswith(f'transformer.h.{i}.attn.') and any(x in k for x in ('position_slopes','alibi_slopes','position_state')) for k in state)
    assert 'transformer.wpe.weight' not in state
    return dict(status='bound',weights=16,rope_buffers=8 if position_kind=="rope" else 0)

def link_graph(p,branch):
    assert p['derived_checkpoint_sha256']==branch['derived_checkpoint_sha256'] and p['width']==branch['width']
    assert len(p['blocks'])==len(branch['blocks'])==4
    for i,(a,b) in enumerate(zip(p['blocks'],branch['blocks'])):
        assert a['index']==b['index']==i
        for lhs,rhs in [('input','ln1_output'),('input_gradient','ln1_gradient'),('output','attention'),('output_gradient','attention_gradient')]:
            x=np.asarray(a[lhs]);y=np.asarray(b[rhs]);assert x.shape==y.shape
            np.testing.assert_allclose(x,y,atol=1e-4,rtol=2e-5,err_msg=f'block{i}:{lhs}')
    return dict(status='linked',edges=16)
