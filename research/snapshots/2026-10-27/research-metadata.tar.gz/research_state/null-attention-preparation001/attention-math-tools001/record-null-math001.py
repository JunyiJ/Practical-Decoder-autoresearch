from pathlib import Path
import ast,json,hashlib,datetime,importlib.util,subprocess,shutil,os
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';T=P/'attention-math-tools001';N=B/'research_state/position-quality-preparation001/pilot-tools002'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2)+'\n');p.chmod(0o444)
now=datetime.datetime.now(datetime.timezone.utc).isoformat();integration=json.loads((P/'integration-review.json').read_text())
for x in integration['files']:assert sha(S/x['path'])==x['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
for p in T.glob('*.py'):ast.parse(p.read_text())
assert 'Ran 3 tests in 6.065s' in (T/'tests-first.log').read_text() and '\nOK' in (T/'tests-first.log').read_text()
# Preserve repaired declared-FP32 frequency oracle exactly.
a=ast.parse((T/'attention-math-audit.py').read_text());old=ast.parse((N/'attention-math-audit.py').read_text())
for tree in (a,old):
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify')
 blocks=[n for n in ast.walk(fn) if isinstance(n,ast.If) and 'position_kind' in ast.unparse(n.test) and "'rope'" in ast.unparse(n.test)]
 assert len(blocks)==1
 if tree is a:new_frequency=ast.dump(blocks[0],include_attributes=False)
 else:assert ast.dump(blocks[0],include_attributes=False)==new_frequency
write(T/'DEFERRED_USE.md','''# Null attention pilot math: prepared, not actual MPS evidence

The NumPy oracle checks four captured attention forward/backward graphs, including inherited first-value reuse. Install attention capture together with objective and block hooks on the SAME explicit training-objective forward/backward; bind all16 weights,8 RoPE buffers or0 NoPE/ALiBi buffers, and16 graph links to the independently verified derived checkpoint. Pass null_kind explicitly to bind_checkpoint; objective/position/value/gain remain inherited and do not derive from null family.

Standard ordinary softmax, prefix n/(n+1) softmax and fixed-zero-null joint softmax use distinct score VJPs. Prefix uses ordinary-softmax centering before its attenuation; null uses unnormalized real probability mass with the null contribution zero. Null is appended after content/position scaling. FP32 RoPE frequency reconstruction is byte-equivalent AST to the repaired position oracle; tolerances remain1e-4/2e-5 and frequency1e-6.

Three NumPy methods passed2376 directional comparisons across108 null/position/value/width/origin routes with distributed scales, plus zero-content all-scale ALiBi ordering and checkpoint/graph corruption checks. This validates the independent oracle, not actual MPS execution, a complete transformer, quality, speed or all historical steps. Capture is syntax/manual reviewed ONLY and has not run.

Still required: null-aware primitive/extreme/mask/common-shift MPS panel, cached attention weighted-output reconstruction with actual prefix counts, full driver/reviewer and resource gates after CPU completion. Old cache K/V-only oracle cannot by itself establish null normalization. Do not copy ordinary-softmax VJP or count cached chunk length as prefix visibility. No research registration yet.
''')
review=dict(status='independent_null_attention_oracle_prepared',at=now,source_sha256=integration['source_sha256'],numpy_methods_passed=3,test_seconds=6.065,directional_comparisons=2376,routes=108,scales_distributed_not_full_cartesian=True,zero_content_all_scale_checks=36,checkpoint_metadata_tensor_graph_corruptions=387,detached_first_value_rejections=9,capture_executed=False,model_or_mps_execution=False,checks=['Joint max includes fixed-zero null; real probability sum can be below one. Prefix VJP divides weighted center by attenuation factor.','QKV/output/allinput/parameter VJP and first-value gradient sum across all4 roles; output projection bias unchanged.','ALiBi fixed power2 bias after content scale; positions0/120, widths64/256, values local/half/blend, all3 normalization kinds.','Exact CP16 weights/8or0frequency buffers,16 block graph edges, forbidden null persistent state and same-shaped semantic-kind mismatch rejection.','Declared FP32 frequency oracle AST identical to repaired position pilot002; no tolerance change.'],limitations=['Only NumPy synthetic proof, no actual MPS/capture/fullmodel quality evidence.','Cached visible-prefix normalization still needs dedicated independent weighted-output audit.','All actual CPU28/full5973 assertions must finish before serial MPS; no competing model work.'],artifacts=[art(p) for p in sorted(T.iterdir()) if p.is_file()],reused_frequency_source=art(N/'attention-math-audit.py'))
write(T/'review.json',review)
sp=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);bank=m.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Independent fixed-null attention graph oracle prepared',summary='Three NumPy methods passed2376 directional checks across108 normalization/position/value/width/origin combinations plus36 analytic mass/ALiBi scale checks and396 corruption rejections. Capture unexecuted; cache normalization and actual MPS gates remain. Integrated source frozen while serial CPU validation runs.',outcome='untried',created_by='continuing-quality-research',related_ids=[json.loads((P/'integration-knowledge001.json').read_text())['id']],artifacts=[art(T/'review.json')]+review['artifacts'],details=review))
write(T/'knowledge.json',dict(id=kid));write(P/'attention-math-knowledge-snapshot001.md',bank.export_markdown())
manifest=json.loads((P/'cpu-execution-manifest.json').read_text());ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True)
rows=[l for l in ps.splitlines() if l.strip().split(None,1)[0] in {str(manifest['pid']),str(manifest.get('active_pid'))}]
obs=dict(at=now,manifest_status=manifest['status'],cpu_driver=manifest['pid'],cpu_worker=manifest.get('active_pid'),process_rows=rows,source_sha256=integration['source_sha256'],all_integrated_hashes_unchanged=True,primary_clean=True,collected=len(manifest['collection']['ids']),closed_batches=len(manifest['batches']),completed_recorded_ids=sum(len(b['expected_ids']) for b in manifest['batches'] if b['exit_code']==0 and 'cleanup' in b),free_gib=shutil.disk_usage('/private/tmp').free/2**30)
write(P/'attention-math-live-observation001.json',obs)
before=P/'attention-math-state-before001';before.mkdir()
for name in ('quality-evolution-progress.json','research-monitor.json'):
 p=B/'research_state'/name;old=p.read_text();write(before/name,old);x=json.loads(old)
 x.setdefault('metadata_history',[]).append(dict(at=now,reason='Null CPU collected5973 and running serially; independent null graph oracle prepared',before=art(before/name)))
 x['next_stage']='complete_null_attention_cpu_and_prepare_null_aware_mps';n=x['next_preparation'];n.update(status='integrated_cpu_running',actual_cases_collected=True,actual_cases_collected_count=28,full_collected=5973,model_tests_executed=True,actual_model_validation_complete=False,full_regression_passed=False,cpu_session=54222,cpu_driver_pid=manifest['pid'],attention_math_tools=str(T),attention_math_knowledge_id=kid,pending=['Actual28 complete and independent subset review','Full5973 exact CPU recorder after terminal manifest','Null-aware primitive/cache/objective/branch MPS packages and six serial pilots/resource audit','Clean publication/fullbank/fresh seeds/unique preregistration'])
 x['latest_null_cpu_observation']=obs
 tmp=p.with_suffix('.tmp-null-math');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
for f in (__file__,'/private/tmp/prepare-null-attention-math001.py'):
 shutil.copyfile(f,T/Path(f).name)
for p in T.iterdir():
 if p.is_file():p.chmod(0o444)
print(json.dumps(dict(knowledge_id=kid,observation=obs)))
