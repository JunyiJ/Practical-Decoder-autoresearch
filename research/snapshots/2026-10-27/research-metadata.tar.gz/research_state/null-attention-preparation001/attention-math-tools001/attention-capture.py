"""Capture actual attention forward/backward for post-worker pilot validation only."""
def install(model):
    assert model.cfg.null_attention_policy=='mha4_fixed_null_attention'
    assert model.cfg.null_attention_kind in ('standard','prefix_control','null_zero')
    rows=[{} for _ in model.transformer.h];hooks=[]
    for i,b in enumerate(model.transformer.h):
        assert b.attn.null_attention_kind==model.cfg.null_attention_kind
        assert b.attn.null_attention_signature==(model.cfg.null_attention_kind,'mha4_fixed_null_attention','final_masked_scores_fixed_zero_null_visible_real_prefix_v1')
        assert b.attn.q_norm is None and b.attn.k_norm is None and b.attn.output_gate is None
        assert b.attn.causal and b.attn.head_dim==32 and b.attn.attn_dropout.p==b.attn.out_dropout.p==0
        def capture(module,inputs,kwargs,output,i=i):
            assert kwargs.get('cache') is None and kwargs.get('start_pos',0)==0 and len(inputs)==1, 'Capture requires uncached zero-offset graph'
            inputs[0].retain_grad();output[0].retain_grad();rows[i].update(input=inputs[0],output=output[0])
        hooks.append(b.attn.register_forward_hook(capture,with_kwargs=True))
        def capture_qkv(module,inputs,output,i=i):
            output.retain_grad();rows[i]['qkv_output']=output
        hooks.append(b.attn.qkv.register_forward_hook(capture_qkv))
    return rows,hooks

def export(model,rows,derived_sha):
    result=[]
    for i,(b,t) in enumerate(zip(model.transformer.h,rows)):
        r=dict(index=i)
        for k,v in t.items():
            assert v.grad is not None;r[k]=v.detach().cpu();r[k+'_gradient']=v.grad.detach().cpu()
        for k,v in [('qkv_weight',b.attn.qkv.weight),('qkv_bias',b.attn.qkv.bias),('out_weight',b.attn.out.weight),('out_bias',b.attn.out.bias)]:
            assert v.grad is not None;r[k]=v.detach().cpu();r[k+'_gradient']=v.grad.detach().cpu()
        packed=t['qkv_output'];bs,ts,dd=t['input'].shape
        r['raw_value']=packed[...,2*dd:].reshape(bs,ts,dd//32,32).transpose(1,2).detach().cpu()
        tlen=t['input'].shape[1]
        if b.attn.position_family_kind=='rope':
            r['cos']=b.freq_cos[:tlen].detach().cpu();r['sin']=b.freq_sin[:tlen].detach().cpu()
        else:
            assert b.freq_cos is None and b.freq_sin is None;r['cos']=r['sin']=None
        result.append(r)
    scales={b.attn.attention_logit_scale for b in model.transformer.h};assert len(scales)==1
    kinds={b.attn.value_residual_kind for b in model.transformer.h};assert len(kinds)==1
    positions={b.attn.position_family_kind for b in model.transformer.h};assert len(positions)==1
    slopes={b.attn.position_slopes for b in model.transformer.h};assert len(slopes)==1
    return dict(null_kind=model.cfg.null_attention_kind,null_policy=model.cfg.null_attention_policy,null_convention='final_masked_scores_fixed_zero_null_visible_real_prefix_v1',position_kind=positions.pop(),slopes=slopes.pop(),start_pos=0,value_kind=kinds.pop(),scale=scales.pop(),width=model.cfg.dim,derived_checkpoint_sha256=derived_sha,atol=1e-4,rtol=2e-5,blocks=result)
