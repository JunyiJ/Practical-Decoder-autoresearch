"""Independent NumPy audit of saved value-reuse cache evidence; no model imports.

QKV and mixed cached values are reconstructed from checkpoint weights and captured
normalized inputs. Full/cached input and output agreement is checked separately;
this is not a second full-transformer implementation or performance benchmark.
"""
import numpy as np

def schedule():
    return [('token','X','A',1)]*11+[('uneven','X','A',n) for n in (5,3,3)]+[
        ('interleaved',slot,seq,n) for n in (2,1,8) for slot,seq in [('X','A'),('Y','B')]]+[
        ('reset','X','A',5),('reset','X','A',6),('reset','X','RESET',0),('reset','X','B',4),('reset','X','B',7)]

def close(actual,want):
    a=np.asarray(actual);b=np.asarray(want)
    assert a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    np.testing.assert_allclose(a,b,atol=1e-4,rtol=2e-5)
    return float(np.max(np.abs(a-b))) if a.size else 0.

def projected(inputs,state,start,kind,width,position):
    assert position in ('rope','nope','alibi') and type(start) is int and 0<=start<128
    rows=[];first=None
    for i,x in enumerate(inputs):
        x=np.asarray(x,dtype=np.float64);b,t,d=x.shape;assert b==2 and d==width
        key=f'transformer.h.{i}.'
        w=np.asarray(state[key+'attn.qkv.weight'],dtype=np.float64);bias=np.asarray(state[key+'attn.qkv.bias'],dtype=np.float64)
        assert w.shape==(3*d,d) and bias.shape==(3*d,)
        qkv=x@w.T+bias
        _,k,v=[z.reshape(b,t,d//32,32).transpose(0,2,1,3) for z in np.split(qkv,3,-1)]
        if i==0:first=v.copy()
        elif kind=='local_half':v=.5*v
        elif kind=='first_blend':v=.5*v+.5*first
        if position=='rope':
            c=np.asarray(state[key+'freq_cos'])[start:start+t];s=np.asarray(state[key+'freq_sin'])[start:start+t]
            exponent=np.arange(0,32,2,dtype=np.float32)/np.float32(32)
            frequency=np.float32(1)/np.power(np.float32(10000),exponent)
            angles=np.arange(start,start+t,dtype=np.float32)[:,None]*frequency[None,:]
            np.testing.assert_allclose(c,np.cos(angles),atol=1e-6,rtol=1e-6)
            np.testing.assert_allclose(s,np.sin(angles),atol=1e-6,rtol=1e-6)
            a=k[...,0::2];z=k[...,1::2];rot=np.empty_like(k)
            rot[...,0::2]=a*c-z*s;rot[...,1::2]=a*s+z*c
        else:
            assert key+'freq_cos' not in state and key+'freq_sin' not in state
            rot=k
        rows.append((rot,v))
    assert len(rows)==4
    return rows

def verify_real_cache(p,state,checkpoint_sha,width,kind,tokens,attention=None,*,position):
    assert position in ('rope','nope','alibi') and p['position_kind']==position
    slopes=tuple(2.**(-8.*(j+1)/(width//32)) for j in range(width//32)) if position=='alibi' else ()
    assert tuple(p['slopes'])==slopes
    assert 'transformer.wpe.weight' not in state
    assert not any(any(x in k for x in ('position_slopes','alibi_slopes','position_state')) for k in state)
    assert p['derived_checkpoint_sha256']==checkpoint_sha and p['width']==width
    assert kind in ('local','local_half','first_blend') and p['value_kind']==kind
    assert (p['capacity'],p['batch_size'],p['head_dim'],p['dtype'])==(128,2,32,'float32')
    assert p['atol']==1e-4 and p['rtol']==2e-5
    assert p['cache_bytes']==4*2*2*128*width*4
    refs=p['references'];assert set(refs)=={'A','B'}
    tokens=np.asarray(tokens);assert tokens.shape==(2,11) and np.issubdtype(tokens.dtype,np.integer)
    assert np.array_equal(refs['A']['tokens'],tokens) and np.array_equal(refs['B']['tokens'],(tokens+17)%65)
    full={}
    for name,ref in refs.items():
        assert np.asarray(ref['logits']).shape==(2,11,65) and np.isfinite(ref['logits']).all()
        assert len(ref['inputs'])==4 and all(np.asarray(x).shape==(2,11,width) for x in ref['inputs'])
        full[name]=projected(ref['inputs'],state,0,kind,width,position)
    offset=p['offset_reference'];assert offset['start']==117 and np.array_equal(offset['tokens'],tokens)
    close(offset['logits'],refs['A']['logits']);assert len(offset['inputs'])==4
    for x,y in zip(offset['inputs'],refs['A']['inputs']):close(x,y)
    projected(offset['inputs'],state,117,kind,width,position)
    if attention is not None:
        assert attention['position_kind']==position and tuple(attention['slopes'])==slopes and attention['start_pos']==0
        assert attention['derived_checkpoint_sha256']==checkpoint_sha and attention['value_kind']==kind and attention['width']==width
        assert len(attention['blocks'])==4
        for i,row in enumerate(attention['blocks']):
            assert row['index']==i
            close(refs['A']['inputs'][i],row['input'])
    expected=schedule();assert len(p['events'])==len(expected)
    positions={};prefix={};sequences={};errors={};reset_count=0;forward_count=0
    for j,(e,route) in enumerate(zip(p['events'],expected)):
        scenario,slot,seq,n=route
        assert (e['scenario'],e['slot'],e['sequence'])==(scenario,slot,seq)
        key=(scenario,slot);start=positions.get(key,0);end=start+n
        if seq=='RESET':
            assert e['start']==e['end']==0 and len(e['cache'])==4
            for i,row in enumerate(e['cache']):
                assert row['index']==i
                for field in ('key','value'):
                    value=np.asarray(row[field]);assert value.shape==(2,width//32,128,32)
                    assert np.isfinite(value).all() and np.count_nonzero(value)==0
            positions[key]=0;prefix.pop(key,None);sequences.pop(key,None);reset_count+=1;continue
        assert e['start']==start and e['end']==end<=11
        assert sequences.get(key,seq)==seq;sequences[key]=seq
        assert len(e['inputs'])==4 and len(e['cache'])==4
        for i,x in enumerate(e['inputs']):errors[f'{j}:input{i}']=close(x,np.asarray(refs[seq]['inputs'][i])[:,start:end])
        errors[f'{j}:logits']=close(e['logits'],np.asarray(refs[seq]['logits'])[:,start:end])
        current=projected(e['inputs'],state,start,kind,width,position)
        cumulative=[]
        for i,((k,v),row) in enumerate(zip(current,e['cache'])):
            assert row['index']==i
            if start:
                oldk,oldv=prefix[key][i];k=np.concatenate([oldk,k],2);v=np.concatenate([oldv,v],2)
            cumulative.append((k,v))
            errors[f'{j}:key{i}']=close(row['key'],k);errors[f'{j}:value{i}']=close(row['value'],v)
            errors[f'{j}:fullkey{i}']=close(row['key'],full[seq][i][0][:,:,:end])
            errors[f'{j}:fullvalue{i}']=close(row['value'],full[seq][i][1][:,:,:end])
        prefix[key]=cumulative;positions[key]=end;forward_count+=1
    assert reset_count==1 and forward_count==24 and all(n==11 for n in positions.values())
    return dict(status='verified',forward_calls=forward_count,reset_events=reset_count,cache_prefixes=4*forward_count,
        qkv_checkpoint_tensors=8,rope_checkpoint_buffers=8 if position=='rope' else 0,absolute_offset=117,position_kind=position,attention_input_links=4 if attention is not None else 0,
        max_abs_error=max(errors.values()),max_logit_error=max(v for k,v in errors.items() if k.endswith(':logits')),
        scope='Full/token/uneven/reset/interleaved saved-logit agreement; checkpoint-bound QKV/RoPE and raw-first-value mixed-cache reconstruction for each prefix; not an independent full-model forward or performance measurement')


POLICY='mha4_fixed_null_attention'
CONVENTION='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'

def attended(x,k,v,state,index,start,key_start,width,position,null_kind,scale):
    """Independent Q/real-KV/output projection, using absolute causal positions.

    Real K/V have already been independently reconstructed, never substituted
    from observed cache bytes. The fixed null score participates in stabilization.
    """
    assert null_kind in ('standard','prefix_control','null_zero')
    assert type(scale) in (int,float) and not isinstance(scale,bool) and scale in (.5,1.,2.)
    x=np.asarray(x,dtype=np.float64);k=np.asarray(k,dtype=np.float64);v=np.asarray(v,dtype=np.float64)
    b,t,d=x.shape;h=width//32;n=k.shape[2]
    assert (b,d)==(2,width) and k.shape==v.shape==(2,h,n,32)
    assert type(start) is int and type(key_start) is int and 0<=key_start<=start and start+t<=128
    pre=f'transformer.h.{index}.'
    w=np.asarray(state[pre+'attn.qkv.weight'],dtype=np.float64);bias=np.asarray(state[pre+'attn.qkv.bias'],dtype=np.float64)
    q=(x@w[:width].T+bias[:width]).reshape(b,t,h,32).transpose(0,2,1,3)
    if position=='rope':
        c=np.asarray(state[pre+'freq_cos'])[start:start+t];s=np.asarray(state[pre+'freq_sin'])[start:start+t]
        even=q[...,0::2];odd=q[...,1::2];rot=np.empty_like(q)
        rot[...,0::2]=even*c-odd*s;rot[...,1::2]=even*s+odd*c;q=rot
    qi=np.arange(start,start+t);ki=np.arange(key_start,key_start+n)
    visible=ki[None,:]<=qi[:,None];counts=visible.sum(-1)
    assert (counts>0).all()
    scores=(q@k.swapaxes(-1,-2))*(scale/np.sqrt(32.))
    if position=='alibi':
        slopes=np.array([2.**(-8.*(j+1)/h) for j in range(h)])
        scores=scores-slopes[None,:,None,None]*(qi[:,None]-ki[None,:])
    scores=np.where(visible,scores,-np.inf)
    maximum=scores.max(-1,keepdims=True)
    if null_kind=='null_zero':maximum=np.maximum(maximum,0.)
    numer=np.exp(scores-maximum);denom=numer.sum(-1,keepdims=True)
    if null_kind=='null_zero':denom=denom+np.exp(-maximum)
    probabilities=numer/denom
    if null_kind=='prefix_control':probabilities=probabilities*(counts/(counts+1.))[None,None,:,None]
    heads=probabilities@v
    joined=heads.transpose(0,2,1,3).reshape(b,t,width)
    outw=np.asarray(state[pre+'attn.out_proj.weight'],dtype=np.float64)
    outb=np.asarray(state[pre+'attn.out_proj.bias'],dtype=np.float64)
    assert outw.shape==(width,width) and outb.shape==(width,)
    return joined@outw.T+outb

def verify(p,state,checkpoint_sha,width,kind,tokens,attention=None,*,position,null_kind,scale):
    assert p['null_kind']==null_kind and null_kind in ('standard','prefix_control','null_zero')
    assert p['null_policy']==POLICY and p['null_convention']==CONVENTION
    assert p['attention_scale']==scale and type(p['attention_scale']) in (int,float)
    assert not any(any(part in ('null_key','null_value','null_logit','null_attention_state') for part in key.split('.')) for key in state)
    result=verify_real_cache(p,state,checkpoint_sha,width,kind,tokens,attention,position=position)
    if attention is not None:
        assert (attention['null_kind'],attention['null_policy'],attention['null_convention'])==(null_kind,POLICY,CONVENTION)
        assert attention['scale']==scale
    errors={};output_links=0
    def check(row,start,key_start,kv,label):
        assert len(row['attention_outputs'])==4
        for i,((k,v),x,actual) in enumerate(zip(kv,row['inputs'],row['attention_outputs'])):
            want=attended(x,k,v,state,i,start,key_start,width,position,null_kind,scale)
            errors[f'{label}:attention{i}']=close(actual,want)
    for name,row in p['references'].items():
        check(row,0,0,projected(row['inputs'],state,0,kind,width,position),'full'+name)
    row=p['offset_reference'];check(row,117,117,projected(row['inputs'],state,117,kind,width,position),'offset117')
    if attention is not None:
        for i,row in enumerate(attention['blocks']):
            errors[f'graph:attention{i}']=close(p['references']['A']['attention_outputs'][i],row['output']);output_links+=1
    prefixes={};calls=0
    for j,row in enumerate(p['events']):
        key=(row['scenario'],row['slot'])
        if row['sequence']=='RESET':prefixes.pop(key,None);continue
        start=row['start'];kv=projected(row['inputs'],state,start,kind,width,position)
        if start:
            kv=[(np.concatenate((oldk,k),2),np.concatenate((oldv,v),2)) for (oldk,oldv),(k,v) in zip(prefixes[key],kv)]
        check(row,start,0,kv,str(j));prefixes[key]=kv;calls+=1
        ref=p['references'][row['sequence']]
        for i,y in enumerate(row['attention_outputs']):errors[f'{j}:fullattention{i}']=close(y,np.asarray(ref['attention_outputs'][i])[:,start:row['end']])
    assert calls==24
    result.update(null_kind=null_kind,null_policy=POLICY,null_convention=CONVENTION,attention_scale=scale,
        output_projection_checkpoint_tensors=8,attention_checkpoint_tensors=16,attention_output_links=output_links,
        independently_reconstructed_attention_outputs=108,weighted_cache_outputs=96,
        max_attention_error=max(errors.values()),scope='Independent checkpoint-bound Q/real K/V/absolute causal normalization and output projection on 2 full,1 offset117 and24 cached calls; captured transformer inputs are observations, not an independent whole-transformer implementation or performance measurement.')
    return result
