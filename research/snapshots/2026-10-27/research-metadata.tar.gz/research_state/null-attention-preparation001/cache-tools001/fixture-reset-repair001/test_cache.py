import ast,copy,importlib.util,unittest
from pathlib import Path
import numpy as np
p=Path(__file__).with_name('cache-audit.py');spec=importlib.util.spec_from_file_location('cache_audit',p);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

def fixture(kind='first_blend',width=64,position='rope',null_kind='null_zero',scale=.5):
    r=np.random.default_rng(739);tokens=np.arange(22).reshape(2,11)%65;state={};refs={}
    freq=np.float32(1)/np.power(np.float32(10000),np.arange(0,32,2,dtype=np.float32)/np.float32(32))
    angles=np.arange(128,dtype=np.float32)[:,None]*freq[None,:]
    for i in range(4):
        pre=f'transformer.h.{i}.'
        state[pre+'attn.qkv.weight']=r.normal(size=(3*width,width))*.1/np.sqrt(width)
        state[pre+'attn.qkv.bias']=r.normal(size=3*width)*.03
        state[pre+'attn.out.weight']=r.normal(size=(width,width))/np.sqrt(width)
        state[pre+'attn.out.bias']=r.normal(size=width)*.2
        if position=='rope':state[pre+'freq_cos']=np.cos(angles);state[pre+'freq_sin']=np.sin(angles)
    def oracle(inputs):
        result=[];first=None
        for i,x in enumerate(inputs):
            pre=f'transformer.h.{i}.';packed=np.einsum('btd,od->bto',x,state[pre+'attn.qkv.weight'])+state[pre+'attn.qkv.bias']
            raw=packed[...,2*width:].reshape(2,11,width//32,32).transpose(0,2,1,3)
            if i==0:first=raw.copy()
            mixed=raw.copy()
            if i and kind!='local':mixed=raw/2+(first/2 if kind=='first_blend' else 0)
            k=packed[...,width:2*width].reshape(2,11,width//32,16,2).transpose(0,2,1,3,4)
            complex_k=(k[...,0]+1j*k[...,1])*((np.cos(angles[:11])+1j*np.sin(angles[:11])) if position=='rope' else 1)
            rotated=np.stack([complex_k.real,complex_k.imag],-1).reshape(2,width//32,11,32)
            result.append((rotated,mixed))
        return result
    full={}
    for name,t in [('A',tokens),('B',(tokens+17)%65)]:
        refs[name]=dict(tokens=t.copy(),logits=r.normal(size=(2,11,65)),inputs=[r.normal(size=(2,11,width)) for _ in range(4)])
        full[name]=oracle(refs[name]['inputs'])
    scenarios=[('token',[('X','A',1)]*11),('uneven',[('X','A',n) for n in [5,3,3]]),
        ('interleaved',[(s,t,n) for n in [2,1,8] for s,t in [('X','A'),('Y','B')]]),
        ('reset',[('X','A',5),('X','A',6),('X','RESET',0),('X','B',4),('X','B',7)])]
    events=[]
    for scenario,steps in scenarios:
        positions={}
        for slot,seq,n in steps:
            start=positions.get(slot,0);end=start+n
            if seq=='RESET':
                events.append(dict(scenario=scenario,slot=slot,sequence=seq,start=0,end=0,
                    cache=[dict(index=i,key=np.zeros((2,width//32,128,32)),value=np.zeros((2,width//32,128,32))) for i in range(4)]));positions[slot]=0;continue
            events.append(dict(scenario=scenario,slot=slot,sequence=seq,start=start,end=end,
                logits=refs[seq]['logits'][:,start:end].copy(),inputs=[x[:,start:end].copy() for x in refs[seq]['inputs']],
                cache=[dict(index=i,key=k[:,:,:end].copy(),value=v[:,:,:end].copy()) for i,(k,v) in enumerate(full[seq])]))
            positions[slot]=end
    evidence=dict(position_kind=position,slopes=tuple(2.**(-8.*(j+1)/(width//32)) for j in range(width//32)) if position=='alibi' else (),offset_reference=dict(start=117,**copy.deepcopy(refs['A'])),derived_checkpoint_sha256='a'*64,width=width,value_kind=kind,capacity=128,batch_size=2,head_dim=32,dtype='float32',atol=1e-4,rtol=2e-5,
        cache_bytes=4*2*2*128*width*4,references=refs,events=events)
    attention=dict(position_kind=position,slopes=evidence['slopes'],start_pos=0,derived_checkpoint_sha256='a'*64,width=width,value_kind=kind,blocks=[dict(index=i,input=x.copy()) for i,x in enumerate(refs['A']['inputs'])])
    evidence.update(null_kind=null_kind,null_policy=a.POLICY,null_convention=a.CONVENTION,attention_scale=scale)
    attention.update(null_kind=null_kind,null_policy=a.POLICY,null_convention=a.CONVENTION,scale=scale)
    def output_oracle(inputs,origin):
        result=[];first=None
        for i,x in enumerate(inputs):
            pre=f'transformer.h.{i}.';packed=np.einsum('btd,od->bto',x,state[pre+'attn.qkv.weight'])+state[pre+'attn.qkv.bias']
            q,k,raw=[v.reshape(2,11,width//32,32).transpose(0,2,1,3) for v in np.split(packed,3,-1)]
            if i==0:first=raw.copy()
            mixed=raw if i==0 or kind=='local' else raw/2+(first/2 if kind=='first_blend' else 0)
            if position=='rope':
                phase=np.cos(angles[origin:origin+11])+1j*np.sin(angles[origin:origin+11])
                def rot(v):
                    z=(v[...,0::2]+1j*v[...,1::2])*phase
                    return np.stack((z.real,z.imag),-1).reshape(v.shape)
                q=rot(q);k=rot(k)
            y=np.empty((2,width//32,11,32))
            for t in range(11):
                scores=np.einsum('bhd,bhkd->bhk',q[:,:,t],k[:,:,:t+1])*scale/(32**.5)
                if position=='alibi':scores-=np.array(evidence['slopes'])[None,:,None]*np.arange(t,-1,-1)[None,None,:]
                if null_kind=='null_zero':scores=np.concatenate((scores,np.zeros((2,width//32,1))),axis=-1)
                weights=np.exp(scores-scores.max(-1,keepdims=True));weights/=weights.sum(-1,keepdims=True)
                if null_kind=='null_zero':weights=weights[...,:-1]
                elif null_kind=='prefix_control':weights*=(t+1)/(t+2)
                y[:,:,t]=np.einsum('bhk,bhkd->bhd',weights,mixed[:,:,:t+1])
            joined=y.transpose(0,2,1,3).reshape(2,11,width)
            result.append(np.einsum('btd,od->bto',joined,state[pre+'attn.out.weight'])+state[pre+'attn.out.bias'])
        return result
    for name,ref in refs.items():ref['attention_outputs']=output_oracle(ref['inputs'],0)
    evidence['offset_reference']['attention_outputs']=output_oracle(evidence['offset_reference']['inputs'],117)
    for row in events:
        if row['sequence']!='RESET':row['attention_outputs']=[x[:,row['start']:row['end']].copy() for x in refs[row['sequence']]['attention_outputs']]
    for i,row in enumerate(attention['blocks']):row['output']=refs['A']['attention_outputs'][i].copy()
    return evidence,state,tokens,attention


class Tests(unittest.TestCase):
    def check(self,p,s,t,att):
        return a.verify(p,s,'a'*64,p['width'],p['value_kind'],t,att,position=p['position_kind'],null_kind=p['null_kind'],scale=p['attention_scale'])
    def test_all_normalization_position_value_width_routes(self):
        n=0
        for null_kind in ('standard','prefix_control','null_zero'):
            for position in ('rope','nope','alibi'):
                for kind in ('local','local_half','first_blend'):
                    for width in (64,256):
                        p,s,t,att=fixture(kind,width,position,null_kind,{'standard':.5,'prefix_control':1.,'null_zero':2.}[null_kind])
                        r=self.check(p,s,t,att)
                        assert r['weighted_cache_outputs']==96 and r['independently_reconstructed_attention_outputs']==108
                        assert r['attention_output_links']==4 and r['attention_checkpoint_tensors']==16
                        n+=1
        assert n==54
    def test_cache_output_checkpoint_and_contract_corruptions(self):
        p,s,t,att=fixture();count=0
        def reject(q,st=s,at=att):
            with self.assertRaises((AssertionError,KeyError,ValueError)):self.check(q,st,t,at)
        for i in range(4):
            for j in (0,1,13,18,22,24):
                for field in ('key','value'):
                    q=copy.deepcopy(p);q['events'][j]['cache'][i][field].flat[0]+=1;reject(q);count+=1
                q=copy.deepcopy(p);q['events'][j]['attention_outputs'][i].flat[0]+=1;reject(q);count+=1
            for field in ('attn.qkv.weight','attn.qkv.bias','attn.out.weight','attn.out.bias','freq_cos','freq_sin'):
                st=copy.deepcopy(s);st[f'transformer.h.{i}.{field}'].flat[0]+=1;reject(p,st);count+=1
            for name in ('A','B'):
                q=copy.deepcopy(p);q['references'][name]['attention_outputs'][i].flat[0]+=1;reject(q);count+=1
            q=copy.deepcopy(p);q['offset_reference']['attention_outputs'][i].flat[0]+=1;reject(q);count+=1
            at=copy.deepcopy(att);at['blocks'][i]['output'].flat[0]+=1;reject(p,at=at);count+=1
        for field,value in [('null_policy','bad'),('null_convention','bad'),('attention_scale',True),('position_kind','bad'),('slopes',(1.,1.)),('cache_bytes',1),('capacity',127),('derived_checkpoint_sha256','b'*64)]:
            q=copy.deepcopy(p);q[field]=value;reject(q);count+=1
        for key in ('null_key','null_value','null_logit','null_attention_state'):
            st=copy.deepcopy(s);st['transformer.h.0.attn.'+key]=np.zeros(1);reject(p,st);count+=1
        for j in (0,1,13,18,22,24):
            q=copy.deepcopy(p);q['events'][j]['cache'][0]['key']=np.concatenate((q['events'][j]['cache'][0]['key'],np.zeros((2,2,1,32))),axis=2);reject(q);count+=1
        q=copy.deepcopy(p);q['offset_reference']['start']=116;reject(q);count+=1
        assert count==131,count
    def test_zero_scores_prefix_counts_projection_bias_and_null_shift(self):
        width=64;p,state,t,att=fixture(position='alibi')
        state['transformer.h.0.attn.qkv.weight'][:width]=0;state['transformer.h.0.attn.qkv.bias'][:width]=0
        x=np.zeros((2,2,width));k=np.zeros((2,2,5,32));v=np.ones_like(k)
        state['transformer.h.0.attn.out.weight']=np.eye(width);state['transformer.h.0.attn.out.bias']=np.full(width,.25)
        for scale in (.5,1.,2.):
            for mode in ('standard','prefix_control','null_zero'):
                y=a.attended(x,k,v,state,0,3,0,width,'nope',mode,scale)
                mass=np.ones(2) if mode=='standard' else np.array([4/5,5/6])
                np.testing.assert_allclose(y,.25+np.broadcast_to(mass[None,:,None],y.shape),atol=1e-14)
                z=a.attended(x,k,np.zeros_like(v),state,0,3,0,width,'nope',mode,scale)
                np.testing.assert_array_equal(z,np.full_like(z,.25))
        # At extreme negative real scores, fixed-zero null retains almost all mass.
        state['transformer.h.0.attn.qkv.bias'][:width]=1
        negative=np.full_like(k,-10000/np.sqrt(32.))
        z=a.attended(x,negative,v,state,0,3,0,width,'nope','null_zero',1.)
        np.testing.assert_array_equal(z,np.full_like(z,.25))
        # Same inherited content scores under ALiBi: slope is after scale.
        state['transformer.h.0.attn.qkv.bias'][:width]=0
        results=[a.attended(x,k,v,state,0,3,0,width,'alibi','null_zero',scale) for scale in (.5,1.,2.)]
        for z in results[1:]:np.testing.assert_array_equal(z,results[0])
    def test_capture_deferred_and_bound_to_same_calls(self):
        tree=ast.parse(Path(__file__).with_name('cache-capture.py').read_text());assert all(isinstance(x,(ast.Expr,ast.FunctionDef)) for x in tree.body)
        s=ast.unparse(tree)
        for text in ['register_forward_hook(output_hook)', 'register_forward_pre_hook(hook)', 'attention_outputs=attention_outputs', 'outputs.clear()', 'validate_null_attention_model(model)', "tokens.device.type == 'mps'", 'forward(tokens, pos=117)', 'h.remove()', 'attn.output_gate is None', 'attn.attn_dropout.p == attn.out_dropout.p == 0']:
            assert text in s,text
        assert sum(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='model' for x in ast.walk(tree))==1
if __name__=='__main__':unittest.main(verbosity=2)
