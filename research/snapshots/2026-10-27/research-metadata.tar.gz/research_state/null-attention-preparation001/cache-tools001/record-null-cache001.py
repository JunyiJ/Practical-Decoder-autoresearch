from pathlib import Path
import ast,json,hashlib,datetime,shutil,subprocess,importlib.util,sys
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';C=P/'cache-tools001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2)+'\n');p.chmod(0o444)
i=json.loads((P/'integration-review.json').read_text())
for row in i['files']:assert sha(S/row['path'])==row['sha256']
paths=sorted((S/'src').rglob('*.py'))+[S/'requirements.txt'];assert not any(p.is_symlink() for p in paths)
source=hashlib.sha256(json.dumps({str(p.relative_to(S)):sha(p) for p in paths},sort_keys=True,allow_nan=False).encode()).hexdigest();assert source==i['source_sha256']
assert subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='63d397017a5a692ded7847a61c7768871c72ee71'
m=json.loads((P/'cpu-execution-manifest.json').read_text());assert m['status']=='running'
ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True)
pids={int(line.split()[0]):line for line in ps.splitlines()[1:] if line.strip()}
assert m['pid'] in pids and m['active_pid'] in pids
assert int(pids[m['active_pid']].split()[1])==m['pid']
actual=[x for x in ps.splitlines() if ' -u -c import torch;torch.set_num_threads(1);import pytest' in x]
assert len(actual)==1
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
obs=dict(at=now,status=m['status'],driver_pid=m['pid'],worker_pid=m['active_pid'],processes=[pids[m['pid']],pids[m['active_pid']]],closed_batches=len(m['batches']),completed_ids=sum(len(b['expected_ids']) for b in m['batches']),free_gib=shutil.disk_usage('/private/tmp').free/2**30,all15_integration_hashes_unchanged=True,source_sha256=source,primary_clean=True,full_regression_passed=False,actual_subset_passed=28)
write(P/'cache-preparation-live-observation001.json',obs)
first=(C/'tests-first.log').read_text();repair=(C/'tests-reset-fixture-repaired.log').read_text()
assert first.count(' ... ok')==3 and 'KeyError' in first and "'attention_outputs'" in first and 'Ran 4 tests in 3.077s' in first
assert repair.count(' ... ok')==1 and 'Ran 1 test in 1.984s' in repair and repair.rstrip().endswith('OK')
for f in ['cache-audit.py','cache-capture.py','test_cache.py']:ast.parse((C/f).read_text())
# The declared FP32 positional reconstruction is byte-for-byte reused, not retested as new proof.
old=B/'research_state/position-quality-preparation001/pilot-tools002/cache-audit.py'
def func(path,name):return ast.dump(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
assert func(old,'projected')==func(C/'cache-audit.py','projected')
review=dict(status='prepared_synthetic_verified_actual_capture_unexecuted',at=now,source_sha256=source,unique_methods_passed=4,first_pass_methods=3,failed_method_repaired_passed=1,successful_methods_repeated=0,synthetic_routes=54,corruption_rejections=127,synthetic_seconds_first=3.077,synthetic_seconds_repaired=1.984,checks=['Independent per-query exp/sum reference across3null*3position*3value*2width54 routes; content scales .5/1/2 distributed, not Cartesian.','Two full references,uncached117..127 and24 token/uneven/interleaved/reset calls;96 real cache prefixes and108 weighted attention output reconstructions against exactQKV/output checkpoint tensors.','Absolute real key/query causal visibility and prefix count; fixedzero null included in joint stabilization after content scale/ALiBi; no null cache slot; output projection bias retained.','CheckpointQKV8+outputprojection8+RoPE8or0 bound;4input+4output graph links; current normalized transformer inputs are observed, not independently recomputed whole transformer.','Zero-score counts4/5 and5/6 at cachedstart3;zero weightedvalues leaveprojectionbias;extreme negative real scores;ALiBi zero-content scale ordering.','Deferred capture only adds hooks to existing calls,validatesnull/value/position signatures,requireshead32/noQKnorm/nooutputgate/dropout0/device.type mps;finally removes hooks.','Repaired declaredFP32frequency projector AST identical historicalpilot002;1e-6 frequency and1e-4/2e-5 main tolerances unchanged.'],failures=[dict(kind='synthetic_test_fixture',detail='Reset event22 has no forward attention_outputs. Test-only skips nonexistent output mutation; all zero-cache corruptions retained. Only failed method rerun;three successful methods not repeated.',path=str(C/'fixture-reset-repair001'))],pre_execution_review=['Draft out_proj tensor names corrected to actual attn.out before tests; originaldraft preserved. Capture guards exclude unsupported QKnorm/outputgates/dropout before execution.'],limitations=['No Torch/model/MPS capture, production execution, training, corpus scoring or quality evidence from this package.','Observed transformer inputs/full-model agreement are not an independent whole-transformer oracle.','Full CPU assertion gate and actual6MPS/resource/prerequisite/publication/uniqueprereg remain pending.'],artifacts=[art(p) for p in sorted(C.rglob('*')) if p.is_file() and '__pycache__' not in p.parts],reused_frequency_source=art(old))
write(C/'review.json',review)
sp=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);bank=mod.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Null-attention independent real-prefix cache/output audit prepared',summary='Four unique NumPy/AST methods pass:54 null/position/value/width routes,127 corruption rejections and analytic visible-count/projection-bias/zero-null checks. Deferred MPS capture adds actual attention outputs to existing calls. One reset-event test fixture repaired without helper/source changes; no MPS execution.',outcome='supported',created_by='continuing-quality-research',related_ids=['kb_8c8ebfebab5fa0492a45bf2f71906674f1cab4e91bb309745495dab0a9275c3c','kb_99dc3be84bdb5ceb62d6fd62afbe743726c4b1f34e6f207084924fae9a17fc5d'],artifacts=[art(C/'review.json'),art(P/'cache-preparation-live-observation001.json')]+review['artifacts'],details=review))
write(C/'knowledge.json',dict(id=kid));write(P/'cache-knowledge-snapshot001.md',bank.export_markdown())
before=P/'cache-state-before001';before.mkdir()
for name in ['quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;oldtext=p.read_text();write(before/name,oldtext);x=json.loads(oldtext);x.setdefault('metadata_history',[]).append(dict(at=now,reason='Null prefix normalization/output cache proof prepared while serialCPU continues',before=art(before/name)))
 n=x['next_preparation'];n.update(cache_tools=str(C),cache_tools_review=str(C/'review.json'),cache_tools_knowledge_id=kid,cache_tools_prepared=True,actual_cache_capture_executed=False,full_regression_passed=False)
 n['pending']=['Finish serial5973 CPU/exact new recorder without repeated passing cases','Prepare null primitive/linkedgraph/pilot/reviewer/resource helpers; actual6serialMPS only afterfullCPU/cleanpublication/no livework','Prepare screening/finalaudit/registration/completionreport helpers;fresh fullbank/seeds/uniqueprereg']
 x['latest_null_cpu_observation']=obs
 tmp=p.with_suffix('.tmp-null-cache');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
for name in ['prepare-null-cache001.py','prepare-null-cache-tests001.py','record-null-cache001.py']:
 shutil.copyfile(Path('/private/tmp')/name,C/name)
for p in C.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:p.chmod(0o444)
print(json.dumps(dict(knowledge_id=kid,source_sha256=source,observation=obs,review=str(C/'review.json'))))
