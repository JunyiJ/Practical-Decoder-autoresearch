from pathlib import Path
import ast
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');old=B/'research_state/position-quality-preparation001/pilot-tools002';p=B/'research_state/null-attention-preparation001/cache-tools001';p.mkdir(exist_ok=False)
s=(old/'cache-audit.py').read_text().replace('def verify(', 'def verify_real_cache(')
s+='''

POLICY='mha4_fixed_null_attention'
CONVENTION='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'

def attended(x,k,v,state,index,start,key_start,width,position,null_kind,scale):
    """Independent Q/real-KV/output projection, using absolute causal positions.

    Real K/V have already been independently reconstructed, never substituted
    from observed cache bytes. The fixed null score participates in stabilization.
    """
    assert null_kind in ('standard','prefix_control','null_zero')
    assert type(scale) in (int,float) and not isinstance(scale,bool) and scale in (.5,1.,2.)
    x=np.asarray(x,dtype=np.float64);k=np.asarray(k,dtype=np.float64);v=np.asarray(v,dtype=np.float64)
    b,t,d=x.shape;h=width//32;n=k.shape[2]
    assert (b,d)==(2,width) and k.shape==v.shape==(2,h,n,32)
    assert type(start) is int and type(key_start) is int and 0<=key_start<=start and start+t<=128
    pre=f'transformer.h.{index}.'
    w=np.asarray(state[pre+'attn.qkv.weight'],dtype=np.float64);bias=np.asarray(state[pre+'attn.qkv.bias'],dtype=np.float64)
    q=(x@w[:width].T+bias[:width]).reshape(b,t,h,32).transpose(0,2,1,3)
    if position=='rope':
        c=np.asarray(state[pre+'freq_cos'])[start:start+t];s=np.asarray(state[pre+'freq_sin'])[start:start+t]
        even=q[...,0::2];odd=q[...,1::2];rot=np.empty_like(q)
        rot[...,0::2]=even*c-odd*s;rot[...,1::2]=even*s+odd*c;q=rot
    qi=np.arange(start,start+t);ki=np.arange(key_start,key_start+n)
    visible=ki[None,:]<=qi[:,None];counts=visible.sum(-1)
    assert (counts>0).all()
    scores=(q@k.swapaxes(-1,-2))*(scale/np.sqrt(32.))
    if position=='alibi':
        slopes=np.array([2.**(-8.*(j+1)/h) for j in range(h)])
        scores=scores-slopes[None,:,None,None]*(qi[:,None]-ki[None,:])
    scores=np.where(visible,scores,-np.inf)
    maximum=scores.max(-1,keepdims=True)
    if null_kind=='null_zero':maximum=np.maximum(maximum,0.)
    numer=np.exp(scores-maximum);denom=numer.sum(-1,keepdims=True)
    if null_kind=='null_zero':denom=denom+np.exp(-maximum)
    probabilities=numer/denom
    if null_kind=='prefix_control':probabilities=probabilities*(counts/(counts+1.))[None,None,:,None]
    heads=probabilities@v
    joined=heads.transpose(0,2,1,3).reshape(b,t,width)
    outw=np.asarray(state[pre+'attn.out_proj.weight'],dtype=np.float64)
    outb=np.asarray(state[pre+'attn.out_proj.bias'],dtype=np.float64)
    assert outw.shape==(width,width) and outb.shape==(width,)
    return joined@outw.T+outb

def verify(p,state,checkpoint_sha,width,kind,tokens,attention=None,*,position,null_kind,scale):
    assert p['null_kind']==null_kind and null_kind in ('standard','prefix_control','null_zero')
    assert p['null_policy']==POLICY and p['null_convention']==CONVENTION
    assert p['attention_scale']==scale and type(p['attention_scale']) in (int,float)
    assert not any(any(part in ('null_key','null_value','null_logit','null_attention_state') for part in key.split('.')) for key in state)
    result=verify_real_cache(p,state,checkpoint_sha,width,kind,tokens,attention,position=position)
    if attention is not None:
        assert (attention['null_kind'],attention['null_policy'],attention['null_convention'])==(null_kind,POLICY,CONVENTION)
        assert attention['scale']==scale
    errors={};output_links=0
    def check(row,start,key_start,kv,label):
        assert len(row['attention_outputs'])==4
        for i,((k,v),x,actual) in enumerate(zip(kv,row['inputs'],row['attention_outputs'])):
            want=attended(x,k,v,state,i,start,key_start,width,position,null_kind,scale)
            errors[f'{label}:attention{i}']=close(actual,want)
    for name,row in p['references'].items():
        check(row,0,0,projected(row['inputs'],state,0,kind,width,position),'full'+name)
    row=p['offset_reference'];check(row,117,117,projected(row['inputs'],state,117,kind,width,position),'offset117')
    if attention is not None:
        for i,row in enumerate(attention['blocks']):
            errors[f'graph:attention{i}']=close(p['references']['A']['attention_outputs'][i],row['output']);output_links+=1
    prefixes={};calls=0
    for j,row in enumerate(p['events']):
        key=(row['scenario'],row['slot'])
        if row['sequence']=='RESET':prefixes.pop(key,None);continue
        start=row['start'];kv=projected(row['inputs'],state,start,kind,width,position)
        if start:
            kv=[(np.concatenate((oldk,k),2),np.concatenate((oldv,v),2)) for (oldk,oldv),(k,v) in zip(prefixes[key],kv)]
        check(row,start,0,kv,str(j));prefixes[key]=kv;calls+=1
        ref=p['references'][row['sequence']]
        for i,y in enumerate(row['attention_outputs']):errors[f'{j}:fullattention{i}']=close(y,np.asarray(ref['attention_outputs'][i])[:,start:row['end']])
    assert calls==24
    result.update(null_kind=null_kind,null_policy=POLICY,null_convention=CONVENTION,attention_scale=scale,
        output_projection_checkpoint_tensors=8,attention_checkpoint_tensors=16,attention_output_links=output_links,
        independently_reconstructed_attention_outputs=108,weighted_cache_outputs=96,
        max_attention_error=max(errors.values()),scope='Independent checkpoint-bound Q/real K/V/absolute causal normalization and output projection on 2 full,1 offset117 and24 cached calls; captured transformer inputs are observations, not an independent whole-transformer implementation or performance measurement.')
    return result
'''
ast.parse(s);(p/'cache-audit.py').write_text(s)
s=(old/'cache-capture.py').read_text()
s=s.replace('    observed=[]','    from src.models.null_attention import validate_null_attention_model\n    signature=validate_null_attention_model(model);assert signature is not None\n    observed=[];outputs=[]')
s=s.replace('    hooks=[b.attn.register_forward_pre_hook(hook) for b in model.transformer.h]','    def output_hook(module,args,result):outputs.append(cpu(result[0]))\n    hooks=[b.attn.register_forward_pre_hook(hook) for b in model.transformer.h]\n    hooks += [b.attn.register_forward_hook(output_hook) for b in model.transformer.h]')
s=s.replace('observed.clear();out=', 'observed.clear();outputs.clear();out=')
s=s.replace('assert len(observed)==4','assert len(observed)==len(outputs)==4')
s=s.replace('validate_value_residual_model(model);validate_position_family_model(model)','validate_value_residual_model(model);validate_position_family_model(model);assert validate_null_attention_model(model)==signature')
s=s.replace('return cpu(out),list(observed)','return cpu(out),list(observed),list(outputs)')
s=s.replace('logits,inputs=forward','logits,inputs,attention_outputs=forward')
s=s.replace('logits=logits,inputs=inputs','logits=logits,inputs=inputs,attention_outputs=attention_outputs')
s=s.replace('return dict(position_kind=',"return dict(null_kind=signature[0],null_policy=signature[1],null_convention=signature[2],attention_scale=model.transformer.h[0].attn.attention_logit_scale,position_kind=")
ast.parse(s);(p/'cache-capture.py').write_text(s)
(p/'DEFERRED_USE.md').write_text('Prepared only. No model or MPS execution yet. Use only after full CPU/publication/no-live-work gates. Capture all attention outputs on the existing full/cached/offset forwards, without extra corpus scoring. Pass independently verified derived checkpoint state/SHA, inherited value/position/attention scale, null family, tokens, and same-objective-forward attention graph to verify. The auditor reconstructs Q and real K/V prefix, absolute visibility, fixed-zero null or prefix count, and output projection; it does not establish an independent whole-transformer forward. Inherit objective, position and value; never infer them from null family. Main tolerances unchanged1e-4/2e-5; declared FP32 RoPE oracle1e-6. Preserve all source/failed evidence; no automatic retry.\n')
print(p)
