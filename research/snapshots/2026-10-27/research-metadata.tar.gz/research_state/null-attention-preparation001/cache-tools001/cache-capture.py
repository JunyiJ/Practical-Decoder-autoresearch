"""Deferred real-MPS cache evidence capture. Imported only after all pilot gates."""

def capture(model,cfg,tokens,checkpoint_sha):
    import torch
    from src.attention.cache import KVCache
    from src.models.value_residual import validate_value_residual_model
    from src.models.position_family import validate_position_family_model
    assert tokens.shape==(2,11) and tokens.device.type=='mps'
    def cpu(x):return x.detach().cpu().clone()
    from src.models.null_attention import validate_null_attention_model
    signature=validate_null_attention_model(model);assert signature is not None
    for block in model.transformer.h:
        attn=block.attn
        assert attn.causal and attn.head_dim==32 and attn.output_gate is None and attn.q_norm is None and attn.k_norm is None
        assert attn.attn_dropout.p==attn.out_dropout.p==0
        assert attn.attention_logit_scale==model.transformer.h[0].attn.attention_logit_scale
    observed=[];outputs=[]
    def hook(module,args):observed.append(cpu(args[0]))
    def output_hook(module,args,result):outputs.append(cpu(result[0]))
    hooks=[b.attn.register_forward_pre_hook(hook) for b in model.transformer.h]
    hooks += [b.attn.register_forward_hook(output_hook) for b in model.transformer.h]
    def forward(t,cache=None,pos=0):
        observed.clear();outputs.clear();out=model(t,cache=cache,start_pos=pos)[0]
        assert len(observed)==len(outputs)==4
        validate_value_residual_model(model);validate_position_family_model(model);assert validate_null_attention_model(model)==signature
        return cpu(out),list(observed),list(outputs)
    def new():return [KVCache(cfg,'mps',batch_size=2) for _ in range(4)]
    def snap(caches,end):
        return [dict(index=i,key=cpu(c.k_cache[:,:,:end]),value=cpu(c.v_cache[:,:,:end])) for i,c in enumerate(caches)]
    streams={'A':tokens,'B':(tokens+17)%65};refs={};events=[]
    try:
        with torch.no_grad():
            for name,t in streams.items():
                logits,inputs,attention_outputs=forward(t);refs[name]=dict(tokens=cpu(t),logits=logits,inputs=inputs,attention_outputs=attention_outputs)
            logits,inputs,attention_outputs=forward(tokens,pos=117)
            offset_ref=dict(start=117,tokens=cpu(tokens),logits=logits,inputs=inputs,attention_outputs=attention_outputs)
            scenarios=[('token',[('X','A',1)]*11),('uneven',[('X','A',n) for n in (5,3,3)]),
                ('interleaved',[(slot,seq,n) for n in (2,1,8) for slot,seq in [('X','A'),('Y','B')]]),
                ('reset',[('X','A',5),('X','A',6),('X','RESET',0),('X','B',4),('X','B',7)])]
            cache_bytes=None
            for scenario,steps in scenarios:
                slots={};positions={}
                for slot,seq,n in steps:
                    if slot not in slots:
                        slots[slot]=new();positions[slot]=0
                    c=slots[slot]
                    size=sum(v.numel()*v.element_size() for x in c for v in x.buffers())
                    assert cache_bytes is None or size==cache_bytes
                    cache_bytes=size
                    if seq=='RESET':
                        for x in c:x.reset()
                        positions[slot]=0
                        events.append(dict(scenario=scenario,slot=slot,sequence=seq,start=0,end=0,cache=snap(c,128)))
                    else:
                        start=positions[slot];end=start+n
                        logits,inputs,attention_outputs=forward(streams[seq][:,start:end],c,start)
                        events.append(dict(scenario=scenario,slot=slot,sequence=seq,start=start,end=end,
                            logits=logits,inputs=inputs,attention_outputs=attention_outputs,cache=snap(c,end)))
                        positions[slot]=end
            return dict(null_kind=signature[0],null_policy=signature[1],null_convention=signature[2],attention_scale=model.transformer.h[0].attn.attention_logit_scale,position_kind=model.position_family_signature[0],slopes=model.transformer.h[0].attn.position_slopes,offset_reference=offset_ref,derived_checkpoint_sha256=checkpoint_sha,value_kind=model.value_residual_signature[0],
                width=cfg.model.dim,capacity=128,batch_size=2,head_dim=32,dtype='float32',atol=1e-4,rtol=2e-5,
                cache_bytes=cache_bytes,references=refs,events=events)
    finally:
        for h in hooks:h.remove()
