from pathlib import Path
import json,hashlib,datetime,importlib.util,sys,shutil,subprocess
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';sys.path.insert(0,str(P/'cpu-tools001'))
from bounded_cpu import passed_ids,collected_ids

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2)+'\n');p.chmod(0o444)
m=json.loads((P/'cpu-execution-manifest.json').read_text());assert len(m['batches'])>=2 and m['status']=='running'
i=json.loads((P/'integration-review.json').read_text())
for x in i['files']:assert sha(S/x['path'])==x['sha256']
names=collected_ids((P/'full-collection.log').read_text());assert len(names)==5973 and names==m['collection']['ids']
assert {str(p.relative_to(S)):sha(p) for p in sorted((S/'tests').rglob('*.py'))}==m['test_hashes']
paths=sorted((S/'src').rglob('*.py'))+[S/'requirements.txt'];assert hashlib.sha256(json.dumps({str(p.relative_to(S)):sha(p) for p in paths},sort_keys=True,allow_nan=False).encode()).hexdigest()==i['source_sha256']
artifacts=[];seconds=0;warnings=0;ids=[]
for j,(f,count) in enumerate([('tests/test_null_attention_geometry.py',16),('tests/test_null_attention_training.py',12)]):
 b=m['batches'][j];assert b['file']==f and b['partition']=='actual';expected=[n for n in names if n.startswith(f+'::')];assert len(expected)==count and expected==b['expected_ids'];log=Path(b['log']);receipt=Path(b['cleanup'])
 assert sha(log)==b['log_sha256'] and not Path(b['scratch']).exists()
 result=passed_ids(log.read_text(),b['exit_code'],expected);r=json.loads(receipt.read_text());assert r['status']=='passed_scratch_removed' and r['verified']==result and r['exit_code']==0 and r['log_sha256']==sha(log) and r['batch']==b['scratch']
 assert r['bytes']==sum(x['bytes'] for x in r['inventory'] if x['kind']=='file')
 ids+=result['ids'];seconds+=result['seconds'];warnings+=result['warnings'];artifacts.extend([art(log),art(receipt)])
assert len(ids)==len(set(ids))==28
now=datetime.datetime.now(datetime.timezone.utc).isoformat();review=dict(status='actual_model_subset_verified',at=now,source_sha256=i['source_sha256'],actual_passed=28,geometry_passed=16,trainer_passed=12,test_seconds=seconds,warnings=warnings,skipped=0,full_regression_passed=False,full_collected=5973,remaining_required=5945,artifacts=artifacts,checks=['All3 null modes independent full-model forward/allparameter gradients with inherited objective/position/value/gain/activation/topology/table routes; exact standard historical math/init/RNG/countgroups.','Fixed-zero joint stabilization, extreme scores, common shifts, zero-score prefix control, visible-prefix count, analytic score/value VJP, projection-bias persistence, attached first-value gradient sum.','Full/token/uneven/reset/interleaved/uncached120 caches and real K/V contents; no persisted null slot; causal future-token invariance.','Eight-update trainer resumes1/4/6, optimizer slots/steps/width factors/independent decay, private train/resetval/untouchedtest RNG, passive H200 canonical table/gain shadows.','Explicit inherited objective call and same-existing-batch independent metrics; sampled/full/raw/derived pureCE penalty veto, no research corpus or holdout scoring.','Exact standard eight-update weights/optimizer/RNG/H200 identity against new synthetic historical-absence control; strict null/current/saved/constructed/load/deletion contracts.'],limitations=['Actual CPU correctness only, no quality/MPS result. All5945 remaining regression cases still required.'])
write(P/'actual-cpu-review001.json',review)
sp=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);bank=mod.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Null-attention actual28 CPU model/trainer cases passed',summary=f'All16 geometry/primitive/evaluator and12 trainer/resume cases passed in{seconds:.2f} test seconds; exact IDs/source/cleanup receipts verified. Full5973 regression remains serially running, no MPS or quality finding.',outcome='supported',created_by='continuing-quality-research',related_ids=[json.loads((P/'integration-knowledge001.json').read_text())['id']],artifacts=[art(P/'actual-cpu-review001.json')]+artifacts,details=review))
write(P/'actual-cpu-knowledge001.json',dict(id=kid));write(P/'actual-cpu-knowledge-snapshot001.md',bank.export_markdown())
before=P/'actual-cpu-state-before001';before.mkdir()
for name in ('quality-evolution-progress.json','research-monitor.json'):
 p=B/'research_state'/name;old=p.read_text();write(before/name,old);x=json.loads(old);x.setdefault('metadata_history',[]).append(dict(at=now,reason='Actual null28 subset independently verified; full regression ongoing',before=art(before/name)))
 x['next_stage']='complete_null_attention_full_cpu_and_prepare_actual_mps';n=x['next_preparation'];n.update(actual_model_validation_complete=True,actual_cases_passed=28,actual_review=str(P/'actual-cpu-review001.json'),actual_knowledge_id=kid,full_regression_passed=False)
 n['pending']=['Finish5945 remaining regression and exact5973 CPU review','Null-aware primitive/cache/fullgraph MPS packages and six serial pilots/resource audit','Clean publication/fullbank/fresh seeds/unique preregistration']
 tmp=p.with_suffix('.tmp-null-actual');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
shutil.copyfile(__file__,P/'record-null-actual001.py');(P/'record-null-actual001.py').chmod(0o444)
print(json.dumps(dict(knowledge_id=kid,actual_passed=28,test_seconds=seconds,warnings=warnings)))
