"""Deferred post-worker capture. No model imports or execution at import time.

Caller must already have passed full CPU/publication/predecessor/live-work gates,
loaded the verified derived checkpoint, and installed the bounded post-worker
watchdog. This module neither trains nor loads/scores research checkpoints.
The hash-bound null-aware attention/cache helpers validate the null policy.
Objective semantics remain inherited; no null primitive is run per graph.
"""
def capture(model,cfg,tokens,derived_sha,helpers):
    import torch
    assert model.training is False and tokens.device.type=='mps'
    assert tuple(tokens.shape)==(2,11) and tokens.dtype==torch.int64
    assert isinstance(derived_sha,str) and len(derived_sha)==64
    assert all(x in '0123456789abcdef' for x in derived_sha)
    cpu_rng=torch.get_rng_state().clone();mps_rng=torch.mps.get_rng_state().clone()
    payload={'schema':'null_attention_linked_mps_graph_v1','derived_checkpoint_sha256':derived_sha}
    # Existing synthetic full/token/chunk/reset/offset checks; no corpus scoring.
    payload['cache']=helpers['cache_capture'].capture(model,cfg,tokens,derived_sha)
    hooks=[];tensors={}
    try:
        for key in ('objective','branch','attention'):
            tensors[key],installed=helpers[key+'_capture'].install(model)
            hooks.extend(installed)
        target=(tokens+1)%65
        model.zero_grad(set_to_none=True)
        logits,loss,breakdown=helpers['objective_capture'].forward(model,tokens,target)
        loss.backward()
        payload['objective']=helpers['objective_capture'].export(model,tensors['objective'],tokens,target,logits,loss,breakdown,derived_sha)
        payload['branch']=helpers['branch_capture'].export(model,tensors['branch'],derived_sha)
        payload['attention']=helpers['attention_capture'].export(model,tensors['attention'],derived_sha)
    finally:
        for hook in hooks:hook.remove()
        tensors.clear()
    # Hooks are gone before the six separate pure-CE synthetic forwards.
    payload['evaluation']=helpers['evaluation_capture'].capture(model,tokens,derived_sha)
    assert torch.equal(cpu_rng,torch.get_rng_state())
    assert torch.equal(mps_rng,torch.mps.get_rng_state())
    payload.update(cpu_rng_unchanged=True,mps_rng_unchanged=True)
    # All exports are detached CPU tensors; no retained live graph leaves here.
    def cpu_only(value):
        if isinstance(value,torch.Tensor):
            assert value.device.type=='cpu' and not value.requires_grad and value.grad_fn is None
        elif isinstance(value,dict):
            for child in value.values():cpu_only(child)
        elif isinstance(value,(list,tuple)):
            for child in value:cpu_only(child)
    cpu_only(payload)
    model.zero_grad(set_to_none=True)
    return payload
