"""Load hash-bound deferred capture and independent audit modules only.

No function in this module executes a model, creates a process, or writes data.
The manifest is preparation evidence, not proof of an actual MPS pilot pass.
"""
import hashlib,importlib.util,json
from pathlib import Path

def load():
    folder=Path(__file__).resolve().parent
    manifest=json.loads((folder/'helper-manifest.json').read_text())
    assert manifest['schema']=='null_attention_linked_graph_helpers_v1'
    required={'objective_capture','objective_audit','evaluation_capture','evaluation_audit',
              'primitive_capture','branch_capture','branch_audit','attention_capture',
              'attention_audit','cache_capture','cache_audit','graph_capture','graph_audit','null_primitive_capture','null_primitive_audit'}
    assert set(manifest['helpers'])==required
    paths=[]
    for key,item in manifest['helpers'].items():
        path=Path(item['path'])
        assert path.is_absolute() and path.is_file() and not path.is_symlink()
        assert not any(p.is_symlink() for p in path.parents)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],key
        paths.append(path)
    assert len(paths)==len(set(paths))
    modules={}
    for key,item in manifest['helpers'].items():
        spec=importlib.util.spec_from_file_location('null_linked_'+key,item['path'])
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        modules[key]=module
    return modules
