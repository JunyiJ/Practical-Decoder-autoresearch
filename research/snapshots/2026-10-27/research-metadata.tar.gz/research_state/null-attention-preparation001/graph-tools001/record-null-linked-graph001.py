from pathlib import Path
import ast,json,hashlib,datetime,shutil,subprocess,importlib.util
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');P=B/'research_state/null-attention-preparation001';C=P/'graph-tools001';R=P/'resource-tools001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def art(p):return dict(path=str(p),sha256=sha(p))
def write(p,x):
 assert not p.exists(),p;p.write_text(x if isinstance(x,str) else json.dumps(x,indent=2)+'\n');p.chmod(0o444)
i=json.loads((P/'integration-review.json').read_text())
for row in i['files']:assert sha(S/row['path'])==row['sha256']
paths=sorted((S/'src').rglob('*.py'))+[S/'requirements.txt'];assert not any(p.is_symlink() for p in paths)
source=hashlib.sha256(json.dumps({str(p.relative_to(S)):sha(p) for p in paths},sort_keys=True,allow_nan=False).encode()).hexdigest();assert source==i['source_sha256']
assert subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='63d397017a5a692ded7847a61c7768871c72ee71'
m=json.loads((P/'cpu-execution-manifest.json').read_text());assert m['status']=='running'
ps=subprocess.check_output(['ps','-axo','pid,ppid,etime,command'],text=True);pids={int(x.split()[0]):x for x in ps.splitlines()[1:] if x.strip()}
assert m['pid'] in pids and m['active_pid'] in pids and int(pids[m['active_pid']].split()[1])==m['pid']
actual=[x for x in ps.splitlines() if ' -u -c import torch;torch.set_num_threads(1);import pytest' in x];assert len(actual)==1
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
obs=dict(at=now,status=m['status'],driver_pid=m['pid'],worker_pid=m['active_pid'],processes=[pids[m['pid']],pids[m['active_pid']]],closed_batches=len(m['batches']),completed_ids=sum(len(b['expected_ids']) for b in m['batches']),free_gib=shutil.disk_usage('/private/tmp').free/2**30,all15_integration_hashes_unchanged=True,source_sha256=source,primary_clean=True,full_regression_passed=False,actual_subset_passed=28)
# Complete validation before recording new metadata.
for folder,name,count,seconds in [(C,'tests-first.log',4,.045),(C,'loader-repaired.log',1,.063),(R,'tests-first.log',1,.005)]:
 log=(folder/name).read_text();assert log.count(' ... ok')==count and f'Ran {count} test' in log and log.rstrip().endswith('OK')
counts=json.loads((C/'test-counts.json').read_text());assert counts==dict(routes=486,payload_corruptions=28,coverage_corruptions=36,dispatch_routes=4,ast_checks=2)
assert 'FAILED (failures=1)' in (C/'loader-first.log').read_text()
manifest=json.loads((C/'helper-manifest.json').read_text());assert len(manifest['helpers'])==15
for row in manifest['helpers'].values():assert sha(row['path'])==row['sha256']
old=json.loads((B/'research_state/logit-z-preparation001/graph-tools001/helper-manifest.json').read_text())
reused=['objective_capture','objective_audit','evaluation_capture','evaluation_audit','primitive_capture','branch_capture','branch_audit']
for key in reused:assert manifest['helpers'][key]==old['helpers'][key]
resolved=json.loads((P/'resolved-final-predecessor001.json').read_text());assert resolved['logit_z_objective_policy']=='mha4_final_logit_z' and resolved['logit_z_coefficient']==0.
for folder in [C,R]:
 for p in folder.glob('*.py'):ast.parse(p.read_text())
for key in ['attention_audit','cache_audit']:
 assert 'np.float32(1)/np.power' in Path(manifest['helpers'][key]['path']).read_text()
assert "device.type=='mps'" in Path(manifest['helpers']['cache_capture']['path']).read_text()
# Verify new consumer field names against actual producer AST, without importing it.
cachetree=ast.parse(Path(manifest['helpers']['cache_audit']['path']).read_text())
producer_keys={k.arg for n in ast.walk(cachetree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='update' for k in n.keywords}
assert {'null_kind','null_policy','null_convention','attention_scale','output_projection_checkpoint_tensors','attention_checkpoint_tensors','attention_output_links','independently_reconstructed_attention_outputs','weighted_cache_outputs'}<=producer_keys
write(P/'linked-graph-live-observation001.json',obs)
for src,dst in [('/private/tmp/prepare-null-linked-graph001.py',C/'preparation-generator001.py'),('/private/tmp/record-null-linked-graph001.py',C/'record-null-linked-graph001.py'),('/private/tmp/prepare-null-resource001.py',R/'preparation-generator001.py')]:shutil.copyfile(src,dst)
def artifacts(folder):return [art(p) for p in sorted(folder.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
graphreview=dict(status='prepared_metadata_ast_verified_actual_mps_unexecuted',at=now,source_sha256=source,unique_methods_passed=5,graph_first_execution_passed=True,graph_seconds=.045,loader_failed_seconds=.035,loader_corrected_seconds=.063,counts=counts,inherited_objective_corruptions=9,helper_hash_corruptions=15,manifest_corruptions=3,actual_capture_executed=False,
 checks=['486 null/objective/position/value/gain/width routes, all checkpoint and same-graph argument links; no objective inheritance from null family.','28 payload and36 required-summary corruptions plus9 inherited objective contract/type corruptions rejected.','One explicit inherited-objective forward/backward, objective/branch/attention hooks removed before six pureCE synthetic forwards, including injected backward/export/evaluator failures. AST execution used only non-tensor stubs.','Null-aware real-prefix cache verifies108 weighted attention reconstructions/96 real KV prefixes,4 input+4 output links,24 calls/reset/offset117,16 attention weights plus8 or0 declared-FP32 RoPE buffers.','New consumer keys compared to actual producer AST; actual final predecessor field logit_z_objective_policy confirmed.','15 helper modules hash-bound;7 previous objective/eval/logit-primitive/branch modules unchanged; numerical proofs reused, not rerun. New null attention/cache/primitive helpers remain actual-MPS-unexecuted.'],
 failures=[dict(kind='test_fixture_ast_expectation',record=art(C/'loader-fixture-repair001/review.json'),summary='Inherited capture-loader AST assertion rejected valid NumPy import/literal kinds tuple in new null primitive. Test-only exact whitelist; only failed loader method rerun, four successful graph methods not repeated.')],
 pre_execution_corrections=['Generated recipe key logit_z_policy corrected to actual logit_z_objective_policy before tests/actual invocation; original drafts preserved.'],
 limitations=['No actual model/production-capture/MPS/primitive/corpus scoring executed. Metadata composition tests are not numerical or quality proof.','Final checkpoints do not independently reconstruct historical objective calls/cache operations/101 EMA snapshots.','Full CPU5973 and six actual MPS with strict checkpoint/optimizer/RNG/H200/pureCE/resource review and clean publication/preregistration remain required.'],artifacts=artifacts(C))
write(C/'review.json',graphreview)
resreview=dict(status='prepared_synthetic_resource_verified_actual_forecast_unmeasured',at=now,source_sha256=source,unique_methods_passed=1,first_execution_passed=True,seconds=.005,inherited_objective_position_value_gain_routes=81,invalid_field_corruptions=32,missing_duplicate_cell_sets=3,infeasible_cases=2,
 checks=['Six distinct null-family/width cells with fixed inherited objective/coefficient/policy/coordinate convention and pureCE validation.','Unchanged worst42 counts12/9/9/6/3/3;40-update training75x plus measured full postworker overhead,50% time/artifact margin,25MiB metadata per trajectory.','Same240s pilot job,2400s research job/21600s round/4096MiB artifact/RSS4096/currentMPSdriver6144 gates.'],limitations=['Synthetic inputs only; no actual MPS timing/resource forecast or quality evidence.'],artifacts=artifacts(R))
write(R/'review.json',resreview)
sp=importlib.util.spec_from_file_location('knowledge',S/'src/research/team/knowledge.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);bank=mod.KnowledgeBank(B/'research_state/knowledge')
kid=bank.add(dict(kind='implementation',title='Null-attention linked objective/attention/cache graph and resource gates prepared',summary='Five metadata/AST graph-loader methods plus one synthetic resource method passed.486 null/inherited-objective/position/value/gain/width routes;28 payload,36 summary and9 objective corruptions. One test-only loader AST fixture failure preserved/repaired without rerunning four passed methods. Actual MPS capture and forecast remain unexecuted.',outcome='supported',created_by='continuing-quality-research',related_ids=['kb_034c3662749bc74e56af5492dd2b92d06a843ffb3f1b31145be4cbc95c6b2897','kb_73b48a2d7ebe0d8bc90da6ecd217c137b4d79544116d3aa1507ff870327c2867','kb_8c8ebfebab5fa0492a45bf2f71906674f1cab4e91bb309745495dab0a9275c3c'],artifacts=[art(C/'review.json'),art(R/'review.json'),art(P/'linked-graph-live-observation001.json')]+graphreview['artifacts']+resreview['artifacts'],details=dict(graph=graphreview,resource=resreview)))
write(C/'knowledge.json',dict(id=kid));write(R/'knowledge.json',dict(id=kid));write(P/'linked-graph-knowledge-snapshot001.md',bank.export_markdown())
before=P/'linked-graph-state-before001';before.mkdir()
for name in ['quality-evolution-progress.json','research-monitor.json']:
 p=B/'research_state'/name;write(before/name,p.read_text());x=json.loads(p.read_text());x.setdefault('metadata_history',[]).append(dict(at=now,reason='Null linked MPS graph and prospective resource gate prepared while serial CPU continues',before=art(before/name)))
 n=x['next_preparation'];n.update(graph_tools=str(C),graph_tools_review=str(C/'review.json'),graph_tools_knowledge_id=kid,graph_tools_prepared=True,resource_tools=str(R),resource_tools_review=str(R/'review.json'),resource_tools_prepared=True,actual_graph_capture_executed=False,actual_resource_forecast_measured=False,full_regression_passed=False)
 n['pending']=['Finish serial5973 CPU/exact new recorder without repeated passing cases','Prepare pilot driver/full checkpoint reviewer; actual6serialMPS only afterfullCPU/cleanpublication/no livework','Prepare screening/finalaudit/registration/completionreport helpers;fresh fullbank/seeds/uniqueprereg']
 x['latest_null_cpu_observation']=obs
 tmp=p.with_suffix('.tmp-null-linked-graph');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)
for folder in [C,R]:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:p.chmod(0o444)
print(json.dumps(dict(knowledge_id=kid,observation=obs,graph_review=str(C/'review.json'),resource_review=str(R/'review.json'))))
