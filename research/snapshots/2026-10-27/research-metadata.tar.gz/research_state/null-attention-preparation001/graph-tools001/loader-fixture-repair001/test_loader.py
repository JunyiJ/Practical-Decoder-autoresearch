import ast,copy,importlib.abc,importlib.util,json,sys,tempfile,unittest
from pathlib import Path
P=Path(__file__).resolve().parent
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='torch' or fullname.startswith(('torch.','src.')) or fullname=='src':raise AssertionError('No actual tensor/model imports')
sys.meta_path.insert(0,Block())
def module(path):
 spec=importlib.util.spec_from_file_location('loader',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
class Tests(unittest.TestCase):
 def test_loader_and_hash_refusals(self):
  loaded=module(P/'load-helpers.py').load();self.assertEqual(len(loaded),15)
  for key in ('objective_capture','branch_capture','attention_capture','cache_capture','evaluation_capture','primitive_capture','graph_capture','null_primitive_capture'):
   tree=ast.parse(Path(loaded[key].__file__).read_text())
   self.assertTrue(all(isinstance(n,(ast.Expr,ast.FunctionDef)) for n in tree.body))
  original=json.loads((P/'helper-manifest.json').read_text())
  self.assertIn('null-attention-preparation001/attention-math-tools001',original['helpers']['attention_audit']['path'])
  self.assertIn('null-attention-preparation001/cache-tools001',original['helpers']['cache_audit']['path'])
  self.assertIn("device.type=='mps'",Path(original['helpers']['cache_capture']['path']).read_text())
  self.assertIn('np.float32(1)/np.power',Path(original['helpers']['attention_audit']['path']).read_text())
  self.assertIn('np.float32(1)/np.power',Path(original['helpers']['cache_audit']['path']).read_text())
  self.assertNotIn('table_audit',loaded)
  with tempfile.TemporaryDirectory(prefix='null-loader-metadata-') as td:
   folder=Path(td).resolve();(folder/'load-helpers.py').write_bytes((P/'load-helpers.py').read_bytes());loader=module(folder/'load-helpers.py')
   for key in original['helpers']:
    bad=copy.deepcopy(original);bad['helpers'][key]['sha256']='0'*64;(folder/'helper-manifest.json').write_text(json.dumps(bad))
    with self.assertRaises(AssertionError):loader.load()
   for change in ('schema','missing','duplicate'):
    bad=copy.deepcopy(original)
    if change=='schema':bad['schema']='bad'
    elif change=='missing':del bad['helpers']['objective_capture']
    else:bad['helpers']['objective_capture']=copy.deepcopy(bad['helpers']['cache_capture'])
    (folder/'helper-manifest.json').write_text(json.dumps(bad))
    with self.assertRaises(AssertionError):loader.load()
if __name__=='__main__':unittest.main(verbosity=2)
