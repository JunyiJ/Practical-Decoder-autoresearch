import ast,copy,importlib.abc,importlib.util,itertools,json,sys,types,unittest
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='torch' or fullname.startswith(('torch.','src.')) or fullname=='src':raise AssertionError('No actual model/tensor imports in metadata tests')
sys.meta_path.insert(0,Block())
s=importlib.util.spec_from_file_location('audit',P/'graph-audit.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
COUNTS=dict(routes=0,payload_corruptions=0,coverage_corruptions=0,dispatch_routes=0,ast_checks=0)

def fixture(w=64,kind='null_zero',pos='rope',value='local',gain='unit',objective='z1e3'):
 sha='a'*64;x=np.arange(22,dtype=np.int64).reshape(2,11);z=np.zeros((2,11,65),np.float32)
 recipe=dict(logit_z_kind=objective,logit_z_coefficient=a.OBJECTIVES[objective],logit_z_objective_policy='mha4_final_logit_z',position_family_kind=pos,value_residual_kind=value,residual_gain_kind=gain,attention_logit_scale=.5,readout_norm_kind='layer_affine',weight_tying_kind='legacy_untied',output_bias_kind='none',input_embedding_scale=1.,residual_topology_kind='serial',gated_activation_kind='silu')
 part=lambda **kw:dict(derived_checkpoint_sha256=sha,**kw)
 p=dict(schema='null_attention_linked_mps_graph_v1',derived_checkpoint_sha256=sha,cpu_rng_unchanged=True,mps_rng_unchanged=True,
  objective=part(logit_z_kind=objective,logit_z_coefficient=a.OBJECTIVES[objective],tokens=x,targets=(x+1)%65,logits=z),
  branch=part(residual_gain_kind=gain),attention=part(null_kind=kind,null_policy=a.POLICY,null_convention=a.CONVENTION,position_kind=pos,value_kind=value,scale=.5),
  cache=part(null_kind=kind,null_policy=a.POLICY,null_convention=a.CONVENTION,position_kind=pos,value_kind=value,references={'A':{'logits':z.copy()}}),evaluation=part())
 results=dict(objective_binding=dict(status='bound'),objective_verify=dict(status='verified'),objective_link=dict(objective_to_branch_edges=4),
  branch_binding=dict(status='bound',weights=28 if gain=='learned_tenth' else 20),branch_verify=dict(status='verified'),
  attention_binding=dict(status='bound',weights=16,rope_buffers=8 if pos=='rope' else 0),attention_verify=dict(status='verified',null_kind=kind,first_value_gradient_roles=4 if value=='first_blend' else 1),attention_link=dict(edges=16),
  cache=dict(status='verified',null_kind=kind,null_policy=a.POLICY,null_convention=a.CONVENTION,attention_scale=.5,output_projection_checkpoint_tensors=8,attention_checkpoint_tensors=16,attention_output_links=4,independently_reconstructed_attention_outputs=108,weighted_cache_outputs=96,forward_calls=24,cache_prefixes=96,reset_events=1,absolute_offset=117,attention_input_links=4,position_kind=pos,qkv_checkpoint_tensors=8,rope_checkpoint_buffers=8 if pos=='rope' else 0),
  evaluation=dict(status='verified',forward_calls=6,synthetic_coverage_targets=21,short_tail=5,objective_graph_links=2))
 calls=[]
 def f(key):
  def run(*args,**kw):calls.append((key,args,kw));return copy.deepcopy(results[key])
  return run
 h=dict(objective_audit=types.SimpleNamespace(bind_checkpoint=f('objective_binding'),verify=f('objective_verify'),link_graph=f('objective_link')),
  branch_audit=types.SimpleNamespace(bind_checkpoint=f('branch_binding'),verify=f('branch_verify')),
  attention_audit=types.SimpleNamespace(bind_checkpoint=f('attention_binding'),verify=f('attention_verify'),link_graph=f('attention_link')),
  cache_audit=types.SimpleNamespace(verify=f('cache')),evaluation_audit=types.SimpleNamespace(evaluation=f('evaluation')))
 return p,recipe,h,results,calls

class Tests(unittest.TestCase):
 def test_independent_family_routes_and_all_required_bindings(self):
  for w,k,o,pos,v,g in itertools.product((64,256),a.KINDS,a.OBJECTIVES,('rope','nope','alibi'),('local','local_half','first_blend'),('unit','static_tenth','learned_tenth')):
   p,r,h,results,calls=fixture(w,k,pos,v,g,o);out=a.verify(p,{},'a'*64,w,k,r,h)
   self.assertEqual((out['null_kind'],out['objective_kind'],out['position_kind'],out['value_kind'],out['gain_kind']),(k,o,pos,v,g))
   self.assertEqual([x[0] for x in calls],['objective_binding','objective_verify','branch_binding','branch_verify','objective_link','attention_binding','attention_verify','attention_link','cache','evaluation'])
   self.assertEqual(calls[0][1][3:6],(w,o,r['readout_norm_kind']))
   self.assertEqual(calls[5][1][-3:],(v,pos,k));self.assertEqual(calls[8][2],{'position':pos,'null_kind':k,'scale':.5})
   self.assertIs(calls[4][1][0],p['objective']);self.assertIs(calls[4][1][1],p['branch'])
   self.assertIs(calls[7][1][1],p['branch']);self.assertIs(calls[8][1][-1],p['attention'])
   self.assertIs(calls[9][1][1],p['objective']);self.assertEqual(calls[9][1][-1],o);COUNTS['routes']+=1
 def test_payload_and_summary_corruption_rejection(self):
  p,r,h,results,calls=fixture()
  mutations=[lambda q:q.update(schema='bad'),lambda q:q.update(derived_checkpoint_sha256='b'*64),lambda q:q.update(cpu_rng_unchanged=False),lambda q:q.update(mps_rng_unchanged=False),lambda q:q['objective'].update(logit_z_kind='none'),lambda q:q['objective'].update(logit_z_coefficient=.0001),lambda q:q['objective'].update(logit_z_coefficient=True),lambda q:q['objective'].update(logits=q['objective']['logits'].astype(np.float64)),lambda q:q['objective'].update(tokens=q['objective']['tokens'].astype(np.int32)),lambda q:q['objective']['targets'].__setitem__((0,0),64),lambda q:q['attention'].update(position_kind='nope'),lambda q:q['cache'].update(position_kind='nope'),lambda q:q['attention'].update(value_kind='first_blend'),lambda q:q['cache'].update(value_kind='first_blend'),lambda q:q['branch'].update(residual_gain_kind='learned_tenth'),lambda q:q['attention'].update(scale=1.),lambda q:q['cache']['references']['A'].update(logits=np.ones((2,11,65),np.float32))]
  mutations += [lambda q,part=part,key=key:q[part].update({key:'bad'}) for part in ('attention','cache') for key in ('null_kind','null_policy','null_convention')]
  mutations += [lambda q,key=key:q[key].update(derived_checkpoint_sha256='c'*64) for key in ('objective','branch','attention','cache','evaluation')]
  for mutate in mutations:
   bad=copy.deepcopy(p);mutate(bad)
   with self.assertRaises(AssertionError):a.verify(bad,{},'a'*64,64,'null_zero',r,h)
   COUNTS['payload_corruptions']+=1
  for result,fields in [('objective_binding',{'status':'bad'}),('objective_verify',{'status':'bad'}),('objective_link',{'objective_to_branch_edges':3}),('branch_binding',{'weights':28,'status':'bad'}),('branch_verify',{'status':'bad'}),('attention_binding',{'weights':15,'rope_buffers':0,'status':'bad'}),('attention_verify',{'null_kind':'bad','first_value_gradient_roles':4,'status':'bad'}),('attention_link',{'edges':15}),('cache',{'null_kind':'bad','null_policy':'bad','null_convention':'bad','attention_scale':1.,'output_projection_checkpoint_tensors':7,'attention_checkpoint_tensors':15,'attention_output_links':3,'independently_reconstructed_attention_outputs':107,'weighted_cache_outputs':95,'forward_calls':23,'cache_prefixes':95,'reset_events':0,'absolute_offset':0,'attention_input_links':3,'position_kind':'nope','qkv_checkpoint_tensors':7,'rope_checkpoint_buffers':0,'status':'bad'}),('evaluation',{'forward_calls':5,'synthetic_coverage_targets':22,'short_tail':4,'objective_graph_links':1,'status':'bad'})]:
   for key,value in fields.items():
    old=results[result][key];results[result][key]=value
    with self.assertRaises(AssertionError):a.verify(p,{},'a'*64,64,'null_zero',r,h)
    results[result][key]=old;COUNTS['coverage_corruptions']+=1
 def test_inherited_objective_contract_rejections(self):
  for key,value in [('logit_z_kind','standard'),('logit_z_kind',False),('logit_z_coefficient',False),('logit_z_coefficient',0),('logit_z_coefficient',.0001),('logit_z_objective_policy','bad')]:
   p,r,h,results,calls=fixture();r[key]=value
   with self.assertRaises(AssertionError):a.verify(p,{},'a'*64,64,'null_zero',r,h)
  for objective in a.OBJECTIVES:
   p,r,h,results,calls=fixture(objective=objective);r['logit_z_coefficient']=False
   with self.assertRaises(AssertionError):a.verify(p,{},'a'*64,64,'null_zero',r,h)
 def test_capture_ast_dispatch_cleanup_with_non_tensor_stubs(self):
  tree=ast.parse((P/'graph-capture.py').read_text())
  self.assertTrue(all(isinstance(n,(ast.Expr,ast.FunctionDef)) for n in tree.body));COUNTS['ast_checks']+=1
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef));imports=[n for n in fn.body if isinstance(n,ast.Import)]
  self.assertEqual([x.names[0].name for x in imports],['torch']);COUNTS['ast_checks']+=1
  # Execute exact function AST except replacing its sole torch import with
  # injected non-tensor stubs. No model/tensor/production function executes.
  fn.body=[n for n in fn.body if n not in imports];module=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]))
  for failure in (None,'objective_export','backward','evaluation'):
   events=[];removed=[]
   class Token:
    device=types.SimpleNamespace(type='mps');shape=(2,11);dtype='int64'
    def __add__(self,x):return self
    def __mod__(self,x):return self
   class RNG:
    def clone(self):return self
   class FakeTensor:pass
   class Loss:
    def backward(self):
     events.append('backward')
     if failure=='backward':raise RuntimeError('injected')
   class Hook:
    def __init__(self,name):self.name=name
    def remove(self):removed.append(self.name);events.append('remove_'+self.name)
   def install(name):
    def run(model):events.append('install_'+name);return {},[Hook(name)]
    return run
   def export(name):
    def run(*args):
     events.append('export_'+name)
     if failure==name+'_export':raise RuntimeError('injected')
     return {'captured':name}
    return run
   def forward(*args):events.append('objective_forward');return object(),Loss(),{}
   def evaluation(*args):
    self.assertEqual(removed,['objective','branch','attention']);events.append('evaluation')
    if failure=='evaluation':raise RuntimeError('injected')
    return {}
   h={name+'_capture':types.SimpleNamespace(install=install(name),export=export(name)) for name in ('objective','branch','attention')}
   h['objective_capture'].forward=forward;h['cache_capture']=types.SimpleNamespace(capture=lambda *x:{})
   h['evaluation_capture']=types.SimpleNamespace(capture=evaluation)
   fake=types.SimpleNamespace(Tensor=FakeTensor,int64='int64',get_rng_state=lambda:RNG(),mps=types.SimpleNamespace(get_rng_state=lambda:RNG()),equal=lambda x,y:True)
   ns={'torch':fake};exec(compile(module,'capture_metadata_ast','exec'),ns)
   model=types.SimpleNamespace(training=False,zero_grad=lambda **kw:events.append('zero_grad'))
   if failure:
    with self.assertRaises(RuntimeError):ns['capture'](model,{},Token(),'a'*64,h)
   else:self.assertTrue(ns['capture'](model,{},Token(),'a'*64,h)['cpu_rng_unchanged'])
   self.assertEqual(removed,['objective','branch','attention']);self.assertEqual(events.count('objective_forward'),1);self.assertEqual(events.count('backward'),1)
   if failure in ('backward','objective_export'):self.assertNotIn('evaluation',events)
   COUNTS['dispatch_routes']+=1
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 if result.wasSuccessful():(P/'test-counts.json').write_text(json.dumps(COUNTS,indent=2)+'\n')
 raise SystemExit(not result.wasSuccessful())
