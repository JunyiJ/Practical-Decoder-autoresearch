"""Compose independent saved-payload audits; NumPy/stdlib only, no model code.

`recipe` must come from the final audited predecessor, and state/hash from the
separately verified derived checkpoint. Null kind is the pilot arm; it
never chooses inherited objective, positional, value-reuse, gain, or table semantics.
"""
import numpy as np

OBJECTIVES={'none':0.,'z1e4':.0001,'z1e3':.001}
KINDS=('standard','prefix_control','null_zero')
POLICY='mha4_fixed_null_attention'
CONVENTION='final_masked_scores_fixed_zero_null_visible_real_prefix_v1'

def verify(payload,state,derived_sha,width,kind,recipe,helpers):
    assert payload['schema']=='null_attention_linked_mps_graph_v1'
    assert isinstance(derived_sha,str) and len(derived_sha)==64 and all(c in '0123456789abcdef' for c in derived_sha)
    assert payload['derived_checkpoint_sha256']==derived_sha
    assert payload['cpu_rng_unchanged'] is True and payload['mps_rng_unchanged'] is True
    assert type(width) is int and width in (64,256) and type(kind) is str and kind in KINDS
    objective=recipe['logit_z_kind'];coefficient=recipe['logit_z_coefficient']
    assert type(objective) is str and objective in OBJECTIVES
    assert type(coefficient) is float and coefficient==OBJECTIVES[objective]
    assert recipe['logit_z_policy']=='mha4_final_logit_z'
    pos=recipe['position_family_kind'];value=recipe['value_residual_kind'];gain=recipe['residual_gain_kind']
    assert pos in ('rope','nope','alibi') and value in ('local','local_half','first_blend')
    assert gain in ('unit','static_tenth','learned_tenth')
    obj,branch,attn,cache,evaluation=(payload[k] for k in ('objective','branch','attention','cache','evaluation'))
    for part in (obj,branch,attn,cache,evaluation):assert part['derived_checkpoint_sha256']==derived_sha
    assert obj['logit_z_kind']==objective and type(obj['logit_z_coefficient']) is float and obj['logit_z_coefficient']==coefficient
    assert np.asarray(obj['logits']).dtype==np.float32
    assert np.asarray(obj['tokens']).dtype==np.int64 and np.asarray(obj['tokens']).shape==(2,11)
    assert np.array_equal(obj['targets'],(np.asarray(obj['tokens'])+1)%65)
    for part in (attn,cache):
        assert (part['null_kind'],part['null_policy'],part['null_convention'])==(kind,POLICY,CONVENTION)
    assert attn['position_kind']==cache['position_kind']==pos
    assert attn['value_kind']==cache['value_kind']==value
    assert branch['residual_gain_kind']==gain
    assert attn['scale']==recipe['attention_logit_scale']
    ob=helpers['objective_audit'].bind_checkpoint(obj,state,derived_sha,width,objective,recipe['readout_norm_kind'],recipe['weight_tying_kind'],recipe['output_bias_kind'],recipe['input_embedding_scale'])
    ov=helpers['objective_audit'].verify(obj)
    bb=helpers['branch_audit'].bind_checkpoint(branch,state,derived_sha,recipe['residual_topology_kind'],width,recipe['gated_activation_kind'],gain)
    bv=helpers['branch_audit'].verify(branch)
    ol=helpers['objective_audit'].link_graph(obj,branch)
    ab=helpers['attention_audit'].bind_checkpoint(attn,state,derived_sha,recipe['attention_logit_scale'],width,value,pos,kind)
    av=helpers['attention_audit'].verify(attn)
    al=helpers['attention_audit'].link_graph(attn,branch)
    cv=helpers['cache_audit'].verify(cache,state,derived_sha,width,value,np.asarray(obj['tokens']),attn,position=pos,null_kind=kind,scale=recipe['attention_logit_scale'])
    np.testing.assert_allclose(obj['logits'],cache['references']['A']['logits'],atol=1e-4,rtol=2e-5)
    ev=helpers['evaluation_audit'].evaluation(evaluation,obj,derived_sha,objective)
    assert ov['status']==bv['status']==av['status']==cv['status']==ev['status']=='verified'
    assert ob['status']==bb['status']==ab['status']=='bound'
    assert ol['objective_to_branch_edges']==4 and al['edges']==16
    assert bb['weights']==(28 if gain=='learned_tenth' else 20)
    assert ab['weights']==16 and ab['rope_buffers']==(8 if pos=='rope' else 0)
    assert av['null_kind']==cv['null_kind']==kind
    assert cv['null_policy']==POLICY and cv['null_convention']==CONVENTION
    assert cv['attention_scale']==recipe['attention_logit_scale']
    assert (cv['output_projection_checkpoint_tensors'],cv['attention_checkpoint_tensors'],cv['attention_output_links'],cv['independently_reconstructed_attention_outputs'],cv['weighted_cache_outputs'])==(8,16,4,108,96)
    assert av['first_value_gradient_roles']==(4 if value=='first_blend' else 1)
    assert (cv['forward_calls'],cv['cache_prefixes'],cv['reset_events'],cv['absolute_offset'],cv['attention_input_links'])==(24,96,1,117,4)
    assert cv['position_kind']==pos and cv['qkv_checkpoint_tensors']==8 and cv['rope_checkpoint_buffers']==ab['rope_buffers']
    assert (ev['forward_calls'],ev['synthetic_coverage_targets'],ev['short_tail'],ev['objective_graph_links'])==(6,21,5,2)
    return dict(status='verified',width=width,null_kind=kind,objective_kind=objective,position_kind=pos,value_kind=value,gain_kind=gain,
        objective=ov,objective_binding=ob,objective_links=ol,branch=bv,branch_binding=bb,
        attention=av,attention_binding=ab,attention_links=al,cache=cv,evaluation=ev,
        scope='One realized penalized graph with checkpoint-bound objective/readout/final norm, branch and attention VJPs; separate synthetic pure-CE and null-aware real-prefix/weighted-output cache checks. Not training-history reconstruction or quality evidence.')
