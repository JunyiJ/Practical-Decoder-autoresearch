import importlib.util,itertools,math,copy,unittest
from pathlib import Path
P=Path(__file__).parent
def module(name):
 s=importlib.util.spec_from_file_location(name,P/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
R=module('resource-gate')
class Tests(unittest.TestCase):
 def test_resource(self):
  rows=[]
  for w,f in itertools.product((64,256),('standard','prefix_control','null_zero')):
   rows.append(dict(width=w,family=f,attention_family='mha',peak_learning_rate=.01,readout_norm_kind='layer_affine',output_bias_prior_sha256='a'*64,output_bias_kind='none',residual_topology_kind='serial',weight_tying_kind='legacy_untied',attention_logit_scale=.5,gated_activation_kind='silu',warmup_steps=0,status='verified',steps=40,cooldown_start=20,snapshots=3,input_embedding_scale=1.,null_attention_kind=f,null_attention_policy='mha4_fixed_null_attention',null_attention_convention='final_masked_scores_fixed_zero_null_visible_real_prefix_v1',logit_z_kind='none',logit_z_coefficient=0.,logit_z_objective_policy='mha4_final_logit_z',logit_z_convention='final_fp32_logsumexp_squared_valid_target_mean_v1',validation_objective='pure_cross_entropy',position_family_kind='rope',position_family_width_policy='mha4_position_family',position_slopes=[],position_frequency_buffers=8,value_residual_kind='local',value_residual_width_policy='mha4_first_value_residual',residual_gain_kind='unit',residual_gain_width_policy='mha4_channel_residual_gain',gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',residual_topology_width_policy='mha4_separate_norm_residual_topology',weight_tying_width_policy='mha4_scaled_table_sharing',output_bias_width_policy='mha4_train_bound_output_bias',readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,input_width_policy='mha4_input_scale',training_seconds=3.,wall_seconds=7.,raw_checkpoint_bytes=2**20,derived_checkpoint_bytes=2**20,sampled_peak_rss_mb=500.,current_driver_mb=100.,driver_allocation_is_not_peak=True))
  r=R.forecast(rows,1.);self.assertEqual(r['status'],'feasible');self.assertEqual([x['trajectories'] for x in r['trial_proxies']],[12,9,9,6,3,3]);self.assertFalse(r['measured_research_duration'])
  for objective,inherited,value,pos in itertools.product(('none','z1e4','z1e3'),('unit','static_tenth','learned_tenth'),('local','local_half','first_blend'),('rope','nope','alibi')):
   same=copy.deepcopy(rows)
   for row in same:
    row['logit_z_kind']=objective;row['logit_z_coefficient']={'none':0.,'z1e4':.0001,'z1e3':.001}[objective];row['residual_gain_kind']=inherited;row['value_residual_kind']=value;row['position_family_kind']=pos;row['position_frequency_buffers']=8 if pos=='rope' else 0;row['position_slopes']=[2.**(-8.*(h+1)/(row['width']//32)) for h in range(row['width']//32)] if pos=='alibi' else []
   self.assertEqual(R.forecast(same,1.)['status'],'feasible')
  for key,value in dict(null_attention_kind='null_zero',null_attention_policy='wrong',null_attention_convention='wrong',logit_z_kind='z1e4',logit_z_coefficient=False,logit_z_objective_policy='wrong',logit_z_convention='wrong',validation_objective='total',position_family_kind='nope',position_family_width_policy='bad',position_frequency_buffers=0,position_slopes=[1.],value_residual_kind='local_half',value_residual_width_policy='bad',gated_activation_kind='relu',residual_gain_kind='learned_tenth',residual_gain_width_policy='bad',peak_learning_rate=.005,steps=39,snapshots=4,status='failed',sampled_peak_rss_mb=4096.,current_driver_mb=6144.,driver_allocation_is_not_peak=False,training_seconds=float('nan'),wall_seconds=240.,raw_checkpoint_bytes=-1,weight_tying_kind='bad',attention_logit_scale=2.,output_bias_prior_sha256='x',readout_norm_kind='rms',input_embedding_scale=.5).items():
   bad=copy.deepcopy(rows);bad[0][key]=value
   with self.assertRaises(ValueError,msg=key):R.forecast(bad,1.)
  for bad in (rows[:-1],rows+[rows[0]],rows[:-1]+[rows[0]]):
   with self.assertRaises(ValueError):R.forecast(bad,1.)
  for key,val in [('training_seconds',6.),('raw_checkpoint_bytes',100*2**20)]:
   bad=copy.deepcopy(rows)
   for r in bad:r[key]=val
   self.assertEqual(R.forecast(bad,1.)['status'],'infeasible')
if __name__=='__main__':unittest.main(verbosity=2)
