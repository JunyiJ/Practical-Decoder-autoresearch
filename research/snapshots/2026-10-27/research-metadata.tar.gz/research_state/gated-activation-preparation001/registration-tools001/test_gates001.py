"""Execute actual prerequisite assertions against metadata fixtures, no model imports."""
import ast,copy,json,types,unittest
from pathlib import Path
folder=Path(__file__).resolve().parent
s=(folder/'freeze-gated-activation-quality001.py').read_text()
a=s.index("assert v['status']");b=s.index('new=set(',a)
c=s.index("assert len(v['independent_branch_math'])");d=s.index('# Verify every required artifact',c)
code=compile(s[a:b]+s[c:d],'<actual-registration-prerequisite-assertions>','exec')
def fixture():
 families=['swiglu','geglu','reglu'];cells=[dict(width=w,family=f) for w in (64,256) for f in families]
 p=dict(source_sha256='s',git_commit='c',output_bias_prior=dict(prior_sha256='p'),recipe=dict(learning_rate=.005),predecessor_review=dict(sha256='r'))
 v=dict(status='verified',source_sha256='s',source_commit='c',recipe=p['recipe'],predecessor_review=p['predecessor_review'],returned_half_life=200,
 independent_training_prior=dict(prior_sha256='p',heldout_frequencies_used=False),tests=dict(full_tests=dict(passed=3607,collected=3607,failed=0),actual_gated_activation_training_tests_passed=12,actual_gated_activation_geometry_tests_passed=13,gated_activation_metadata_tests_passed=318),pilot_audit=cells,artifacts=[dict(path='fixture',sha256='h')],resource_proxy=dict(status='feasible',hours=2.,total_mb_with_margin=1800.,trial_proxies=[dict(seconds_per_trajectory_with_margin=120.)]*6),independent_table_math=[dict(**x,status='verified') for x in cells],independent_branch_math=[dict(**x,status='verified',binding=dict(status='bound',weights=20),linkage=dict(status='linked')) for x in cells])
 v['independent_attention_math']=[dict(**x,status='verified',binding=dict(status='bound',weights=16,rope_buffers=8),linkage=dict(status='linked',edges=16)) for x in cells]
 return p,v

def verify(p,v):
 exec(code,dict(v=v,p=p,tests=v['tests']['full_tests'],study=types.SimpleNamespace(FAMILIES=['swiglu','geglu','reglu']),Path=Path,file_digest=lambda p:'h'))
class Tests(unittest.TestCase):
 def test_actual_assertions_accept_complete_metadata(self):verify(*fixture())
 def test_actual_assertions_reject_incomplete_or_corrupt_gates(self):
  mutations=[lambda v:v.update(status='pending'),lambda v:v.update(source_sha256='bad'),lambda v:v.update(source_commit='bad'),lambda v:v.update(recipe={}),lambda v:v.update(predecessor_review={}),lambda v:v.update(returned_half_life=50),lambda v:v['independent_training_prior'].update(prior_sha256='bad'),lambda v:v['independent_training_prior'].update(heldout_frequencies_used=True),lambda v:v['tests']['full_tests'].update(passed=3606),lambda v:v['tests']['full_tests'].update(collected=3608),lambda v:v['tests']['full_tests'].update(failed=1),lambda v:v['tests'].update(actual_gated_activation_training_tests_passed=11),lambda v:v['tests'].update(actual_gated_activation_geometry_tests_passed=12),lambda v:v['tests'].update(gated_activation_metadata_tests_passed=317),lambda v:v['pilot_audit'].pop(),lambda v:v['artifacts'][0].update(sha256='bad'),lambda v:v['resource_proxy'].update(status='infeasible'),lambda v:v['resource_proxy'].update(hours=6),lambda v:v['resource_proxy'].update(total_mb_with_margin=4096),lambda v:v['resource_proxy']['trial_proxies'][0].update(seconds_per_trajectory_with_margin=2400),lambda v:v['independent_branch_math'].pop(),lambda v:v['independent_branch_math'][0].update(family='wrong'),lambda v:v['independent_branch_math'][0]['binding'].update(weights=19),lambda v:v['independent_branch_math'][0]['binding'].update(status='wrong'),lambda v:v['independent_branch_math'][0]['linkage'].update(status='wrong'),lambda v:v['independent_branch_math'][0].update(status='wrong'),lambda v:v['independent_table_math'].pop(),lambda v:v['independent_table_math'][0].update(status='wrong'),lambda v:v['independent_attention_math'].pop(),lambda v:v['independent_attention_math'][0].update(family='wrong'),lambda v:v['independent_attention_math'][0].update(status='wrong'),lambda v:v['independent_attention_math'][0]['binding'].update(weights=15),lambda v:v['independent_attention_math'][0]['binding'].update(rope_buffers=7),lambda v:v['independent_attention_math'][0]['binding'].update(status='wrong'),lambda v:v['independent_attention_math'][0]['linkage'].update(edges=15),lambda v:v['independent_attention_math'][0]['linkage'].update(status='wrong')]
  for i,mutate in enumerate(mutations):
   with self.subTest(i=i):
    p,v=fixture();mutate(v)
    with self.assertRaises(AssertionError):verify(p,v)

class LaunchHistory(unittest.TestCase):
 def test_current_and_legacy_history_before_spawn(self):
  text=(folder/'launch-gated-activation-quality001.py').read_text()
  start=text.index('history=active.setdefault');end=text.index('json.dumps(active',start)
  chunk=compile(text[start:end],'<actual-launch-history>','exec')
  self.assertLess(start,text.index('subprocess.Popen'))
  prior=Path('/prior/attention-scale-quality-001')
  completion=dict(status='completed_reviewed',review=str(prior/'review.json'),source_commit='s',result_id='kb_fixture')
  for history in ([],['old-study'],[dict(campaign=str(prior))],[str(prior)],['old-study',dict(study=prior.name,review=str(prior/'review.json'))]):
   active=dict(completed_algorithm_studies=copy.deepcopy(history),source_commit='s',attention_scale_quality_completion=completion)
   ns=dict(active=active,prior=prior);exec(chunk,ns)
   self.assertEqual(sum(map(ns['names_prior'],active['completed_algorithm_studies'])),1)
  with self.assertRaises(AssertionError):exec(chunk,dict(active=dict(completed_algorithm_studies=[],source_commit='s'),prior=prior))
  # Actual current history is read-only and must be accepted without schema invention.
  base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
  active=json.loads((base/'research_state/active-campaign.json').read_text())
  prior=base/'research_runs/attention-scale-quality-001';self.assertEqual(active['campaign'],str(prior))
  exec(chunk,dict(active=active,prior=prior))
 def test_actual_metadata_suffix_on_real_schema_with_stubbed_writes(self):
  text=(folder/'launch-gated-activation-quality001.py').read_text()
  suffix=compile(text[text.index('def write('):text.index('print(json.dumps')],'<actual-metadata-suffix>','exec')
  tree=ast.parse(text[text.index('def write('):text.index('print(json.dumps')])
  tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef)]
  suffix=compile(tree,'<actual-metadata-suffix-no-filesystem>','exec')
  base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');run=base/'research_runs/gated-activation-quality-001';source=Path('/source')
  for optional in (None,{},'old historical label'):
   active=json.loads((base/'research_state/active-campaign.json').read_text());m=json.loads((base/'research_state/research-monitor.json').read_text());d=json.loads((base/'research_state/quality-evolution-progress.json').read_text())
   m['gated_activation_preparation']=copy.deepcopy(optional);d['gated_activation_preparation']=copy.deepcopy(optional)
   writes=[];p=dict(git_commit='new',source_sha256='hash',preregistration_id='kb_pred',implementation_id='kb_impl',recipe=dict(attention_logit_scale=.5,learning_rate=.01))
   ns=dict(active=active,m=m,d=d,p=p,now='fixture-time',run=run,source=source,prior=base/'research_runs/attention-scale-quality-001',proc=types.SimpleNamespace(pid=999999),fp=base/'research_state/active-campaign.json',monitor_path=base/'research_state/research-monitor.json',progress_path=base/'research_state/quality-evolution-progress.json',write=lambda p,x:writes.append((p,copy.deepcopy(x))),Path=Path,__file__=str(folder/'launch-gated-activation-quality001.py'))
   exec(suffix,ns);self.assertEqual(len(writes),3)
   for _,record in writes:
    self.assertEqual(record['campaign'],str(run));self.assertEqual(record['source_commit'],'new');self.assertEqual(record['status'],'running')
   self.assertEqual(writes[1][1]['active_stage'],'gated_activation_quality');self.assertEqual(writes[2][1]['active_stage'],'gated_activation_quality')
   for key in ('review','result_id','documentation_commit','completed_reviewed_at','completed_at','conclusion'):self.assertNotIn(key,writes[0][1])
   self.assertLess(text.index('m=json.loads'),text.index('subprocess.Popen'))
 def test_live_guard_ast_and_preflight_ordering_without_cli(self):
  for name in ('freeze-gated-activation-quality001.py','launch-gated-activation-quality001.py'):
   text=(folder/name).read_text();tree=ast.parse(text)
   node=next(n for n in tree.body if isinstance(n,ast.If) and 'live_model_commands' in ast.unparse(n.test))
   fake=types.SimpleNamespace(check_output=lambda *a,**k:'pid command')
   ns=dict(live_model_commands=lambda *a,**k:['active-model'],subprocess=fake,os=types.SimpleNamespace(getpid=lambda:1,getppid=lambda:2))
   with self.assertRaises(ValueError):exec(compile(ast.Module(body=[node],type_ignores=[]),'<guard-only>','exec'),ns)
   self.assertLess(text.index('if live_model_commands'),text.index('from src.research'))
  freeze=(folder/'freeze-gated-activation-quality001.py').read_text()
  self.assertLess(freeze.index('for artifact in artifacts:'),freeze.index('incumbent_path.write_bytes'))
  self.assertLess(freeze.index('for artifact in artifacts:'),freeze.index('implementation=bank.add'))
if __name__=='__main__':unittest.main(verbosity=2)
