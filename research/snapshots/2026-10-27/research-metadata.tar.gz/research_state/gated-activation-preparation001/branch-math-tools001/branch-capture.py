"""Capture one actual MPS forward/backward after worker exit; no model creation."""
def install(model):
    blocks=[{} for _ in model.transformer.h];hooks=[]
    def save(i,key,tensor):
        tensor.retain_grad();blocks[i][key]=tensor
    for i,b in enumerate(model.transformer.h):
        def block_hook(module,inputs,output,i=i):
            save(i,'input',inputs[0]);save(i,'output',output[0])
        def attn_hook(module,inputs,output,i=i):save(i,'attention',output[0])
        def n1_hook(module,inputs,output,i=i):save(i,'ln1_output',output)
        def n2_hook(module,inputs,output,i=i):
            blocks[i]['ln2_input']=inputs[0];save(i,'ln2_output',output)
        def ffn_hook(module,inputs,output,i=i):save(i,'ffn_output',output)
        hooks.extend([b.register_forward_hook(block_hook),b.attn.register_forward_hook(attn_hook),b.ln1.register_forward_hook(n1_hook),b.ln2.register_forward_hook(n2_hook),b.mlp.register_forward_hook(ffn_hook)])
    return blocks,hooks

def export(model,blocks,derived_sha):
    import torch
    result=[]
    for i,(b,t) in enumerate(zip(model.transformer.h,blocks)):
        row=dict(index=i,ln1_eps=float(torch.finfo(torch.float32).eps) if b.ln1.eps is None else b.ln1.eps,ln2_eps=float(torch.finfo(torch.float32).eps) if b.ln2.eps is None else b.ln2.eps)
        for name,value in t.items():row[name]=value.detach().cpu()
        for name,key in [('input','input'),('attention','attention'),('output','output'),('ln1','ln1_output'),('ln2','ln2_output'),('ffn','ffn_output')]:
            assert t[key].grad is not None;row[name+'_gradient']=t[key].grad.detach().cpu()
        for name,param in [('ln1_weight',b.ln1.weight),('ln2_weight',b.ln2.weight),('gate_weight',b.mlp.linear_gate.weight),('up_weight',b.mlp.linear_up.weight),('down_weight',b.mlp.linear_down.weight)]:
            row[name]=param.detach().cpu();assert param.grad is not None;row[name+'_gradient']=param.grad.detach().cpu()
        result.append(row)
    return dict(gated_activation_kind=model.cfg.gated_activation_kind,kind=model.residual_topology_signature[0],width=model.cfg.dim,derived_checkpoint_sha256=derived_sha,atol=1e-4,rtol=2e-5,blocks=result)
