import importlib.util,copy,unittest
from pathlib import Path
import numpy as np
import math
spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('branch-math-audit.py'));audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)

def fixture(kind,w,activation="silu"):
 def phi(z):
  if activation=="silu":return z/(1+np.exp(-z))
  if activation=="gelu_exact":return .5*z*(1+np.vectorize(math.erf,otypes=[float])(z/math.sqrt(2)))
  return np.where(z>0,z,0.)
 def slope(z):
  if activation=="silu":
   s=1/(1+np.exp(-z));return s+z*s*(1-s)
  if activation=="gelu_exact":return .5*(1+np.vectorize(math.erf,otypes=[float])(z/math.sqrt(2)))+z*np.exp(-z*z/2)/math.sqrt(2*math.pi)
  return (z>0).astype(float)
 rng=np.random.default_rng(9417);blocks=[];directions=[];eps=float(np.finfo(np.float32).eps)
 for i in range(4):
  x=rng.normal(size=(1,2,w));q=rng.normal(scale=.015,size=(w,w));gamma1=rng.uniform(.8,1.2,w);gamma2=rng.uniform(.8,1.2,w)
  wg=rng.normal(scale=.015,size=(21*w//8,w));wu=rng.normal(scale=.015,size=wg.shape);wd=rng.normal(scale=.015,size=(w,21*w//8));g=rng.normal(scale=.2,size=x.shape)
  def forward(x,q,gamma1,gamma2,wg,wu,wd):
   n1=x*gamma1/(np.mean(x**2,-1,keepdims=True)+eps)**.5;a=n1@q.T
   z=x if kind=='parallel_separate_norms' else x+a;n2=z*gamma2/(np.mean(z**2,-1,keepdims=True)+eps)**.5
   gate=n2@wg.T;up=n2@wu.T;sil=phi(gate);f=(sil*up)@wd.T
   return n1,a,z,n2,gate,up,sil,f,x+a+f
  n1,a,z,n2,gate,up,sil,f,y=forward(x,q,gamma1,gamma2,wg,wu,wd)
  dp=g@wd;sg=1/(1+np.exp(-gate));dg=dp*up*slope(gate);du=dp*sil;dn=dg@wg+du@wu
  inv=1/(np.mean(z*z,-1,keepdims=True)+eps)**.5;dz=dn*gamma2*inv-z*inv**3*np.mean(dn*gamma2*z,-1,keepdims=True)
  da=g+(dz if kind=='serial' else 0);dn1=da@q
  inv1=1/(np.mean(x*x,-1,keepdims=True)+eps)**.5;dx=g+dz+dn1*gamma1*inv1-x*inv1**3*np.mean(dn1*gamma1*x,-1,keepdims=True)
  gg1=(dn1*x*inv1).sum((0,1));gg2=(dn*z*inv).sum((0,1));gwg=dg.reshape(-1,dg.shape[-1]).T@n2.reshape(-1,w);gwu=du.reshape(-1,du.shape[-1]).T@n2.reshape(-1,w);gwd=g.reshape(-1,w).T@(sil*up).reshape(-1,21*w//8);gq=da.reshape(-1,w).T@n1.reshape(-1,w)
  # Independent central finite differences of scalar loss, seven whole-array directions.
  params=[x,q,gamma1,gamma2,wg,wu,wd];grads=[dx,gq,gg1,gg2,gwg,gwu,gwd]
  for j in range(7):
   direction=rng.normal(size=params[j].shape);direction/=np.linalg.norm(direction);plus=list(params);minus=list(params);plus[j]=params[j]+1e-5*direction;minus[j]=params[j]-1e-5*direction
   numeric=np.sum((forward(*plus)[-1]-forward(*minus)[-1])*g)/(2e-5);analytic=np.sum(grads[j]*direction)
   np.testing.assert_allclose(numeric,analytic,atol=1e-8,rtol=1e-5);directions.append(abs(numeric-analytic))
  blocks.append(dict(index=i,input=x,attention=a,output=y,output_gradient=g,ln2_input=z,ln1_output=n1,ln2_output=n2,ffn_output=f,ffn_gradient=g,ln1_gradient=dn1,ln2_gradient=dn,attention_gradient=da,input_gradient=dx,ln1_eps=eps,ln2_eps=eps,ln1_weight=gamma1,ln2_weight=gamma2,gate_weight=wg,up_weight=wu,down_weight=wd,ln1_weight_gradient=gg1,ln2_weight_gradient=gg2,gate_weight_gradient=gwg,up_weight_gradient=gwu,down_weight_gradient=gwd))
 return dict(gated_activation_kind=activation,kind=kind,width=w,atol=1e-4,rtol=2e-5,blocks=blocks),max(directions)

class Tests(unittest.TestCase):
 def test_twelve_activation_topology_width_formulas_and336_directions(self):
  for kind in ('serial','parallel_separate_norms'):
   for w in (64,256):
    for activation in ('silu','gelu_exact','relu'):
     p,error=fixture(kind,w,activation);self.assertEqual(audit.verify(p)['status'],'verified');self.assertLess(error,1e-8)
 def test_saved_field_corruption_rejected(self):
  p,_=fixture('serial',64)
  keys=['ln2_input','input_gradient','attention_gradient','output','ln1_output','ln2_output','ffn_output','ffn_gradient','ln2_gradient','gate_weight_gradient','up_weight_gradient','down_weight_gradient','ln1_weight_gradient','ln2_weight_gradient']
  for key in keys:
   q=copy.deepcopy(p);q['blocks'][0][key].flat[0]+=.1
   with self.assertRaises(AssertionError):audit.verify(q)
  q=copy.deepcopy(p);q['kind']='parallel_separate_norms'
  with self.assertRaises(AssertionError):audit.verify(q)
  q=copy.deepcopy(p);q['blocks'][0]['ln2_eps']=1e-5
  with self.assertRaises(AssertionError):audit.verify(q)
 def test_activation_semantic_binding_and_zero_derivative(self):
  for activation in ('silu','gelu_exact','relu'):
   p,_=fixture('serial',64,activation);p['derived_checkpoint_sha256']='a'*64
   state={}
   mapping={'ln1_weight':'ln1.weight','ln2_weight':'ln2.weight','gate_weight':'mlp.linear_gate.weight','up_weight':'mlp.linear_up.weight','down_weight':'mlp.linear_down.weight'}
   for i,b in enumerate(p['blocks']):
    for k,v in mapping.items():state[f'transformer.h.{i}.{v}']=b[k].copy()
   self.assertEqual(audit.bind_checkpoint(p,state,'a'*64,'serial',64,activation)['weights'],20)
   for other in ('silu','gelu_exact','relu'):
    if other==activation:continue
    with self.assertRaises(AssertionError):audit.bind_checkpoint(p,state,'a'*64,'serial',64,other)
    q=copy.deepcopy(p);q['gated_activation_kind']=other
    with self.assertRaises(AssertionError):audit.verify(q)
   for key in state:
    bad={k:v.copy() for k,v in state.items()};bad[key].flat[0]+=.01
    with self.assertRaises(AssertionError):audit.bind_checkpoint(p,bad,'a'*64,'serial',64,activation)
  y,dy=audit.activation(np.array([-1.,0.,1.]),'relu')
  np.testing.assert_array_equal(y,[0.,0.,1.]);np.testing.assert_array_equal(dy,[0.,0.,1.])
if __name__=='__main__':unittest.main(verbosity=2)
