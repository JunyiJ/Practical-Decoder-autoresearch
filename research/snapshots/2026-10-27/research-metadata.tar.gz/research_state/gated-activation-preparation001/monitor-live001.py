"""Read-only process and recent-log observation; no model imports or process control."""
import datetime,json,os,subprocess,time
from pathlib import Path
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');R=B/'research_runs/gated-activation-quality-001'
a=json.loads((B/'research_state/active-campaign.json').read_text());s=json.loads((R/'state.json').read_text());p=json.loads((R/'plan.json').read_text())
assert a['campaign']==str(R) and a['source_commit']==p['git_commit']
rows=[]
for line in subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines():
 parts=line.split(None,2)
 if len(parts)==3 and parts[0].isdigit():rows.append((int(parts[0]),int(parts[1]),parts[2]))
controllers=[x for x in rows if ' -m src.research.gated_activation_study --plan '+str(R/'plan.json') in x[2]]
children=[x for x in rows if any(x[1]==c[0] for c in controllers)]
observed=dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=s['status'],completed=sum(x['status']=='completed' for x in s['records']),controller_pids=[x[0] for x in controllers],worker_pids=[x[0] for x in children],source_commit=p['git_commit'])
if s['status']=='running':
 assert len(controllers)==1 and len(children)==1,(controllers,children)
 command=children[0][2];assert '--request '+str(R/'trials') in command
 req=Path(command.split('--request ',1)[1].strip());log=req.parent/'worker.log'
 observed.update(trial_id=req.parent.name,log_age_seconds=time.time()-log.stat().st_mtime,latest_log_lines=log.read_text().splitlines()[-2:])
print(json.dumps(observed,indent=2))
