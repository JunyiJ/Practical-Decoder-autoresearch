"""Pure numerical promotion guards; no model, scoring or result recording."""
import copy,importlib.util,sys,unittest
from pathlib import Path
folder=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
fixture=load('screen_fixtures',folder.parent/'screening-tools001/test_audit.py')
rec=load('recorder',folder/'record-completion.py')

def report(lr=.005,scale=1.,norm='layer_affine',winner='reglu',alias=True):
    p=fixture.plan(lr,scale,norm);rows,_=fixture.panel(p,winner,alias);selection=fixture.a.reconstruct(p,rows)
    actual=selection['winner'];eligible=selection['candidate_eligible'];comparisons=[]
    if eligible:
        refs=[fixture.a.REFERENCE]+([] if winner=='swiglu' else ['swiglu'])
        for width in (64,256):
            for reference in refs:
                values={str(seed):-.02-.001*i for i,seed in enumerate(fixture.a.CONFIRM)}
                comparisons.append(dict(candidate=winner,reference=reference,width=width,quality_improvement=True,sensitivity=[dict(text_block_tokens=block,paired_seed_deltas=copy.deepcopy(values),mean_delta=sum(values.values())/3,conditional_text_bootstrap_95pct=[-.03,-.01]) for block in (2048,4096,8192)]))
    return p,dict(selection=selection,comparisons=comparisons,quality_decision=dict(frozen_screen_winner=actual,qualifies_for_incumbent_replacement=eligible))

class Checks(unittest.TestCase):
    def test_all_inherited_recipe_winner_alias_routes(self):
        for lr in fixture.a.RATES:
            for scale in (1.,.5,.25):
                for norm in ('layer_affine','layer_no_bias','rms'):
                    for winner in fixture.a.FAMILIES:
                        for alias in (False,True):
                            with self.subTest(lr=lr,scale=scale,norm=norm,winner=winner,alias=alias):
                                p,r=report(lr,scale,norm,winner,alias)
                                self.assertEqual(rec.verified_decision(p,r),(r['selection']['winner'],r['quality_decision']['qualifies_for_incumbent_replacement']))
    def test_seed_veto_and_text_veto(self):
        for mode in ('seed','text'):
            p,r=report();c=next(x for x in r['comparisons'] if x['width']==256)
            for v in c['sensitivity']:
                if mode=='seed':
                    v['paired_seed_deltas']['2433']=.001;v['mean_delta']=sum(v['paired_seed_deltas'].values())/3
                else:v['conditional_text_bootstrap_95pct'][1]=.001
            c['quality_improvement']=False;r['quality_decision']['qualifies_for_incumbent_replacement']=False
            self.assertEqual(rec.verified_decision(p,r),('reglu',False))
    def test_corrupt_decision_rejected(self):
        for damage in ('choice','grid','best','local_delta','local_seed','local_reference','eligible','winner','confirmation_seed','upper','mean','missing','duplicate','adopt','inherited_lr'):
            with self.subTest(damage=damage):
                p,r=report(alias=False);s=r['selection'];c=next(x for x in r['comparisons'] if x['reference']=='swiglu' and x['width']==256)
                if damage=='choice':s['choices']['reglu']['lr']=.0125
                elif damage=='grid':s['choices']['reglu']['grid'].pop()
                elif damage=='best':s['best_selected_arm']='geglu'
                elif damage=='local_delta':s['local_contrasts'][0]['mean_delta']+=.1
                elif damage=='local_seed':s['local_contrasts'][0]['paired_seed_deltas']['999']=0.
                elif damage=='local_reference':s['local_contrasts'].pop()
                elif damage=='eligible':s['candidate_eligible']=False
                elif damage=='winner':s['winner']='geglu'
                elif damage=='confirmation_seed':c['sensitivity'][0]['paired_seed_deltas']['999']=0.
                elif damage=='upper':c['sensitivity'][2]['conditional_text_bootstrap_95pct'][1]=.1
                elif damage=='mean':c['sensitivity'][1]['mean_delta']+=.1
                elif damage=='missing':r['comparisons'].remove(c)
                elif damage=='duplicate':r['comparisons'].append(copy.deepcopy(c))
                elif damage=='adopt':r['quality_decision']['qualifies_for_incumbent_replacement']=False
                elif damage=='inherited_lr':p['recipe']['learning_rate']=.0125
                with self.assertRaises(AssertionError):rec.verified_decision(p,r)

class SelectedModel(unittest.TestCase):
    def test_exact_selected_gate_and_all_inherited_contracts(self):
        for topology in ('serial','parallel_separate_norms'):
            for table in ('legacy_untied','matched_untied','scaled_tied'):
                for family in rec.FAMILIES:
                    p,_=report(winner=family);p['recipe'].update(residual_topology_kind=topology,weight_tying_kind=table)
                    p['output_bias_prior']={'alphabet':['a','b']}
                    r=p['recipe'];m=dict(gated_activation_kind={'swiglu':'silu','geglu':'gelu_exact','reglu':'relu'}[family],gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale=r['attention_logit_scale'],attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',residual_topology_kind=topology,residual_topology_width_policy='mha4_separate_norm_residual_topology',weight_tying_kind=table,weight_tying_width_policy='mha4_scaled_table_sharing',output_bias_kind=r['output_bias_kind'],output_bias_width_policy='mha4_train_bound_output_bias',output_bias_prior=p['output_bias_prior'],readout_norm_kind=r['readout_norm_kind'],readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,input_embedding_scale=r['input_embedding_scale'],input_width_policy='mha4_input_scale',vocab_size=2)
                    cfg=dict(model=m,training=dict(lr_schedule={},weight_averaging=dict(half_lives=[200])))
                    self.assertEqual(rec.verify_selected_model(p,family,cfg),m)
                    for key in m:
                        changed=copy.deepcopy(cfg);changed['model'][key]='corrupted'
                        with self.assertRaises(AssertionError):rec.verify_selected_model(p,family,changed)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    assert 'torch' not in sys.modules
    print('162 synthetic inherited recipe/winner/alias routes;2 confirmation vetoes;15 decision corruption routes plus18 selected-model routes with field corruption checks. No actual future result recording or models.')
    raise SystemExit(not result.wasSuccessful())
