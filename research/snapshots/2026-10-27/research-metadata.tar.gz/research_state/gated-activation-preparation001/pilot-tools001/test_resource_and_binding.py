import copy,importlib.util,unittest
from pathlib import Path
import numpy as np

def load(name):
 s=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
resource=load('resource-gate');branch=load('branch-math-audit')

def rows():
 return [dict(width=w,family=f,attention_family='mha',peak_learning_rate=.01,readout_norm_kind='layer_affine',output_bias_prior_sha256='a'*64,output_bias_kind='none',warmup_steps=0,status='verified',steps=40,cooldown_start=20,snapshots=3,input_embedding_scale=1.,weight_tying_kind='legacy_untied',weight_tying_width_policy='mha4_scaled_table_sharing',residual_topology_kind='serial',gated_activation_kind={'swiglu':'silu','geglu':'gelu_exact','reglu':'relu'}[f],gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale=.5,attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',residual_topology_width_policy='mha4_separate_norm_residual_topology',output_bias_width_policy='mha4_train_bound_output_bias',readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,input_width_policy='mha4_input_scale',training_seconds=4.,wall_seconds=7.,raw_checkpoint_bytes=12*1024**2,derived_checkpoint_bytes=4*1024**2,sampled_peak_rss_mb=500.,current_driver_mb=700.,driver_allocation_is_not_peak=True) for w in (64,256) for f in ('swiglu','geglu','reglu')]

class Tests(unittest.TestCase):
 def test_worst42_counts_and_limits(self):
  r=resource.forecast(rows(),1.);self.assertEqual(r['physical_trajectories'],42);self.assertEqual([x['trajectories'] for x in r['trial_proxies']],[12,9,9,6,3,3]);self.assertEqual(r['status'],'feasible')
  self.assertAlmostEqual(r['hours'],42*1.5*(4*75+3)/3600)
  for key,value in [('training_seconds',30.),('raw_checkpoint_bytes',100*1024**2)]:
   q=rows()
   for row in q:row[key]=value;row['wall_seconds']=35.
   self.assertEqual(resource.forecast(q,1.)['status'],'infeasible')
 def test_invalid_cells_and_contracts(self):
  changes={'gated_activation_kind':'wrong','gated_activation_width_policy':'wrong','attention_logit_scale':3.,'attention_logit_scale_width_policy':'wrong','width':128,'family':'wrong','attention_family':'kda','peak_learning_rate':.005,'steps':3000,'snapshots':101,'cooldown_start':2000,'warmup_steps':2,'residual_topology_kind':'bad','residual_topology_width_policy':'bad','weight_tying_kind':'scaled_tied','sampled_peak_rss_mb':4096.,'current_driver_mb':6144.,'driver_allocation_is_not_peak':False,'training_seconds':float('nan'),'readout_norm_epsilon':1e-6,'output_bias_prior_sha256':'bad','input_embedding_scale':.5}
  for key,value in changes.items():
   q=rows();q[0][key]=value
   with self.assertRaises(ValueError,msg=key):resource.forecast(q,1.)
  with self.assertRaises(ValueError):resource.forecast(rows()[:-1],1.)
  q=rows();q[-1]=q[0]
  with self.assertRaises(ValueError):resource.forecast(q,1.)
 def test_exact_checkpoint_weight_binding(self):
  mapping={'ln1_weight':'ln1.weight','ln2_weight':'ln2.weight','gate_weight':'mlp.linear_gate.weight','up_weight':'mlp.linear_up.weight','down_weight':'mlp.linear_down.weight'}
  for kind in ('serial','parallel_separate_norms'):
   for width in (64,256):
    p=dict(gated_activation_kind='silu',kind=kind,width=width,derived_checkpoint_sha256='a'*64,blocks=[dict(index=i,**{k:np.array([i+1.,2.]) for k in mapping}) for i in range(4)])
    state={f'transformer.h.{i}.{name}':p['blocks'][i][key].copy() for i in range(4) for key,name in mapping.items()}
    self.assertEqual(branch.bind_checkpoint(p,state,'a'*64,kind,width,'silu')['weights'],20)
    for i in range(4):
     for key in mapping:
      q=copy.deepcopy(p);q['blocks'][i][key][0]+=.01
      with self.assertRaises(AssertionError):branch.bind_checkpoint(q,state,'a'*64,kind,width,'silu')
    for field,value in [('derived_checkpoint_sha256','b'*64),('kind','wrong'),('width',128)]:
     q=copy.deepcopy(p);q[field]=value
     with self.assertRaises(AssertionError):branch.bind_checkpoint(q,state,'a'*64,kind,width,'silu')
if __name__=='__main__':unittest.main(verbosity=2)
