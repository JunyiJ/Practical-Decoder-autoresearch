"""No model imports, subprocesses, pilots or controller execution."""
import ast,copy,json,unittest
from pathlib import Path
from types import SimpleNamespace
F=Path(__file__).resolve().parent
class Tests(unittest.TestCase):
 def test_driver_cpu_gate_executes_pure_predicate(self):
  tree=ast.parse((F/'pilot-driver001.py').read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
  gate=next(n for n in main.body if isinstance(n,ast.If) and 'Complete matching full CPU' in ast.unparse(n))
  code=compile(ast.Module(body=[gate],type_ignores=[]),'cpu-gate','exec')
  cpu=dict(status='cpu_verified',source_sha256='a'*64,full_tests=dict(passed=3607,collected=3607,failed=0),actual_gated_activation_training_tests_passed=12,actual_gated_activation_geometry_tests_passed=13,gated_activation_metadata_tests_passed=318)
  def check(c):exec(code,{'cpu':c,'tests':c['full_tests'],'sha':'a'*64})
  check(cpu)
  for field,value in [('status','running'),('source_sha256','b'*64),('actual_gated_activation_training_tests_passed',11),('actual_gated_activation_geometry_tests_passed',12),('gated_activation_metadata_tests_passed',317)]:
   c=copy.deepcopy(cpu);c[field]=value
   with self.assertRaises(ValueError):check(c)
  for field,value in [('passed',3606),('collected',3606),('failed',1)]:
   c=copy.deepcopy(cpu);c['full_tests'][field]=value
   with self.assertRaises(ValueError):check(c)
 def test_predecessor_and_live_guard_before_model_import(self):
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   tree=ast.parse((F/name).read_text());body=next(n.body for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main') if name.startswith('pilot') else tree.body
   torchline=next(n.lineno for n in body if isinstance(n,ast.Import) and any(a.name=='torch' for a in n.names))
   guards=[n for n in body if isinstance(n,ast.If) and ('Completed reviewed attention-scale' in ast.unparse(n) or 'Competing model work' in ast.unparse(n))]
   self.assertEqual(len(guards),2)
   for guard in guards:self.assertLess(guard.lineno,torchline)
   live=next(n for n in guards if 'Competing model' in ast.unparse(n));code=compile(ast.Module(body=[live],type_ignores=[]),'live-guard','exec')
   exec(code,{'live':[]})
   with self.assertRaises(ValueError):exec(code,{'live':['synthetic existing CPU worker']})
 def test_activation_and_attention_binding_wiring(self):
  text=(F/'review-prerequisites001.py').read_text()
  self.assertIn("branch_audit.bind_checkpoint(branch,state_arrays,item['checkpoint_sha256'],topology,w,study.ACTIVATIONS[f])",text)
  self.assertIn("attn_audit.bind_checkpoint(attention_evidence,state_arrays,item['checkpoint_sha256'],p['recipe']['attention_logit_scale'],w)",text)
  self.assertIn("cfg.model.gated_activation_kind==row['gated_activation_kind']==study.ACTIVATIONS[f]",text)
  self.assertNotIn('study.SCALES',text)
  for name in ('pilot-driver001.py','review-prerequisites001.py'):
   text=(F/name).read_text();self.assertIn('111538',text);self.assertIn('9443',text);self.assertNotIn('9423',text);ast.parse(text)
if __name__=='__main__':unittest.main(verbosity=2)
