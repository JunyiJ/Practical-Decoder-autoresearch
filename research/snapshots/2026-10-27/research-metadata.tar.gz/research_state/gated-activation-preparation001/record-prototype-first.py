import ast, datetime, difflib, hashlib, importlib.util, json, pathlib, shutil, subprocess, tarfile
B=pathlib.Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');S=pathlib.Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI');D=pathlib.Path('/private/tmp/rsi-gated-activation-development001');P=B/'research_state/gated-activation-preparation001'
files=['src/models/gated_activation.py','src/models/mlp.py','src/models/blocks.py','src/models/gpt.py','src/train/optimizers.py','src/utils/checkpoint.py','tests/test_gated_activation_contract.py','research/GATED_ACTIVATION_PROTOCOL.md']
assert 'Ran 139 tests' in (P/'contract-first.log').read_text() and (P/'contract-first.log').read_text().rstrip().endswith('OK')
now=datetime.datetime.now(datetime.timezone.utc).isoformat();base='53302eb5ff0674a0babdabce24183dc952436c6a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==base
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
capsule=P/'source-capsule001';capsule.mkdir();mapping={};changes=[];patch=''
for name in files:
 p=D/name;target=capsule/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);target.chmod(0o444);mapping[name]=sha(p)
 if name.endswith('.py'):ast.parse(p.read_text())
 exists=(S/name).is_file();old=(S/name).read_text() if exists else ''
 assert p.read_text()!=old,name
 patch+=f'diff --git a/{name} b/{name}\n'+''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile=f'a/{name}' if exists else '/dev/null',tofile=f'b/{name}'))
 changes.append(dict(path=name,old_sha256=sha(S/name) if exists else None,new_sha256=sha(p)))
patchpath=P/'prototype001.patch';patchpath.write_text(patch)
check=subprocess.run(['git','apply','--check',str(patchpath)],cwd=S,text=True,capture_output=True)
(P/'patch-check001.log').write_text(check.stdout+check.stderr);assert check.returncode==0
with tarfile.open(P/'prototype001.tar.gz','w:gz') as tf:
 for name in files:tf.add(capsule/name,arcname=name)
source_mapping={k:v for k,v in mapping.items() if k.startswith('src/')}
review=dict(status='separate_source_metadata_validated_only',created_at=now,development_root=str(D),base_commit=base,changed_source_mapping_sha256=hashlib.sha256(json.dumps(source_mapping,sort_keys=True).encode()).hexdigest(),digest_scope='Six changed/new production files only, NOT the full engine digest',files=changes,standalone_metadata_tests=139,standalone_seconds=.062,torch_imports_blocked=True,model_tests_executed=False,model_tests_written=False,controller_implemented=False,source_integrated=False,research_registered=False,patch_apply_check_passed=True,reviewed=['Only gate nonlinearity branch changes; default uses same linear_gate then F.silu then linear_up multiplication/down/dropout order. Actual bitwise/RNG proof deferred.','Six-source-file integration: pure contract, MLP, block config propagation, GPT signature, optimizer guard, checkpoint guard.','Same three parameterized matrices/order/shapes; no new learned parameter, buffer or RNG call by inspection; all three existing Muon matrix roles unchanged.','Explicit gelu_exact selects F.gelu approximate=none; ReLU zero derivative requires actual independent test.','Narrow policy requires explicit inherited attention/residual/table/output-bias/readout/input contracts. Existing ffn=swiglu is structural legacy key; authoritative gated_activation_kind is bound to config/model/checkpoint.','Constructed signature plus every block activation/bias-free projections/hidden ratio/product-norm absence checked; same-shaped mismatches and config deletion rejected.','All actual model forward/all-gradient/optimizer/initRNG/cache/resume/H200 and full CPU/MPS/resource gates remain pending; metadata is not empirical quality evidence.'],next_steps=['Implement final-only attention-scale predecessor/controller/independent report auditor and finite prospective protocol','Write independent actual geometry and trainer tests; do not run beside current worker','After attention-scale final complete audit/docs, integrate only reviewed changes, execute full bounded serial CPU and six serial MPS with checkpoint-bound FFN math/resource gates','Clean reviewed source publication/fullbank/freshseed scan/new unique registration; no inherited recipe resolution from partial screening'])
rp=P/'prototype-review001.json';rp.write_text(json.dumps(review,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('kb',S/'src/research/team/knowledge.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);bank=m.KnowledgeBank(B/'research_state/knowledge')
idea=json.loads((P/'preparation-review001.json').read_text())['idea_id']
paths=[rp,patchpath,P/'prototype001.tar.gz',P/'contract-first.log',P/'patch-check001.log']
kid=bank.add(dict(kind='implementation',title='Separate gate-activation prototype with explicit same-shape semantics',summary='Unintegrated SwiGLU/GEGLU/ReGLU prototype changes only the gate nonlinearity inside the existing three-projection container, with narrow inherited contracts and model/optimizer/checkpoint guards. 139 pure metadata cases passed with Torch imports blocked. Actual model/RNG/all-gradient/optimizer/cache/resume/H200 tests, controller and MPS/resource validation remain pending; no research launched.',outcome='untried',created_by='continuing-quality-research',related_ids=[idea],artifacts=[dict(path=str(p),sha256=sha(p)) for p in paths],details=review))
(P/'prototype-knowledge001.json').write_text(json.dumps(dict(implementation_id=kid,review=str(rp)),indent=2)+'\n');(P/'full-knowledge-snapshot002.md').write_text(bank.export_markdown())
for p in paths+[P/'prototype-knowledge001.json',P/'full-knowledge-snapshot002.md']:p.chmod(0o444)
progresspath=B/'research_state/quality-evolution-progress.json';progress=json.loads(progresspath.read_text());progress['next_preparation'].update(status='separate_prototype_metadata_only',development_root=str(D),prototype_review=str(rp),implementation_id=kid,metadata_tests=139);progresspath.write_text(json.dumps(progress,indent=2)+'\n')
print(json.dumps(dict(implementation_id=kid,review=str(rp),changed_source_mapping_sha256=review['changed_source_mapping_sha256'],tests=139)))
