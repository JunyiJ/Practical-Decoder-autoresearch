"""Prospective 42-trajectory worst-case forecast from six real correctness pilots.

This is a resource proxy with fixed margin, never a quality or timing finding.
"""
import math


def forecast(rows, inherited_scale):
    if type(inherited_scale) not in (int,float) or inherited_scale not in (1.,.5,.25):
        raise ValueError('Invalid inherited input scale')
    expected={(w,f) for w in (64,256) for f in ('swiglu','geglu','reglu')}
    if (not isinstance(rows,list) or len(rows)!=6 or
            {(r.get('width'),r.get('family')) for r in rows}!=expected):
        raise ValueError('Exactly six distinct width/gated-activation pilot cells required')
    attention={r.get('attention_family') for r in rows}
    rates={r.get('peak_learning_rate') for r in rows}
    if attention!={'mha'} or rates!={.01}:
        raise ValueError('All pilot cells must use the reviewed MHA backbone and upper-grid peak LR .01')
    if len({r.get('readout_norm_kind') for r in rows})!=1 or len({r.get('output_bias_prior_sha256') for r in rows})!=1 or not all(isinstance(r.get('output_bias_prior_sha256'),str) and len(r['output_bias_prior_sha256'])==64 for r in rows):
        raise ValueError('All pilots must share the reviewed final norm and exact training prior')
    if len({r.get('output_bias_kind') for r in rows})!=1:
        raise ValueError('All pilots must share the final reviewed output bias kind')
    if len({r.get('residual_topology_kind') for r in rows})!=1:raise ValueError('Inherited topology must match across all pilots')
    if len({r.get('weight_tying_kind') for r in rows})!=1:raise ValueError('All pilots must share final reviewed table kind')
    if len({r.get('attention_logit_scale') for r in rows})!=1:raise ValueError('All pilots must share inherited attention scale')
    warmups={r.get('warmup_steps') for r in rows}
    if warmups!={0}:
        raise ValueError('All pilot cells require the zero warmup inherited from the reviewed predecessor')
    proxies=[];seconds=0.;storage=0.
    for row in rows:
        if (row.get('status')!='verified' or row.get('steps')!=40
                or row.get('cooldown_start')!=20 or row.get('snapshots')!=3
                or row.get('input_embedding_scale')!=inherited_scale
                or row.get('weight_tying_kind') not in ('legacy_untied','matched_untied','scaled_tied')
                or row.get('residual_topology_kind') not in ('serial','parallel_separate_norms')
                or row.get('attention_logit_scale') not in (1.,.5,2.)
                or row.get('gated_activation_kind')!={'swiglu':'silu','geglu':'gelu_exact','reglu':'relu'}[row['family']]
                or row.get('gated_activation_width_policy')!='mha4_gated_activation_21_8'
                or row.get('attention_logit_scale_width_policy')!='mha4_fixed_attention_logit_scale'
                or row.get('residual_topology_width_policy')!='mha4_separate_norm_residual_topology'
                or row.get('weight_tying_width_policy')!='mha4_scaled_table_sharing'
                or row.get('output_bias_kind') not in ('none','learned_zero','learned_train_unigram')
                or row.get('output_bias_width_policy')!='mha4_train_bound_output_bias'
                or row.get('readout_norm_kind') not in ('layer_affine','layer_no_bias','rms')
                or row.get('readout_norm_width_policy')!='mha4_readout_norm'
                or row.get('readout_norm_epsilon')!=1e-5
                or row.get('input_width_policy')!='mha4_input_scale'):
            raise ValueError('Pilot budget, warmup, cooldown or H200 contract changed')
        for key in ('training_seconds','wall_seconds','raw_checkpoint_bytes','derived_checkpoint_bytes',
                    'sampled_peak_rss_mb','current_driver_mb'):
            value=row.get(key)
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
                raise ValueError('Pilot resource measurements must be finite positive numbers')
        if (row['training_seconds']>row['wall_seconds'] or row['wall_seconds']>=240
                or row['sampled_peak_rss_mb']>=4096 or row['current_driver_mb']>=6144
                or row.get('driver_allocation_is_not_peak') is not True):
            raise ValueError('Pilot resource limit or memory interpretation failed')
        count=(12 if row['family']=='swiglu' else 9) if row['width']==64 else (6 if row['family']=='swiglu' else 3)
        time=1.5*(row['training_seconds']*75+row['wall_seconds']-row['training_seconds'])
        size=1.5*(row['raw_checkpoint_bytes']+row['derived_checkpoint_bytes']+25*1024**2)
        proxies.append(dict(width=row['width'],family=row['family'],trajectories=count,
            seconds_per_trajectory_with_margin=time,artifact_mb_per_trajectory_with_margin=size/1024**2,
            within_trial_limit=time<2400))
        seconds+=count*time;storage+=count*size
    feasible=seconds<21600 and storage/1024**2<4096 and all(p['within_trial_limit'] for p in proxies)
    return dict(status='feasible' if feasible else 'infeasible',physical_trajectories=42,
        hours=seconds/3600,total_mb_with_margin=storage/1024**2,trial_proxies=proxies,
        method='40-update training time scaled75x plus measured two-output/check overhead;50% time and artifact margins;25MiB metadata allowance per trajectory.',
        measured_research_duration=False)
