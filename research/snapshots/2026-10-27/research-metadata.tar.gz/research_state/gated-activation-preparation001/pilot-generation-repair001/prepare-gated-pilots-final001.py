from pathlib import Path
import shutil,ast
B=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI/research_state')
G=B/'gated-activation-preparation001';A=B/'attention-scale-preparation001/pilot-tools001';D=G/'pilot-tools-draft001';F=G/'pilot-tools001'
assert not F.exists();F.mkdir()
for name in ['attention-capture.py','attention-math-audit.py','table-math-audit.py','pilot-geometry.py','prior-audit.py','branch-capture.py','branch-math-audit.py']:
 shutil.copyfile(D/name,F/name)
shutil.copyfile(D/'pilot-driver-draft001.py',F/'pilot-driver001.py')
shutil.copyfile(G/'branch-math-tools001/test_branch_math.py',F/'test_branch_math.py')
# Same attention math, with the new branch declaration carried by the fixtures.
s=(A/'test_attention_math.py').read_text();(F/'test_attention_math.py').write_text(s)
s=(A/'resource-gate.py').read_text().replace("('baseline','half','double')","('swiglu','geglu','reglu')").replace('width/attention-scale','width/gated-activation').replace("row['family']=='baseline'","row['family']=='swiglu'")
s=s.replace("or row.get('attention_logit_scale')!={'baseline':1.,'half':.5,'double':2.}[row['family']]", "or row.get('attention_logit_scale') not in (1.,.5,2.)\n                or row.get('gated_activation_kind')!={'swiglu':'silu','geglu':'gelu_exact','reglu':'relu'}[row['family']]\n                or row.get('gated_activation_width_policy')!='mha4_gated_activation_21_8'")
s=s.replace("    warmups={", "    if len({r.get('attention_logit_scale') for r in rows})!=1:raise ValueError('All pilots must share inherited attention scale')\n    warmups={")
(F/'resource-gate.py').write_text(s)
s=(A/'review-prerequisites001.py').read_text()
for old,new in [('saved attention-scale','saved gated-activation'),('research_runs/parallel-block-quality-001','research_runs/attention-scale-quality-001'),('reviewed parallel-block','reviewed attention-scale'),('from src.research import attention_scale_study as study','from src.research import gated_activation_study as study'),('==3264','==3607'),('actual_attention_scale_training','actual_gated_activation_training'),('actual_attention_scale_geometry_tests_passed\']==12','actual_gated_activation_geometry_tests_passed\']==13'),('attention_scale_metadata_tests_passed\']==210','gated_activation_metadata_tests_passed\']==318'),('9423','9443'),('ATTENTION_SCALE_PROTOCOL','GATED_ACTIVATION_PROTOCOL'),("study.SCALES[f]","p['recipe']['attention_logit_scale']"),("f=='baseline'","f=='swiglu'"),('Attention-scale resource','Gated-activation resource'),('Full3264 collected CPU suite,210 metadata cases,12 geometry','Full3607 collected CPU suite,318 metadata cases,13 geometry'),('baseline/half/double','SwiGLU/GEGLU/ReGLU'),('RMS normalizer/SwiGLU forward','RMS normalizer and exact declared SiLU/erf-GELU/ReLU forward'),('Final reviewed parallel-block decision resolves residual','Final reviewed attention-scale decision resolves attention scale/residual')]:
 assert old in s,old;s=s.replace(old,new)
s=s.replace('from src.utils.checkpoint import read_checkpoint,load_model_weights', 'from src.models.gated_activation import validate_gated_activation_model,POLICY as GATE_POLICY\nfrom src.utils.checkpoint import read_checkpoint,load_model_weights')
s=s.replace("  attention_guard=b", "  gated_guard=b'    from ..models.gated_activation import validate_gated_activation_load\\n    validate_gated_activation_load(model, checkpoint)\\n'\n  assert current.count(gated_guard)==1;current=current.replace(gated_guard,b'',1)\n  attention_guard=b")
s=s.replace("source/'src/models/attention_scale.py',", "source/'src/models/attention_scale.py',source/'src/models/gated_activation.py',")
needle=" cfg.model.attention_logit_scale=p['recipe']['attention_logit_scale']\n"
assert s.count(needle)==1
s=s.replace(needle,needle+" validate_gated_activation_model(model)\n assert model.gated_activation_signature==(study.ACTIVATIONS[f],GATE_POLICY)\n assert cfg.model.gated_activation_kind==row['gated_activation_kind']==study.ACTIVATIONS[f]\n assert cfg.model.gated_activation_width_policy==row['gated_activation_width_policy']==GATE_POLICY\n assert all(b.mlp.gate_activation==study.ACTIVATIONS[f] for b in model.transformer.h)\n cfg.model.gated_activation_kind='relu' if study.ACTIVATIONS[f]!='relu' else 'silu'\n try:load_model_weights(model,cp)\n except ValueError:pass\n else:raise AssertionError('Changed same-shaped gated activation accepted')\n cfg.model.gated_activation_kind=study.ACTIVATIONS[f]\n")
s=s.replace("binding=branch_audit.bind_checkpoint(branch,state_arrays,item['checkpoint_sha256'],topology,w)","binding=branch_audit.bind_checkpoint(branch,state_arrays,item['checkpoint_sha256'],topology,w,study.ACTIVATIONS[f])")
s=s.replace("folder/'test_attention_math.py',", "folder/'test_attention_math.py',folder/'test_branch_math.py',folder/'test_resource_and_binding.py',folder/'test_guard_contracts.py',")
(F/'review-prerequisites001.py').write_text(s)
s=(A/'test_resource_and_binding.py').read_text()
s=s.replace("('baseline','half','double')","('swiglu','geglu','reglu')").replace("attention_logit_scale={'baseline':1.,'half':.5,'double':2.}[f]","gated_activation_kind={'swiglu':'silu','geglu':'gelu_exact','reglu':'relu'}[f],gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale=.5")
s=s.replace("changes={'attention_logit_scale':3.,", "changes={'gated_activation_kind':'wrong','gated_activation_width_policy':'wrong','attention_logit_scale':3.,")
s=s.replace("p=dict(kind=kind,", "p=dict(gated_activation_kind='silu',kind=kind,")
s=s.replace("state,'a'*64,kind,width)","state,'a'*64,kind,width,'silu')")
(F/'test_resource_and_binding.py').write_text(s)
for f in F.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
print(F)
