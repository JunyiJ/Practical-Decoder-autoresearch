"""Synthetic metadata fixtures only: no models, real checkpoint bytes or scoring."""
import ast,copy,hashlib,importlib.abc,importlib.util,json,sys,tempfile,unittest
from pathlib import Path
from statistics import mean
class NoModels(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('torch','src'):raise RuntimeError('Model imports prohibited')
sys.meta_path.insert(0,NoModels())
folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('screen_audit',folder/'audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI')
oldplan=json.loads((base/'research_runs/embedding-scale-quality-001/plan.json').read_text())
oldstate=json.loads((base/'research_runs/embedding-scale-quality-001/state.json').read_text())
oldrow=oldstate['records'][0]
oldreq=json.loads((base/'research_runs/embedding-scale-quality-001/trials'/oldrow['trial_id']/'request.json').read_text())
oldraw=json.loads((base/'research_runs/embedding-scale-quality-001/trials'/oldrow['trial_id']/'result.json').read_text())
# Execute only pure selection functions from the frozen source; full source validation
# and tensor integration are exercised by the separate serial project CPU suite.
tree=ast.parse((source/'src/research/gated_activation_study.py').read_text())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('local_jobs','confirmation_manifest','freeze_selection')]
ns=dict(FAMILIES=a.FAMILIES,LRS=a.RATES,SCREEN_SEEDS=a.SCREENS,CONFIRM_SEEDS=a.CONFIRM,WIDTHS=[64,256],REFERENCE=a.REFERENCE,mean=mean,digest=a.digest,endpoint=lambda p,r:a.endpoint(r),validate_plan=lambda p:p,validate_rows=lambda *x:None)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pure-selection-extract>','exec'),ns)
def plan(lr=.005,scale=1.,norm='layer_affine'):
 p=copy.deepcopy(oldplan)
 p.update(families=a.FAMILIES,learning_rates=a.RATES,seeds=a.SCREENS,confirmation_seeds=a.CONFIRM,widths=[64,256],gated_activations=a.ACTIVATIONS,gated_activation_policy='mha4_gated_activation_21_8',prior_pseudocount=1,recipe=dict(warmup_steps=0,learning_rate=lr,weight_decay=.00006,input_embedding_scale=scale,readout_norm_kind=norm,readout_norm_epsilon=1e-5,output_bias_kind='none',weight_tying_kind='legacy_untied',residual_topology_kind='serial',attention_logit_scale=.5),output_bias_prior={'fixture':'synthetic metadata placeholder; prior arithmetic separately tested'})
 p['config']['model'].update(input_width_policy='mha4_input_scale',input_embedding_scale=scale)
 p['config']['training']['learning_rate']=lr
 p['screen_jobs']=[[f,r,64,s] for r in a.RATES for i,s in enumerate(a.SCREENS) for f in (a.FAMILIES if i==0 else a.FAMILIES[::-1])]
 return p
def panel(p,best,alias):
 incumbent=p['recipe']['learning_rate'];other=next(x for x in a.RATES if x!=incumbent)
 selected=dict(swiglu=incumbent if alias else other,geglu=.01,reglu=.005)
 levels=dict(swiglu=1.3,geglu=1.4,reglu=1.4);levels[best]=1.2
 rows=[]
 for f,lr,w,s in p['screen_jobs']:
  value=levels[f] if lr==selected[f] else 1.6
  rows.append(dict(family=f,lr=lr,width=w,seed=s,stage='local',status='completed',averaged_outputs={'200':{'coverage':{'evaluations':{'128':{'mean_ce':value}}}}}))
 return rows,selected

def fake_worker(p,f,run):
 # Historical JSON supplies schema, not measurements: coverage, losses and checkpoint
 # bytes below are replaced with explicitly synthetic values, only in a temp directory.
 row=copy.deepcopy(oldrow);raw=copy.deepcopy(oldraw);d=run/'trials'/f;d.mkdir(parents=True)
 row.update(family=f,lr=.005,width=64,n_heads=2,seed=2421,trial_id=f,stage='local',status='completed',tokens_processed=3072000)
 cfg=copy.deepcopy(p['config']);m,t=cfg['model'],cfg['training'];threads=t.pop('cpu_threads')
 m.update(dim=64,n_heads=2,vocab_size=1,input_width_policy='mha4_input_scale',input_embedding_scale=p['recipe']['input_embedding_scale'],readout_norm_kind=p['recipe']['readout_norm_kind'],readout_norm_width_policy='mha4_readout_norm',readout_norm_epsilon=1e-5,weight_tying_kind=p['recipe']['weight_tying_kind'],residual_topology_kind=p['recipe']['residual_topology_kind'],residual_topology_width_policy='mha4_separate_norm_residual_topology',attention_logit_scale=p['recipe']['attention_logit_scale'],gated_activation_kind=a.ACTIVATIONS[f],gated_activation_width_policy='mha4_gated_activation_21_8',attention_logit_scale_width_policy='mha4_fixed_attention_logit_scale',weight_tying_width_policy='mha4_scaled_table_sharing',output_bias_kind=p['recipe']['output_bias_kind'],output_bias_width_policy='mha4_train_bound_output_bias',output_bias_prior=p['output_bias_prior'])
 t.update(learning_rate=.005,seed=2421,eval_seed=2026,strict_device=True,checkpoint_dir=str(d/'checkpoints'),checkpoint_every=0,keep_best_checkpoint=False,resume_from=None,max_train_seconds=None,metrics_file=str(d/'metrics.jsonl'),summary_file=str(d/'training_summary.json'))
 req=dict(stage='local',config=cfg,cpu_threads=threads,result_path=str(d/'result.json'))
 rawcp=d/'synthetic-raw.bin';derived=d/'synthetic-derived.bin';rawcp.write_bytes(b'SYNTHETIC NOT A CHECKPOINT');derived.write_bytes(b'SYNTHETIC DERIVED NOT A CHECKPOINT')
 row.update(checkpoint=str(rawcp),checkpoint_sha256=a.sha(rawcp),metric=1.5,raw_metric=1.6)
 raw['final_checkpoint']=str(rawcp)
 e=dict(context=128,eval_batch_size=8,block_tokens=2048,target_count=111538,window_count=872,block_target_counts=[2048]*54+[946],block_loss_sums=[1.6*x for x in [2048]*54+[946]],mean_ce=1.6)
 raw['coverage']['evaluations']={'128':e};row['coverage']=copy.deepcopy(raw['coverage']['evaluations'])
 avg=raw['averaged_outputs']['200'];avg.update(checkpoint=str(derived),checkpoint_sha256=a.sha(derived),parent_checkpoint=dict(path=str(rawcp),sha256=a.sha(rawcp)))
 avg['coverage'].update(checkpoint_sha256=a.sha(derived),parent_checkpoint_sha256=a.sha(rawcp),holdout_consumed=False)
 e=copy.deepcopy(e);e.update(mean_ce=1.5,block_loss_sums=[1.5*x for x in [2048]*54+[946]])
 avg['coverage']['evaluations']={'128':e};row['averaged_outputs']=copy.deepcopy(raw['averaged_outputs'])
 for name,obj in [('request',req),('result',raw)]:
  path=d/f'{name}.json';path.write_text(json.dumps(obj));row[name+'_sha256']=a.sha(path)
 return row

class TestMetadata(unittest.TestCase):
 def test_all_inherited_recipe_winner_alias_routes_match_pure_controller(self):
  for lr in a.RATES:
   for scale in (1.,.5,.25):
    for best in a.FAMILIES:
     for alias in (False,True):
      with self.subTest(lr=lr,scale=scale,best=best,alias=alias):
       p=plan(lr,scale);p['recipe'].update(weight_tying_kind=('legacy_untied','matched_untied','scaled_tied')[a.RATES.index(lr)],residual_topology_kind='serial' if alias else 'parallel_separate_norms');rows,selected=panel(p,best,alias);v=a.reconstruct(p,rows)
       self.assertEqual(v,ns['freeze_selection'](p,rows))
       self.assertEqual(v['winner'],'incumbent_unchanged' if best=='swiglu' and alias else best)
       self.assertEqual(v['confirmation']['total_distinct_trials'],36 if alias else 42)
       self.assertEqual({c[3] for c in v['confirmation']['jobs']},set(a.CONFIRM))
 def test_ties_choose_lower_lr_then_affine(self):
  p=plan();rows,_=panel(p,'reglu',True)
  for r in rows:a.endpoint(r)['mean_ce']=1.3
  v=a.reconstruct(p,rows);self.assertEqual(v,ns['freeze_selection'](p,rows));self.assertEqual(v['winner'],'incumbent_unchanged');self.assertTrue(all(x['lr']==.0025 for x in v['choices'].values()))
 def test_bad_seed_veto(self):
  p=plan();rows,_=panel(p,'geglu',True)
  for r in rows:
   if r['family']=='geglu' and r['lr']==.01:a.endpoint(r)['mean_ce']=1.28 if r['seed']==2421 else 1.305
  v=a.reconstruct(p,rows);self.assertEqual(v['best_selected_arm'],'geglu');self.assertFalse(v['candidate_eligible']);self.assertEqual(v,ns['freeze_selection'](p,rows))
 def test_invalid_panels(self):
  for damage in ('missing','duplicate','seed','order','kind','epsilon','policy','scale','warmup','inherited_bias','inherited_table','inherited_topology','inherited_attention'):
   with self.subTest(damage=damage):
    p=plan();rows,_=panel(p,'reglu',True)
    if damage=='missing':rows.pop()
    elif damage=='duplicate':rows[-1]=copy.deepcopy(rows[0])
    elif damage=='seed':rows[0]['seed']=2431
    elif damage=='order':rows[0],rows[1]=rows[1],rows[0]
    elif damage=='kind':p['gated_activations']={'reglu':'relu'}
    elif damage=='epsilon':p['recipe']['readout_norm_epsilon']=1e-6
    elif damage=='policy':p['gated_activation_policy']='wrong'
    elif damage=='scale':p['recipe']['input_embedding_scale']=2.
    elif damage=='warmup':p['recipe']['warmup_steps']=100
    elif damage=='inherited_bias':p['recipe']['output_bias_kind']='wrong'
    elif damage=='inherited_table':p['recipe']['weight_tying_kind']='wrong'
    elif damage=='inherited_topology':p['recipe']['residual_topology_kind']='wrong'
    elif damage=='inherited_attention':p['recipe']['attention_logit_scale']=3.
    with self.assertRaises(AssertionError):a.reconstruct(p,rows)
 def test_synthetic_worker_schema_and_mutations(self):
  for f in a.FAMILIES:
   with tempfile.TemporaryDirectory(prefix='output-bias-synthetic-schema-') as tmp:
    p=plan();run=Path(tmp);row=fake_worker(p,f,run);a.check_row(p,row,run)
    for damage in ('family','lr','seed','metric','hash','steps','epsilon','kind'):
     with self.subTest(family=f,damage=damage):
      r=copy.deepcopy(row)
      if damage=='family':r['family']=next(k for k in a.FAMILIES if k!=f)
      elif damage=='lr':r['lr']=.01
      elif damage=='seed':r['seed']=2422
      elif damage=='metric':r['metric']+=.01
      elif damage=='hash':r['checkpoint_sha256']='0'*64
      elif damage=='steps':r['tokens_processed']=1
      else:
       path=run/'trials'/f/'request.json';original=path.read_text();req=json.loads(original)
       req['config']['model']['readout_norm_epsilon' if damage=='epsilon' else 'readout_norm_kind']=1e-6 if damage=='epsilon' else 'wrong'
       path.write_text(json.dumps(req));r['request_sha256']=a.sha(path)
      try:
       with self.assertRaises(AssertionError):a.check_row(p,r,run)
      finally:
       if damage in ('epsilon','kind'):path.write_text(original)
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TestMetadata))
 assert 'torch' not in sys.modules
 print('Synthetic metadata only. No model import, checkpoint tensor load, scoring or real evidence mutation.')
 raise SystemExit(not result.wasSuccessful())
