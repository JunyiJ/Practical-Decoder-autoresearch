"""Plot final reviewed decay-quality quality and cost evidence; no training/scoring."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
con=json.loads((root/'research_state/decay-quality-conclusion.json').read_text());review=json.loads(Path(con['review']).read_text())
assert review['status']=='verified' and review['distinct_trajectories'] in (36,42) and review['distinct_checkpoints']==2*review['distinct_trajectories']
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,3,figsize=(15,5.4),gridspec_kw={'width_ratios':[1.3,1.3,1]})
pairs=[('weak','anchor'),('strong','anchor'),('strong','weak')]
labels=['Weak − anchor','Strong − anchor','Strong − weak'];values=[]
for ax,w in zip(axes[:2],(64,256)):
 for i,(a,b) in enumerate(pairs):
  c=next(x for x in con['comparisons'] if x['width']==w and x['candidate']==a and x['reference']==b);v=c['sensitivity'][1]
  ds=[v['paired_seed_deltas'][str(s)] for s in (2251,2252,2253)];lo,hi=v['conditional_text_bootstrap_95pct'];values.extend(ds+[lo,hi])
  color=['#087d87','#b67131','#75609e'][i]
  ax.scatter(ds,np.array([i]*3)+[-.11,0,.11],s=32,color=color,zorder=3)
  ax.plot([lo,hi],[i,i],color=color,linewidth=2,alpha=.75);ax.scatter(v['mean_delta'],i,marker='D',color=color,s=68,edgecolor='white',zorder=4)
 ax.axvline(0,color='#555',linewidth=.8);ax.axvline(-.005,color='#888',linewidth=.8,linestyle=':')
 ax.set_yticks(range(3),labels);ax.set_ylim(2.55,-.55);ax.set_title(f'Width {w} · H200 quality');ax.set_xlabel('Paired validation CE difference');ax.grid(axis='x',alpha=.15)
lo=min(values+[0]);hi=max(values+[0]);margin=max(.003,(hi-lo)*.08)
for ax in axes[:2]:ax.set_xlim(lo-margin,hi+margin);ax.locator_params(axis='x',nbins=4)
ax=axes[2];families=['weak','strong'];y=np.arange(2)
for offset,w,color in [(-.17,'64','#087d87'),(.17,'256','#c18c31')]:
 vals=[con['cost'][f][w]['training_time_ratio_vs_anchor'] for f in families]
 ax.barh(y+offset,vals,height=.29,label=f'Width {w}',color=color)
 for i,val in enumerate(vals):ax.text(val+.025,i+offset,f'{val:.2f}×',va='center',fontsize=10)
ax.set_yticks(y,['Weak','Strong']);ax.invert_yaxis();ax.axvline(1,color='#555',linewidth=.8)
ax.set_xlim(0,max(con['cost'][f][w]['training_time_ratio_vs_anchor'] for f in families for w in ('64','256'))*1.25)
ax.set_xlabel('Training time / control');ax.set_title('Measured training cost');ax.legend(frameon=False,fontsize=9);ax.grid(axis='x',alpha=.15)
fig.suptitle('Independent decay — paired quality and cost',fontsize=15)
decision = 'Frozen candidate passes the adoption rule.' if con['quality_decision']['qualifies_for_incumbent_replacement'] else 'Frozen adoption rule fails; retain incumbent.'
fig.text(.025,.035,'Dots = paired seeds; diamonds = means; lines = 4,096-token conditional text intervals. Dotted line = mean-gain threshold.\n'+decision+' Equal updates/tokens; different decay and selected LR; adaptive validation, no holdout.',fontsize=9,color='#555')
fig.tight_layout(rect=[0,.14,1,.93]);out=root/'research_state/reports/pretraining-learning-guide/decay-quality001.png';fig.savefig(out,dpi=180);print(out)
