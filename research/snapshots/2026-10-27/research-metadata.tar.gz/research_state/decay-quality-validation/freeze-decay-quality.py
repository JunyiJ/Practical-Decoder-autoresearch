"""Register exactly one new independent-decay round after actual source/test/pilot gates."""
import argparse,datetime,json,os,re,subprocess
from pathlib import Path
from src.research import decay_quality_study as study
from src.research.protocol import file_digest,digest
from src.research.team.knowledge import KnowledgeBank

parser=argparse.ArgumentParser();parser.add_argument('--register',action='store_true');args=parser.parse_args()
if not args.register:parser.error('Explicit --register required')

base=Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI');source=Path.cwd().resolve()
run=base/'research_runs/decay-quality-001';folder=base/'research_state/decay-quality-validation';prior=base/'research_runs/ffn-hidden-norm-quality-001'
assert source==Path('/Users/junyi/.codex/worktrees/rope-position-fix/LLM-pretraining-RSI') and not run.exists()
assert 'PYTORCH_ENABLE_MPS_FALLBACK' not in os.environ
active=json.loads((base/'research_state/active-campaign.json').read_text())
assert active['campaign']==str(prior) and active['status']=='completed_reviewed' and not active.get('human_stopped')
assert json.loads((prior/'state.json').read_text())['status']=='completed'
lines=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()
assert not [x for x in lines if re.search(r'src\.research\.(?:worker|moe_study|schedule_study|capacity_study|averaging_study|horizon_study|qknorm_study|output_gate_study|ffn_hidden_norm_study|decay_quality_study|context_interaction|context256_study|batch_study)|src\.train\.train|python.*-m pytest',x)]
p=study.make_plan(source,prior/'review.json');assert p['returned_half_life']==200
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
remote_main = subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],text=True).split()[0]
# A later human merge must not silently enter an already tested study.
subprocess.check_call(['git','merge-base','--is-ancestor',p['git_commit'],remote_main])
p['publication_lineage'] = dict(tested_commit=p['git_commit'], observed_remote_main=remote_main,
    tested_commit_is_remote_ancestor=True, later_remote_changes_excluded=True)
review=folder/'review.json';v=json.loads(review.read_text());tests=v['tests']['full_tests']
assert v['status']=='verified' and v['source_sha256']==p['source_sha256'] and v['source_commit']==p['git_commit']
assert v['recipe']==p['recipe'] and v['returned_half_life']==200 and v['predecessor_review']==p['predecessor_review']
assert tests['passed']==tests['collected']>=1608 and tests['failed']==0 and v['tests']['actual_decay_training_tests_passed']==6 and v['tests']['actual_decay_algebra_tests_passed']==7
assert len(v['pilot_audit'])==6 and {(x['width'],x['family']) for x in v['pilot_audit']}=={(w,f) for w in (64,256) for f in study.FAMILIES}
for a in v['artifacts']:assert file_digest(Path(a['path']))==a['sha256']
assert v['resource_proxy']['hours']<6 and v['resource_proxy']['total_mb_with_margin']<4096
assert all(x['seconds_per_trajectory_with_margin']<2400 for x in v['resource_proxy']['trial_proxies'])
new=set(study.SCREEN_SEEDS+study.CONFIRM_SEEDS)
def seeds(value,key=''):
 out=set()
 if 'seed' in key:
  if type(value) is int:out.add(value)
  elif isinstance(value,list):out.update(x for x in value if type(x) is int)
 if isinstance(value,dict):
  for k,v in value.items():out|=seeds(v,k)
 elif isinstance(value,list):
  for v in value:out|=seeds(v,key)
 return out
for path in (base/'research_runs').glob('*/plan.json'):assert not new&seeds(json.loads(path.read_text())),str(path)
protocol=source/'research/DECAY_QUALITY_PROTOCOL.md';con=json.loads((base/'research_state/ffn-hidden-norm-conclusion.json').read_text());bank=KnowledgeBank(base/'research_state/knowledge')
incumbent_path=base/'research_state/decay-quality-incumbent.json';assert not incumbent_path.exists()
incumbent_path.write_bytes((base/'research_state/best-observed-config.json').read_bytes());incumbent_path.chmod(0o444)
incumbent=json.loads(incumbent_path.read_text());p['incumbent_snapshot']=dict(path=str(incumbent_path),sha256=file_digest(incumbent_path),result_id=incumbent['result_id'])
preparation=json.loads((folder/'handoff-knowledge-id.json').read_text())
idea=json.loads((folder/'knowledge-id.json').read_text())
implementation=bank.add(dict(kind='implementation',outcome='supported',created_by='continuing-quality-research',title='Independent-decay comparison with source-matched optimizer, resume and H200 checks',
 summary=f"The complete {tests['passed']}-case source-matched CPU suite and six serial MPS shortened pilots passed. Independent update-order/shrinkage and absent-gradient algebra, actual optimizer/resume/H200 contracts, common model full/cached logits and norm checks, private RNG, coverage and bounded resource estimates were checked. Correctness pilots are excluded from quality findings.",
 scope=dict(source_commit=p['git_commit'],holdout_consumed=False),details=v,artifacts=[dict(path=str(review),sha256=file_digest(review))],related_ids=[con['result_id'],idea['idea_id'],preparation['implementation_preparation_id']]))
prereg=bank.add(dict(kind='prediction',outcome='untried',created_by='continuing-quality-research',title='Preregistered independent-decay quality001: finite coefficient comparison on the evolved recipe',summary=protocol.read_text(),
 scope=dict(source_commit=p['git_commit'],recipe=p['recipe'],returned_half_life=200,holdout_consumed=False),
 details=dict(prediction='The earlier independent-decay anchor may interact with the evolved four-layer cooldown/H200 recipe. Weak2e-5 and strong18e-5 bracket anchor6e-5 by a factor of three. No quantitative gain, overfitting diagnosis, final-norm prediction or optimal-decay claim is assumed.',
 selection='18 width64 screens on2241/2242 choose three family LRs. Freeze best selected arm with ties anchor/weak/strong. Require mean gain>.005 and every seed better versus fixed incumbent and tuned anchor for nonanchor; otherwise retention, no alternate fallback. Fresh2251/2252/2253 confirmation64/256; only eligible frozen winner and all conditional text upper bounds<0 can qualify.',
 limits={k:p[k] for k in ('max_trials','trial_seconds','session_seconds','max_disk_mb','max_process_rss_mb','max_mps_driver_mb')},
 lineage='Final completed FFN-hidden-norm review resolves the common attention/norm/LR; independent per-update coefficient changes across three arms, with zero inner decay. Equal3000updates/3072000targets with cooldown start2000/H200. 36or42physical and72or84correlated raw/H200 outputs. Six fixed references alias selectedanchor only on exact config/LR match. No old trial continuation, grid extension or larger-width reselection; permanent stop006 retained.'),
 artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in (protocol,review,prior/'review.json')],related_ids=[implementation,con['result_id'],idea['idea_id']]))
snapshot=base/'research_state/decay-quality-knowledge-snapshot.md';assert not snapshot.exists();snapshot.write_text(bank.export_markdown());snapshot.chmod(0o444)
artifacts=[folder/'publication-lineage-repair.json',folder/'freeze-decay-quality-before-remote-advance.txt',incumbent_path,protocol,review,folder/'review-prerequisites.py',folder/'freeze-decay-quality.py',folder/'launch-decay-quality.py',base/'research_state/quality-evolution-intent.json',base/'research_state/stage1-conclusion.json',base/'research_state/ffn-hidden-norm-conclusion.json',base/'research_state/ffn-hidden-norm-completed-knowledge-snapshot.md']+[prior/f for f in ('plan.json','report.json','review.json','selection.json')]
p.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=dict(path=str(snapshot),sha256=file_digest(snapshot)),artifacts=[dict(path=str(x),sha256=file_digest(x)) for x in artifacts],research_root=str(base),predecessor=str(prior),human_edit_policy='Primary kimi/KDA untouched; isolated reviewed source; all old studies closed.')
study.verify_lineage(p);run.mkdir();serialized=json.dumps(p,indent=2,sort_keys=True)+'\n'
for path in (run/'plan.json',base/'research_state/decay-quality-plan.json'):path.write_text(serialized);path.chmod(0o444)
lineage=dict(source_commit=p['git_commit'],source_root=str(source),plan_sha256=digest(p),preregistration_id=prereg,implementation_id=implementation,knowledge_snapshot=p['knowledge_snapshot'],predecessor_review=p['predecessor_review'],recipe=p['recipe'],maximum_physical_trajectories=42,maximum_correlated_model_outputs=84,returned_half_life=200,completed_study_reruns=0)
(run/'lineage.json').write_text(json.dumps(lineage,indent=2)+'\n');print(json.dumps(lineage,indent=2))
