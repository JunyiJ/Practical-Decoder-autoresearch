"""Synthetic metadata only: final promotion guard positive/negative/adversarial cases."""
import copy, importlib.util, json
from pathlib import Path
folder=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('decay_recorder',folder/'record-completion.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def report():
 local=[dict(reference=ref,paired_seed_deltas={'2241':-.01,'2242':-.01},mean_delta=-.01,supported=True) for ref in ('incumbent_reference','anchor')]
 comparisons=[]
 for w in (64,256):
  for ref in ('incumbent_reference','anchor'):
   intervals=[dict(text_block_tokens=n,mean_delta=-.01,paired_seed_deltas={str(k):-.01 for k in (2251,2252,2253)},conditional_text_bootstrap_95pct=[-.015,-.005]) for n in (2048,4096,8192)]
   comparisons.append(dict(candidate='weak',reference=ref,width=w,sensitivity=intervals,quality_improvement=True))
 return dict(selection=dict(choices={f:dict(mean_ce=x) for f,x in [('anchor',1.5),('weak',1.49),('strong',1.51)]},winner='weak',best_selected_arm='weak',candidate_eligible=True,local_contrasts=local),comparisons=comparisons,quality_decision=dict(frozen_screen_winner='weak',qualifies_for_incumbent_replacement=True))
checks=[]
r=report();r['selection']['choices']['anchor']['mean_ce']=1.48;r['selection'].update(winner='anchor',best_selected_arm='anchor');r['selection']['local_contrasts']=r['selection']['local_contrasts'][:1]
r['comparisons']=[{**c,'candidate':'anchor'} for c in r['comparisons'] if c['reference']=='incumbent_reference'];r['quality_decision']['frozen_screen_winner']='anchor'
assert m.verified_decision(r)==('anchor',True);checks.append('Anchor decay with a frozen improved LR uses only fixed-reference contrasts')
r=report();r['selection']['choices']['strong']['mean_ce']=1.48;r['selection'].update(winner='strong',best_selected_arm='strong');r['comparisons']=[{**c,'candidate':'strong'} for c in r['comparisons']];r['quality_decision']['frozen_screen_winner']='strong'
assert m.verified_decision(r)==('strong',True);checks.append('Strong-decay winner follows the same complete two-reference adoption rule')
r=report();assert m.verified_decision(r)==('weak',True);checks.append('Supported frozen winner accepts all required comparisons')
r=report();r['comparisons'][-1]['sensitivity'][-1]['conditional_text_bootstrap_95pct'][1]=.0001;r['comparisons'][-1]['quality_improvement']=False;r['quality_decision']['qualifies_for_incumbent_replacement']=False
assert m.verified_decision(r)==('weak',False);checks.append('A single largest-block interval vetoes adoption')
r=report()
for c in r['selection']['local_contrasts']:c.update(paired_seed_deltas={'2241':-.011,'2242':.001},mean_delta=-.005,supported=False)
r['selection'].update(winner='incumbent_unchanged',candidate_eligible=False);r['quality_decision']=dict(frozen_screen_winner='incumbent_unchanged',qualifies_for_incumbent_replacement=False)
assert m.verified_decision(r)==('incumbent_unchanged',False);checks.append('Failed local best retains incumbent despite passing confirmation metadata')
def rejects(label, mutate):
 r=report();mutate(r)
 try:m.verified_decision(r)
 except (AssertionError,ValueError,KeyError):checks.append(label)
 else:raise AssertionError(label)
rejects('Reject false local supported flag',lambda r:r['selection']['local_contrasts'][0].update(paired_seed_deltas={'2241':-.03,'2242':.01},mean_delta=-.01))
rejects('Reject fallback to another arm',lambda r:r['selection'].update(winner='strong'))
rejects('Reject incorrect best-arm mean ordering',lambda r:r['selection']['choices']['strong'].update(mean_ce=1.48))
rejects('Reject missing width comparison',lambda r:r['comparisons'].pop())
rejects('Reject duplicate comparison',lambda r:r['comparisons'].append(copy.deepcopy(r['comparisons'][0])))
rejects('Reject changed confirmation seed set',lambda r:r['comparisons'][0]['sensitivity'][0]['paired_seed_deltas'].update({'9999':-.01}))
rejects('Reject false all-seed gain',lambda r:r['comparisons'][0]['sensitivity'][0]['paired_seed_deltas'].update({'2253':.001}))
rejects('Reject false interval support',lambda r:r['comparisons'][0]['sensitivity'][2].update(conditional_text_bootstrap_95pct=[-.01,.001]))
rejects('Reject false promotion flag',lambda r:r['quality_decision'].update(qualifies_for_incumbent_replacement=False))
print(json.dumps(dict(status='synthetic_metadata_checks_passed',checks=checks,quality_measurement=False,model_work=False,limitations=['No real decay result exists; this checks the recorder decision guard only.']),indent=2))
