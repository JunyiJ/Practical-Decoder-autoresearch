"""Record source-matched partitioned CPU gates only after actual execution."""
import argparse
import datetime
import json
import re
from pathlib import Path

from src.research.protocol import file_digest
from src.research.team.suite import source_digest

parser = argparse.ArgumentParser()
parser.add_argument('--actual', type=Path, required=True)
parser.add_argument('--remaining', type=Path, required=True)
parser.add_argument('--collection', type=Path, required=True)
args = parser.parse_args()
base = Path('/Users/junyi/Documents/ChatGPT/LLM-pretraining-RSI')
source = Path.cwd()
folder = base/'research_state/decay-quality-validation'
prior = json.loads((base/'research_runs/ffn-hidden-norm-quality-001/review.json').read_text())
assert prior['status'] == 'verified' and prior['distinct_trajectories'] in (36,42)
review_path = folder/'separate-source-review.json'
review = json.loads(review_path.read_text())
assert review['source_sha256'] == source_digest(source)
for artifact in review['artifacts']:
    path = Path(artifact['path'])
    relative = path.relative_to('/private/tmp/rsi-decay-quality-development')
    assert file_digest(source/relative) == artifact['sha256']


def passed(path):
    text = path.read_text()
    match = re.search(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s', text)
    assert match and not re.search(r'\b(?:FAILED|ERROR|failed|error|skipped|xfailed|xpassed)\b', text), str(path)
    return int(match[1]), float(match[3]), int(match[2] or 0)


actual, actual_seconds, actual_warnings = passed(args.actual)
remaining, remaining_seconds, remaining_warnings = passed(args.remaining)
assert actual == 13
collection = args.collection.read_text()
match = re.search(r'(\d+) tests collected', collection)
assert match and int(match[1]) == actual + remaining and actual + remaining >= 1608
actual_names = {line.strip() for line in collection.splitlines()
                if line.startswith(('tests/test_decay_quality_training.py::',
                                    'tests/test_decay_quality_algebra.py::'))}
assert len(actual_names) == 13
assert sum(name.startswith('tests/test_decay_quality_training.py::') for name in actual_names) == 6
assert sum(name.startswith('tests/test_decay_quality_algebra.py::') for name in actual_names) == 7
# Run the actual partition with -v so the executed cases are independently
# bound to the full collected manifest, rather than trusting only a count.
actual_text = args.actual.read_text()
executed = {line.split(' PASSED',1)[0].strip() for line in actual_text.splitlines()
            if line.startswith('tests/test_decay_quality_') and ' PASSED' in line}
assert executed == actual_names
files = [args.actual,args.remaining,args.collection,review_path,Path(__file__)]
files += [source/relative for relative in review['changed_files']]
result = dict(status='cpu_verified', reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_sha256=source_digest(source), base_commit=review['base_commit'],
    actual_decay_training_tests_passed=6, actual_decay_algebra_tests_passed=7,
    full_tests=dict(passed=actual+remaining,collected=int(match[1]),failed=0,
        warnings=actual_warnings+remaining_warnings,remaining_tests=remaining,
        partition='13 named decay optimizer/trainer cases and remaining project cases; no duplicate count',
        actual_seconds=actual_seconds,remaining_seconds=remaining_seconds,total_seconds=actual_seconds+remaining_seconds),
    checks=['All three coefficients at widths64/256: actual optimizer roles/zero child decay, strict finite states, CPU online/H200 noninterference, continuation before/at boundary, exact private RNG and changed-decay resume rejection',
        'Actual no-update nominal shrinkage for all parameter roles, absent-gradient exclusion, independently calculated update ordering and post-resume LR scheduling',
        'Trainer cases distribute none/RMS/LayerNorm across coefficients; serial pilots must cover all coefficients on the final-reviewed common norm',
        'Full source-matched collected project suite passed'],
    limitations=['CPU correctness is not model-quality evidence or an MPS measurement','Six serial MPS pilots and full prerequisite/resource audit still required'],
    artifacts=[dict(path=str(path.resolve()),sha256=file_digest(path)) for path in files])
destination = folder/'cpu-review.json'
assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['full_tests']))
